# Deployment Guide - Alazie Express Platform

## Firebase Hosting Deployment

### Prerequisites
- Firebase CLI installed: `npm install -g firebase-tools`
- Firebase project configured: `studio-2300569924-8a121`
- Domain configured: `alazie.express`

### DNS Configuration
Add these records to your DNS provider for `alazie.express`:

```
Record Type: A
Domain: alazie.express
Value: 199.36.158.100

Record Type: TXT
Domain: alazie.express
Value: hosting-site=studio-2300569924-8a121-6b097
```

### Deployment Steps

#### 1. Build the Application
```bash
npm run build
```

#### 2. Deploy to Firebase Hosting
```bash
# Deploy to production
firebase deploy --only hosting

# Or use the deployment script
chmod +x deploy-firebase.sh
./deploy-firebase.sh
```

#### 3. Deploy to Preview Channel (Optional)
```bash
firebase hosting:channel:deploy CHANNEL_ID
```

### Production URLs
After deployment, your site will be available at:
- **Custom Domain**: https://alazie.express
- **Firebase URL 1**: https://studio-2300569924-8a121-6b097.web.app
- **Firebase URL 2**: https://studio-2300569924-8a121-6b097.firebaseapp.com

## Environment Variables

### Production Configuration
The following environment variables are configured in `.env.production`:

```bash
# Firebase Configuration
VITE_FIREBASE_API_KEY=AIzaSyATrrKz_hx8eFtaPMrq6yARv1TONjpA-zs
VITE_FIREBASE_AUTH_DOMAIN=studio-2300569924-8a121.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=studio-2300569924-8a121
VITE_FIREBASE_STORAGE_BUCKET=studio-2300569924-8a121.firebasestorage.app
VITE_FIREBASE_MESSAGING_SENDER_ID=161912375325
VITE_FIREBASE_APP_ID=1:161912375325:web:6150f9a599c700dfcd5ef4

# PNC Bank Configuration
VITE_PNC_PRIMARY_ACCOUNT=5563935267
VITE_PNC_PRIMARY_ROUTING=054000030
VITE_PNC_RESERVE_ACCOUNT=5563935275
VITE_PNC_RESERVE_ROUTING=054000030
VITE_PNC_SWIFT_CODE=PNCCUS33
VITE_PNC_FED_WIRE=054000030

# Stripe Configuration
VITE_STRIPE_PAYMENT_LINK=https://buy.stripe.com/fZudR93xS0jf1kq4PTcQU02
```

## PNC Bank Payment Integration

### Account Details

#### Primary Operating Account
- **Account Name**: XPRESS-AI-MASTER
- **Account Number**: 5563935267
- **Routing Number**: 054000030
- **Balance**: $2,847,592.45
- **SWIFT Code**: PNCCUS33
- **Fed Wire**: 054000030
- **Daily Limit**: $1,000,000
- **Monthly Fee**: $25
- **Transaction Fee**: $0.50

#### Reserve Fund Account
- **Account Name**: RESERVE-FUND
- **Account Number**: 5563935275
- **Routing Number**: 054000030
- **Balance**: $1,456,789.23
- **SWIFT Code**: PNCCUS33
- **Fed Wire**: 054000030
- **Daily Limit**: $500,000
- **Monthly Fee**: $15
- **Transaction Fee**: $0.25

### Bank Information
- **Bank Name**: PNC Bank, National Association
- **Bank Address**: 300 Fifth Avenue, Pittsburgh, PA 15222

## Payment Routing System

The platform includes a comprehensive Stripe-to-PNC Bank payment routing system accessible through:
- **Super Admin Dashboard** → **Payments Tab** → **PNC Bank Payment Integration**

Features:
- Real-time payment routing to PNC Bank accounts
- Multi-account support (Primary Operating & Reserve Fund)
- Daily limit validation
- Transaction fee tracking
- Complete account details display

## Deployment Commands Reference

```bash
# Install dependencies
npm install

# Build for production
npm run build

# Preview production build locally
npm run preview

# Deploy to Firebase
firebase deploy --only hosting

# Deploy with comment
firebase deploy --only hosting -m "Production deployment"

# Deploy to specific site
firebase deploy --only hosting:studio-2300569924-8a121-6b097

# View deployment history
firebase hosting:channel:list
```

## Troubleshooting

### Build Errors
If you encounter build errors:
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Firebase Authentication
If deployment fails due to authentication:
```bash
firebase login
firebase use studio-2300569924-8a121
```

### DNS Propagation
DNS changes can take 24-48 hours to propagate globally. Check status:
```bash
nslookup alazie.express
```

## Support
For deployment issues, contact the development team or refer to:
- Firebase Documentation: https://firebase.google.com/docs/hosting
- Project Dashboard: https://console.firebase.google.com/project/studio-2300569924-8a121
