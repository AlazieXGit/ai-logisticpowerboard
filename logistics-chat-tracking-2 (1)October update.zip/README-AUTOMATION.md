# Stripe Connect Integration - Complete Setup Guide

## Overview
This platform integrates Stripe Connect to enable carriers, vendors, and contractors to receive direct payouts with automated fund routing to PNC Bank accounts.

## Features
- ✅ Complete Stripe Connect onboarding flow
- ✅ Identity verification and bank account linking
- ✅ Payout scheduling (daily, weekly, monthly, manual)
- ✅ Compliance document management with RLS
- ✅ Real-time balance and payout tracking
- ✅ Automated webhook processing
- ✅ Email notifications for payments
- ✅ Database logging with Row Level Security

## Setup Instructions

### 1. Stripe Account Setup
1. Create a Stripe account at https://stripe.com
2. Enable Stripe Connect in your dashboard
3. Configure your platform settings:
   - Platform name: "Alazie Express"
   - Support email: support@alazieexpress.com
   - Platform URL: https://alazieexpress.com

### 2. Get API Keys
1. Go to Developers → API Keys
2. Copy your publishable key (pk_live_...)
3. Copy your secret key (sk_live_...)
4. Add to `.env.production`:
```
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_your_key
STRIPE_SECRET_KEY=sk_live_your_key
```

### 3. Configure Webhooks
1. Go to Developers → Webhooks
2. Add endpoint: `https://your-project.supabase.co/functions/v1/stripe-connect-webhook`
3. Select events:
   - account.updated
   - account.application.deauthorized
   - payout.created
   - payout.updated
   - payout.paid
   - payout.failed
4. Copy webhook signing secret
5. Add to `.env.production`:
```
STRIPE_CONNECT_WEBHOOK_SECRET=whsec_your_secret
```

### 4. Database Setup
Run migrations in Supabase SQL Editor:
```sql
-- Run: supabase/migrations/20250112_stripe_connect.sql
-- Run: supabase/storage-policies.sql
```

### 5. Deploy Edge Functions
```bash
# Deploy Stripe Connect webhook handler
supabase functions deploy stripe-connect-webhook --no-verify-jwt

# Deploy Stripe Connect operations
supabase functions deploy stripe-connect-operations

# Set environment variables
supabase secrets set STRIPE_SECRET_KEY=sk_live_your_key
supabase secrets set STRIPE_CONNECT_WEBHOOK_SECRET=whsec_your_secret
```

### 6. PNC Bank Configuration
Add PNC Bank account details to `.env.production`:
```
PNC_BANK_ACCOUNT_ID=acct_your_account_id
PNC_ROUTING_NUMBER=043000096
PNC_ACCOUNT_NUMBER=your_account_number
PNC_ACCOUNT_TYPE=checking
```

## User Flow

### For Carriers/Vendors
1. Navigate to Connect Onboarding page
2. Select account type (carrier/vendor/contractor)
3. Enter business information
4. Complete Stripe identity verification
5. Link bank account
6. Upload compliance documents
7. Configure payout schedule
8. Start receiving payouts

### For Admins
1. View all connected accounts in dashboard
2. Monitor payout status in real-time
3. Review compliance documents
4. Approve/reject verification requests
5. Track transfer history

## API Endpoints

### Create Connect Account
```typescript
POST /functions/v1/stripe-connect-operations
{
  "action": "create_account",
  "data": {
    "account_type": "carrier",
    "business_name": "ABC Trucking",
    "business_type": "company",
    "email": "carrier@example.com"
  }
}
```

### Create Onboarding Link
```typescript
POST /functions/v1/stripe-connect-operations
{
  "action": "create_account_link",
  "data": {
    "stripe_account_id": "acct_xxx",
    "return_url": "https://app.com/onboarding-complete"
  }
}
```

### Create Payout
```typescript
POST /functions/v1/stripe-connect-operations
{
  "action": "create_payout",
  "data": {
    "stripe_account_id": "acct_xxx",
    "amount": 1000.00,
    "currency": "usd",
    "description": "Weekly payout"
  }
}
```

## Database Schema

### stripe_connect_accounts
- User's Stripe Connect account info
- Onboarding and verification status
- Business details

### payout_schedules
- Payout frequency configuration
- Minimum payout amounts
- Schedule preferences

### compliance_documents
- Identity documents
- Business licenses
- Tax forms
- Insurance certificates

### stripe_payouts
- Payout history
- Status tracking
- Bank account details

## Security Features

### Row Level Security (RLS)
All tables have RLS enabled:
- Users can only access their own data
- Admins have full access
- Service role bypasses RLS for automation

### Storage Security
- Compliance documents in private bucket
- RLS policies on storage.objects
- Folder-based access control

### Webhook Verification
- Signature verification on all webhooks
- Replay attack prevention
- Event deduplication

## Monitoring

### Real-Time Updates
Dashboard refreshes every 30 seconds:
- Account status
- Pending payouts
- Transfer history

### Email Notifications
Automatic emails for:
- Successful onboarding
- Payout initiated
- Payout completed
- Verification required

### Error Handling
- Webhook retry logic
- Failed payout alerts
- Compliance document rejection notices

## Testing

### Test Mode
Use Stripe test keys for development:
```
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_key
STRIPE_SECRET_KEY=sk_test_your_key
```

### Test Cards
- Success: 4242 4242 4242 4242
- Decline: 4000 0000 0000 0002
- Requires Auth: 4000 0025 0000 3155

## Troubleshooting

### Webhook Not Receiving Events
1. Check webhook URL is correct
2. Verify signing secret matches
3. Check Supabase function logs
4. Test webhook in Stripe dashboard

### Payout Failed
1. Check bank account details
2. Verify account is verified
3. Check balance is sufficient
4. Review failure_code in database

### Onboarding Incomplete
1. Check requirements in Stripe dashboard
2. Verify all required fields submitted
3. Check verification status
4. Review account.updated webhooks

## Support
For issues, contact: support@alazieexpress.com
