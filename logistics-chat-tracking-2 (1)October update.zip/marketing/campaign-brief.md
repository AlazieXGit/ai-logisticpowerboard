# Campaign Brief – "Move Money, Move Faster"

## Objective
Acquire back office customers running multi-platform payouts and revenue tracking.

## Target Audience
- Marketplaces with complex payout needs
- Logistics dispatchers managing multiple carriers
- Fintech operations leads requiring audit trails
- Companies needing dual-authorization transfers

## Unique Value Proposition
Centralized manual transfers with dual authorization, OTP verification, and automated revenue rollups in a security-hardened interface.

## Key Features to Highlight
- Dual-authorization with OTP security
- Real-time revenue and profit visualization
- Complete audit trail for compliance
- Role-based access control
- Intrusion-hardened UI with CSP protection

## Channels
- Meta Business (primary)
- Google Search Ads
- LinkedIn sponsored content
- Email sequences
- Retargeting campaigns

## Success Metrics
- CTR > 2.5%
- Cost per lead < $120
- SQL conversion rate > 25%
- Demo-to-close rate > 15%

## Messaging
Primary: "Secure manual transfers with complete visibility"
Secondary: "Stop spreadsheet chaos. Centralize fees, savings and profit."
CTA: "Get a Demo" / "See It Live"