# AI-Xpress Platform - Production Deployment Runbook

## 🎯 Overview
Complete step-by-step guide to deploy AI-Xpress Platform to production.

## ✅ Pre-Deployment Checklist

### 1. Environment Setup
- [ ] Supabase project created at https://supabase.com
- [ ] Database migrations applied
- [ ] Environment variables configured
- [ ] Backend service deployed
- [ ] Frontend built and deployed

### 2. Required Environment Variables
```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-role-key
VITE_API_URL=https://your-backend-url.com
```

## 🚀 Deployment Steps

### Step 1: Database Setup (Supabase)
```bash
# 1. Create Supabase project
# 2. Run migrations
cd supabase/migrations
# Apply 0001_init_schema.sql via Supabase SQL Editor

# 3. Verify tables created
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public';
```

### Step 2: Backend Deployment (Render/Railway)
```bash
# 1. Install dependencies
pip install -r backend/requirements.txt

# 2. Test locally
cd backend
uvicorn main:app --reload

# 3. Deploy to Render
# - Connect GitHub repo
# - Set build command: pip install -r backend/requirements.txt
# - Set start command: uvicorn backend.main:app --host 0.0.0.0 --port $PORT
# - Add environment variables

# 4. Verify deployment
curl https://your-backend.onrender.com/health
```

### Step 3: Frontend Deployment (Vercel/Netlify)
```bash
# 1. Build frontend
npm install
npm run build

# 2. Deploy to Vercel
vercel --prod

# Or deploy to Netlify
netlify deploy --prod

# 3. Verify deployment
curl https://your-frontend.vercel.app
```

### Step 4: Integration Testing
```bash
# Test analytics endpoint
curl https://your-backend.com/api/analytics/report

# Test frontend connection
# Open browser to https://your-frontend.com
# Navigate to Super Admin Dashboard
# Verify live data displays
```

## 🔧 Local Development

### Quick Start
```bash
# 1. Clone repository
git clone <repo-url>
cd ai-xpress-platform

# 2. Copy environment variables
cp .env.example .env
# Edit .env with your values

# 3. Start with Docker
docker-compose up --build

# Access services:
# Frontend: http://localhost:5173
# Backend: http://localhost:8000
# Database: localhost:5432
```

### Manual Start (without Docker)
```bash
# Terminal 1: Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload

# Terminal 2: Frontend
npm install
npm run dev
```

## 📊 Verification

### Backend Health Check
```bash
curl http://localhost:8000/health
# Expected: {"status":"healthy","service":"AI-Xpress Platform"}
```

### Analytics Endpoint
```bash
curl http://localhost:8000/api/analytics/report
# Expected: JSON with live metrics
```

### Database Connection
```bash
# Check Supabase tables exist
psql $DATABASE_URL -c "\dt"
```

## 🐛 Troubleshooting

### Issue: Backend can't connect to Supabase
**Solution**: Verify SUPABASE_SERVICE_KEY is set correctly

### Issue: Frontend shows no data
**Solution**: Check VITE_API_URL points to backend, verify CORS enabled

### Issue: Database tables missing
**Solution**: Run migrations in Supabase SQL Editor

## 📈 Monitoring

### Key Metrics to Monitor
- API response times (/api/analytics/report)
- Database query performance
- Error rates in logs
- User activity metrics

### Logging
```bash
# Backend logs
docker logs aixpress-backend -f

# Frontend logs (browser console)
# Check Network tab for API calls
```

## 🔐 Security

### Production Checklist
- [ ] Service role key never exposed to frontend
- [ ] CORS configured for production domains only
- [ ] Database RLS policies enabled
- [ ] API rate limiting configured
- [ ] HTTPS enforced on all endpoints

## 📞 Support
For issues, check logs and verify all environment variables are set correctly.
