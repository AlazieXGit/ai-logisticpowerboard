(function(){
  const d = document;
  const form = d.getElementById('manualTransferForm');
  const btn = d.getElementById('initiateBtn');
  const dialog = d.getElementById('confirmDialog');
  const summary = d.getElementById('confirmSummary');
  const status = d.getElementById('status');
  const host = window.__API_HOST__ || '';

  function serialize(form){
    const o = {}; new FormData(form).forEach((v,k)=>o[k]=v); return o;
  }

  function validate(payload){
    const errors = [];
    if (!payload.fromAccount) errors.push('From Account is required');
    if (!payload.toAccount) errors.push('To Account is required');
    const amt = Number(payload.amount);
    if (!(amt>0)) errors.push('Amount must be greater than 0');
    if (!/^wire|ach|wallet$/.test(payload.transferType)) errors.push('Invalid transfer type');
    if (!/^\d{6}$/.test(payload.otp)) errors.push('OTP must be 6 digits');
    if (payload.memo && payload.memo.length>140) errors.push('Memo too long');
    return errors;
  }

  btn.addEventListener('click', () => {
    // Ensure it always opens
    const data = serialize(form);
    const errors = validate(data);
    if (errors.length){ status.textContent = errors.join(' • '); status.className='status err'; return; }
    summary.innerHTML = `
      <ul>
        <li><b>From:</b> ${data.fromAccount}</li>
        <li><b>To:</b> ${data.toAccount}</li>
        <li><b>Amount:</b> $${Number(data.amount).toLocaleString()}</li>
        <li><b>Type:</b> ${data.transferType}</li>
        <li><b>Memo:</b> ${data.memo||'-'}</li>
      </ul>`;
    dialog.showModal();
  });

  dialog.addEventListener('close', async () => {
    if (dialog.returnValue !== 'confirm') return; // user canceled
    status.textContent = 'Executing transfer…'; status.className='status';
    try {
      const payload = serialize(form);
      const r = await fetch(`${host}/api/transfers/manual`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });
      const json = await r.json();
      if (!r.ok) throw new Error(json.message || `HTTP ${r.status}`);
      status.textContent = `Transfer queued: ${json.transferId}`; status.className='status ok';
      form.reset();
    } catch (e) {
      status.textContent = `Error: ${e.message}`; status.className='status err';
    }
  });
})();