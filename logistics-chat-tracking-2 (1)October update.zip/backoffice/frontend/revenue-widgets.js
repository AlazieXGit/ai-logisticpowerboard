(async function(){
  const host = window.__API_HOST__ || '';
  async function fetchJSON(url, opts){
    const r = await fetch(url, { headers:{'Accept':'application/json'}, credentials:'include', ...opts });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }
  async function renderRevenue(){
    const el = document.getElementById('revenueSummary');
    if (!el) return;
    try {
      const data = await fetchJSON(`${host}/api/revenue/summary`);
      el.innerHTML = '';
      const cards = [
        {label:'Total Platform Revenue', val:data.totalRevenue},
        {label:'Automated Service Fees', val:data.automatedFees},
        {label:'Platform Fees', val:data.platformFees},
        {label:'Operations & Admin Fees', val:data.opAdminFees},
        {label:'Dispatch Fees', val:data.dispatchFees},
        {label:'Total Savings', val:data.totalSavings},
        {label:'Total Profit', val:data.totalProfit}
      ];
      cards.forEach(c => {
        const div = document.createElement('div');
        div.className = 'card';
        div.innerHTML = `<div class="kpi">$${Number(c.val).toLocaleString()}</div><div class="label">${c.label}</div>`;
        el.appendChild(div);
      });
      // Optional: lightweight chart (no deps)
      const ctx = document.getElementById('revenueChart');
      if (ctx && data.series) {
        const g = ctx.getContext('2d');
        g.clearRect(0,0,ctx.width,ctx.height);
        g.strokeStyle = '#06b6d4'; g.lineWidth = 2;
        const xs = data.series.map((_,i)=>i);
        const ys = data.series.map(p=>p.total);
        const min = Math.min(...ys), max = Math.max(...ys);
        const pad = 18; const w = ctx.width - pad*2; const h = ctx.height - pad*2;
        g.beginPath();
        ys.forEach((y,i)=>{
          const xPos = pad + (i/(ys.length-1))*w;
          const yPos = pad + (1-((y-min)/(max-min||1)))*h;
          i? g.lineTo(xPos,yPos) : g.moveTo(xPos,yPos);
        });
        g.stroke();
      }
    } catch (e) {
      console.error(e);
    }
  }
  renderRevenue();
})();