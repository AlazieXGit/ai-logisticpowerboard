(function(){
  const row = document.querySelector('[data-row="secondary"]');
  const panels = {
    'manual-protocol': document.getElementById('panel-manual-protocol'),
    'revenue': document.getElementById('panel-revenue'),
    'security': document.getElementById('panel-security')
  };
  // Hover-accessible tabs
  document.querySelectorAll('.tabs [role="tab"]').forEach(btn => {
    btn.addEventListener('mouseenter', () => btn.focus());
    btn.addEventListener('click', (e) => {
      const tab = e.target.dataset.tab;
      if (!tab) return;
      document.querySelectorAll('.tabs [role="tab"]').forEach(b => b.setAttribute('aria-selected','false'));
      e.target.setAttribute('aria-selected','true');
      // Toggle panels
      Object.values(panels).forEach(p => p && (p.hidden = true));
      if (panels[tab]) panels[tab].hidden = false;
      if (tab === 'manual-protocol') panels['manual-protocol'].classList.add('is-active');
    });
  });
})();