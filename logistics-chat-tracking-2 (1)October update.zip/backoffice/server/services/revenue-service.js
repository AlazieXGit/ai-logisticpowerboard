const { revenueSummary, revenueSeries } = require('../db/queries');
async function getSummary(){
  const summary = await revenueSummary();
  const series = await revenueSeries();
  return { ...summary, series };
}
module.exports = { getSummary };