CREATE TABLE IF NOT EXISTS transfers (
  id SERIAL PRIMARY KEY,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  created_by TEXT NOT NULL,
  from_account TEXT NOT NULL,
  to_account TEXT NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  transfer_type TEXT NOT NULL,
  memo TEXT,
  status TEXT NOT NULL DEFAULT 'queued',
  audit JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS revenue_ledger (
  id SERIAL PRIMARY KEY,
  occurred_at DATE NOT NULL,
  platform TEXT NOT NULL,
  automated_fee NUMERIC(14,2) NOT NULL DEFAULT 0,
  platform_fee NUMERIC(14,2) NOT NULL DEFAULT 0,
  op_admin_fee NUMERIC(14,2) NOT NULL DEFAULT 0,
  dispatch_fee NUMERIC(14,2) NOT NULL DEFAULT 0,
  savings NUMERIC(14,2) NOT NULL DEFAULT 0,
  profit NUMERIC(14,2) NOT NULL DEFAULT 0
);