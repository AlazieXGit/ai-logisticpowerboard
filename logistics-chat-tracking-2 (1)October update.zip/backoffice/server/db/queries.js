const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function insertTransfer(t){
  const { rows } = await pool.query(
    `INSERT INTO transfers (created_by, from_account, to_account, amount, transfer_type, memo, audit)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [t.createdBy, t.fromAccount, t.toAccount, t.amount, t.transferType, t.memo||null, t.audit||{}]
  );
  return rows[0].id;
}

async function revenueSummary(){
  const { rows } = await pool.query(`
    SELECT
      COALESCE(SUM(automated_fee),0) automated,
      COALESCE(SUM(platform_fee),0) platform,
      COALESCE(SUM(op_admin_fee),0) op_admin,
      COALESCE(SUM(dispatch_fee),0) dispatch,
      COALESCE(SUM(savings),0) savings,
      COALESCE(SUM(profit),0) profit
    FROM revenue_ledger`);
  const r = rows[0];
  const totalRevenue = Number(r.automated)+Number(r.platform)+Number(r.op_admin)+Number(r.dispatch);
  return {
    automatedFees: r.automated,
    platformFees: r.platform,
    opAdminFees: r.op_admin,
    dispatchFees: r.dispatch,
    totalSavings: r.savings,
    totalProfit: r.profit,
    totalRevenue
  };
}

async function revenueSeries(){
  const { rows } = await pool.query(`
    SELECT occurred_at::date as d,
      SUM(automated_fee+platform_fee+op_admin_fee+dispatch_fee) AS total
    FROM revenue_ledger
    GROUP BY d
    ORDER BY d ASC`);
  return rows.map(r=>({ date:r.d, total:Number(r.total) }));
}

module.exports = { insertTransfer, revenueSummary, revenueSeries };