const express = require('express');
const router = express.Router();
const requireRole = require('../middleware/authz');
const { getSummary } = require('../services/revenue-service');

router.get('/summary', requireRole(['BackOffice','SuperAdmin']), async (req,res)=>{
  const data = await getSummary();
  res.json(data);
});

module.exports = router;