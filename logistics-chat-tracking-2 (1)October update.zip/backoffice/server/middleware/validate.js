const { body, validationResult } = require('express-validator');

const manualTransferRules = [
  body('fromAccount').isString().isLength({min:3,max:64}),
  body('toAccount').isString().isLength({min:3,max:64}),
  body('amount').isFloat({gt:0}),
  body('transferType').isIn(['wire','ach','wallet']),
  body('otp').matches(/^\d{6}$/),
  body('memo').optional().isLength({max:140})
];

function handleErrors(req,res,next){
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({message:'Validation failed', errors: errors.array()});
  next();
}

module.exports = { manualTransferRules, handleErrors };