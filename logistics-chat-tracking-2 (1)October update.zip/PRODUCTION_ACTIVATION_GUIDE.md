# Production Feature Activation Guide
## AI-Xpress Platform - Moving Features from Development to Production

## 🎯 Overview
This guide walks through activating inactive, restricted, or development features for production deployment.

## 📋 Features to Activate

### 1. PNC Bank Integration
**Status**: Development → Production  
**Priority**: HIGH

#### Activation Steps:
```bash
# 1. Set environment variables
FEATURE_PNC_BANK=true
FEATURE_PNC_STATUS=production
PNC_API_KEY=your_production_api_key
PNC_BANK_ACCOUNT_ID=acct_your_account_id
```

#### Code Changes:
- ✅ Backend integration already implemented
- ✅ Frontend components ready (PNCBankPaymentIntegration.tsx)
- ⚠️ Update API credentials in production

#### Testing:
```bash
curl -X GET http://localhost:8000/api/admin/features/pnc_bank_integration \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

### 2. AI Development Platform
**Status**: Restricted → Production (Super Admin Only)  
**Priority**: MEDIUM

#### Activation Steps:
```bash
FEATURE_AI_DEV_PLATFORM=true
FEATURE_AI_DEV_STATUS=production
AI_PERFORMANCE_BOOST=100
```

#### Security:
- ✅ Super Admin access control enforced
- ✅ Rate limiting recommended
- ⚠️ Monitor resource usage

---

### 3. Wells Fargo Integration
**Status**: Manual Verification → Automated  
**Priority**: MEDIUM

#### Current Issue:
Account ****7892 requires manual micro-deposit verification

#### Activation Steps:
```bash
FEATURE_WELLS_FARGO=true
FEATURE_WELLS_FARGO_STATUS=production
WELLS_FARGO_AUTO_VERIFY=true  # Enable after testing
```

---

### 4. Super Admin Development Access
**Status**: Commented Out → Active  
**Priority**: HIGH

#### Activation Steps:
```bash
FEATURE_SUPER_ADMIN_DEV=true
FEATURE_SUPER_ADMIN_DEV_STATUS=production
```

#### Code Location:
`src/components/ComprehensiveRevenueOverview.tsx:278`

---

### 5. Community Super Admin Communications
**Status**: Development → Production  
**Priority**: LOW

```bash
FEATURE_COMMUNITY_COMMS=true
FEATURE_COMMUNITY_STATUS=production
```

---

## 🚀 Quick Start - Activate All Features

### Method 1: Automated Script
```bash
chmod +x scripts/activate-production-features.sh
./scripts/activate-production-features.sh
```

### Method 2: Manual Configuration
```bash
# 1. Copy production config
cp .env.production .env

# 2. Update security credentials
openssl rand -hex 64  # Generate SECRET_KEY

# 3. Update .env with your values
nano .env

# 4. Restart services
docker-compose down
docker-compose up -d

# 5. Verify activation
curl http://localhost:8000/api/admin/features
```

---

## 🔐 Security Checklist

- [ ] Generate new SECRET_KEY for production
- [ ] Update all API keys to production credentials
- [ ] Set STRIPE_SECRET_KEY to live key (sk_live_...)
- [ ] Configure production database with strong password
- [ ] Update CORS_ORIGINS with your domain
- [ ] Disable FEATURE_LOGIN_TEST_PANEL in production
- [ ] Enable SSL/TLS certificates
- [ ] Set up firewall rules
- [ ] Configure rate limiting
- [ ] Enable audit logging

---

## 📊 Feature Status Dashboard

Access the admin dashboard to monitor feature status:
```
https://www.alazie.express/admin/features
```

Or via API:
```bash
curl -X GET https://api.yourdomain.com/api/admin/features \
  -H "Authorization: Bearer YOUR_SUPER_ADMIN_TOKEN"
```

---

## 🧪 Testing After Activation

### 1. Health Check
```bash
curl http://localhost:8000/api/admin/system/health
```

### 2. Feature Verification
```bash
# Check specific feature
curl http://localhost:8000/api/admin/features/pnc_bank_integration
```

### 3. Integration Tests
```bash
# Run backend tests
cd backend
pytest tests/

# Run frontend tests
npm run test
```

---

## 🔄 Rollback Procedure

If issues occur:
```bash
# 1. Restore backup
cp .env.backup .env

# 2. Restart services
docker-compose restart

# 3. Check logs
docker-compose logs -f backend
```

---

## 📞 Support & Monitoring

### Logs
```bash
# Backend logs
docker-compose logs -f backend

# Database logs
docker-compose logs -f db

# All services
docker-compose logs -f
```

### Monitoring Endpoints
- Health: `/api/admin/system/health`
- Features: `/api/admin/features`
- Metrics: `/api/dashboard/metrics`

---

## 🎓 Best Practices

1. **Staged Rollout**: Activate features one at a time
2. **Monitor Metrics**: Watch error rates and performance
3. **User Communication**: Notify users of new features
4. **Documentation**: Update user guides
5. **Backup**: Always backup before major changes

---

## ✅ Post-Activation Checklist

- [ ] All features activated successfully
- [ ] Security credentials updated
- [ ] Services restarted
- [ ] Health checks passing
- [ ] Integration tests passing
- [ ] Monitoring configured
- [ ] Documentation updated
- [ ] Team notified
- [ ] Users notified (if applicable)
- [ ] Backup verified

---

**Last Updated**: 2025-01-14  
**Version**: 1.0.0
