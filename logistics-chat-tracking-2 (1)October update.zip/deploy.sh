#!/bin/bash

# LoadBoard AI Deployment Script
# Supports Render (preferred), Railway, and local deployment

set -e

echo "🚀 LoadBoard AI Deployment Script"
echo "==================================="

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run from project root."
    exit 1
fi

# Function to deploy to Render
deploy_render() {
    echo "📦 Deploying to Render..."
    
    # Check if render CLI is installed
    if ! command -v render &> /dev/null; then
        echo "Installing Render CLI..."
        npm install -g @render/cli
    fi
    
    # Deploy using render.yaml
    echo "🔧 Deploying with render.yaml configuration..."
    render deploy
    
    echo "✅ Render deployment initiated!"
    echo "🌐 Your app will be available at: https://loadboard-ai.onrender.com"
}

# Function to deploy to Railway
deploy_railway() {
    echo "🚂 Deploying to Railway..."
    
    # Check if railway CLI is installed
    if ! command -v railway &> /dev/null; then
        echo "Installing Railway CLI..."
        npm install -g @railway/cli
    fi
    
    # Login and deploy
    railway login
    railway link
    railway up
    
    echo "✅ Railway deployment complete!"
    echo "🌐 Check your Railway dashboard for the live URL"
}

# Function for local development
local_dev() {
    echo "💻 Starting local development..."
    
    # Install frontend dependencies
    echo "📦 Installing frontend dependencies..."
    npm install
    
    # Install backend dependencies
    echo "🐍 Installing backend dependencies..."
    cd backend
    pip install -r requirements.txt
    cd ..
    
    # Start backend in background
    echo "🔧 Starting backend server..."
    cd backend
    python main.py &
    BACKEND_PID=$!
    cd ..
    
    # Start frontend
    echo "⚛️ Starting frontend development server..."
    npm run dev
    
    # Cleanup on exit
    trap "kill $BACKEND_PID" EXIT
}

# Main deployment logic
case "${1:-render}" in
    "render")
        deploy_render
        ;;
    "railway")
        deploy_railway
        ;;
    "local")
        local_dev
        ;;
    *)
        echo "Usage: $0 [render|railway|local]"
        echo "Default: render"
        exit 1
        ;;
esac

echo "🎉 Deployment process completed!"