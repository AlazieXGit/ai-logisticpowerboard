# Back Office – Manual Transfer Protocol

This package adds a secure Manual Transfer UI, second-row tabs, and revenue aggregation widgets to the existing back office.

## Features

- Dual authorization with OTP verification
- Role-based access control (BackOffice/SuperAdmin)
- Real-time revenue tracking and visualization
- Comprehensive audit logging
- Security-hardened interface with CSP headers
- Accessible tab navigation with hover support

## Installation

1. Copy the `backoffice/` folder to your project root
2. Install dependencies: `npm install express pg express-validator`
3. Set up database using `server/db/schema.sql`
4. Wire routes in your Express app:

```javascript
const transfers = require('./server/routes/transfers');
const revenue = require('./server/routes/revenue');
app.use('/api/transfers', transfers);
app.use('/api/revenue', revenue);
```

## Environment Variables

- `DATABASE_URL` - PostgreSQL connection string
- `STRIPE_SECRET_KEY` - For payment processing
- `STRIPE_WEBHOOK_SECRET` - For webhook verification

## Security

- All authorization codes are placeholders - inject real values server-side
- OTP verification required for all transfers
- Full audit trail maintained
- CSP headers prevent XSS attacks
- Role-based access enforcement