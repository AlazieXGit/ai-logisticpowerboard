# Architecture Overview

## Components
- Frontend: Vanilla HTML/CSS/JS
- API: Express routes (`/api/transfers/manual`, `/api/revenue/summary`)
- DB: PostgreSQL (`transfers`, `revenue_ledger`)

## Flow
```
Back Office UI -> POST /api/transfers/manual -> transfer-service -> Database
Back Office UI -> GET /api/revenue/summary -> revenue-service -> Database
```

## Security
- Role-based authorization (BackOffice/SuperAdmin)
- OTP verification for transfers
- CSP headers and security middleware
- Full audit logging

## Database Schema
- `transfers` table: id, created_at, created_by, from_account, to_account, amount, transfer_type, memo, status, audit
- `revenue_ledger` table: id, occurred_at, platform, automated_fee, platform_fee, op_admin_fee, dispatch_fee, savings, profit