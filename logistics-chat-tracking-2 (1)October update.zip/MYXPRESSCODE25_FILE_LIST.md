# MYXPRESSCODE25 - Complete File List
**Updated: 2025-01-27**
**Total Files**: 350+ files | **Estimated Size**: 65MB+ source code

## RAW DATA FILES (Updated - Individual Files Under 2500 chars)
- raw_data_01_package_config.txt - Package.json configuration
- raw_data_02_vite_config.txt - Vite, PostCSS, ESLint configuration  
- raw_data_03_tailwind_config.txt - Tailwind CSS configuration
- raw_data_04_main_app_files.txt - Main application files (App.tsx, main.tsx)
- raw_data_05_core_lib_context.txt - Core libraries and context files
- raw_data_06_utility_libs.txt - Utility libraries and finance calculations
- raw_data_07_validation_services.txt - Validation schemas and session services
- raw_data_08_ui_components_core.txt - Core UI components overview
- raw_data_09_business_components.txt - Business component structure
- raw_data_10_services_backend.txt - Backend services and APIs
- raw_data_11_data_analysis.txt - Data analysis and correction instructions
- raw_data_12_comprehensive_overview.txt - Complete system architecture

## CONFIGURATION FILES
- package.json - Project dependencies and scripts
- vite.config.ts - Vite build configuration
- tailwind.config.ts - Tailwind CSS theming
- postcss.config.js - PostCSS configuration
- eslint.config.js - ESLint rules and plugins
- tsconfig.json - TypeScript configuration
- tsconfig.app.json - App-specific TypeScript config
- tsconfig.node.json - Node-specific TypeScript config
- components.json - shadcn/ui component configuration

## CORE APPLICATION FILES
- src/main.tsx - Application entry point with ErrorBoundary
- src/App.tsx - Main application component with routing
- src/App.css - Application-specific styles
- src/index.css - Global CSS styles and Tailwind imports

## CONTEXT & PROVIDERS
- src/contexts/AppContext.tsx - Global application state management
- src/components/theme-provider.tsx - Dark/light theme provider

## CORE LIBRARIES
- src/lib/supabase.ts - Supabase client configuration
- src/lib/utils.ts - Utility functions (cn, formatters, etc.)
- src/lib/finance.ts - Financial calculations and mock data
- src/lib/validation.ts - Zod validation schemas
- src/lib/creditServices.ts - Credit and tax integration services

## ENHANCED DATA ANALYSIS SYSTEM
- src/data/reallive-data.ts - Real-time data analysis interfaces
- src/data/reallive-MOCK.ts - Mock data for testing and development
- src/data/correction-instructions.ts - Error handling and validation rules

## SERVICES
- src/services/SessionService.ts - Session management and timeouts
- src/services/PaymentTermsConfig.ts - Payment configuration
- src/services/RevenueCalculationService.ts - Revenue calculations
- backoffice/server/services/revenue-service.js
- backoffice/server/services/transfer-service.js

## Source Code - Main
- src/main.tsx
- src/App.tsx
- src/App.css
- src/index.css

## Source Code - Contexts
- src/contexts/AppContext.tsx

## Source Code - Hooks
- src/hooks/use-mobile.tsx
- src/hooks/use-toast.ts

## Source Code - Libraries
- src/lib/finance.ts
- src/lib/supabase.ts
- src/lib/utils.ts
- src/lib/validation.ts
- src/lib/creditServices.ts

## Source Code - Data
- src/data/correction-instructions.ts
- src/data/reallive-MOCK.ts
- src/data/reallive-data.ts

## Source Code - Middlewares
- src/middlewares/sessionTracker.ts

## Source Code - Pages
- src/pages/BlockedAccess.tsx
- src/pages/Index.tsx
- src/pages/Landing.tsx
- src/pages/NotFound.tsx

## Source Code - Services
- src/services/PaymentTermsConfig.ts
- src/services/RevenueCalculationService.ts
- src/services/SessionService.ts

## Source Code - Tests
- src/test/user-threat-monitor.spec.ts

## UI Components (Core)
- src/components/ui/accordion.tsx
- src/components/ui/alert-dialog.tsx
- src/components/ui/alert.tsx
- src/components/ui/aspect-ratio.tsx
- src/components/ui/avatar.tsx
- src/components/ui/badge.tsx
- src/components/ui/breadcrumb.tsx
- src/components/ui/button.tsx
- src/components/ui/calendar.tsx
- src/components/ui/card.tsx
- src/components/ui/carousel.tsx
- src/components/ui/chart.tsx
- src/components/ui/checkbox.tsx
- src/components/ui/collapsible.tsx
- src/components/ui/command.tsx
- src/components/ui/context-menu.tsx
- src/components/ui/dialog.tsx
- src/components/ui/drawer.tsx
- src/components/ui/dropdown-menu.tsx
- src/components/ui/form.tsx
- src/components/ui/hover-card.tsx
- src/components/ui/input-otp.tsx
- src/components/ui/input.tsx
- src/components/ui/label.tsx
- src/components/ui/menubar.tsx
- src/components/ui/navigation-menu.tsx
- src/components/ui/pagination.tsx
- src/components/ui/popover.tsx
- src/components/ui/progress.tsx
- src/components/ui/radio-group.tsx
- src/components/ui/resizable.tsx
- src/components/ui/scroll-area.tsx
- src/components/ui/select.tsx
- src/components/ui/separator.tsx
- src/components/ui/sheet.tsx
- src/components/ui/sidebar.tsx
- src/components/ui/skeleton.tsx
- src/components/ui/slider.tsx
- src/components/ui/sonner.tsx
- src/components/ui/switch.tsx
- src/components/ui/table.tsx
- src/components/ui/tabs.tsx
- src/components/ui/textarea.tsx
- src/components/ui/toast.tsx
- src/components/ui/toaster.tsx
- src/components/ui/toggle-group.tsx
- src/components/ui/toggle.tsx
- src/components/ui/tooltip.tsx
- src/components/ui/use-toast.ts
- src/components/theme-provider.tsx

## Business Components (300+ files)
- src/components/ACHNetworkRegistration.tsx
- src/components/AIAgentMedicalSystem.tsx
- src/components/AIAgentSystem.tsx
- src/components/AIAlazieXpressLoadboard.tsx
- src/components/AIAutomotivePurchasingAgent.tsx
- src/components/AIAutomotiveRoboticsInternational.tsx
- src/components/AIAutomotiveRoboticsSystem.tsx
- src/components/AIAutomotiveShippingPlatform.tsx
- src/components/AIBankingAssistant.tsx
- src/components/AICodeEditor.tsx
- src/components/AIDevPlatform.tsx
- src/components/AIDispatchAgent.tsx
- src/components/AILoadMatchingSystemEnhanced.tsx
- src/components/AIMarketAnalysis.tsx
- src/components/AIPoweredLoadboard2029.tsx
- src/components/AIProjectManager.tsx
- src/components/AIRealEstatePurchasingAgent.tsx
- src/components/AISystemMonitor.tsx
- src/components/AITaxAssistantPlatform.tsx
- src/components/APIManagementSystem.tsx

[... and 280+ more business component files ...]

## App Package Documentation
- app-package/ARCHITECTURE.md
- app-package/README.md

## Marketing & Investment
- marketing/campaign-brief.md
- zips/INVESTMENT_PACKAGE/executive_summary.md
- zips/INVESTMENT_PACKAGE/market_and_moat.md
- zips/MARKETING_CAMPAIGN/campaign_brief.md
- zips/MARKETING_CAMPAIGN/creative_copy_variants.md

## Raw Data Files
- raw_data1_project_config.txt
- raw_data2_config_files.txt
- raw_data3_main_app_files.txt
- raw_data4_core_lib_context.txt
- raw_data5_utility_libs.txt
- raw_data6_super_admin_dashboard.txt
- raw_data7_super_admin_dashboard_part2.txt
- raw_data8_ui_components_core.txt
- raw_data9_ui_components_extended.txt
- raw_data10_business_components.txt
- raw_data11_services_backend.txt

**Note**: Due to file size limitations (2500 chars max), the complete raw code cannot be included in a single file. Each component file contains 500-2000+ lines of TypeScript/React code.

**Total Files**: 350+ files
**Estimated Total Size**: 65MB+ of source code

## Recent Additions
- Enhanced AI Tax Assistant Platform with comprehensive manual input forms
- Real-time data analysis with correction instructions
- Credit services integration for tax optimization
- Advanced developer platform with manual edit capabilities
- Complete back office system for revenue and transfer management