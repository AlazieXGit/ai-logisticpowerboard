#!/bin/bash

# Firebase Deployment Script for alazie.express
# AI-Xpress Platform Production Deployment

echo "🚀 Starting Firebase deployment for alazie.express..."

# Build the application
echo "📦 Building application..."
npm run build

# Check if build was successful
if [ $? -ne 0 ]; then
    echo "❌ Build failed. Aborting deployment."
    exit 1
fi

echo "✅ Build completed successfully"

# Deploy to Firebase Hosting
echo "🌐 Deploying to Firebase Hosting..."
firebase deploy --only hosting -m "Production deployment to alazie.express"

if [ $? -eq 0 ]; then
    echo "✅ Deployment successful!"
    echo "🌍 Site available at:"
    echo "   - https://alazie.express"
    echo "   - https://studio-2300569924-8a121-6b097.web.app"
    echo "   - https://studio-2300569924-8a121-6b097.firebaseapp.com"
else
    echo "❌ Deployment failed"
    exit 1
fi
