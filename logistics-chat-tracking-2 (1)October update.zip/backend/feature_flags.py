"""
Feature Flags System for Production Activation
Centralized control for activating development/restricted features
"""
import os
from typing import Dict, Any
from enum import Enum

class FeatureStatus(str, Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"
    DISABLED = "disabled"

class FeatureFlags:
    """Manage feature activation across environments"""
    
    def __init__(self):
        self.environment = os.getenv("ENVIRONMENT", "development")
        self._flags = self._load_flags()
    
    def _load_flags(self) -> Dict[str, Any]:
        """Load feature flags from environment"""
        return {
            # Banking Integrations
            "pnc_bank_integration": {
                "enabled": os.getenv("FEATURE_PNC_BANK", "false").lower() == "true",
                "status": os.getenv("FEATURE_PNC_STATUS", "development"),
                "api_key": os.getenv("PNC_API_KEY", ""),
                "account_id": os.getenv("PNC_BANK_ACCOUNT_ID", ""),
            },
            "wells_fargo_integration": {
                "enabled": os.getenv("FEATURE_WELLS_FARGO", "false").lower() == "true",
                "status": os.getenv("FEATURE_WELLS_FARGO_STATUS", "development"),
                "auto_verification": os.getenv("WELLS_FARGO_AUTO_VERIFY", "false").lower() == "true",
            },
            
            # AI Features
            "ai_development_platform": {
                "enabled": os.getenv("FEATURE_AI_DEV_PLATFORM", "false").lower() == "true",
                "status": os.getenv("FEATURE_AI_DEV_STATUS", "development"),
                "super_admin_only": True,
                "performance_boost": os.getenv("AI_PERFORMANCE_BOOST", "100"),
            },
            
            # Admin Features
            "super_admin_dev_access": {
                "enabled": os.getenv("FEATURE_SUPER_ADMIN_DEV", "false").lower() == "true",
                "status": os.getenv("FEATURE_SUPER_ADMIN_DEV_STATUS", "development"),
            },
            "minimized_admin_login": {
                "enabled": os.getenv("FEATURE_MINI_ADMIN_LOGIN", "true").lower() == "true",
                "status": os.getenv("FEATURE_MINI_ADMIN_STATUS", "production"),
            },
            
            # Testing & Development
            "login_test_panel": {
                "enabled": os.getenv("FEATURE_LOGIN_TEST_PANEL", "false").lower() == "true",
                "status": os.getenv("FEATURE_LOGIN_TEST_STATUS", "development"),
                "production_safe": False,
            },
            
            # Communications
            "community_admin_comms": {
                "enabled": os.getenv("FEATURE_COMMUNITY_COMMS", "false").lower() == "true",
                "status": os.getenv("FEATURE_COMMUNITY_STATUS", "development"),
            },
        }
    
    def is_enabled(self, feature_name: str) -> bool:
        """Check if a feature is enabled"""
        feature = self._flags.get(feature_name, {})
        return feature.get("enabled", False)
    
    def get_status(self, feature_name: str) -> str:
        """Get feature status"""
        feature = self._flags.get(feature_name, {})
        return feature.get("status", "disabled")
    
    def get_config(self, feature_name: str) -> Dict[str, Any]:
        """Get full feature configuration"""
        return self._flags.get(feature_name, {})
    
    def all_features(self) -> Dict[str, Any]:
        """Get all feature flags"""
        return self._flags

# Global instance
feature_flags = FeatureFlags()
