"""
API Key models for third-party integrations
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey
from sqlalchemy.sql import func
from backend.database import Base
from datetime import datetime, timedelta
import secrets

class APIKey(Base):
    __tablename__ = "api_keys"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String, nullable=False)
    key_hash = Column(String, unique=True, nullable=False, index=True)
    key_prefix = Column(String, nullable=False)  # First 8 chars for display
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True), nullable=True)
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    
    @staticmethod
    def generate_key():
        """Generate a secure API key"""
        return f"aix_{secrets.token_urlsafe(32)}"
    
    @staticmethod
    def hash_key(key: str):
        """Hash API key for storage"""
        import hashlib
        return hashlib.sha256(key.encode()).hexdigest()
