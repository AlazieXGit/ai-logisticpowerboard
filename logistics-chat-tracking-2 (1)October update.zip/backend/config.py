import os
from dotenv import load_dotenv

load_dotenv()

# Environment
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")
NODE_ENV = os.getenv("NODE_ENV", "development")

# Database
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise ValueError("❌ DATABASE_URL is missing in .env")

# Security
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    raise ValueError("❌ SECRET_KEY is missing — set it in .env for security")

JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", SECRET_KEY)
API_KEY_SALT = os.getenv("API_KEY_SALT", SECRET_KEY[:32])

ALGORITHM = os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7"))

# API
API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", "8000"))
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")

# Supabase (Optional)
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

# Stripe
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")
STRIPE_PUBLISHABLE_KEY = os.getenv("STRIPE_PUBLISHABLE_KEY")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET")

# PNC Bank
PNC_API_KEY = os.getenv("PNC_API_KEY")
PNC_BANK_ACCOUNT_ID = os.getenv("PNC_BANK_ACCOUNT_ID")
PNC_PRIMARY_ACCOUNT = os.getenv("PNC_PRIMARY_ACCOUNT")
PNC_PRIMARY_ROUTING = os.getenv("PNC_PRIMARY_ROUTING")

# Wells Fargo
WELLS_FARGO_ACCOUNT = os.getenv("WELLS_FARGO_ACCOUNT")
WELLS_FARGO_AUTO_VERIFY = os.getenv("WELLS_FARGO_AUTO_VERIFY", "false").lower() == "true"

# Feature Flags
FEATURE_FLAGS_ENABLED = os.getenv("FEATURE_FLAGS_ENABLED", "true").lower() == "true"
