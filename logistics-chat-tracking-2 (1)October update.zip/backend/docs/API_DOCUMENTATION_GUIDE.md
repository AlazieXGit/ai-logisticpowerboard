# AI-Xpress Platform API Documentation Guide

## 🚀 Quick Start

### Access Documentation
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **OpenAPI JSON**: http://localhost:8000/openapi.json

### Test Credentials
```
Email: admin@ai-xpress.com
Password: admin123
```

## 🔐 Authentication Methods

### 1. JWT Authentication (Web Apps)
```bash
# Login
curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@ai-xpress.com","password":"admin123"}'

# Use token
curl -X GET "http://localhost:8000/api/dashboard/metrics" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### 2. API Key Authentication (Integrations)
```bash
# Generate API key (requires JWT first)
curl -X POST "http://localhost:8000/api/api-keys/generate" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"My Integration","expires_days":365}'

# Use API key
curl -X GET "http://localhost:8000/api/dashboard/metrics" \
  -H "X-API-Key: YOUR_API_KEY"
```

## 📚 API Endpoints

### Authentication
- `POST /api/auth/login` - Login and get tokens
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - Logout and revoke token

### Dashboard
- `GET /api/dashboard/metrics` - Dashboard KPIs
- `GET /api/analytics/realtime` - Real-time analytics
- `GET /api/system/metrics` - Public system metrics

### Revenue
- `GET /api/revenue/summary` - Revenue breakdown by platform

### Trust Accounts
- `GET /api/trust-accounts` - List all accounts
- `GET /api/trust-accounts/{account_number}` - Get specific account
- `POST /api/trust-accounts` - Create new account

### Loadboard
- `GET /api/loads` - List all loads (public)
- `POST /api/loads/{load_id}/book` - Book a load
- `GET /api/loads/analytics` - Load analytics

### API Keys
- `POST /api/api-keys/generate` - Generate new API key
- `GET /api/api-keys` - List your API keys
- `DELETE /api/api-keys/{key_id}` - Revoke API key

## 🔌 WebSocket Endpoints

### Real-time Metrics
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/metrics?token=YOUR_JWT_TOKEN');
ws.onmessage = (event) => {
  const metrics = JSON.parse(event.data);
  console.log(metrics);
};
```

### Real-time Revenue
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/revenue?token=YOUR_JWT_TOKEN');
```

### Trust Account Updates
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/trust-accounts/1234567890?token=YOUR_JWT_TOKEN');
```

## 🎨 Custom Branding Features

✅ Custom title and description
✅ Company contact information
✅ Getting started guide
✅ Code examples for all endpoints
✅ Request/response examples
✅ Authentication examples
✅ Security scheme documentation
✅ Multiple server environments
✅ Organized endpoint tags
✅ Comprehensive error responses

## 🛠️ Development

Run the API server:
```bash
cd backend
python main.py
```

Access documentation at http://localhost:8000/docs
