"""
Custom OpenAPI configuration for AI-Xpress Platform API
"""

tags_metadata = [
    {
        "name": "Authentication",
        "description": "User authentication with JWT tokens. Login to receive access and refresh tokens.",
    },
    {
        "name": "Dashboard",
        "description": "Real-time dashboard metrics and analytics for platform overview.",
    },
    {
        "name": "Revenue",
        "description": "Revenue tracking, platform fees, and financial analytics.",
    },
    {
        "name": "Trust Accounts",
        "description": "Manage trust accounts, balances, and transactions.",
    },
    {
        "name": "Loadboard",
        "description": "Freight load management, booking, and carrier operations.",
    },
    {
        "name": "API Keys",
        "description": "Generate and manage API keys for third-party integrations.",
    },
]

description = """
# AI-Xpress Platform API

Welcome to the **AI-Xpress Platform API** - a comprehensive logistics and financial management system.

## 🚀 Getting Started

### 1. Authentication

To use the API, you need to authenticate using one of two methods:

#### JWT Authentication (Recommended for web apps)
```bash
# Login to get tokens
curl -X POST "https://api.ai-xpress.com/api/auth/login" \\
  -H "Content-Type: application/json" \\
  -d '{"email": "user@example.com", "password": "your_password"}'

# Use the access token in subsequent requests
curl -X GET "https://api.ai-xpress.com/api/dashboard/metrics" \\
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

#### API Key Authentication (For third-party integrations)
```bash
# Generate an API key first (requires JWT login)
curl -X POST "https://api.ai-xpress.com/api/api-keys/generate" \\
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"name": "My Integration", "expires_days": 365}'

# Use the API key
curl -X GET "https://api.ai-xpress.com/api/dashboard/metrics" \\
  -H "X-API-Key: YOUR_API_KEY"
```

### 2. Making Requests

All requests must include proper authentication headers. The API returns JSON responses.

### 3. Rate Limits

- **Authenticated users**: 1000 requests/hour
- **API keys**: 5000 requests/hour

## 📚 Features

- **Real-time Updates**: WebSocket support for live data
- **Comprehensive Analytics**: Dashboard metrics and revenue tracking
- **Trust Account Management**: Secure financial operations
- **Load Management**: Complete freight logistics system
- **API Key Management**: Third-party integration support

## 🔒 Security

All endpoints use HTTPS. Tokens expire after 30 minutes. Refresh tokens are valid for 7 days.
"""

custom_openapi_config = {
    "title": "AI-Xpress Platform API",
    "version": "2.0.0",
    "description": description,
    "contact": {
        "name": "AI-Xpress Support",
        "email": "support@ai-xpress.com",
        "url": "https://ai-xpress.com/support"
    },
    "license_info": {
        "name": "Proprietary",
        "url": "https://ai-xpress.com/terms"
    },
}
