"""Admin operations service"""
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from backend.core.supabase_client import get_supabase_client
from backend.services.audit_service import AuditService

class AdminOperationsService:
    @staticmethod
    async def block_ip(
        ip_address: str,
        reason: str,
        admin_id: str,
        admin_email: str,
        expires_hours: Optional[int] = None
    ) -> Dict[str, Any]:
        """Block an IP address"""
        supabase = get_supabase_client()
        
        expires_at = None
        if expires_hours:
            expires_at = (datetime.utcnow() + timedelta(hours=expires_hours)).isoformat()
        
        block_data = {
            "ip_address": ip_address,
            "reason": reason,
            "blocked_by": admin_id,
            "expires_at": expires_at,
            "is_active": True
        }
        
        result = supabase.table("blocked_ips").insert(block_data).execute()
        
        await AuditService.log_action(
            admin_id=admin_id,
            admin_email=admin_email,
            action_type="IP_BLOCK",
            target_type="ip_address",
            target_id=ip_address,
            details={"reason": reason, "expires_hours": expires_hours}
        )
        
        return result.data[0] if result.data else {}
    
    @staticmethod
    async def unblock_ip(ip_address: str, admin_id: str, admin_email: str) -> Dict[str, Any]:
        """Unblock an IP address"""
        supabase = get_supabase_client()
        
        result = supabase.table("blocked_ips").update({"is_active": False}).eq("ip_address", ip_address).execute()
        
        await AuditService.log_action(
            admin_id=admin_id,
            admin_email=admin_email,
            action_type="IP_UNBLOCK",
            target_type="ip_address",
            target_id=ip_address
        )
        
        return result.data[0] if result.data else {}
