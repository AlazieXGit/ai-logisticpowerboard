"""
Payment terms configuration service.
"""
from typing import Dict, Any, List
from backend.core.supabase_client import get_supabase_client

def create_payment_term(term_name: str, platform_fee: float, carrier_pct: float, 
                       broker_pct: float, created_by: str) -> Dict[str, Any]:
    """Create new payment term configuration."""
    supabase = get_supabase_client()
    try:
        result = supabase.table('payment_terms_config').insert({
            'term_name': term_name,
            'platform_fee_percentage': platform_fee,
            'carrier_percentage': carrier_pct,
            'broker_percentage': broker_pct,
            'created_by': created_by
        }).execute()
        return {"success": True, "data": result.data}
    except Exception as e:
        return {"success": False, "error": str(e)}

def update_payment_term(term_id: str, updates: Dict[str, Any], updated_by: str) -> Dict[str, Any]:
    """Update payment term configuration."""
    supabase = get_supabase_client()
    try:
        updates['updated_by'] = updated_by
        updates['updated_at'] = 'NOW()'
        result = supabase.table('payment_terms_config').update(updates).eq('id', term_id).execute()
        return {"success": True, "data": result.data}
    except Exception as e:
        return {"success": False, "error": str(e)}

def get_payment_terms(active_only: bool = True) -> List[Dict[str, Any]]:
    """Get all payment terms."""
    supabase = get_supabase_client()
    try:
        query = supabase.table('payment_terms_config').select('*')
        if active_only:
            query = query.eq('is_active', True)
        result = query.order('created_at', desc=True).execute()
        return result.data if result.data else []
    except Exception as e:
        return []

def delete_payment_term(term_id: str) -> Dict[str, Any]:
    """Soft delete payment term."""
    supabase = get_supabase_client()
    try:
        result = supabase.table('payment_terms_config').update({
            'is_active': False
        }).eq('id', term_id).execute()
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}
