from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.database import get_db
from backend.models import TrustAccount
from decimal import Decimal
from typing import List, Optional

router = APIRouter(prefix="/trust-accounts", tags=["Trust Accounts"])

@router.get("/")
async def list_trust_accounts(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(TrustAccount))
    return result.scalars().all()

@router.post("/")
async def create_trust_account(account: dict, db: AsyncSession = Depends(get_db)):
    new_account = TrustAccount(
        account_name=account["account_name"],
        account_number=account["account_number"],
        routing_number=account["routing_number"],
        balance=Decimal(str(account.get("balance", 0.00))),
        currency=account.get("currency", "USD"),
        account_type=account.get("account_type", "trust"),
        owner_email=account.get("owner_email")
    )
    db.add(new_account)
    await db.commit()
    await db.refresh(new_account)
    return new_account

@router.get("/{account_number}")
async def get_trust_account(account_number: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(TrustAccount).where(TrustAccount.account_number == account_number)
    )
    account = result.scalars().first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    return account

@router.put("/{account_number}/balance")
async def update_balance(account_number: str, amount: float, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(TrustAccount).where(TrustAccount.account_number == account_number)
    )
    account = result.scalars().first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    
    account.balance = Decimal(str(amount))
    await db.commit()
    await db.refresh(account)
    return account

@router.delete("/{account_number}")
async def delete_trust_account(account_number: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(TrustAccount).where(TrustAccount.account_number == account_number)
    )
    account = result.scalars().first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    
    await db.delete(account)
    await db.commit()
    return {"message": "Account deleted successfully"}
