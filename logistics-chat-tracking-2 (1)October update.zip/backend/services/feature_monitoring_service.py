"""
Feature Monitoring Service
Tracks feature usage, errors, performance, and handles automatic disabling
"""
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from backend.core.supabase_client import get_supabase_client
import logging

logger = logging.getLogger(__name__)

class FeatureMonitoringService:
    def __init__(self):
        self.supabase = get_supabase_client()
        
        # Thresholds for automatic feature disabling
        self.ERROR_RATE_THRESHOLD = 25.0  # 25% error rate
        self.CRITICAL_ERROR_THRESHOLD = 5  # 5 critical errors in 5 minutes
        self.RESPONSE_TIME_THRESHOLD = 5000  # 5 seconds
        
    async def track_usage(self, feature_name: str, user_id: Optional[str] = None, 
                         session_id: Optional[str] = None, metadata: Dict = None):
        """Track feature usage"""
        try:
            self.supabase.table('feature_metrics').insert({
                'feature_name': feature_name,
                'metric_type': 'usage',
                'metric_value': 1,
                'user_id': user_id,
                'session_id': session_id,
                'metadata': metadata or {}
            }).execute()
            
            # Update adoption tracking
            if user_id:
                self._update_adoption(feature_name, user_id)
                
        except Exception as e:
            logger.error(f"Error tracking usage: {e}")
    
    async def track_error(self, feature_name: str, error_type: str, 
                         error_message: str, severity: str = 'medium',
                         user_id: Optional[str] = None, **kwargs):
        """Track feature errors and check for auto-disable"""
        try:
            self.supabase.table('feature_errors').insert({
                'feature_name': feature_name,
                'error_type': error_type,
                'error_message': error_message,
                'severity': severity,
                'user_id': user_id,
                'error_stack': kwargs.get('error_stack'),
                'request_data': kwargs.get('request_data', {})
            }).execute()
            
            # Check if feature should be auto-disabled
            if severity == 'critical':
                await self._check_auto_disable(feature_name)
                
        except Exception as e:
            logger.error(f"Error tracking error: {e}")
    
    async def track_performance(self, feature_name: str, operation: str, 
                               duration_ms: float, success: bool = True, **kwargs):
        """Track feature performance"""
        try:
            self.supabase.table('feature_performance').insert({
                'feature_name': feature_name,
                'operation_name': operation,
                'duration_ms': duration_ms,
                'cpu_usage': kwargs.get('cpu_usage'),
                'memory_usage': kwargs.get('memory_usage'),
                'success': success,
                'user_id': kwargs.get('user_id'),
                'metadata': kwargs.get('metadata', {})
            }).execute()
            
        except Exception as e:
            logger.error(f"Error tracking performance: {e}")
    
    def _update_adoption(self, feature_name: str, user_id: str):
        """Update feature adoption metrics"""
        try:
            # Upsert adoption record
            self.supabase.rpc('upsert_feature_adoption', {
                'p_feature_name': feature_name,
                'p_user_id': user_id
            }).execute()
        except Exception as e:
            logger.error(f"Error updating adoption: {e}")
    
    async def _check_auto_disable(self, feature_name: str):
        """Check if feature should be automatically disabled"""
        try:
            # Check critical errors in last 5 minutes
            five_min_ago = datetime.utcnow() - timedelta(minutes=5)
            
            result = self.supabase.table('feature_errors')\
                .select('*')\
                .eq('feature_name', feature_name)\
                .eq('severity', 'critical')\
                .gte('created_at', five_min_ago.isoformat())\
                .execute()
            
            critical_count = len(result.data)
            
            if critical_count >= self.CRITICAL_ERROR_THRESHOLD:
                await self.disable_feature(
                    feature_name, 
                    f"Auto-disabled: {critical_count} critical errors in 5 minutes"
                )
                
                # Create alert
                await self.create_alert(
                    feature_name,
                    'critical_error',
                    'critical',
                    f"Feature auto-disabled due to {critical_count} critical errors",
                    threshold_value=self.CRITICAL_ERROR_THRESHOLD,
                    current_value=critical_count
                )
                
        except Exception as e:
            logger.error(f"Error checking auto-disable: {e}")
    
    async def disable_feature(self, feature_name: str, reason: str):
        """Disable a feature"""
        try:
            self.supabase.table('feature_health').upsert({
                'feature_name': feature_name,
                'status': 'disabled',
                'auto_disabled': True,
                'disabled_reason': reason,
                'updated_at': datetime.utcnow().isoformat()
            }).execute()
            
            logger.warning(f"Feature {feature_name} auto-disabled: {reason}")
            
        except Exception as e:
            logger.error(f"Error disabling feature: {e}")
    
    async def create_alert(self, feature_name: str, alert_type: str, 
                          severity: str, message: str, **kwargs):
        """Create a feature alert"""
        try:
            self.supabase.table('feature_alerts').insert({
                'feature_name': feature_name,
                'alert_type': alert_type,
                'severity': severity,
                'message': message,
                'threshold_value': kwargs.get('threshold_value'),
                'current_value': kwargs.get('current_value'),
                'metadata': kwargs.get('metadata', {})
            }).execute()
            
        except Exception as e:
            logger.error(f"Error creating alert: {e}")

# Global instance
monitoring_service = FeatureMonitoringService()
