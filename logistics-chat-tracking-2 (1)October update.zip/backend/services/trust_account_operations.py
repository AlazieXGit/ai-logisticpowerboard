# Trust Account Business Logic Operations
from decimal import Decimal
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.models import TrustAccount
from datetime import datetime

class TrustAccountOperations:
    """Business logic for trust account operations"""
    
    @staticmethod
    async def transfer_funds(
        db: AsyncSession,
        from_account: str,
        to_account: str,
        amount: Decimal
    ) -> dict:
        """Transfer funds between trust accounts"""
        # Get source account
        result = await db.execute(
            select(TrustAccount).where(TrustAccount.account_number == from_account)
        )
        source = result.scalars().first()
        
        if not source:
            raise ValueError(f"Source account {from_account} not found")
        
        if source.balance < amount:
            raise ValueError("Insufficient funds")
        
        # Get destination account
        result = await db.execute(
            select(TrustAccount).where(TrustAccount.account_number == to_account)
        )
        dest = result.scalars().first()
        
        if not dest:
            raise ValueError(f"Destination account {to_account} not found")
        
        # Perform transfer
        source.balance -= amount
        dest.balance += amount
        
        await db.commit()
        await db.refresh(source)
        await db.refresh(dest)
        
        return {
            "status": "success",
            "from_account": from_account,
            "to_account": to_account,
            "amount": float(amount),
            "timestamp": datetime.utcnow().isoformat()
        }
    
    @staticmethod
    async def get_total_balance(db: AsyncSession) -> Decimal:
        """Get total balance across all trust accounts"""
        result = await db.execute(select(TrustAccount))
        accounts = result.scalars().all()
        return sum(acc.balance for acc in accounts)
    
    @staticmethod
    async def get_accounts_by_owner(
        db: AsyncSession,
        owner_email: str
    ) -> List[TrustAccount]:
        """Get all accounts owned by a specific user"""
        result = await db.execute(
            select(TrustAccount).where(TrustAccount.owner_email == owner_email)
        )
        return result.scalars().all()
