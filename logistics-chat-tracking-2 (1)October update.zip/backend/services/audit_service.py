"""Audit logging service for admin actions"""
from datetime import datetime
from typing import Optional, Dict, Any
from backend.core.supabase_client import get_supabase_client

class AuditService:
    @staticmethod
    async def log_action(
        admin_id: str,
        admin_email: str,
        action_type: str,
        target_type: Optional[str] = None,
        target_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> Dict[str, Any]:
        """Log an admin action to the audit trail"""
        supabase = get_supabase_client()
        
        audit_entry = {
            "admin_id": admin_id,
            "admin_email": admin_email,
            "action_type": action_type,
            "target_type": target_type,
            "target_id": target_id,
            "details": details or {},
            "ip_address": ip_address,
            "user_agent": user_agent,
            "created_at": datetime.utcnow().isoformat()
        }
        
        result = supabase.table("admin_audit_log").insert(audit_entry).execute()
        return result.data[0] if result.data else {}
    
    @staticmethod
    async def get_audit_logs(
        limit: int = 100,
        admin_id: Optional[str] = None,
        action_type: Optional[str] = None
    ) -> list:
        """Retrieve audit logs with optional filters"""
        supabase = get_supabase_client()
        
        query = supabase.table("admin_audit_log").select("*")
        
        if admin_id:
            query = query.eq("admin_id", admin_id)
        if action_type:
            query = query.eq("action_type", action_type)
        
        result = query.order("created_at", desc=True).limit(limit).execute()
        return result.data or []
