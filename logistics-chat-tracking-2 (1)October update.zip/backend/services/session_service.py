from datetime import datetime, timedelta
from typing import Optional, Dict
from supabase import create_client
import os

supabase_url = os.getenv("VITE_SUPABASE_URL", "")
supabase_key = os.getenv("VITE_SUPABASE_ANON_KEY", "")
supabase = create_client(supabase_url, supabase_key)

async def create_session(user_email: str, access_token: str, refresh_token: str, 
                         ip_address: str = None, user_agent: str = None) -> Dict:
    expires_at = datetime.utcnow() + timedelta(minutes=30)
    
    session_data = {
        "user_email": user_email,
        "access_token": access_token,
        "refresh_token": refresh_token,
        "ip_address": ip_address,
        "user_agent": user_agent,
        "expires_at": expires_at.isoformat(),
        "is_active": True
    }
    
    result = supabase.table("user_sessions").insert(session_data).execute()
    return result.data[0] if result.data else None

async def get_session_by_refresh_token(refresh_token: str) -> Optional[Dict]:
    result = supabase.table("user_sessions").select("*").eq("refresh_token", refresh_token).eq("is_active", True).execute()
    return result.data[0] if result.data else None

async def update_session_activity(session_id: str) -> bool:
    result = supabase.table("user_sessions").update({
        "last_activity": datetime.utcnow().isoformat()
    }).eq("id", session_id).execute()
    return bool(result.data)

async def invalidate_session(session_id: str) -> bool:
    result = supabase.table("user_sessions").update({
        "is_active": False
    }).eq("id", session_id).execute()
    return bool(result.data)

async def cleanup_expired_sessions():
    result = supabase.table("user_sessions").update({
        "is_active": False
    }).lt("expires_at", datetime.utcnow().isoformat()).execute()
    return result.data
