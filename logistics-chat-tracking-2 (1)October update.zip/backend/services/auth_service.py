from sqlalchemy.orm import Session
from backend.models import User, RefreshToken
from backend.services.jwt_service import (
    create_access_token, 
    create_refresh_token, 
    get_refresh_token_expiry,
    verify_access_token
)
from passlib.context import CryptContext
from datetime import datetime

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def authenticate_user(db: Session, email: str, password: str):
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(password, user.password_hash):
        return None
    return user

def create_tokens(db: Session, user: User):
    access_token = create_access_token({"sub": user.id, "email": user.email, "role": user.role})
    refresh_token_str = create_refresh_token()
    
    refresh_token = RefreshToken(
        user_id=user.id,
        token=refresh_token_str,
        expires_at=get_refresh_token_expiry()
    )
    db.add(refresh_token)
    db.commit()
    
    return access_token, refresh_token_str

def refresh_access_token(db: Session, refresh_token: str):
    token = db.query(RefreshToken).filter(
        RefreshToken.token == refresh_token,
        RefreshToken.revoked == False,
        RefreshToken.expires_at > datetime.utcnow()
    ).first()
    
    if not token:
        return None
    
    user = db.query(User).filter(User.id == token.user_id).first()
    if not user:
        return None
    
    access_token = create_access_token({"sub": user.id, "email": user.email, "role": user.role})
    return access_token

def revoke_refresh_token(db: Session, refresh_token: str):
    token = db.query(RefreshToken).filter(RefreshToken.token == refresh_token).first()
    if token:
        token.revoked = True
        db.commit()
