"""Complete admin operations service with all features"""
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from backend.core.supabase_client import get_supabase_client
from backend.services.audit_service import AuditService

async def suspend_user(
    user_id: str,
    user_email: str,
    reason: str,
    admin_id: str,
    admin_email: str,
    expires_hours: Optional[int] = None
) -> Dict[str, Any]:
    """Suspend a user account"""
    supabase = get_supabase_client()
    
    expires_at = None
    if expires_hours:
        expires_at = (datetime.utcnow() + timedelta(hours=expires_hours)).isoformat()
    
    suspension_data = {
        "user_id": user_id,
        "user_email": user_email,
        "reason": reason,
        "suspended_by": admin_id,
        "expires_at": expires_at,
        "is_active": True
    }
    
    result = supabase.table("suspended_users").insert(suspension_data).execute()
    
    await AuditService.log_action(
        admin_id=admin_id,
        admin_email=admin_email,
        action_type="USER_SUSPEND",
        target_type="user",
        target_id=user_id,
        details={"reason": reason, "expires_hours": expires_hours}
    )
    
    return result.data[0] if result.data else {}

async def unsuspend_user(user_id: str, admin_id: str, admin_email: str) -> Dict[str, Any]:
    """Unsuspend a user account"""
    supabase = get_supabase_client()
    
    result = supabase.table("suspended_users").update({"is_active": False}).eq("user_id", user_id).execute()
    
    await AuditService.log_action(
        admin_id=admin_id,
        admin_email=admin_email,
        action_type="USER_UNSUSPEND",
        target_type="user",
        target_id=user_id
    )
    
    return result.data[0] if result.data else {}
