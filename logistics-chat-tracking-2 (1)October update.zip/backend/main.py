from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from backend.config import CORS_ORIGINS, API_HOST, API_PORT
from backend.routes import auth_routes, dashboard_routes, revenue_routes, trust_account_routes, loadboard_routes
from backend.routes import api_key_routes, admin_routes, monitoring_routes, analytics_routes



from backend.docs.openapi_config import tags_metadata, custom_openapi_config
from backend.websocket_handler import manager, verify_websocket_token, broadcast_metrics, broadcast_revenue
from backend.database import init_db
import asyncio
import uvicorn

app = FastAPI(
    **custom_openapi_config,
    openapi_tags=tags_metadata,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Custom OpenAPI schema
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=custom_openapi_config["title"],
        version=custom_openapi_config["version"],
        description=custom_openapi_config["description"],
        routes=app.routes,
        tags=tags_metadata,
    )
    
    # Add security schemes
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Enter your JWT token from /api/auth/login"
        },
        "ApiKeyAuth": {
            "type": "apiKey",
            "in": "header",
            "name": "X-API-Key",
            "description": "Enter your API key from /api/api-keys/generate"
        }
    }
    
    # Add servers
    openapi_schema["servers"] = [
        {"url": "https://api.ai-xpress.com", "description": "Production"},
        {"url": "http://localhost:8000", "description": "Development"}
    ]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_routes.router)
app.include_router(dashboard_routes.router)
app.include_router(revenue_routes.router)
app.include_router(trust_account_routes.router)
app.include_router(loadboard_routes.router)
app.include_router(api_key_routes.router)
app.include_router(admin_routes.router)
app.include_router(monitoring_routes.router)
app.include_router(analytics_routes.router)



# WebSocket endpoints
@app.websocket("/ws/metrics")
async def websocket_metrics(websocket: WebSocket, token: str = Query(...)):
    """
    WebSocket endpoint for real-time metrics updates.
    
    Connect with your JWT token to receive live dashboard metrics every second.
    """
    payload = await verify_websocket_token(token)
    if not payload:
        await websocket.close(code=1008)
        return
    
    await manager.connect(websocket, "metrics")
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket, "metrics")

@app.websocket("/ws/revenue")
async def websocket_revenue(websocket: WebSocket, token: str = Query(...)):
    """
    WebSocket endpoint for real-time revenue updates.
    
    Receive live revenue data and platform breakdowns every second.
    """
    payload = await verify_websocket_token(token)
    if not payload:
        await websocket.close(code=1008)
        return
    
    await manager.connect(websocket, "revenue")
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket, "revenue")

@app.websocket("/ws/trust-accounts/{account_number}")
async def websocket_trust_account(websocket: WebSocket, account_number: str, token: str = Query(...)):
    """
    WebSocket endpoint for real-time trust account updates.
    
    Monitor specific trust account transactions and balance changes in real-time.
    """
    payload = await verify_websocket_token(token)
    if not payload:
        await websocket.close(code=1008)
        return
    
    await manager.connect(websocket, "trust_accounts", account_number)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket, "trust_accounts", account_number)

@app.on_event("startup")
async def startup_event():
    """Initialize database and start background tasks"""
    init_db()
    asyncio.create_task(broadcast_metrics())
    asyncio.create_task(broadcast_revenue())

@app.get("/", tags=["Health"])
async def root():
    """API health check endpoint"""
    return {
        "message": "AI-Xpress Platform API",
        "status": "operational",
        "version": "2.0.0",
        "docs": "/docs",
        "redoc": "/redoc"
    }

if __name__ == "__main__":
    uvicorn.run(app, host=API_HOST, port=API_PORT)
