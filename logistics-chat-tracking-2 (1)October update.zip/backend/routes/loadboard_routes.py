from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel, Field
from typing import List, Optional
from backend.database import get_db
from backend.middleware.auth import get_current_user
from backend.models import User
from backend.models_business import Load
from datetime import datetime

router = APIRouter(prefix="/api/loads", tags=["Loadboard"])

class BookLoadRequest(BaseModel):
    carrier_id: str = Field(..., description="Carrier identifier", example="CARRIER-12345")
    
    class Config:
        json_schema_extra = {
            "example": {
                "carrier_id": "CARRIER-12345"
            }
        }

class LoadResponse(BaseModel):
    id: str
    origin: str
    destination: str
    weight: float
    rate: float
    status: str
    pickup_date: str
    delivery_date: Optional[str]
    
    class Config:
        json_schema_extra = {
            "example": {
                "id": "LOAD-001",
                "origin": "Los Angeles, CA",
                "destination": "New York, NY",
                "weight": 45000.0,
                "rate": 5500.00,
                "status": "available",
                "pickup_date": "2025-10-15T08:00:00Z",
                "delivery_date": "2025-10-18T17:00:00Z"
            }
        }

class LoadAnalytics(BaseModel):
    totalLoads: int = Field(..., example=150)
    availableLoads: int = Field(..., example=75)
    bookedLoads: int = Field(..., example=60)
    totalRevenue: float = Field(..., example=825000.00)

@router.get("", response_model=List[LoadResponse])
async def get_loads(
    status: Optional[str] = Query(None, description="Filter by status (available, booked, delivered)"),
    db: Session = Depends(get_db)
):
    """
    Get all available loads.
    
    Returns a list of freight loads with origin, destination, weight, rate, and status.
    Can be filtered by status parameter.
    
    **Public Endpoint** - No authentication required for viewing loads.
    
    **Use Case:** Loadboard display, carrier search, freight matching
    """
    query = db.query(Load)
    if status:
        query = query.filter(Load.status == status)
    
    loads = query.all()
    return [
        {
            "id": load.id,
            "origin": load.origin,
            "destination": load.destination,
            "weight": load.weight,
            "rate": load.rate,
            "status": load.status,
            "pickup_date": load.pickup_date.isoformat(),
            "delivery_date": load.delivery_date.isoformat() if load.delivery_date else None
        }
        for load in loads
    ]

@router.post("/{load_id}/book")
async def book_load(
    load_id: str,
    request: BookLoadRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Book a freight load.
    
    Assigns a carrier to an available load and updates status to 'booked'.
    
    **Requirements:**
    - Load must be in 'available' status
    - Valid carrier ID required
    - Authentication required
    
    **Returns:** Confirmation message with load ID
    """
    load = db.query(Load).filter(Load.id == load_id).first()
    if not load:
        raise HTTPException(status_code=404, detail="Load not found")
    
    if load.status != "available":
        raise HTTPException(
            status_code=400, 
            detail=f"Load not available. Current status: {load.status}"
        )
    
    load.status = "booked"
    load.carrier_id = request.carrier_id
    db.commit()
    
    return {"message": "Load booked successfully", "load_id": load_id}

@router.get("/analytics", response_model=LoadAnalytics)
async def get_load_analytics(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get comprehensive loadboard analytics.
    
    Returns:
    - Total loads in system
    - Available loads count
    - Booked loads count
    - Total revenue from all loads
    
    **Use Case:** Business intelligence, capacity planning, revenue forecasting
    """
    total_loads = db.query(func.count(Load.id)).scalar() or 0
    available_loads = db.query(func.count(Load.id)).filter(Load.status == "available").scalar() or 0
    booked_loads = db.query(func.count(Load.id)).filter(Load.status == "booked").scalar() or 0
    total_revenue = db.query(func.sum(Load.rate)).scalar() or 0
    
    return {
        "totalLoads": total_loads,
        "availableLoads": available_loads,
        "bookedLoads": booked_loads,
        "totalRevenue": float(total_revenue)
    }
