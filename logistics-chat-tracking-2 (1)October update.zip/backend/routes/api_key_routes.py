"""
API Key management routes
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime, timedelta
from backend.database import get_db
from backend.models_api_keys import APIKey
from backend.middleware.auth import get_current_user

router = APIRouter(prefix="/api/api-keys", tags=["API Keys"])

class APIKeyCreate(BaseModel):
    name: str = Field(..., description="Friendly name for the API key", example="Production Integration")
    expires_days: Optional[int] = Field(365, description="Days until expiration (null for no expiration)", example=365)
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "Production Integration",
                "expires_days": 365
            }
        }

class APIKeyResponse(BaseModel):
    id: int
    name: str
    key_prefix: str
    is_active: bool
    created_at: datetime
    expires_at: Optional[datetime]
    last_used_at: Optional[datetime]
    
    class Config:
        from_attributes = True

class APIKeyCreateResponse(BaseModel):
    key: str = Field(..., description="Full API key - save this securely, it won't be shown again!")
    api_key: APIKeyResponse

@router.post("/generate", response_model=APIKeyCreateResponse, status_code=status.HTTP_201_CREATED)
async def generate_api_key(
    key_data: APIKeyCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Generate a new API key for third-party integrations.
    
    **Important**: Save the returned key securely - it cannot be retrieved later!
    """
    key = APIKey.generate_key()
    key_hash = APIKey.hash_key(key)
    
    expires_at = None
    if key_data.expires_days:
        expires_at = datetime.utcnow() + timedelta(days=key_data.expires_days)
    
    api_key = APIKey(
        user_id=current_user["user_id"],
        name=key_data.name,
        key_hash=key_hash,
        key_prefix=key[:12],
        expires_at=expires_at
    )
    
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    
    return {"key": key, "api_key": api_key}

@router.get("/", response_model=List[APIKeyResponse])
async def list_api_keys(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all API keys for the current user"""
    keys = db.query(APIKey).filter(APIKey.user_id == current_user["user_id"]).all()
    return keys

@router.delete("/{key_id}")
async def revoke_api_key(
    key_id: int,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Revoke an API key"""
    api_key = db.query(APIKey).filter(
        APIKey.id == key_id,
        APIKey.user_id == current_user["user_id"]
    ).first()
    
    if not api_key:
        raise HTTPException(status_code=404, detail="API key not found")
    
    api_key.is_active = False
    db.commit()
    
    return {"message": "API key revoked successfully"}
