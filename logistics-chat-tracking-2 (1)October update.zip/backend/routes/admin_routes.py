"""Admin operations API routes"""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from typing import Optional, List
from backend.services.admin_operations import AdminOperationsService
from backend.services.admin_operations_complete import suspend_user, unsuspend_user
from backend.services.audit_service import AuditService
from backend.core.supabase_client import get_supabase_client

router = APIRouter(prefix="/api/admin", tags=["admin"])

class BlockIPRequest(BaseModel):
    ip_address: str = Field(..., description="IP address to block")
    reason: str = Field(..., description="Reason for blocking")
    expires_hours: Optional[int] = Field(None, description="Hours until expiry")
    admin_id: str
    admin_email: str

class SuspendUserRequest(BaseModel):
    user_id: str
    user_email: str
    reason: str
    expires_hours: Optional[int] = None
    admin_id: str
    admin_email: str

class EditPaymentRequest(BaseModel):
    payment_id: str
    new_amount: Optional[float] = None
    new_status: Optional[str] = None
    reason: str
    admin_id: str
    admin_email: str

@router.post("/block-ip")
async def block_ip_endpoint(request: BlockIPRequest):
    """Block an IP address"""
    try:
        result = await AdminOperationsService.block_ip(
            ip_address=request.ip_address,
            reason=request.reason,
            admin_id=request.admin_id,
            admin_email=request.admin_email,
            expires_hours=request.expires_hours
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/unblock-ip/{ip_address}")
async def unblock_ip_endpoint(ip_address: str, admin_id: str, admin_email: str):
    """Unblock an IP address"""
    result = await AdminOperationsService.unblock_ip(ip_address, admin_id, admin_email)
    return {"success": True, "data": result}

@router.post("/suspend-user")
async def suspend_user_endpoint(request: SuspendUserRequest):
    """Suspend a user account"""
    try:
        result = await suspend_user(
            user_id=request.user_id,
            user_email=request.user_email,
            reason=request.reason,
            admin_id=request.admin_id,
            admin_email=request.admin_email,
            expires_hours=request.expires_hours
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/unsuspend-user/{user_id}")
async def unsuspend_user_endpoint(user_id: str, admin_id: str, admin_email: str):
    """Unsuspend a user account"""
    result = await unsuspend_user(user_id, admin_id, admin_email)
    return {"success": True, "data": result}

@router.post("/edit-payment")
async def edit_payment_endpoint(request: EditPaymentRequest):
    """Edit payment details"""
    try:
        supabase = get_supabase_client()
        
        override_data = {
            "payment_id": request.payment_id,
            "new_amount": request.new_amount,
            "new_status": request.new_status,
            "reason": request.reason,
            "modified_by": request.admin_id
        }
        
        result = supabase.table("payment_overrides").insert(override_data).execute()
        
        await AuditService.log_action(
            admin_id=request.admin_id,
            admin_email=request.admin_email,
            action_type="PAYMENT_EDIT",
            target_type="payment",
            target_id=request.payment_id,
            details={"new_amount": request.new_amount, "new_status": request.new_status, "reason": request.reason}
        )
        
        return {"success": True, "data": result.data[0] if result.data else {}}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/audit-logs")
async def get_audit_logs(limit: int = 100, admin_id: Optional[str] = None, action_type: Optional[str] = None):
    """Get audit logs"""
    logs = await AuditService.get_audit_logs(limit=limit, admin_id=admin_id, action_type=action_type)
    return {"success": True, "data": logs}

@router.get("/blocked-ips")
async def get_blocked_ips():
    """Get all blocked IPs"""
    supabase = get_supabase_client()
    result = supabase.table("blocked_ips").select("*").eq("is_active", True).execute()
    return {"success": True, "data": result.data or []}

@router.get("/suspended-users")
async def get_suspended_users():
    """Get all suspended users"""
    supabase = get_supabase_client()
    result = supabase.table("suspended_users").select("*").eq("is_active", True).execute()
    return {"success": True, "data": result.data or []}
