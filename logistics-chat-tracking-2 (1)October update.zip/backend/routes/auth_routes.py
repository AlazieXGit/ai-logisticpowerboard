from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr, Field
from backend.database import get_db
from backend.services.auth_service import (
    authenticate_user,
    create_tokens,
    refresh_access_token,
    revoke_refresh_token
)
from backend.middleware.auth import get_current_user
from backend.models import User

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

class LoginRequest(BaseModel):
    email: EmailStr = Field(..., description="User email address", example="admin@ai-xpress.com")
    password: str = Field(..., description="User password", example="SecurePass123!")
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "admin@ai-xpress.com",
                "password": "SecurePass123!"
            }
        }

class RefreshRequest(BaseModel):
    refresh_token: str = Field(..., description="Refresh token received from login")
    
    class Config:
        json_schema_extra = {
            "example": {
                "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
            }
        }

class UserResponse(BaseModel):
    id: int
    email: str
    role: str

class TokenResponse(BaseModel):
    access_token: str = Field(..., description="JWT access token (expires in 30 minutes)")
    refresh_token: str = Field(..., description="Refresh token (expires in 7 days)")
    user: UserResponse
    
    class Config:
        json_schema_extra = {
            "example": {
                "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNjk5OTk5OTk5fQ...",
                "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2gifQ...",
                "user": {
                    "id": 1,
                    "email": "admin@ai-xpress.com",
                    "role": "admin"
                }
            }
        }

@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    """
    Authenticate user and receive JWT tokens.
    
    Returns both access and refresh tokens. Use the access token for API requests.
    When the access token expires, use the refresh token to get a new one.
    
    **Test Credentials:**
    - Email: admin@ai-xpress.com
    - Password: admin123
    """
    user = authenticate_user(db, request.email, request.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password"
        )
    
    access_token, refresh_token = create_tokens(db, user)
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "user": {"id": user.id, "email": user.email, "role": user.role}
    }

@router.post("/refresh")
async def refresh(request: RefreshRequest, db: Session = Depends(get_db)):
    """
    Refresh access token using refresh token.
    
    When your access token expires, use this endpoint with your refresh token
    to get a new access token without requiring the user to log in again.
    """
    access_token = refresh_access_token(db, request.refresh_token)
    if not access_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token"
        )
    return {"access_token": access_token}

@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(
    request: RefreshRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Logout user by revoking refresh token.
    
    This invalidates the refresh token, preventing it from being used to generate
    new access tokens. The current access token will remain valid until it expires.
    """
    revoke_refresh_token(db, request.refresh_token)
    return None
