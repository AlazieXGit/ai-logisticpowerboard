from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from typing import Optional
from backend.middleware.auth import get_current_user
from backend.services.business_logic import get_live_analytics

router = APIRouter(prefix="/api/analytics", tags=["Analytics"])

class AnalyticsReport(BaseModel):
    liveTransactions: int = Field(..., example=1250)
    actualVolume: float = Field(..., example=2500000.50)
    realUserActivity: int = Field(..., example=150)
    systemPerformance: float = Field(..., example=98.5)
    errorRate: float = Field(..., example=0.5)
    uptimePercentage: float = Field(..., example=99.5)
    dataIntegrity: float = Field(..., example=98.5)
    timestamp: str = Field(..., example="2025-10-13T17:22:00Z")

@router.get("/report", response_model=AnalyticsReport)
async def get_analytics_report(
    current_user: dict = Depends(get_current_user),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None)
):
    """
    Get comprehensive analytics report from live data.
    
    Aggregates real-time metrics from Supabase including:
    - Transaction counts and volumes
    - User activity metrics
    - System performance indicators
    - Data integrity scores
    
    **Authentication Required:** Bearer token or API key
    """
    analytics = get_live_analytics(start_date, end_date)
    return analytics
