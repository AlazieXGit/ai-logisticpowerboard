"""
Feature Monitoring API Routes
"""
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime, timedelta
from backend.core.supabase_client import get_supabase_client
from backend.services.feature_monitoring_service import monitoring_service

router = APIRouter(prefix="/api/monitoring", tags=["Feature Monitoring"])

class MetricRequest(BaseModel):
    feature_name: str
    metric_type: str
    metric_value: float
    user_id: Optional[str] = None
    metadata: Optional[Dict] = {}

class ErrorRequest(BaseModel):
    feature_name: str
    error_type: str
    error_message: str
    severity: str = 'medium'
    user_id: Optional[str] = None
    error_stack: Optional[str] = None

class PerformanceRequest(BaseModel):
    feature_name: str
    operation_name: str
    duration_ms: float
    success: bool = True
    user_id: Optional[str] = None

@router.get("/dashboard")
async def get_dashboard_data(time_window: int = 60):
    """Get comprehensive monitoring dashboard data"""
    try:
        supabase = get_supabase_client()
        window_start = datetime.utcnow() - timedelta(minutes=time_window)
        
        # Get feature health with error handling
        try:
            health_result = supabase.table('feature_health').select('*').execute()
            health_data = health_result.data if health_result.data else []
        except:
            health_data = []
        
        # Get recent alerts
        try:
            alerts_result = supabase.table('feature_alerts')\
                .select('*')\
                .eq('resolved', False)\
                .order('created_at', desc=True)\
                .limit(20)\
                .execute()
            alerts_data = alerts_result.data if alerts_result.data else []
        except:
            alerts_data = []
        
        # Get recent errors grouped by feature
        try:
            errors_result = supabase.table('feature_errors')\
                .select('feature_name, error_type, severity, created_at')\
                .gte('created_at', window_start.isoformat())\
                .order('created_at', desc=True)\
                .limit(100)\
                .execute()
            errors_data = errors_result.data if errors_result.data else []
        except:
            errors_data = []
        
        # Get performance metrics
        try:
            perf_result = supabase.table('feature_performance')\
                .select('feature_name, operation_name, duration_ms, success')\
                .gte('created_at', window_start.isoformat())\
                .execute()
            perf_data = perf_result.data if perf_result.data else []
        except:
            perf_data = []
        
        # Get adoption metrics
        try:
            adoption_result = supabase.table('feature_adoption')\
                .select('*')\
                .order('usage_count', desc=True)\
                .limit(20)\
                .execute()
            adoption_data = adoption_result.data if adoption_result.data else []
        except:
            adoption_data = []
        
        # Calculate summary statistics
        total_errors = len(errors_data)
        critical_errors = len([e for e in errors_data if e.get('severity') == 'critical'])
        avg_response_time = sum([p.get('duration_ms', 0) for p in perf_data]) / len(perf_data) if perf_data else 0
        
        # Format features data for frontend
        features = []
        feature_names = set([h.get('feature_name') for h in health_data])
        
        for fname in feature_names:
            feature_health = next((h for h in health_data if h.get('feature_name') == fname), {})
            feature_errors = [e for e in errors_data if e.get('feature_name') == fname]
            feature_perf = [p for p in perf_data if p.get('feature_name') == fname]
            feature_adoption = next((a for a in adoption_data if a.get('feature_name') == fname), {})
            
            # Calculate health score from available metrics
            health_score = 100.0
            if feature_health.get('error_rate'):
                health_score -= min(feature_health.get('error_rate', 0) * 5, 50)
            
            features.append({
                'name': fname,
                'status': feature_health.get('status', 'active'),
                'health': round(health_score, 1),
                'uptime': float(feature_health.get('uptime_percentage', 100.0)),
                'errorRate': float(feature_health.get('error_rate', 0.0)),
                'responseTime': float(feature_health.get('avg_response_time', 0.0)),
                'totalUsers': feature_adoption.get('total_users', feature_health.get('active_users', 0)),
                'activeUsers': feature_health.get('active_users', 0),
                'lastError': feature_errors[0].get('created_at') if feature_errors else None,
                'errorCount': len(feature_errors)
            })

        
        return {
            'success': True,
            'features': features,
            'summary': {
                'totalFeatures': len(features),
                'activeFeatures': len([f for f in features if f['status'] == 'active']),
                'totalErrors': total_errors,
                'criticalErrors': critical_errors,
                'avgResponseTime': round(avg_response_time, 2)
            },
            'alerts': alerts_data,
            'recentErrors': errors_data[:20],
            'timestamp': datetime.utcnow().isoformat()
        }
    except Exception as e:
        # Return error in JSON format, not HTML
        return {
            'success': False,
            'error': str(e),
            'features': [],
            'summary': {
                'totalFeatures': 0,
                'activeFeatures': 0,
                'totalErrors': 0,
                'criticalErrors': 0,
                'avgResponseTime': 0
            },
            'alerts': [],
            'recentErrors': [],
            'timestamp': datetime.utcnow().isoformat()
        }


@router.get("/features/{feature_name}/health")
async def get_feature_health(feature_name: str):
    """Get detailed health metrics for a specific feature"""
    try:
        supabase = get_supabase_client()
        
        health = supabase.table('feature_health')\
            .select('*')\
            .eq('feature_name', feature_name)\
            .single()\
            .execute()
        
        return health.data
    except Exception as e:
        raise HTTPException(status_code=404, detail="Feature not found")

@router.get("/features/{feature_name}/metrics")
async def get_feature_metrics(feature_name: str, time_window: int = 60):
    """Get metrics for a specific feature"""
    try:
        supabase = get_supabase_client()
        window_start = datetime.utcnow() - timedelta(minutes=time_window)
        
        metrics = supabase.table('feature_metrics')\
            .select('*')\
            .eq('feature_name', feature_name)\
            .gte('timestamp', window_start.isoformat())\
            .order('timestamp', desc=True)\
            .execute()
        
        return {'metrics': metrics.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/features/{feature_name}/errors")
async def get_feature_errors(feature_name: str, limit: int = 50):
    """Get recent errors for a specific feature"""
    try:
        supabase = get_supabase_client()
        
        errors = supabase.table('feature_errors')\
            .select('*')\
            .eq('feature_name', feature_name)\
            .order('created_at', desc=True)\
            .limit(limit)\
            .execute()
        
        return {'errors': errors.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/track/usage")
async def track_usage(request: MetricRequest):
    """Track feature usage"""
    await monitoring_service.track_usage(
        request.feature_name,
        request.user_id,
        metadata=request.metadata
    )
    return {'success': True}

@router.post("/track/error")
async def track_error(request: ErrorRequest):
    """Track feature error"""
    await monitoring_service.track_error(
        request.feature_name,
        request.error_type,
        request.error_message,
        request.severity,
        request.user_id,
        error_stack=request.error_stack
    )
    return {'success': True}

@router.post("/track/performance")
async def track_performance(request: PerformanceRequest):
    """Track feature performance"""
    await monitoring_service.track_performance(
        request.feature_name,
        request.operation_name,
        request.duration_ms,
        request.success,
        user_id=request.user_id
    )
    return {'success': True}

@router.get("/alerts")
async def get_alerts(resolved: bool = False, limit: int = 50):
    """Get feature alerts"""
    try:
        supabase = get_supabase_client()
        
        query = supabase.table('feature_alerts')\
            .select('*')\
            .eq('resolved', resolved)\
            .order('created_at', desc=True)\
            .limit(limit)
        
        result = query.execute()
        return {'alerts': result.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str, admin_id: str):
    """Acknowledge an alert"""
    try:
        supabase = get_supabase_client()
        
        supabase.table('feature_alerts').update({
            'acknowledged': True,
            'acknowledged_by': admin_id,
            'acknowledged_at': datetime.utcnow().isoformat()
        }).eq('id', alert_id).execute()
        
        return {'success': True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/adoption")
async def get_adoption_metrics():
    """Get feature adoption metrics"""
    try:
        supabase = get_supabase_client()
        
        adoption = supabase.table('feature_adoption')\
            .select('*')\
            .order('usage_count', desc=True)\
            .execute()
        
        return {'adoption': adoption.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
