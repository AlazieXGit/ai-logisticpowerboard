from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from typing import List
from backend.database import get_db
from backend.middleware.auth import get_current_user
from backend.models import User
from backend.models_business import TrustAccount
from datetime import datetime

router = APIRouter(prefix="/api/trust-accounts", tags=["Trust Accounts"])

class TrustAccountCreate(BaseModel):
    account_name: str = Field(..., description="Account holder name", example="ABC Logistics Trust")
    account_number: str = Field(..., description="Bank account number", example="1234567890")
    routing_number: str = Field(..., description="Bank routing number", example="021000021")
    balance: float = Field(0.0, description="Initial balance", example=50000.00)
    currency: str = Field("USD", description="Currency code", example="USD")
    
    class Config:
        json_schema_extra = {
            "example": {
                "account_name": "ABC Logistics Trust",
                "account_number": "1234567890",
                "routing_number": "021000021",
                "balance": 50000.00,
                "currency": "USD"
            }
        }

class TrustAccountResponse(BaseModel):
    id: int
    account_name: str
    account_number: str
    routing_number: str
    balance: float
    currency: str
    created_at: str
    
    class Config:
        json_schema_extra = {
            "example": {
                "id": 1,
                "account_name": "ABC Logistics Trust",
                "account_number": "1234567890",
                "routing_number": "021000021",
                "balance": 50000.00,
                "currency": "USD",
                "created_at": "2025-10-13T03:23:00Z"
            }
        }

@router.get("", response_model=List[TrustAccountResponse])
async def get_trust_accounts(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all trust accounts.
    
    Returns a list of all trust accounts in the system with their
    current balances and account information.
    
    **Use Case:** Financial overview, account management, reconciliation
    """
    accounts = db.query(TrustAccount).all()
    return [
        {
            "id": acc.id,
            "account_name": acc.account_name,
            "account_number": acc.account_number,
            "routing_number": acc.routing_number,
            "balance": acc.balance,
            "currency": acc.currency,
            "created_at": acc.created_at.isoformat()
        }
        for acc in accounts
    ]

@router.get("/{account_number}", response_model=TrustAccountResponse)
async def get_trust_account(
    account_number: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get single trust account by account number.
    
    Retrieve detailed information about a specific trust account
    including current balance and transaction history.
    """
    account = db.query(TrustAccount).filter(
        TrustAccount.account_number == account_number
    ).first()
    
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    
    return {
        "id": account.id,
        "account_name": account.account_name,
        "account_number": account.account_number,
        "routing_number": account.routing_number,
        "balance": account.balance,
        "currency": account.currency,
        "created_at": account.created_at.isoformat()
    }

@router.post("", status_code=status.HTTP_201_CREATED)
async def create_trust_account(
    account: TrustAccountCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Create new trust account.
    
    Establishes a new trust account in the system for holding client funds.
    Requires admin privileges.
    
    **Important:** Ensure account and routing numbers are valid before creation.
    """
    # Check for duplicate account number
    existing = db.query(TrustAccount).filter(
        TrustAccount.account_number == account.account_number
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Account number already exists"
        )
    
    new_account = TrustAccount(**account.dict())
    db.add(new_account)
    db.commit()
    db.refresh(new_account)
    return {"id": new_account.id, "message": "Account created successfully"}
