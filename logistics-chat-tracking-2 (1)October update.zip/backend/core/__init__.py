# Backend core module
