from sqlalchemy import Column, String, Integer, Float, DateTime, Boolean, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import uuid

Base = declarative_base()

def generate_uuid():
    return str(uuid.uuid4())

class TrustAccount(Base):
    __tablename__ = "trust_accounts"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    account_name = Column(String, nullable=False)
    account_number = Column(String, unique=True, nullable=False, index=True)
    routing_number = Column(String, nullable=False)
    balance = Column(Float, default=0.0)
    currency = Column(String, default="USD")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Load(Base):
    __tablename__ = "loads"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    origin = Column(String, nullable=False)
    destination = Column(String, nullable=False)
    weight = Column(Float, nullable=False)
    rate = Column(Float, nullable=False)
    status = Column(String, default="available")
    pickup_date = Column(DateTime, nullable=False)
    delivery_date = Column(DateTime)
    carrier_id = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
