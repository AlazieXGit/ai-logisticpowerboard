"""Seed database with initial data"""
from backend.database import SessionLocal
from backend.models import User
from backend.models_business import TrustAccount, Load
from backend.services.auth_service import hash_password
from datetime import datetime, timedelta

def seed_database():
    db = SessionLocal()
    
    # Create admin user
    admin = User(
        email="admin@xpress.com",
        password_hash=hash_password("admin123"),
        role="admin"
    )
    db.add(admin)
    
    # Create test user
    user = User(
        email="user@xpress.com",
        password_hash=hash_password("user123"),
        role="user"
    )
    db.add(user)
    
    # Create trust accounts
    accounts = [
        TrustAccount(account_name="Main Operating", account_number="1234567890", routing_number="021000021", balance=150000.0),
        TrustAccount(account_name="Revenue Account", account_number="0987654321", routing_number="021000021", balance=75000.0),
    ]
    for acc in accounts:
        db.add(acc)
    
    # Create loads
    loads = [
        Load(origin="Los Angeles, CA", destination="New York, NY", weight=20000, rate=3500, status="available", pickup_date=datetime.now() + timedelta(days=2)),
        Load(origin="Chicago, IL", destination="Miami, FL", weight=15000, rate=2800, status="available", pickup_date=datetime.now() + timedelta(days=1)),
    ]
    for load in loads:
        db.add(load)
    
    db.commit()
    print("✅ Database seeded successfully")

if __name__ == "__main__":
    seed_database()
