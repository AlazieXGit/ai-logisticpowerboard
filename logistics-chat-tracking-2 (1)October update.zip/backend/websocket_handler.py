from fastapi import WebSocket, WebSocketDisconnect, Query
from typing import Dict, Set
from sqlalchemy.orm import Session
from backend.services.jwt_service import verify_access_token
from backend.database import SessionLocal
from backend.models_business import TrustAccount, Load
from sqlalchemy import func
import asyncio
import json

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {
            "metrics": set(),
            "revenue": set(),
            "trust_accounts": {}
        }
    
    async def connect(self, websocket: WebSocket, channel: str, identifier: str = None):
        await websocket.accept()
        if identifier:
            if identifier not in self.active_connections[channel]:
                self.active_connections[channel][identifier] = set()
            self.active_connections[channel][identifier].add(websocket)
        else:
            self.active_connections[channel].add(websocket)
    
    def disconnect(self, websocket: WebSocket, channel: str, identifier: str = None):
        if identifier:
            if identifier in self.active_connections[channel]:
                self.active_connections[channel][identifier].discard(websocket)
        else:
            self.active_connections[channel].discard(websocket)
    
    async def broadcast(self, message: dict, channel: str, identifier: str = None):
        if identifier and identifier in self.active_connections[channel]:
            connections = self.active_connections[channel][identifier]
        elif not identifier and channel in self.active_connections:
            connections = self.active_connections[channel]
        else:
            return
        
        for connection in connections.copy():
            try:
                await connection.send_json(message)
            except:
                connections.discard(connection)

manager = ConnectionManager()

async def verify_websocket_token(token: str):
    """Verify WebSocket JWT token"""
    try:
        payload = verify_access_token(token)
        return payload
    except:
        return None

async def broadcast_metrics():
    """Broadcast system metrics periodically"""
    while True:
        db = SessionLocal()
        try:
            transactions = db.query(func.count(Load.id)).scalar() or 0
            revenue = db.query(func.sum(TrustAccount.balance)).scalar() or 0
            
            await manager.broadcast({
                "transactions": transactions,
                "revenue": float(revenue),
                "timestamp": asyncio.get_event_loop().time()
            }, "metrics")
        finally:
            db.close()
        
        await asyncio.sleep(5)

async def broadcast_revenue():
    """Broadcast revenue updates periodically"""
    while True:
        db = SessionLocal()
        try:
            total = db.query(func.sum(TrustAccount.balance)).scalar() or 0
            
            await manager.broadcast({
                "total": float(total),
                "timestamp": asyncio.get_event_loop().time()
            }, "revenue")
        finally:
            db.close()
        
        await asyncio.sleep(3)
