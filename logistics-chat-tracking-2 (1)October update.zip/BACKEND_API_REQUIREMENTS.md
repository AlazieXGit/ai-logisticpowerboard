# Backend API Requirements for Production

## Overview
This document lists all API endpoints required by the frontend for production deployment.

## 🔐 Authentication Endpoints

### POST /api/auth/login
**Request:**
```json
{
  "email": "string",
  "password": "string"
}
```
**Response:**
```json
{
  "access_token": "string",
  "refresh_token": "string",
  "user": { "id": "string", "email": "string", "role": "string" }
}
```

### POST /api/auth/refresh
**Request:**
```json
{
  "refresh_token": "string"
}
```
**Response:**
```json
{
  "access_token": "string"
}
```

### POST /api/auth/logout
**Headers:** `Authorization: Bearer {token}`
**Response:** `204 No Content`

## 📊 Dashboard & Analytics

### GET /api/dashboard/metrics
**Headers:** `Authorization: Bearer {token}`
**Response:**
```json
{
  "totalTransactions": 0,
  "totalVolume": 0,
  "userCount": 0,
  "platformRevenue": 0
}
```

### GET /api/analytics/realtime
**Headers:** `Authorization: Bearer {token}`
**Response:**
```json
{
  "liveTransactions": 0,
  "actualVolume": 0,
  "realUserActivity": 0,
  "systemPerformance": 0,
  "errorRate": 0,
  "uptimePercentage": 0,
  "dataIntegrity": 0
}
```

### GET /api/system/metrics
**Response:**
```json
{
  "transactions": 0,
  "revenue": 0,
  "activeUsers": 0,
  "systemLoad": 0,
  "timestamp": "ISO8601"
}
```

## 💰 Revenue & Trust Accounts

### GET /api/revenue/summary
**Headers:** `Authorization: Bearer {token}`
**Response:**
```json
{
  "total": 0,
  "totalTransactions": 0,
  "platforms": [
    {
      "name": "string",
      "revenue": 0,
      "percentage": 0,
      "transactions": 0,
      "hourlyRate": 0,
      "status": "string"
    }
  ]
}
```

### GET /api/trust-accounts
**Headers:** `Authorization: Bearer {token}`
**Response:**
```json
[
  {
    "id": "string",
    "account_name": "string",
    "account_number": "string",
    "routing_number": "string",
    "balance": 0,
    "currency": "USD",
    "created_at": "ISO8601"
  }
]
```

### GET /api/trust-accounts/{account_number}
**Response:** Single trust account object

### POST /api/trust-accounts
**Request:**
```json
{
  "account_name": "string",
  "account_number": "string",
  "routing_number": "string",
  "balance": 0,
  "currency": "USD"
}
```

## 🚛 Loadboard

### GET /api/loads
**Response:**
```json
[
  {
    "id": "string",
    "origin": "string",
    "destination": "string",
    "weight": 0,
    "rate": 0,
    "status": "available",
    "pickup_date": "ISO8601",
    "delivery_date": "ISO8601"
  }
]
```

### POST /api/loads/{load_id}/book
**Request:**
```json
{
  "carrier_id": "string"
}
```

### GET /api/loads/analytics
**Response:** Load analytics data

## 🔌 WebSocket Endpoints

### WS /ws/metrics
Real-time system metrics updates

### WS /ws/revenue
Real-time revenue updates

### WS /ws/trust-accounts/{account_number}
Real-time trust account balance updates

## 📝 Notes

- All endpoints require JWT authentication except public endpoints
- WebSocket connections require token in query param: `?token={jwt}`
- All timestamps in ISO8601 format
- All monetary values in cents/smallest currency unit
