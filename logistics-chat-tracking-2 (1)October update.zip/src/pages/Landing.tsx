import React from 'react';
import LandingPage from '@/components/LandingPage';
import FeatureShowcase from '@/components/FeatureShowcase';

const Landing: React.FC = () => {
  return (
    <div className="min-h-screen">
      <LandingPage />
      <FeatureShowcase />
    </div>
  );
};

export default Landing;