import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Ban, Shield, AlertTriangle } from 'lucide-react';

const BlockedAccess: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full space-y-6">
        {/* Main Alert */}
        <Alert className="border-red-500 bg-red-900/20">
          <Ban className="h-4 w-4" />
          <AlertDescription className="text-red-300">
            🚫 IMMEDIATE SYSTEM LOCKOUT - IP 192.168.1.100 BLOCKED
          </AlertDescription>
        </Alert>

        {/* Blocked Access Card */}
        <Card className="bg-black/80 border-red-500">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2 text-center justify-center">
              <Shield className="h-8 w-8" />
              ACCESS PERMANENTLY DENIED
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="bg-red-900/20 p-6 rounded border border-red-500">
              <Ban className="h-16 w-16 mx-auto mb-4 text-red-400" />
              <h2 className="text-2xl font-bold text-red-400 mb-2">
                ACCOUNT LOCKED OUT
              </h2>
              <p className="text-gray-300">
                This IP address has been immediately blocked from all system access.
              </p>
            </div>

            <div className="space-y-4 text-left">
              <div className="flex items-center gap-3 text-red-300">
                <AlertTriangle className="h-5 w-5" />
                <span>IP Address: 192.168.1.100</span>
              </div>
              <div className="flex items-center gap-3 text-red-300">
                <AlertTriangle className="h-5 w-5" />
                <span>Status: PERMANENTLY BLOCKED</span>
              </div>
              <div className="flex items-center gap-3 text-red-300">
                <AlertTriangle className="h-5 w-5" />
                <span>Reason: Immediate lockout by Super Admin</span>
              </div>
              <div className="flex items-center gap-3 text-red-300">
                <AlertTriangle className="h-5 w-5" />
                <span>Timestamp: {new Date().toLocaleString()}</span>
              </div>
            </div>

            <div className="bg-gray-900/50 p-4 rounded border border-gray-600">
              <h3 className="text-gray-300 font-semibold mb-2">Security Notice:</h3>
              <ul className="text-sm text-gray-400 space-y-1 text-left">
                <li>• All access attempts are logged and monitored</li>
                <li>• This action was taken by Super Admin Alucius Alford</li>
                <li>• No further access will be permitted from this IP</li>
                <li>• Contact system administrator for assistance</li>
              </ul>
            </div>

            <div className="text-xs text-gray-500">
              Incident ID: BLOCK-{Date.now()}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BlockedAccess;