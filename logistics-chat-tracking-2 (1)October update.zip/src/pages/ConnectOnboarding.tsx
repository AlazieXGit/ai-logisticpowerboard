import StripeConnectOnboarding from '@/components/StripeConnectOnboarding'

export default function ConnectOnboarding() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
      <StripeConnectOnboarding />
    </div>
  )
}
