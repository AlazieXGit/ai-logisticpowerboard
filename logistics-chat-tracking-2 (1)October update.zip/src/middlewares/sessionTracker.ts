import { supabase } from '@/lib/supabase';

interface SessionData {
  userId: string;
  username: string;
  ipAddress: string;
  userAgent: string;
  timestamp: string;
  action: string;
}

interface ThreatIncident {
  userId: string;
  incidentType: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  details: string;
  timestamp: string;
}

class SessionTracker {
  private watchlist: Set<string> = new Set();
  private quarantinedUsers: Set<string> = new Set();
  private incidentCounts: Map<string, number> = new Map();
  private readonly QUARANTINE_THRESHOLD = 3;

  async trackSession(sessionData: SessionData): Promise<void> {
    try {
      // Send session data to Supabase function
      await supabase.functions.invoke('session-threat-monitor', {
        body: {
          action: 'track_session',
          user_id: sessionData.userId,
          session_data: sessionData
        }
      });

      // Check for anomalies
      await this.detectAnomalies(sessionData);
    } catch (error) {
      console.error('Session tracking error:', error);
    }
  }

  async detectAnomalies(sessionData: SessionData): Promise<void> {
    const { userId, ipAddress, action } = sessionData;

    // Detect suspicious patterns
    const suspiciousPatterns = [
      this.detectMultipleFailedLogins(userId, action),
      this.detectUnusualIPPattern(userId, ipAddress),
      this.detectRapidRequests(userId),
      this.detectOffHoursActivity(sessionData)
    ];

    const detectedThreats = suspiciousPatterns.filter(Boolean);

    if (detectedThreats.length > 0) {
      await this.recordThreatIncident({
        userId,
        incidentType: detectedThreats.join(', '),
        severity: this.calculateSeverity(detectedThreats.length),
        details: `Detected ${detectedThreats.length} suspicious patterns`,
        timestamp: new Date().toISOString()
      });
    }
  }

  private detectMultipleFailedLogins(userId: string, action: string): string | null {
    if (action === 'failed_login') {
      const key = `failed_login_${userId}`;
      const count = (this.incidentCounts.get(key) || 0) + 1;
      this.incidentCounts.set(key, count);
      
      if (count >= 3) {
        return 'Multiple Failed Login Attempts';
      }
    }
    return null;
  }

  private detectUnusualIPPattern(userId: string, ipAddress: string): string | null {
    // Simple IP pattern detection (in real implementation, use geolocation)
    const privateIPRanges = [
      /^10\./,
      /^192\.168\./,
      /^172\.(1[6-9]|2[0-9]|3[0-1])\./
    ];

    const isPrivateIP = privateIPRanges.some(range => range.test(ipAddress));
    if (!isPrivateIP && ipAddress !== '127.0.0.1') {
      return 'Unusual IP Address Pattern';
    }
    return null;
  }

  private detectRapidRequests(userId: string): string | null {
    const key = `rapid_requests_${userId}`;
    const now = Date.now();
    const requests = this.incidentCounts.get(key) || 0;
    
    // Reset counter every minute
    setTimeout(() => {
      this.incidentCounts.set(key, 0);
    }, 60000);

    if (requests > 50) {
      return 'Rapid Request Pattern';
    }
    
    this.incidentCounts.set(key, requests + 1);
    return null;
  }

  private detectOffHoursActivity(sessionData: SessionData): string | null {
    const hour = new Date(sessionData.timestamp).getHours();
    // Consider 11 PM to 6 AM as off-hours
    if (hour >= 23 || hour <= 6) {
      return 'Off-Hours Activity';
    }
    return null;
  }

  private calculateSeverity(threatCount: number): 'low' | 'medium' | 'high' | 'critical' {
    if (threatCount >= 4) return 'critical';
    if (threatCount >= 3) return 'high';
    if (threatCount >= 2) return 'medium';
    return 'low';
  }

  async recordThreatIncident(incident: ThreatIncident): Promise<void> {
    try {
      // Increment incident count for user
      const currentCount = this.incidentCounts.get(incident.userId) || 0;
      const newCount = currentCount + 1;
      this.incidentCounts.set(incident.userId, newCount);

      // Add to watchlist if not already there
      this.watchlist.add(incident.userId);

      // Auto-quarantine if threshold exceeded
      if (newCount >= this.QUARANTINE_THRESHOLD) {
        await this.quarantineUser(incident.userId);
      }

      console.log('Threat incident recorded:', incident);
    } catch (error) {
      console.error('Error recording threat incident:', error);
    }
  }

  async quarantineUser(userId: string): Promise<void> {
    try {
      this.quarantinedUsers.add(userId);
      
      await supabase.functions.invoke('session-threat-monitor', {
        body: {
          action: 'quarantine_user',
          user_id: userId
        }
      });

      console.log(`User ${userId} has been quarantined`);
    } catch (error) {
      console.error('Error quarantining user:', error);
    }
  }

  async releaseUser(userId: string): Promise<void> {
    try {
      this.quarantinedUsers.delete(userId);
      this.watchlist.delete(userId);
      this.incidentCounts.delete(userId);
      
      await supabase.functions.invoke('session-threat-monitor', {
        body: {
          action: 'release_user',
          user_id: userId
        }
      });

      console.log(`User ${userId} has been released from quarantine`);
    } catch (error) {
      console.error('Error releasing user:', error);
    }
  }

  isUserQuarantined(userId: string): boolean {
    return this.quarantinedUsers.has(userId);
  }

  isUserOnWatchlist(userId: string): boolean {
    return this.watchlist.has(userId);
  }

  getUserIncidentCount(userId: string): number {
    return this.incidentCounts.get(userId) || 0;
  }
}

// Export singleton instance
export const sessionTracker = new SessionTracker();
export type { SessionData, ThreatIncident };