// Transfer validation utilities

export interface ValidationResult {
  valid: boolean;
  issues?: Record<string, string>;
}

export interface TransferForm {
  sourceAccount: string;
  destinationAccount: string;
  amount: string;
  currency: string;
  memo: string;
  transferType: string;
  backOfficeAuthCode: string;
  superAdminAuthCode: string;
  platformFeeBps: number;
}

export function validateTransfer(form: TransferForm): ValidationResult {
  const issues: Record<string, string> = {};

  // Required fields validation
  if (!form.sourceAccount?.trim()) {
    issues.sourceAccount = "Source account is required";
  }

  if (!form.destinationAccount?.trim()) {
    issues.destinationAccount = "Destination account is required";
  }

  if (!form.amount?.trim()) {
    issues.amount = "Amount is required";
  } else {
    const amount = parseFloat(form.amount);
    if (isNaN(amount) || amount <= 0) {
      issues.amount = "Amount must be a positive number";
    }
    if (amount > 10000000) {
      issues.amount = "Amount exceeds maximum limit of $10M";
    }
  }

  // Currency validation
  const validCurrencies = ["USD", "EUR", "GBP"];
  if (!validCurrencies.includes(form.currency)) {
    issues.currency = "Invalid currency";
  }

  // Transfer type validation
  const validTypes = ["ACH", "WIRE", "INTERNAL"];
  if (!validTypes.includes(form.transferType)) {
    issues.transferType = "Invalid transfer type";
  }

  // Authorization codes validation
  if (!form.backOfficeAuthCode?.match(/^BO-[A-Z0-9]{4}-[A-Z0-9]{4}$/)) {
    issues.backOfficeAuthCode = "Invalid back office authorization code format";
  }

  if (!form.superAdminAuthCode?.match(/^SA-[A-Z0-9]{4}-[A-Z0-9]{4}$/)) {
    issues.superAdminAuthCode = "Invalid super admin authorization code format";
  }

  // Platform fee validation
  if (form.platformFeeBps < 0 || form.platformFeeBps > 1000) {
    issues.platformFeeBps = "Platform fee must be between 0 and 1000 basis points";
  }

  // Memo validation (optional but limited length)
  if (form.memo && form.memo.length > 140) {
    issues.memo = "Memo must be 140 characters or less";
  }

  return {
    valid: Object.keys(issues).length === 0,
    issues: Object.keys(issues).length > 0 ? issues : undefined
  };
}

export function validateAccountFormat(account: string): boolean {
  // Basic account format validation
  const patterns = [
    /^WALLET-\d{3,6}$/,           // WALLET-001
    /^BANK-[A-Z0-9]{3,6}$/,      // BANK-123
    /^External – ACH •{4} \d{4}$/, // External – ACH •••• 7921
    /^Ops Settlement \d{3}$/,     // Ops Settlement 001
  ];
  
  return patterns.some(pattern => pattern.test(account));
}

export function sanitizeInput(input: string): string {
  return input.trim().replace(/[<>\"'&]/g, '');
}