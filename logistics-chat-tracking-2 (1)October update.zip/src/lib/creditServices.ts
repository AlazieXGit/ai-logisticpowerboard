// Enhanced Credit Services with Tax Integration
export interface CreditProfile {
  score: number;
  history: CreditHistoryItem[];
  accounts: CreditAccount[];
  inquiries: CreditInquiry[];
  taxImpact: TaxCreditImpact;
}

export interface CreditHistoryItem {
  date: string;
  type: 'payment' | 'inquiry' | 'account_opened' | 'account_closed';
  description: string;
  impact: number;
}

export interface CreditAccount {
  id: string;
  type: 'credit_card' | 'loan' | 'mortgage' | 'auto';
  balance: number;
  limit: number;
  status: 'active' | 'closed' | 'delinquent';
  monthlyPayment: number;
}

export interface CreditInquiry {
  date: string;
  creditor: string;
  type: 'hard' | 'soft';
  purpose: string;
}

export interface TaxCreditImpact {
  deductibleInterest: number;
  businessCreditImpact: number;
  investmentRelated: number;
  recommendations: string[];
}

export class CreditServices {
  static async getCreditProfile(userId: string): Promise<CreditProfile> {
    // Mock implementation - replace with actual credit bureau API
    return {
      score: 742,
      history: [
        {
          date: '2024-01-15',
          type: 'payment',
          description: 'On-time payment - Credit Card',
          impact: 5
        },
        {
          date: '2024-01-10',
          type: 'inquiry',
          description: 'Hard inquiry - Auto Loan',
          impact: -3
        }
      ],
      accounts: [
        {
          id: 'cc1',
          type: 'credit_card',
          balance: 2500,
          limit: 10000,
          status: 'active',
          monthlyPayment: 125
        },
        {
          id: 'auto1',
          type: 'auto',
          balance: 18500,
          limit: 25000,
          status: 'active',
          monthlyPayment: 485
        }
      ],
      inquiries: [
        {
          date: '2024-01-10',
          creditor: 'Chase Auto Finance',
          type: 'hard',
          purpose: 'Auto Loan Application'
        }
      ],
      taxImpact: {
        deductibleInterest: 1250,
        businessCreditImpact: 0,
        investmentRelated: 350,
        recommendations: [
          'Consider business credit card for deductible expenses',
          'Investment loan interest may be deductible',
          'Home equity loan interest could provide tax benefits'
        ]
      }
    };
  }

  static calculateTaxDeductions(profile: CreditProfile): number {
    const { taxImpact } = profile;
    return taxImpact.deductibleInterest + 
           taxImpact.businessCreditImpact + 
           taxImpact.investmentRelated;
  }

  static generateCreditReport(profile: CreditProfile): string {
    return `
      Credit Score: ${profile.score}
      Total Accounts: ${profile.accounts.length}
      Total Debt: $${profile.accounts.reduce((sum, acc) => sum + acc.balance, 0).toLocaleString()}
      Tax Deductible Interest: $${profile.taxImpact.deductibleInterest.toLocaleString()}
    `;
  }

  static async updateCreditProfile(userId: string, updates: Partial<CreditProfile>): Promise<boolean> {
    // Mock implementation
    console.log('Updating credit profile for user:', userId, updates);
    return true;
  }

  static async generateTaxOptimizationSuggestions(profile: CreditProfile): Promise<string[]> {
    const suggestions = [...profile.taxImpact.recommendations];
    
    // Add dynamic suggestions based on profile
    if (profile.score > 750) {
      suggestions.push('Consider leveraging excellent credit for tax-advantaged investments');
    }
    
    if (profile.accounts.some(acc => acc.type === 'mortgage')) {
      suggestions.push('Mortgage interest deduction available');
    }

    return suggestions;
  }
}

export default CreditServices;