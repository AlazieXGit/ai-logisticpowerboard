import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://kekmpxfmtsyhgwenakxw.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtla21weGZtdHN5aGd3ZW5ha3h3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk3OTI4NTcsImV4cCI6MjA2NTM2ODg1N30.zskSzpZlmFKvgzy_NNzS2PWOMm4w4gzJc139RQP0Dy8';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };