// Finance calculation utilities and mock data

export interface Platform {
  name: string;
  revenue: number;
  fees: number;
  automatedServiceFees: number;
  platformFees: number;
  opsAdminFees: number;
  dispatchFees: number;
  savings: number;
  profit: number;
}

export interface GrandTotals {
  totalRevenue: number;
  automatedServiceFees: number;
  platformFees: number;
  opsAdminFees: number;
  dispatchFees: number;
  savings: number;
  profit: number;
}

export const mockPlatforms: Platform[] = [
  {
    name: "TMS Platform",
    revenue: 890123.45,
    fees: 45678.90,
    automatedServiceFees: 23456.78,
    platformFees: 12345.67,
    opsAdminFees: 8901.23,
    dispatchFees: 5678.90,
    savings: 67890.12,
    profit: 123456.78
  },
  {
    name: "Dispatch System", 
    revenue: 567890.12,
    fees: 23456.78,
    automatedServiceFees: 15678.90,
    platformFees: 8901.23,
    opsAdminFees: 5678.90,
    dispatchFees: 3456.78,
    savings: 45678.90,
    profit: 89012.34
  },
  {
    name: "Banking Platform",
    revenue: 1234567.89,
    fees: 67890.12,
    automatedServiceFees: 34567.89,
    platformFees: 23456.78,
    opsAdminFees: 15678.90,
    dispatchFees: 9876.54,
    savings: 156789.01,
    profit: 234567.89
  }
];

export function computeGrandTotals(platforms: Platform[]): GrandTotals {
  return platforms.reduce((totals, platform) => ({
    totalRevenue: totals.totalRevenue + platform.revenue,
    automatedServiceFees: totals.automatedServiceFees + platform.automatedServiceFees,
    platformFees: totals.platformFees + platform.platformFees,
    opsAdminFees: totals.opsAdminFees + platform.opsAdminFees,
    dispatchFees: totals.dispatchFees + platform.dispatchFees,
    savings: totals.savings + platform.savings,
    profit: totals.profit + platform.profit
  }), {
    totalRevenue: 0,
    automatedServiceFees: 0,
    platformFees: 0,
    opsAdminFees: 0,
    dispatchFees: 0,
    savings: 0,
    profit: 0
  });
}

export interface TransferPayload {
  sourceAccount: string;
  destinationAccount: string;
  amount: number;
  currency: string;
  memo: string;
  transferType: string;
  authorization: {
    backOfficeAuthCode: string;
    superAdminAuthCode: string;
  };
  fees: {
    platformFeeBps: number;
  };
}

export async function submitManualTransfer(payload: TransferPayload): Promise<{ reference: string; status: string }> {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  if (payload.amount <= 0) {
    throw new Error("Invalid amount");
  }
  
  return {
    reference: `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    status: "QUEUED"
  };
}