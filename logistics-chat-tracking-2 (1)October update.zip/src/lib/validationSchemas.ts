import { z } from 'zod';

// Admin Access Validation
export const AdminAccessSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  accessLevel: z.enum(['ADMIN', 'SUPER_ADMIN', 'VIEWER', 'REVOKED']),
  reason: z.string().optional()
});

// User Registration Validation
export const UserRegistrationSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  confirmPassword: z.string(),
  businessName: z.string().min(2, 'Business name required'),
  businessType: z.enum(['individual', 'company', 'non_profit'])
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

// Payment Validation
export const PaymentSchema = z.object({
  amount: z.number().positive('Amount must be positive'),
  currency: z.string().length(3, 'Currency must be 3 characters'),
  description: z.string().min(1, 'Description required'),
  recipientId: z.string().min(1, 'Recipient required')
});

// Transfer Validation
export const TransferSchema = z.object({
  sourceAccount: z.string().min(1, 'Source account required'),
  destinationAccount: z.string().min(1, 'Destination account required'),
  amount: z.number().positive('Amount must be positive'),
  notes: z.string().optional()
});

// Document Upload Validation
export const DocumentUploadSchema = z.object({
  documentType: z.enum(['identity', 'address_proof', 'tax_document', 'bank_statement']),
  file: z.instanceof(File).refine((file) => file.size <= 5000000, 'File must be less than 5MB'),
  accountId: z.string().min(1, 'Account ID required')
});

// Bulk Action Validation
export const BulkActionSchema = z.object({
  action: z.enum(['approve', 'reject', 'suspend', 'activate']),
  itemIds: z.array(z.string()).min(1, 'At least one item must be selected'),
  reason: z.string().optional()
});

export type AdminAccess = z.infer<typeof AdminAccessSchema>;
export type UserRegistration = z.infer<typeof UserRegistrationSchema>;
export type Payment = z.infer<typeof PaymentSchema>;
export type Transfer = z.infer<typeof TransferSchema>;
export type DocumentUpload = z.infer<typeof DocumentUploadSchema>;
export type BulkAction = z.infer<typeof BulkActionSchema>;
