import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyATrrKz_hx8eFtaPMrq6yARv1TONjpA-zs",
  authDomain: "studio-2300569924-8a121.firebaseapp.com",
  projectId: "studio-2300569924-8a121",
  storageBucket: "studio-2300569924-8a121.firebasestorage.app",
  messagingSenderId: "161912375325",
  appId: "1:161912375325:web:6150f9a599c700dfcd5ef4"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
