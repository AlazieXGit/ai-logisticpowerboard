import { z } from 'zod';

// IP Blocking validation
export const blockIPSchema = z.object({
  ip_address: z.string().regex(
    /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/,
    'Invalid IP address format'
  ),
  reason: z.string().min(10, 'Reason must be at least 10 characters'),
  expires_hours: z.number().positive().optional(),
  admin_id: z.string().uuid(),
  admin_email: z.string().email()
});

// User Suspension validation
export const suspendUserSchema = z.object({
  user_id: z.string().uuid('Invalid user ID'),
  user_email: z.string().email('Invalid email address'),
  reason: z.string().min(10, 'Reason must be at least 10 characters'),
  expires_hours: z.number().positive().optional(),
  admin_id: z.string().uuid(),
  admin_email: z.string().email()
});

// Payment Edit validation
export const editPaymentSchema = z.object({
  payment_id: z.string().min(1, 'Payment ID is required'),
  new_amount: z.number().positive().optional(),
  new_status: z.enum(['pending', 'completed', 'failed', 'refunded']).optional(),
  reason: z.string().min(10, 'Reason must be at least 10 characters'),
  admin_id: z.string().uuid(),
  admin_email: z.string().email()
}).refine(
  data => data.new_amount !== undefined || data.new_status !== undefined,
  { message: 'Must provide either new_amount or new_status' }
);

export type BlockIPInput = z.infer<typeof blockIPSchema>;
export type SuspendUserInput = z.infer<typeof suspendUserSchema>;
export type EditPaymentInput = z.infer<typeof editPaymentSchema>;
