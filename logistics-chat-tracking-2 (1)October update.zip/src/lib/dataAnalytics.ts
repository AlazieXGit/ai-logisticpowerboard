// Data Analytics Interfaces and Types
export interface MockDataMetrics {
  totalTransactions: number;
  totalVolume: number;
  averageTransactionSize: number;
  userCount: number;
  platformRevenue: number;
  conversionRate: number;
  dataQuality: number;
}

export interface RealDataMetrics {
  liveTransactions: number;
  actualVolume: number;
  realUserActivity: number;
  systemPerformance: number;
  errorRate: number;
  uptimePercentage: number;
  dataIntegrity: number;
}

export interface ProjectionData {
  expectedRevenue: number;
  userGrowth: number;
  marketShare: number;
  riskLevel: "Low" | "Medium" | "High";
  confidence: number;
}

export interface DataProjections {
  nextQuarter: ProjectionData;
  nextYear: ProjectionData;
  fiveYearOutlook: ProjectionData;
}

export interface CombinedInsights {
  accuracyScore: number;
  variancePercentage: number;
  trendAlignment: "Strong Positive" | "Positive" | "Neutral" | "Negative" | "Strong Negative";
  riskFactors: string[];
  opportunities: string[];
  criticalIssues: string[];
}

export interface CorrectionInstructions {
  commonErrors: string[];
  dataValidation: string[];
  performanceOptimizations: string[];
  securityChecks: string[];
}

export interface DataAnalysisReport {
  timestamp: string;
  mockDataAnalysis: MockDataMetrics;
  realDataAnalysis: RealDataMetrics;
  combinedInsights: CombinedInsights;
  projections: DataProjections;
  correctionInstructions: CorrectionInstructions;
}