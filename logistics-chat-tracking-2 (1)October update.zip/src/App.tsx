import React, { useState } from 'react';
import { ThemeProvider } from '@/components/theme-provider';
import { AppProvider } from '@/contexts/AppContext';
import AuthModal from '@/components/AuthModal';
import SuperAdminDashboard from '@/components/SuperAdminDashboard';
import SuperAdminBanner from '@/components/SuperAdminBanner';
import LandingPage from '@/components/LandingPage';
import EnhancedSynergyPlatform from '@/components/EnhancedSynergyPlatform';
import { UserPortalDashboard } from '@/components/UserPortalDashboard';
import { BasicUserPortal } from '@/components/BasicUserPortal';
import { PremiumUserPortal } from '@/components/PremiumUserPortal';
import { CreditReportViewer } from '@/components/CreditReportViewer';
import { CreditPrequalificationSystem } from '@/components/CreditPrequalificationSystem';
import { TrialDepositNotification } from '@/components/TrialDepositNotification';
import { EnhancedSubscriptionManager } from '@/components/EnhancedSubscriptionManager';
import { AIPaymentAutomation } from '@/components/AIPaymentAutomation';
import EnterpriseDashboard from '@/components/EnterpriseDashboard';
function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userType, setUserType] = useState<'admin' | 'basic' | 'premium' | 'synergy' | 'enterprise'>('admin');
  const [showAdminBanner, setShowAdminBanner] = useState(false);
  const [synergyUserType, setSynergyUserType] = useState<'free' | 'pro' | 'enterprise'>('free');
  const [showDepositNotification, setShowDepositNotification] = useState(true);
  const handleAuthenticated = () => {
    setIsAuthenticated(true);
    if (userType === 'admin') {
      setShowAdminBanner(true);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setShowAdminBanner(false);
  };

  // If not authenticated, show auth modal over landing page
  if (!isAuthenticated) {
    return (
      <ThemeProvider defaultTheme="dark" storageKey="ai-alazie-xpress-theme">
        <AppProvider>
          <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
            <div className="fixed top-4 left-4 z-50">
              <h1 className="text-2xl font-bold text-blue-400">AI ALAZIE XPRESS ENTERPRISE</h1>
            </div>
            <LandingPage />
            <AuthModal onAuthenticated={handleAuthenticated} />
          </div>
        </AppProvider>
      </ThemeProvider>
    );
  }
  // Authenticated - show appropriate dashboard based on user type
  return (
    <ThemeProvider defaultTheme="dark" storageKey="ai-alazie-xpress-theme">
      <AppProvider>
        <div className="min-h-screen">
          {/* Urgent Trial Deposit Notification - System Override */}
          {showDepositNotification && (
            <TrialDepositNotification 
              onContinue={() => setShowDepositNotification(false)}
            />
          )}
          
          {/* Super Admin Banner */}
          {userType === 'admin' && (
            <SuperAdminBanner 
              isVisible={showAdminBanner} 
              onClose={() => setShowAdminBanner(false)} 
            />
          )}
          
          <div className={`fixed top-4 left-4 z-40 ${showAdminBanner && userType === 'admin' ? 'mt-20' : ''}`}>
            <h1 className="text-2xl font-bold text-blue-400">AI ALAZIE XPRESS ENTERPRISE</h1>
          </div>
          
          <div className={showAdminBanner && userType === 'admin' ? 'pt-20' : ''}>
            {userType === 'admin' ? <SuperAdminDashboard /> : 
             userType === 'synergy' ? <EnhancedSynergyPlatform /> :
             userType === 'basic' ? <BasicUserPortal /> :
             userType === 'premium' ? <PremiumUserPortal /> : 
             userType === 'enterprise' ? <EnterpriseDashboard /> : <UserPortalDashboard />}
          </div>
          
          {/* User Type Toggle & Logout */}
          <div className="fixed bottom-4 right-4 z-40 flex gap-3">
            {userType === 'admin' && (
              <button
                onClick={() => setShowAdminBanner(!showAdminBanner)}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg shadow-lg text-sm"
              >
                {showAdminBanner ? 'Hide' : 'Show'} Admin Banner
              </button>
            )}
            <button
              onClick={() => {
                const types = ['admin', 'basic', 'premium', 'synergy', 'enterprise'] as const;
                const currentIndex = types.indexOf(userType);
                const nextIndex = (currentIndex + 1) % types.length;
                setUserType(types[nextIndex]);
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-lg text-sm"
            >
              Switch to {
                userType === 'admin' ? 'Basic' : 
                userType === 'basic' ? 'Premium' : 
                userType === 'premium' ? 'Synergy AI' : 
                userType === 'synergy' ? 'Enterprise' : 'Admin'
              }
            </button>
            <button
              onClick={handleLogout}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg shadow-lg text-sm"
            >
              Logout
            </button>
            <button
              onClick={() => setShowDepositNotification(true)}
              className="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg shadow-lg text-sm"
            >
              Show Deposit Alert
            </button>
          </div>
        </div>
      </AppProvider>
    </ThemeProvider>
  );
}

export default App;