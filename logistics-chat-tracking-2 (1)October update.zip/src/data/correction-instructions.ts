// Correction Instructions for AI Tax Assistant Platform
export interface CorrectionInstruction {
  id: string;
  category: 'validation' | 'calculation' | 'compliance' | 'optimization';
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  solution: string;
  affectedFields: string[];
}

export const taxCorrectionInstructions: CorrectionInstruction[] = [
  {
    id: 'tax-001',
    category: 'validation',
    priority: 'high',
    title: 'SSN Format Validation',
    description: 'Social Security Number must be in XXX-XX-XXXX format',
    solution: 'Implement regex validation: /^\\d{3}-\\d{2}-\\d{4}$/',
    affectedFields: ['personalInfo.ssn']
  },
  {
    id: 'tax-002',
    category: 'calculation',
    priority: 'high',
    title: 'Income Calculation Accuracy',
    description: 'Total income must equal sum of all income sources',
    solution: 'Add validation to ensure income.total = w2 + selfEmployment + investments + rental + unemployment + other',
    affectedFields: ['income.w2Income', 'income.selfEmployment', 'income.investments']
  },
  {
    id: 'tax-003',
    category: 'compliance',
    priority: 'high',
    title: 'Filing Status Validation',
    description: 'Filing status must match IRS requirements',
    solution: 'Validate filing status against dependents count and marital status',
    affectedFields: ['personalInfo.filingStatus', 'personalInfo.dependents']
  },
  {
    id: 'tax-004',
    category: 'optimization',
    priority: 'medium',
    title: 'Deduction Optimization',
    description: 'Compare standard vs itemized deductions',
    solution: 'Calculate both options and recommend higher deduction amount',
    affectedFields: ['deductions.standardDeduction', 'deductions.itemizedDeductions']
  },
  {
    id: 'tax-005',
    category: 'validation',
    priority: 'medium',
    title: 'Document Upload Verification',
    description: 'Required documents must be uploaded before filing',
    solution: 'Check all required documents are uploaded and verified',
    affectedFields: ['documents']
  }
];

export const commonTaxErrors = [
  {
    error: 'Math calculation errors',
    frequency: '45%',
    solution: 'Use automated calculations with validation',
    prevention: 'Implement real-time calculation checks'
  },
  {
    error: 'Missing or incorrect SSN',
    frequency: '23%',
    solution: 'Validate SSN format and check against IRS database',
    prevention: 'Real-time SSN validation'
  },
  {
    error: 'Incorrect filing status',
    frequency: '18%',
    solution: 'Provide guided filing status selection',
    prevention: 'Interactive filing status wizard'
  },
  {
    error: 'Missing signatures',
    frequency: '12%',
    solution: 'Digital signature integration',
    prevention: 'Mandatory signature step before submission'
  }
];

export const taxOptimizationTips = [
  {
    category: 'Deductions',
    tip: 'Maximize retirement contributions',
    impact: 'Up to $6,500 tax savings',
    eligibility: 'All taxpayers under 50'
  },
  {
    category: 'Credits',
    tip: 'Claim education credits',
    impact: 'Up to $2,500 credit',
    eligibility: 'Students or parents paying tuition'
  },
  {
    category: 'Business',
    tip: 'Deduct home office expenses',
    impact: 'Average $1,200 deduction',
    eligibility: 'Self-employed or remote workers'
  },
  {
    category: 'Investment',
    tip: 'Harvest tax losses',
    impact: 'Offset capital gains',
    eligibility: 'Investors with taxable accounts'
  }
];

export const auditRiskFactors = [
  {
    factor: 'High income (>$200k)',
    riskLevel: 'High',
    percentage: '2.4%',
    mitigation: 'Ensure all income is properly documented'
  },
  {
    factor: 'Large charitable deductions',
    riskLevel: 'Medium',
    percentage: '1.1%',
    mitigation: 'Keep detailed records and receipts'
  },
  {
    factor: 'Business losses',
    riskLevel: 'Medium',
    percentage: '1.6%',
    mitigation: 'Document business purpose and expenses'
  },
  {
    factor: 'Cash transactions',
    riskLevel: 'High',
    percentage: '3.2%',
    mitigation: 'Maintain detailed transaction logs'
  }
];

export class TaxValidationService {
  static validateTaxForm(formData: any): CorrectionInstruction[] {
    const errors: CorrectionInstruction[] = [];
    
    // SSN validation
    if (!formData.personalInfo?.ssn?.match(/^\d{3}-\d{2}-\d{4}$/)) {
      errors.push(taxCorrectionInstructions.find(i => i.id === 'tax-001')!);
    }
    
    // Income validation
    const totalIncome = Object.values(formData.income || {})
      .reduce((sum: number, val: any) => sum + (Number(val) || 0), 0);
    
    if (totalIncome <= 0) {
      errors.push(taxCorrectionInstructions.find(i => i.id === 'tax-002')!);
    }
    
    return errors;
  }
  
  static calculateOptimizations(formData: any): string[] {
    const optimizations: string[] = [];
    
    // Standard vs Itemized deduction comparison
    const standardDeduction = 13850; // 2023 single filer
    const itemizedTotal = (formData.deductions?.itemizedDeductions || [])
      .reduce((sum: number, item: any) => sum + (item.amount || 0), 0);
    
    if (itemizedTotal > standardDeduction) {
      optimizations.push(`Itemize deductions to save $${(itemizedTotal - standardDeduction).toLocaleString()}`);
    }
    
    return optimizations;
  }
}

export default {
  taxCorrectionInstructions,
  commonTaxErrors,
  taxOptimizationTips,
  auditRiskFactors,
  TaxValidationService
};