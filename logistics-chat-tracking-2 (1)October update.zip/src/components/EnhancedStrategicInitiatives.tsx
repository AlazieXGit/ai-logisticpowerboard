import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Target, TrendingUp, AlertTriangle, CheckCircle, Clock, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Project {
  name: string;
  status: string;
  completion: number;
  budget: number;
  spent: number;
  roi: number;
  risk_level?: string;
  manager?: string;
  department?: string;
}

const EnhancedStrategicInitiatives = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjectData();
    const interval = setInterval(fetchProjectData, 90000);
    return () => clearInterval(interval);
  }, []);

  const fetchProjectData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enterprise-analytics-processor', {
        body: { action: 'get_projects' }
      });
      
      if (!error && data?.projects) {
        const enhancedProjects = data.projects.map((project: any) => ({
          ...project,
          risk_level: project.risk_level || (project.completion < 30 ? 'high' : project.completion < 70 ? 'medium' : 'low'),
          manager: project.manager || 'Sarah Chen',
          department: project.department || 'Engineering'
        }));
        setProjects(enhancedProjects);
      }
    } catch (error) {
      console.error('Error fetching project data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'planning': return 'bg-blue-100 text-blue-800';
      case 'on-hold': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'low': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'medium': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'high': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <Target className="w-4 h-4 text-gray-500" />;
    }
  };

  if (loading) {
    return <div className="p-6">Loading strategic initiatives...</div>;
  }

  const totalBudget = projects.reduce((acc, p) => acc + p.budget, 0);
  const totalSpent = projects.reduce((acc, p) => acc + p.spent, 0);
  const avgCompletion = projects.reduce((acc, p) => acc + p.completion, 0) / projects.length;

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-blue-900">Strategic Initiatives</h2>
        <Badge variant="outline" className="bg-indigo-50">
          Project Portfolio • Live Updates
        </Badge>
      </div>

      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-blue-900">{projects.length}</div>
            <p className="text-sm text-gray-600">Active Projects</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-600">{avgCompletion.toFixed(1)}%</div>
            <p className="text-sm text-gray-600">Avg Completion</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-purple-600">${totalBudget.toLocaleString()}</div>
            <p className="text-sm text-gray-600">Total Budget</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-orange-600">
              {((totalSpent / totalBudget) * 100).toFixed(1)}%
            </div>
            <p className="text-sm text-gray-600">Budget Utilized</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="portfolio" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="risk">Risk Matrix</TabsTrigger>
          <TabsTrigger value="roi">ROI Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="portfolio" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {projects.map((project, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <Badge className={getStatusColor(project.status)}>
                      {project.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span>PM: {project.manager}</span>
                    <span>Dept: {project.department}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span className="font-medium">{project.completion.toFixed(1)}%</span>
                      </div>
                      <Progress value={project.completion} className="h-2" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-gray-600">Budget</div>
                        <div className="font-medium">${project.budget.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Spent</div>
                        <div className="font-medium">${project.spent.toLocaleString()}</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getRiskIcon(project.risk_level || 'medium')}
                        <span className={`text-sm font-medium ${getRiskColor(project.risk_level || 'medium')}`}>
                          {project.risk_level || 'Medium'} Risk
                        </span>
                      </div>
                      {project.roi > 0 && (
                        <div className="text-sm">
                          <span className="text-gray-600">ROI: </span>
                          <span className="font-medium text-green-600">{project.roi.toFixed(1)}%</span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Project Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {projects.map((project, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{project.name}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">
                          {((project.spent / project.budget) * 100).toFixed(1)}% budget used
                        </Badge>
                        <Badge variant={project.completion > 75 ? 'default' : 'secondary'}>
                          {project.completion > 75 ? 'On Track' : 'Needs Attention'}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-xs text-gray-600 mb-1">Completion Progress</div>
                        <Progress value={project.completion} className="h-2" />
                      </div>
                      <div>
                        <div className="text-xs text-gray-600 mb-1">Budget Utilization</div>
                        <Progress value={(project.spent / project.budget) * 100} className="h-2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {['low', 'medium', 'high'].map((riskLevel) => {
              const riskProjects = projects.filter(p => (p.risk_level || 'medium').toLowerCase() === riskLevel);
              return (
                <Card key={riskLevel} className={`border-l-4 ${
                  riskLevel === 'low' ? 'border-l-green-500' : 
                  riskLevel === 'medium' ? 'border-l-yellow-500' : 'border-l-red-500'
                }`}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 capitalize">
                      {getRiskIcon(riskLevel)}
                      {riskLevel} Risk Projects
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {riskProjects.map((project, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="font-medium text-sm">{project.name}</div>
                          <div className="text-xs text-gray-600 mt-1">
                            {project.completion.toFixed(1)}% complete • ${project.spent.toLocaleString()} spent
                          </div>
                        </div>
                      ))}
                      {riskProjects.length === 0 && (
                        <div className="text-sm text-gray-500 text-center py-4">
                          No projects in this risk category
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="roi" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Return on Investment Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {projects.filter(p => p.roi > 0).map((project, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <div className="font-medium">{project.name}</div>
                      <div className="text-sm text-gray-600">
                        Investment: ${project.spent.toLocaleString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-600">
                        {project.roi.toFixed(1)}% ROI
                      </div>
                      <div className="text-sm text-gray-600">
                        ${(project.spent * (project.roi / 100)).toLocaleString()} return
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedStrategicInitiatives;