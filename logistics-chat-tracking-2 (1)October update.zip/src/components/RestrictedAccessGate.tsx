import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, AlertTriangle, TestTube, ExternalLink, Building2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import SuperAdminAuth from './SuperAdminAuth';
import SuperAdminControlCenter from './SuperAdminControlCenter';

const RestrictedAccessGate: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [threatData] = useState({
    threat_level: 'HIGH',
    active_incidents: 2,
    threat_details: [
      {
        type: 'Suspicious Login',
        ip: '192.168.1.100',
        timestamp: '7/25/2025, 3:45:21 PM',
        credentials: {
          username: 'admin_user',
          password: 'admin123',
          email: 'admin@company.com'
        }
      },
      {
        type: 'Multiple Failed Attempts',
        ip: '10.0.0.50',
        timestamp: '7/25/2025, 3:40:21 PM',
        credentials: {
          username: 'admin_user',
          password: 'admin123',
          email: 'admin@company.com'
        }
      }
    ]
  });

  const handleAuthentication = (isAdmin: boolean) => {
    setIsAuthenticated(isAdmin);
  };

  const navigateToTest = () => {
    window.location.href = '/test-login';
  };

  const navigateToBackOffice = () => {
    window.location.href = '/back-office';
  };

  const navigateToPlatform = () => {
    window.location.href = '/platform';
  };

  // If authenticated as super admin, show control center
  if (isAuthenticated) {
    return <SuperAdminControlCenter />;
  }

  // Default restricted access screen with threat lockdown
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-gray-900 to-black flex items-center justify-center p-4">
      <div className="max-w-3xl w-full space-y-6">
        {/* Navigation Buttons */}
        <div className="flex justify-center gap-4">
          <Button 
            onClick={navigateToTest}
            className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
          >
            <TestTube className="h-4 w-4" />
            Test Login Functionality
          </Button>
          <Button 
            onClick={navigateToBackOffice}
            className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
          >
            <Building2 className="h-4 w-4" />
            Back Office Access
          </Button>
          <Button 
            onClick={navigateToPlatform}
            className="bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2"
          >
            <ExternalLink className="h-4 w-4" />
            Platform Access
          </Button>
        </div>

        {/* Critical Security Alert Header */}
        <Alert className="border-red-500 bg-red-900/40 border-2">
          <AlertTriangle className="h-6 w-6 text-red-400 animate-pulse" />
          <AlertDescription className="text-red-300">
            <div className="space-y-3">
              <h2 className="text-2xl font-bold text-red-400">🚨 SECURITY THREAT DETECTED</h2>
              <div className="text-sm space-y-1">
                <p>• Suspicious Login from 192.168.1.100 at 7/25/2025, 3:45:21 PM</p>
                <p>• Multiple Failed Attempts from 10.0.0.50 at 7/25/2025, 3:40:21 PM</p>
                <p>• Threat Level: <span className="text-red-400 font-bold">HIGH</span></p>
                <p>• Active Incidents: <span className="text-red-400 font-bold">2</span></p>
              </div>
              <div className="bg-red-800/50 p-3 rounded mt-3">
                <p className="font-bold text-red-200">ALL USER ACCESS RESTRICTED - SUPER ADMIN ONLY</p>
                <p className="text-red-300 text-sm mt-1">admin_user account SUSPENDED</p>
              </div>
            </div>
          </AlertDescription>
        </Alert>

        {/* Platform Access Information */}
        <Card className="bg-blue-900/20 border-blue-500">
          <CardHeader>
            <CardTitle className="text-blue-400 flex items-center gap-2">
              <ExternalLink className="h-5 w-5" />
              Super Admin Platform Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-800/50 p-4 rounded border border-blue-500/30">
                <h4 className="font-semibold text-blue-400 mb-2">Back Office System</h4>
                <p className="text-gray-300 text-sm mb-3">Administrative operations and management console</p>
                <Button 
                  onClick={navigateToBackOffice}
                  size="sm"
                  className="bg-blue-600 hover:bg-blue-700 w-full"
                >
                  Access Back Office
                </Button>
              </div>
              <div className="bg-gray-800/50 p-4 rounded border border-purple-500/30">
                <h4 className="font-semibold text-purple-400 mb-2">Main Platform</h4>
                <p className="text-gray-300 text-sm mb-3">Core platform services and database management</p>
                <Button 
                  onClick={navigateToPlatform}
                  size="sm"
                  className="bg-purple-600 hover:bg-purple-700 w-full"
                >
                  Access Platform
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Super Admin Access Only */}
        <Card className="bg-black/80 border-red-500">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Shield className="h-6 w-6" />
              SUPER ADMIN ACCESS ONLY
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-4">
              <p className="text-gray-300">
                System controlled by <span className="text-red-400 font-bold">Alucius Alford</span>
              </p>
              <p className="text-red-300 text-sm">
                Single login route - alaziellc.innovation@gmail.com only
              </p>
              <div className="bg-red-900/30 p-4 rounded border border-red-500/50">
                <p className="text-red-300 font-semibold mb-2">SUSPENDED ACCOUNTS:</p>
                <div className="text-sm space-y-1">
                  <p className="text-gray-300">• admin_user (Username: admin_user)</p>
                  <p className="text-gray-300">• admin@company.com (Email access)</p>
                  <p className="text-gray-300">• All standard user accounts</p>
                </div>
              </div>
              <SuperAdminAuth onAuthenticated={handleAuthentication} />
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2">
          <div className="text-xs text-red-400 font-semibold">
            🔒 PLATFORM SECURED - ALUCIUS ALFORD CONTROL
          </div>
          <div className="text-xs text-gray-500">
            alaziellc.innovation@gmail.com - PIN: #19762020 required
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestrictedAccessGate;