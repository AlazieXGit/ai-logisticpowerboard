import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Shield, Building2, DollarSign, Clock, CheckCircle, AlertCircle, Lock, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface EscrowTransaction {
  id: string;
  amount: number;
  party1: string;
  party2: string;
  description: string;
  status: 'pending' | 'funded' | 'released' | 'disputed';
  createdAt: string;
  hardCopy: boolean;
}

const EscrowAccountManager: React.FC = () => {
  const [transactions, setTransactions] = useState<EscrowTransaction[]>([]);
  const [amount, setAmount] = useState('');
  const [party1, setParty1] = useState('');
  const [party2, setParty2] = useState('');
  const [description, setDescription] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const alazielEscrowAccount = {
    name: 'Alaziel Banking - Escrow Account',
    accountNumber: '5573-9012-4567-8902',
    routingNumber: '031176110',
    balance: 5000000.00, // Updated to 5 million minimum - Target: 15 million
    hardCopy: true
  };

  useEffect(() => {
    loadTransactions();
  }, []);

  const loadTransactions = () => {
    const mockTransactions: EscrowTransaction[] = [
      {
        id: 'ESC-ALZ-001',
        amount: 25000,
        party1: 'ABC Logistics Corp',
        party2: 'XYZ Freight Solutions',
        description: 'Load delivery escrow - Route 405',
        status: 'funded',
        createdAt: '2024-01-15',
        hardCopy: true
      },
      {
        id: 'ESC-ALZ-002',
        amount: 15000,
        party1: 'Global Transport LLC',
        party2: 'Regional Carriers Inc',
        description: 'Multi-stop delivery escrow',
        status: 'pending',
        createdAt: '2024-01-16',
        hardCopy: true
      }
    ];
    setTransactions(mockTransactions);
  };

  const createEscrow = async () => {
    if (!amount || !party1 || !party2 || !description) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    setIsProcessing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const newTransaction: EscrowTransaction = {
        id: `ESC-ALZ-${Date.now()}`,
        amount: parseFloat(amount),
        party1,
        party2,
        description,
        status: 'pending',
        createdAt: new Date().toISOString().split('T')[0],
        hardCopy: true
      };
      
      setTransactions(prev => [newTransaction, ...prev]);
      
      toast({
        title: 'Hard Copy Secured',
        description: `Escrow account created successfully via Alaziel Banking - Hard Copy Created`,
        variant: 'default'
      });
      
      setAmount('');
      setParty1('');
      setParty2('');
      setDescription('');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create escrow account',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const releaseEscrow = async (transactionId: string) => {
    setTransactions(prev => 
      prev.map(tx => 
        tx.id === transactionId 
          ? { ...tx, status: 'released' }
          : tx
      )
    );
    
    toast({
      title: 'Hard Copy Secured',
      description: 'Escrow funds released successfully - Hard Copy Updated',
      variant: 'default'
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Hard Copy Secured', description: 'Banking information copied and secured' });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-600';
      case 'funded': return 'bg-blue-600';
      case 'released': return 'bg-green-600';
      case 'disputed': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Alaziel Banking - Escrow Account Manager
            <Lock className="h-4 w-4 text-red-400" />
            <Badge className="bg-red-600 text-white">HARD COPY</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-emerald-900/20 p-4 rounded-lg border border-emerald-500/30">
            <div className="flex items-center gap-2 mb-2">
              <Building2 className="h-4 w-4 text-emerald-400" />
              <span className="text-emerald-300 font-semibold">Alaziel Escrow Account Details</span>
              {alazielEscrowAccount.hardCopy && <Lock className="h-3 w-3 text-red-400" />}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-white font-medium">{alazielEscrowAccount.name}</p>
                <div className="flex items-center gap-2">
                  <p className="text-gray-300 text-sm">Account: {alazielEscrowAccount.accountNumber}</p>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => copyToClipboard(alazielEscrowAccount.accountNumber)}
                    className="text-emerald-400 hover:bg-emerald-900/20 p-1"
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
                <div className="flex items-center gap-2">
                  <p className="text-gray-300 text-sm">Routing: {alazielEscrowAccount.routingNumber}</p>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => copyToClipboard(alazielEscrowAccount.routingNumber)}
                    className="text-emerald-400 hover:bg-emerald-900/20 p-1"
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
                <p className="text-gray-300 text-sm">SWIFT: {alazielEscrowAccount.swiftCode}</p>
              </div>
              <div className="text-right">
                <p className="text-emerald-400 text-2xl font-bold">
                  ${alazielEscrowAccount.balance.toLocaleString()}
                </p>
                <div className="flex flex-col gap-1 mt-1">
                  <Badge className="bg-emerald-600 text-white">ALAZIEL BANKING</Badge>
                  <Badge className="bg-red-600 text-white">HARD COPY SECURED</Badge>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-emerald-300">Escrow Amount ($)</Label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter escrow amount"
                className="bg-gray-700 border-emerald-500/30 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-emerald-300">Party 1 (Payer)</Label>
              <Input
                value={party1}
                onChange={(e) => setParty1(e.target.value)}
                placeholder="First party name"
                className="bg-gray-700 border-emerald-500/30 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-emerald-300">Party 2 (Payee)</Label>
            <Input
              value={party2}
              onChange={(e) => setParty2(e.target.value)}
              placeholder="Second party name"
              className="bg-gray-700 border-emerald-500/30 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-emerald-300">Escrow Description</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the terms and conditions of this escrow"
              className="bg-gray-700 border-emerald-500/30 text-white"
              rows={3}
            />
          </div>

          <Button 
            onClick={createEscrow}
            disabled={isProcessing}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
          >
            {isProcessing ? (
              <>
                <AlertCircle className="h-4 w-4 mr-2 animate-spin" />
                Creating Escrow via Alaziel Banking (Hard Copy)...
              </>
            ) : (
              <>
                <Shield className="h-4 w-4 mr-2" />
                Create Escrow Account - Generate Hard Copy
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            Active Escrow Transactions
            <Lock className="h-4 w-4 text-red-400" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactions.map((transaction) => (
              <div key={transaction.id} className="bg-gray-700 p-4 rounded-lg border border-emerald-500/20">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="text-white font-semibold flex items-center gap-2">
                      {transaction.id}
                      {transaction.hardCopy && <Lock className="h-3 w-3 text-red-400" />}
                    </h3>
                    <p className="text-gray-300 text-sm">{transaction.description} 🔒</p>
                  </div>
                  <div className="flex gap-2">
                    <Badge className={getStatusColor(transaction.status)}>
                      {transaction.status.toUpperCase()}
                    </Badge>
                    {transaction.hardCopy && <Badge className="bg-red-600">HARD COPY</Badge>}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <p className="text-gray-400 text-xs">Party 1 (Payer)</p>
                    <p className="text-white text-sm">{transaction.party1}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-xs">Party 2 (Payee)</p>
                    <p className="text-white text-sm">{transaction.party2}</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-emerald-400" />
                    <span className="text-emerald-400 font-bold text-lg">
                      ${transaction.amount.toLocaleString()}
                    </span>
                  </div>
                  
                  {transaction.status === 'funded' && (
                    <Button 
                      onClick={() => releaseEscrow(transaction.id)}
                      size="sm"
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Release Funds 🔒
                    </Button>
                  )}
                  
                  <div className="flex items-center gap-1 text-gray-400 text-xs">
                    <Clock className="h-3 w-3" />
                    {transaction.createdAt}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EscrowAccountManager;