import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Server, Settings, Database, Users, CreditCard, 
  Shield, BarChart3, Power, Eye 
} from 'lucide-react';
import BackOfficeControlCenter from './BackOfficeControlCenter';
import SuperAdminPlatformAccess from './SuperAdminPlatformAccess';
import SystemControlPanel from './SystemControlPanel';

interface GlobalBackOfficeAccessProps {
  isVisible: boolean;
  onToggle: () => void;
}

const GlobalBackOfficeAccess: React.FC<GlobalBackOfficeAccessProps> = ({ 
  isVisible, 
  onToggle 
}) => {
  const [activePanel, setActivePanel] = useState<string | null>(null);
  const [systemActive, setSystemActive] = useState(true);

  if (!isVisible) {
    return (
      <div className="fixed top-4 right-4 z-50">
        <Button
          onClick={onToggle}
          className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg"
          size="sm"
        >
          <Server className="h-4 w-4 mr-2" />
          Back Office Access
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/90 z-50 overflow-auto">
      <div className="container mx-auto p-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Server className="h-8 w-8 text-blue-400" />
            <div>
              <h1 className="text-2xl font-bold text-blue-400">Global Back Office Access</h1>
              <p className="text-gray-300">Super Admin Control Panel</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="bg-blue-600">ALUCIUS ALFORD - SUPER ADMIN</Badge>
            <Button
              onClick={onToggle}
              variant="outline"
              className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
            >
              Close Back Office
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Button
            onClick={() => setActivePanel('back-office')}
            className={`h-20 flex flex-col gap-2 ${
              activePanel === 'back-office' ? 'bg-blue-600' : 'bg-gray-800'
            }`}
          >
            <Server className="h-6 w-6" />
            <span className="text-sm">Back Office Control</span>
          </Button>
          
          <Button
            onClick={() => setActivePanel('platform-access')}
            className={`h-20 flex flex-col gap-2 ${
              activePanel === 'platform-access' ? 'bg-green-600' : 'bg-gray-800'
            }`}
          >
            <Settings className="h-6 w-6" />
            <span className="text-sm">Platform Access</span>
          </Button>
          
          <Button
            onClick={() => setActivePanel('system-control')}
            className={`h-20 flex flex-col gap-2 ${
              activePanel === 'system-control' ? 'bg-yellow-600' : 'bg-gray-800'
            }`}
          >
            <Power className="h-6 w-6" />
            <span className="text-sm">System Control</span>
          </Button>
          
          <Button
            onClick={() => setActivePanel('database')}
            className={`h-20 flex flex-col gap-2 ${
              activePanel === 'database' ? 'bg-purple-600' : 'bg-gray-800'
            }`}
          >
            <Database className="h-6 w-6" />
            <span className="text-sm">Database Admin</span>
          </Button>
        </div>

        <div className="bg-gray-900/50 rounded-lg p-6 border border-gray-700">
          {activePanel === 'back-office' && <BackOfficeControlCenter />}
          {activePanel === 'platform-access' && <SuperAdminPlatformAccess />}
          {activePanel === 'system-control' && (
            <SystemControlPanel 
              onSystemToggle={setSystemActive} 
              systemActive={systemActive} 
            />
          )}
          {activePanel === 'database' && (
            <div className="text-center py-12">
              <Database className="h-16 w-16 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Database Administration</h3>
              <p className="text-gray-300 mb-4">Full database access and management tools</p>
              <Badge className="bg-purple-600">23 Tables Active</Badge>
            </div>
          )}
          {!activePanel && (
            <div className="text-center py-12">
              <Eye className="h-16 w-16 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Select Control Panel</h3>
              <p className="text-gray-300">Choose a control panel above to access system functions</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GlobalBackOfficeAccess;