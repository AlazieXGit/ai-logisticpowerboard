import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { FileText, Building2, Shield, DollarSign, Users, AlertCircle, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface TrustAccount {
  id: string;
  trustorName: string;
  beneficiaries: string[];
  assets: number;
  status: 'active' | 'pending' | 'revoked';
  createdAt: string;
}

const LivingRevocableTrust: React.FC = () => {
  const [trustAccounts, setTrustAccounts] = useState<TrustAccount[]>([]);
  const [trustorName, setTrustorName] = useState('');
  const [beneficiaries, setBeneficiaries] = useState('');
  const [initialAssets, setInitialAssets] = useState('');
  const [trustTerms, setTrustTerms] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const alazielTrustAccount = {
    name: 'Alaziel Banking - Trust Account',
    accountNumber: '4472-8901-3456-7892',
    routingNumber: '021000021',
    swiftCode: 'ALAZUS33TRS',
    balance: 5890000.00,
    trustOfficer: 'Alaziel Trust Services'
  };

  React.useEffect(() => {
    loadTrustAccounts();
  }, []);

  const loadTrustAccounts = () => {
    const mockTrusts: TrustAccount[] = [
      {
        id: 'TRUST-ALZ-2024-001',
        trustorName: 'Alucius Alford',
        beneficiaries: ['Alford Family Foundation', 'Educational Trust Fund'],
        assets: 2500000,
        status: 'active',
        createdAt: '2024-01-10'
      },
      {
        id: 'TRUST-ALZ-2024-002',
        trustorName: 'Corporate Holdings LLC',
        beneficiaries: ['Employee Benefit Trust', 'Retirement Fund'],
        assets: 1800000,
        status: 'active',
        createdAt: '2024-01-12'
      }
    ];
    setTrustAccounts(mockTrusts);
  };

  const createTrust = async () => {
    if (!trustorName || !beneficiaries || !initialAssets || !trustTerms) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    setIsProcessing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const newTrust: TrustAccount = {
        id: `TRUST-ALZ-${Date.now()}`,
        trustorName,
        beneficiaries: beneficiaries.split(',').map(b => b.trim()),
        assets: parseFloat(initialAssets),
        status: 'pending',
        createdAt: new Date().toISOString().split('T')[0]
      };
      
      setTrustAccounts(prev => [newTrust, ...prev]);
      
      toast({
        title: 'Success',
        description: `Living Revocable Trust created successfully via Alaziel Banking`,
        variant: 'default'
      });
      
      // Reset form
      setTrustorName('');
      setBeneficiaries('');
      setInitialAssets('');
      setTrustTerms('');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create trust account',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-600';
      case 'pending': return 'bg-yellow-600';
      case 'revoked': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Alaziel Banking - Living Revocable Trust Services
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
            <div className="flex items-center gap-2 mb-2">
              <Building2 className="h-4 w-4 text-blue-400" />
              <span className="text-blue-300 font-semibold">Alaziel Trust Account Details</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-white font-medium">{alazielTrustAccount.name}</p>
                <p className="text-gray-300 text-sm">Account: {alazielTrustAccount.accountNumber}</p>
                <p className="text-gray-300 text-sm">Routing: {alazielTrustAccount.routingNumber}</p>
                <p className="text-gray-300 text-sm">SWIFT: {alazielTrustAccount.swiftCode}</p>
                <p className="text-gray-300 text-sm">Trust Officer: {alazielTrustAccount.trustOfficer}</p>
              </div>
              <div className="text-right">
                <p className="text-blue-400 text-2xl font-bold">
                  ${alazielTrustAccount.balance.toLocaleString()}
                </p>
                <Badge className="bg-blue-600 text-white mt-1">ALAZIEL TRUST SERVICES</Badge>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-blue-300">Trustor Name</Label>
              <Input
                value={trustorName}
                onChange={(e) => setTrustorName(e.target.value)}
                placeholder="Enter trustor full name"
                className="bg-gray-700 border-blue-500/30 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-blue-300">Initial Assets ($)</Label>
              <Input
                type="number"
                value={initialAssets}
                onChange={(e) => setInitialAssets(e.target.value)}
                placeholder="Enter initial asset value"
                className="bg-gray-700 border-blue-500/30 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-blue-300">Beneficiaries (comma-separated)</Label>
            <Input
              value={beneficiaries}
              onChange={(e) => setBeneficiaries(e.target.value)}
              placeholder="Enter beneficiary names separated by commas"
              className="bg-gray-700 border-blue-500/30 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-blue-300">Trust Terms & Conditions</Label>
            <Textarea
              value={trustTerms}
              onChange={(e) => setTrustTerms(e.target.value)}
              placeholder="Enter trust terms, conditions, and distribution instructions"
              className="bg-gray-700 border-blue-500/30 text-white"
              rows={4}
            />
          </div>

          <Button 
            onClick={createTrust}
            disabled={isProcessing}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isProcessing ? (
              <>
                <AlertCircle className="h-4 w-4 mr-2 animate-spin" />
                Creating Trust via Alaziel Banking...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4 mr-2" />
                Create Living Revocable Trust
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400">Active Trust Accounts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {trustAccounts.map((trust) => (
              <div key={trust.id} className="bg-gray-700 p-4 rounded-lg border border-blue-500/20">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="text-white font-semibold">{trust.id}</h3>
                    <p className="text-gray-300 text-sm">Trustor: {trust.trustorName}</p>
                  </div>
                  <Badge className={getStatusColor(trust.status)}>
                    {trust.status.toUpperCase()}
                  </Badge>
                </div>
                
                <div className="mb-3">
                  <p className="text-gray-400 text-xs mb-1">Beneficiaries</p>
                  <div className="flex flex-wrap gap-1">
                    {trust.beneficiaries.map((beneficiary, index) => (
                      <Badge key={index} className="bg-blue-600/20 text-blue-300 text-xs">
                        <Users className="h-3 w-3 mr-1" />
                        {beneficiary}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-blue-400" />
                    <span className="text-blue-400 font-bold text-lg">
                      ${trust.assets.toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {trust.status === 'active' && (
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Manage Trust
                      </Button>
                    )}
                    
                    <span className="text-gray-400 text-xs">
                      Created: {trust.createdAt}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LivingRevocableTrust;