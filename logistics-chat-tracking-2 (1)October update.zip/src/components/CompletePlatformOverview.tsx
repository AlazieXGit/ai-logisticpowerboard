import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import PlatformInstructionsDocuments from './PlatformInstructionsDocuments';
import { 
  Building2, DollarSign, CreditCard, FileText, 
  Shield, Activity, TrendingUp, Download 
} from 'lucide-react';

interface AccountInfo {
  accountNumber: string;
  routingNumber: string;
  accountType: string;
  balance: number;
  status: string;
}

interface PaymentProcessor {
  name: string;
  status: string;
  monthlyVolume: number;
  fees: number;
}

const CompletePlatformOverview: React.FC = () => {
  const [accounts, setAccounts] = useState<AccountInfo[]>([]);
  const [processors, setProcessors] = useState<PaymentProcessor[]>([]);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    initializePlatformData();
  }, []);
  const initializePlatformData = async () => {
    try {
      // Calculate comprehensive revenue from all platforms and fee sources
      const platformRevenues = {
        // Core Platform Revenues
        tmsOperations: 2500000,
        aiBankingServices: 1800000,
        loadboardRevenue: 950000,
        synergyAIPlatform: 750000,
        automotiveRobotics: 650000,
        realEstateOperations: 500000,
        creditRepairServices: 400000,
        
        // Fee-Based Revenues (Now included as additional revenue with 10% admin integration)
        platformFees: 892456.78 * 1.10, // Added 10% admin integration fee
        adminFees: 234567.80 * 1.10,
        transactionFees: 445623.90 * 1.10,
        processingFees: 156780.25 * 1.10,
        complianceFees: 89432.75 * 1.10,
        
        // Account-Based Revenues
        trustAccountRevenue: 1200000,
        escrowAccountRevenue: 850000,
        virtualAccountRevenue: 600000,
        directDepositRevenue: 350000,
        
        // Additional Revenue Streams
        subscriptionRevenue: 280000,
        licenseRevenue: 195000,
        consultingRevenue: 125000,
        maintenanceRevenue: 95000,
        
        // Investment & Asset Revenues
        propertyRentalIncome: 450000,
        vehicleLeaseRevenue: 275000,
        equipmentRentalRevenue: 180000,
        
        // International Operations
        internationalTradingRevenue: 320000,
        globalShippingRevenue: 240000,
        currencyExchangeRevenue: 85000
      };

      // Calculate total revenue from all sources
      const totalCalculatedRevenue = Object.values(platformRevenues).reduce((sum, value) => sum + value, 0);

      // Mock comprehensive platform data with updated balances and external payroll accounts
      const mockAccounts: AccountInfo[] = [
        {
          accountNumber: '****1234',
          routingNumber: '021000021',
          accountType: 'Trust Banking',
          balance: 28500000, // Increased to reflect accumulated fees
          status: 'Active'
        },
        {
          accountNumber: '****5678',
          routingNumber: '121000248',
          accountType: 'Operating Account',
          balance: 12750000, // Increased to reflect fee accumulation
          status: 'Active'
        },
        {
          accountNumber: '****9012',
          routingNumber: '031000021',
          accountType: 'Escrow Account',
          balance: 8500000, // Increased to reflect accumulated revenues
          status: 'Active'
        },
        {
          accountNumber: '5186776357552',
          routingNumber: '041215663',
          accountType: 'Fee Collection Account',
          balance: 1818861.48, // Sum of all accumulated fees
          status: 'Active'
        },
        {
          accountNumber: '****3456',
          routingNumber: '051000021',
          accountType: 'Cash App - Super Admin Payroll',
          balance: 15000, // Immediate payroll due
          status: 'Active - Payroll Due'
        },
        {
          accountNumber: '5563935283',
          routingNumber: '054000030',
          accountType: 'Growth Account - x5283',
          balance: 2500000,
          status: 'Active'
        }
      ];

      const mockProcessors: PaymentProcessor[] = [
        {
          name: 'Stripe',
          status: 'Connected',
          monthlyVolume: 3200000, // Increased to reflect higher volume
          fees: 96000 * 1.10 // Updated fee calculation with 10% admin
        },
        {
          name: 'Square',
          status: 'Connected',
          monthlyVolume: 2400000, // Increased volume
          fees: 72000 * 1.10 // Updated fees with 10% admin
        },
        {
          name: 'PayPal',
          status: 'Connected',
          monthlyVolume: 1500000, // Increased volume
          fees: 45000 * 1.10 // Updated fees with 10% admin
        },
        {
          name: 'Plaid Banking',
          status: 'Connected',
          monthlyVolume: 1100000,
          fees: 33000 * 1.10 // Added 10% admin fee
        }
      ];

      setAccounts(mockAccounts);
      setProcessors(mockProcessors);
      setTotalRevenue(totalCalculatedRevenue); // Now uses calculated total
    } catch (error) {
      console.error('Error initializing platform data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const initiateTransfer = async (fromAccount: string, toAccount: string, amount: number) => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: {
          action: 'transfer',
          fromAccount,
          toAccount,
          amount,
          timestamp: new Date().toISOString()
        }
      });

      if (error) throw error;
      
      alert(`Transfer initiated: ${formatCurrency(amount)} from ${fromAccount} to ${toAccount}`);
    } catch (error) {
      console.error('Transfer error:', error);
      alert('Transfer failed. Please try again.');
    }
  };

  if (loading) {
    return <div className="animate-pulse bg-gray-200 h-96 rounded-lg"></div>;
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-600 to-purple-700 text-white">
        <CardHeader>
          <CardTitle className="text-3xl font-bold flex items-center gap-2">
            <Building2 className="h-8 w-8" />
            Complete Platform Overview & Payment System
          </CardTitle>
          <p className="text-blue-100">Comprehensive account management and internal transfer system</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-blue-200">Total Platform Revenue</p>
              <p className="text-4xl font-bold">{formatCurrency(totalRevenue)}</p>
            </div>
            <div>
              <p className="text-blue-200">Active Accounts</p>
              <p className="text-3xl font-bold">{accounts.length}</p>
            </div>
            <div>
              <p className="text-blue-200">Connected Processors</p>
              <p className="text-3xl font-bold">{processors.length}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="accounts" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="accounts">Account Management</TabsTrigger>
          <TabsTrigger value="transfers">Internal Transfers</TabsTrigger>
          <TabsTrigger value="processors">Payment Processors</TabsTrigger>
          <TabsTrigger value="instructions">Platform Instructions</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>
        <TabsContent value="accounts" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {accounts.map((account, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{account.accountType}</span>
                    <Badge className={account.status === 'Active' ? 'bg-green-500' : 'bg-red-500'}>
                      {account.status}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Account Number:</span>
                    <span className="font-mono">{account.accountNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Routing Number:</span>
                    <span className="font-mono">{account.routingNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Balance:</span>
                    <span className="text-xl font-bold text-green-600">
                      {formatCurrency(account.balance)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="transfers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Internal Account Transfers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button 
                    onClick={() => initiateTransfer('Trust Banking', 'Operating Account', 500000)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Transfer $500K to Operating
                  </Button>
                  <Button 
                    onClick={() => initiateTransfer('Operating Account', 'Escrow Account', 250000)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Transfer $250K to Escrow
                  </Button>
                  <Button 
                    onClick={() => initiateTransfer('Escrow Account', 'Trust Banking', 100000)}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    Transfer $100K to Trust
                  </Button>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Transfer Instructions:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• All transfers are processed in real-time</li>
                    <li>• Maximum single transfer: $1,000,000</li>
                    <li>• All transfers are logged and audited</li>
                    <li>• Transfers require admin approval for amounts over $100K</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="processors" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {processors.map((processor, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{processor.name}</span>
                    <Badge className="bg-green-500">{processor.status}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Monthly Volume:</span>
                    <span className="font-bold text-blue-600">
                      {formatCurrency(processor.monthlyVolume)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Processing Fees:</span>
                    <span className="font-bold text-red-600">
                      {formatCurrency(processor.fees)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Net Revenue:</span>
                    <span className="font-bold text-green-600">
                      {formatCurrency(processor.monthlyVolume - processor.fees)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="instructions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Platform Instructions & Documentation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">Account Information:</h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Business Name: Alazie LLC</li>
                  <li>• EIN: 82-1155909</li>
                  <li>• Address: 2408 Yanceyville St, Greensboro, NC 27405</li>
                  <li>• Primary Contact: Alucius Alford</li>
                </ul>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Revenue Tracking:</h4>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>• All revenue is tracked in real-time across platforms</li>
                  <li>• Monthly reports generated automatically</li>
                  <li>• Tax documents prepared quarterly</li>
                  <li>• Property acquisitions tracked separately</li>
                </ul>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-800 mb-2">Property & Asset Management:</h4>
                <ul className="text-sm text-purple-700 space-y-1">
                  <li>• All property purchases documented with deeds</li>
                  <li>• Vehicle titles stored in secure digital vault</li>
                  <li>• Insurance policies maintained and tracked</li>
                  <li>• Depreciation schedules calculated automatically</li>
                </ul>
              </div>
              
              <div className="bg-orange-50 p-4 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">Business Operations:</h4>
                <ul className="text-sm text-orange-700 space-y-1">
                  <li>• Operating agreements filed with state</li>
                  <li>• Banking relationships established with multiple institutions</li>
                  <li>• Credit lines available for expansion</li>
                  <li>• Automated bookkeeping and accounting systems</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          <PlatformInstructionsDocuments />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export { CompletePlatformOverview };
export default CompletePlatformOverview;