import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Link, CreditCard, Shield } from 'lucide-react';
import { PaymentTermsService, PAYMENT_TERMS_CONFIG } from '@/services/PaymentTermsConfig';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
export const PaymentProcessor = () => {
  const { toast } = useToast();
  const [selectedComponent, setSelectedComponent] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const STRIPE_CONNECT_URL = 'https://connect.stripe.com/d/setup/s/_StKxYRy3NqfUnvDSW7w5t6V0VW/YWNjdF8xUnhZSE1DbXZ5OFZhUVFa/9f9ec6f38af26a765';
  const STRIPE_DASHBOARD_URL = 'https://dashboard.stripe.com/b/acct_1RxYHMCmvy8VaQQZ/account/status';

  const handleComponentSelect = (componentName: string) => {
    setSelectedComponent(componentName);
    const terms = PaymentTermsService.getComponentTerms(componentName);
    if (terms) {
      const total = PaymentTermsService.calculateTotal(terms.basePrice, terms.processingFee);
      setAmount(total.toString());
    }
  };

  const processPayment = async () => {
    if (!selectedComponent || !paymentMethod) {
      toast({
        title: "Missing Information",
        description: "Please select a component and payment method",
        variant: "destructive"
      });
      return;
    }
    
    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: {
          amount: parseFloat(amount) * 100,
          currency: 'usd',
          payment_method: paymentMethod,
          component: selectedComponent,
          stripe_connect: true,
          description: `Payment for ${selectedComponent}`
        }
      });

      if (error) throw error;

      toast({
        title: "Payment Processed",
        description: `Successfully processed payment via Stripe Connect routing`,
      });

      // Reset form
      setSelectedComponent('');
      setPaymentMethod('');
      setAmount('');
    } catch (error) {
      console.error('Payment error:', error);
      toast({
        title: "Payment Failed",
        description: "Unable to process payment. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Payment Processing System</CardTitle>
          <div className="text-sm text-gray-600">
            <p><strong>{PAYMENT_TERMS_CONFIG.companyInfo.name}</strong></p>
            <p>{PAYMENT_TERMS_CONFIG.companyInfo.contact}</p>
            <p>{PAYMENT_TERMS_CONFIG.companyInfo.address}</p>
            <p>{PAYMENT_TERMS_CONFIG.companyInfo.city}, {PAYMENT_TERMS_CONFIG.companyInfo.state} {PAYMENT_TERMS_CONFIG.companyInfo.zip}</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Select Service Component</Label>
            <Select value={selectedComponent} onValueChange={handleComponentSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Choose service component" />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_TERMS_CONFIG.components.map((component) => (
                  <SelectItem key={component.componentName} value={component.componentName}>
                    {component.componentName} - ${component.basePrice}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Payment Method</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="online-check">Online Check (Immediate Processing)</SelectItem>
                <SelectItem value="ach">ACH Transfer</SelectItem>
                <SelectItem value="wire">Wire Transfer</SelectItem>
                <SelectItem value="card">Credit Card</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Total Amount</Label>
            <Input
              type="number"
              value={amount}
              readOnly
              className="bg-gray-100"
            />
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-800 mb-2">Payment Terms</h4>
            <div className="text-sm text-blue-700 space-y-1">
              <p><strong>Payment Due:</strong> {PAYMENT_TERMS_CONFIG.terms.paymentDue}</p>
              <p><strong>Check Processing:</strong> {PAYMENT_TERMS_CONFIG.terms.checkProcessing}</p>
              <p><strong>Late Fee:</strong> ${PAYMENT_TERMS_CONFIG.terms.lateFee}</p>
              <p><strong>Security:</strong> {PAYMENT_TERMS_CONFIG.terms.encryption}</p>
              <p><strong>Compliance:</strong> {PAYMENT_TERMS_CONFIG.terms.compliance.join(", ")}</p>
            </div>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-semibold text-green-800 mb-2 flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Stripe Dashboard Access
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <Button 
                onClick={() => window.open(STRIPE_DASHBOARD_URL, '_blank')}
                className="bg-green-600 hover:bg-green-700 text-white"
                size="sm"
              >
                <CreditCard className="h-3 w-3 mr-1" />
                Open Dashboard
              </Button>
              <Button 
                onClick={() => window.open(STRIPE_CONNECT_URL, '_blank')}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                size="sm"
              >
                <Link className="h-3 w-3 mr-1" />
                Setup Connect
              </Button>
            </div>
          </div>

          <Button onClick={processPayment} className="w-full" disabled={!selectedComponent || !paymentMethod || isProcessing}>
            {isProcessing ? 'Processing...' : `Process Payment - $${amount}`}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};