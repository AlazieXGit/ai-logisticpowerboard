import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { CheckCircle, XCircle, FileText, History, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

interface AccountReviewModalProps {
  approval: any;
  onClose: () => void;
}

export function AccountReviewModal({ approval, onClose }: AccountReviewModalProps) {
  const [accountDetails, setAccountDetails] = useState<any>(null);
  const [notes, setNotes] = useState('');
  const [newNote, setNewNote] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadAccountDetails();
  }, [approval]);

  const loadAccountDetails = async () => {
    try {
      const { data } = await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'get_account_details',
          data: { accountId: approval.account_id },
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });
      setAccountDetails(data);
    } catch (error) {
      console.error('Error loading account details:', error);
    }
  };

  const handleApprove = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'approve_account',
          data: {
            accountId: approval.account_id,
            approvalRequestId: approval.id,
            notes
          },
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });

      if (error) throw error;
      toast.success('Account approved successfully');
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    if (!notes.trim()) {
      toast.error('Please provide a reason for rejection');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'reject_account',
          data: {
            accountId: approval.account_id,
            approvalRequestId: approval.id,
            reason: notes
          },
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });

      if (error) throw error;
      toast.success('Account rejected');
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddNote = async () => {
    if (!newNote.trim()) return;

    try {
      await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'add_note',
          data: {
            accountId: approval.account_id,
            noteType: 'general',
            noteText: newNote
          },
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });

      setNewNote('');
      loadAccountDetails();
      toast.success('Note added');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Review Account: {approval.stripe_connect_accounts?.email}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="details" className="space-y-4">
          <TabsList>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="notes">Notes</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-semibold">{accountDetails?.account?.email}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Business Type</p>
                <p className="font-semibold">{accountDetails?.account?.business_type || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Account Type</p>
                <Badge>{accountDetails?.account?.account_type}</Badge>
              </div>
              <div>
                <p className="text-sm text-gray-500">Status</p>
                <Badge variant="outline">{accountDetails?.account?.status}</Badge>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Decision Notes</label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add notes about your decision..."
                rows={4}
              />
            </div>

            <div className="flex gap-3">
              <Button onClick={handleApprove} disabled={loading} className="flex-1 bg-green-600">
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve Account
              </Button>
              <Button onClick={handleReject} disabled={loading} variant="destructive" className="flex-1">
                <XCircle className="w-4 h-4 mr-2" />
                Reject Account
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="documents" className="space-y-3">
            {accountDetails?.documents?.map((doc: any) => (
              <div key={doc.id} className="p-4 border rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="font-semibold">{doc.file_name}</p>
                    <p className="text-sm text-gray-500">{doc.document_type}</p>
                  </div>
                </div>
                <Badge>{doc.verification_status}</Badge>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="notes" className="space-y-4">
            <div className="space-y-2">
              <Textarea
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Add a new note..."
                rows={3}
              />
              <Button onClick={handleAddNote} size="sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                Add Note
              </Button>
            </div>

            <div className="space-y-3">
              {accountDetails?.notes?.map((note: any) => (
                <div key={note.id} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline">{note.note_type}</Badge>
                    <span className="text-xs text-gray-500">
                      {new Date(note.created_at).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm">{note.note_text}</p>
                  <p className="text-xs text-gray-500 mt-1">By: {note.admin_email}</p>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-3">
            {accountDetails?.history?.map((item: any) => (
              <div key={item.id} className="p-3 border-l-4 border-blue-500 bg-gray-50">
                <div className="flex items-center justify-between mb-1">
                  <Badge>{item.action}</Badge>
                  <span className="text-xs text-gray-500">
                    {new Date(item.created_at).toLocaleString()}
                  </span>
                </div>
                <p className="text-sm font-semibold">{item.admin_email}</p>
                {item.reason && <p className="text-sm text-gray-600 mt-1">{item.reason}</p>}
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}