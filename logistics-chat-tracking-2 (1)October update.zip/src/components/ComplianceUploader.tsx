import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Upload, FileText, CheckCircle, XCircle, Clock } from 'lucide-react'
import { StripeConnectService } from '@/services/StripeConnectService'
import { supabase } from '@/lib/supabase'

interface ComplianceUploaderProps {
  connectAccountId: string
}

export default function ComplianceUploader({ connectAccountId }: ComplianceUploaderProps) {
  const [documents, setDocuments] = useState<any[]>([])
  const [uploading, setUploading] = useState(false)
  const [documentType, setDocumentType] = useState('identity')
  const [file, setFile] = useState<File | null>(null)

  useEffect(() => {
    loadDocuments()
  }, [connectAccountId])

  const loadDocuments = async () => {
    const { data } = await supabase
      .from('compliance_documents')
      .select('*')
      .eq('connect_account_id', connectAccountId)
      .order('created_at', { ascending: false })
    
    setDocuments(data || [])
  }

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)
    try {
      await StripeConnectService.uploadComplianceDocument(connectAccountId, file, documentType)
      setFile(null)
      loadDocuments()
    } catch (err) {
      console.error('Upload error:', err)
    } finally {
      setUploading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'rejected': return <XCircle className="h-4 w-4 text-red-500" />
      default: return <Clock className="h-4 w-4 text-yellow-500" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Compliance Documents</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4 p-4 border rounded-lg">
          <div>
            <Label>Document Type</Label>
            <Select value={documentType} onValueChange={setDocumentType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="identity">Identity Document</SelectItem>
                <SelectItem value="business_license">Business License</SelectItem>
                <SelectItem value="tax_form">Tax Form</SelectItem>
                <SelectItem value="bank_statement">Bank Statement</SelectItem>
                <SelectItem value="insurance">Insurance Certificate</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Upload File</Label>
            <Input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </div>

          <Button onClick={handleUpload} disabled={!file || uploading} className="w-full">
            <Upload className="h-4 w-4 mr-2" />
            {uploading ? 'Uploading...' : 'Upload Document'}
          </Button>
        </div>

        <div className="space-y-2">
          <h4 className="font-semibold">Uploaded Documents</h4>
          {documents.map((doc) => (
            <div key={doc.id} className="flex items-center justify-between p-3 border rounded">
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5" />
                <div>
                  <p className="font-medium">{doc.file_name}</p>
                  <p className="text-sm text-muted-foreground">{doc.document_type.replace('_', ' ')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusIcon(doc.verification_status)}
                <Badge variant={doc.verification_status === 'approved' ? 'default' : 'secondary'}>
                  {doc.verification_status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
