import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { History, Search, Filter, Download, ArrowUpDown, CreditCard, Building2, Zap, DollarSign } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Transaction {
  id: string;
  date: string;
  account: string;
  email: string;
  type: 'deposit' | 'withdrawal' | 'transfer';
  method: 'debit_credit' | 'ach' | 'wire' | 'direct_deposit';
  amount: number;
  status: 'completed' | 'pending' | 'failed';
  description: string;
  recipient?: string;
}

const TransactionHistoryPanel: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAccount, setFilterAccount] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const { toast } = useToast();

  useEffect(() => {
    loadTransactionHistory();
  }, []);

  useEffect(() => {
    filterTransactions();
  }, [transactions, searchTerm, filterAccount, filterType]);

  const loadTransactionHistory = () => {
    const mockTransactions: Transaction[] = [
      {
        id: 'TXN-001',
        date: new Date().toISOString(),
        account: 'AI Banking - banking@nukieson.com',
        email: 'banking@nukieson.com',
        type: 'withdrawal',
        method: 'debit_credit',
        amount: 15000,
        status: 'completed',
        description: 'Alucius Alford Unlimited Withdrawal',
        recipient: 'Alucius Alford'
      },
      {
        id: 'TXN-002',
        date: new Date(Date.now() - 3600000).toISOString(),
        account: 'Alaziel Banking - banking@alaziellc.com',
        email: 'banking@alaziellc.com',
        type: 'deposit',
        method: 'ach',
        amount: 25000,
        status: 'completed',
        description: 'Corporate Revenue Deposit'
      },
      {
        id: 'TXN-003',
        date: new Date(Date.now() - 7200000).toISOString(),
        account: 'AI Banking - banking@nukieson.com',
        email: 'banking@nukieson.com',
        type: 'transfer',
        method: 'wire',
        amount: 50000,
        status: 'pending',
        description: 'Wire Transfer to Business Partner'
      },
      {
        id: 'TXN-004',
        date: new Date(Date.now() - 10800000).toISOString(),
        account: 'AI Banking - banking@nukieson.com',
        email: 'banking@nukieson.com',
        type: 'withdrawal',
        method: 'direct_deposit',
        amount: 8500,
        status: 'completed',
        description: 'Direct Deposit Withdrawal',
        recipient: 'Employee Payroll'
      },
      {
        id: 'TXN-005',
        date: new Date(Date.now() - 14400000).toISOString(),
        account: 'Alaziel Banking - banking@alaziellc.com',
        email: 'banking@alaziellc.com',
        type: 'deposit',
        method: 'ach',
        amount: 75000,
        status: 'completed',
        description: 'Client Payment Received'
      }
    ];
    setTransactions(mockTransactions);
  };

  const filterTransactions = () => {
    let filtered = transactions;

    if (searchTerm) {
      filtered = filtered.filter(tx => 
        tx.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tx.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tx.recipient?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterAccount !== 'all') {
      filtered = filtered.filter(tx => tx.email === filterAccount);
    }

    if (filterType !== 'all') {
      filtered = filtered.filter(tx => tx.type === filterType);
    }

    setFilteredTransactions(filtered);
  };

  const getMethodIcon = (method: string) => {
    switch(method) {
      case 'debit_credit': return <CreditCard className="h-4 w-4" />;
      case 'ach': return <Building2 className="h-4 w-4" />;
      case 'wire': return <Zap className="h-4 w-4" />;
      case 'direct_deposit': return <DollarSign className="h-4 w-4" />;
      default: return <ArrowUpDown className="h-4 w-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'completed': return <Badge className="bg-green-600">COMPLETED</Badge>;
      case 'pending': return <Badge className="bg-yellow-600">PENDING</Badge>;
      case 'failed': return <Badge className="bg-red-600">FAILED</Badge>;
      default: return <Badge className="bg-gray-600">UNKNOWN</Badge>;
    }
  };

  const exportTransactions = () => {
    const csvContent = "data:text/csv;charset=utf-8," + 
      "ID,Date,Account,Type,Method,Amount,Status,Description\n" +
      filteredTransactions.map(tx => 
        `${tx.id},${tx.date},${tx.email},${tx.type},${tx.method},${tx.amount},${tx.status},${tx.description}`
      ).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "transaction_history.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({ title: 'Export Complete', description: 'Transaction history exported successfully' });
  };

  return (
    <Card className="bg-black/40 border-emerald-500">
      <CardHeader>
        <CardTitle className="text-emerald-400 flex items-center gap-2">
          <History className="h-5 w-5" />
          Transaction History - All Accounts
        </CardTitle>
        <div className="flex gap-2">
          <Badge className="bg-blue-600">AI BANKING</Badge>
          <Badge className="bg-green-600">ALAZIEL LLC</Badge>
          <Badge className="bg-purple-600">UNIFIED PLATFORM</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-900 border-emerald-500 text-white"
              />
            </div>
          </div>
          <Select value={filterAccount} onValueChange={setFilterAccount}>
            <SelectTrigger className="w-[200px] bg-gray-900 border-emerald-500">
              <SelectValue placeholder="Filter by account" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Accounts</SelectItem>
              <SelectItem value="banking@nukieson.com">AI Banking</SelectItem>
              <SelectItem value="banking@alaziellc.com">Alaziel LLC</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[150px] bg-gray-900 border-emerald-500">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="deposit">Deposits</SelectItem>
              <SelectItem value="withdrawal">Withdrawals</SelectItem>
              <SelectItem value="transfer">Transfers</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={exportTransactions} variant="outline" className="border-emerald-500">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>

        <div className="space-y-2 max-h-[600px] overflow-y-auto">
          {filteredTransactions.map((transaction) => (
            <Card key={transaction.id} className="bg-gray-900 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getMethodIcon(transaction.method)}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{transaction.id}</span>
                        {getStatusBadge(transaction.status)}
                      </div>
                      <p className="text-sm text-gray-400">{transaction.description}</p>
                      <p className="text-xs text-emerald-400">{transaction.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${
                      transaction.type === 'deposit' ? 'text-green-400' : 
                      transaction.type === 'withdrawal' ? 'text-red-400' : 'text-yellow-400'
                    }`}>
                      {transaction.type === 'deposit' ? '+' : transaction.type === 'withdrawal' ? '-' : '~'}
                      ${transaction.amount.toLocaleString()}
                    </div>
                    <p className="text-xs text-gray-400">
                      {new Date(transaction.date).toLocaleString()}
                    </p>
                    {transaction.recipient && (
                      <p className="text-xs text-blue-400">To: {transaction.recipient}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredTransactions.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No transactions found matching your criteria</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TransactionHistoryPanel;