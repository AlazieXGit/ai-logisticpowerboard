import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, MessageSquare, Truck, Brain, Zap, Shield, Globe, Clock, ArrowRight, CheckCircle } from 'lucide-react';


const FeatureShowcase: React.FC = () => {


  const capabilities = [
    {
      id: 'tracking',
      title: 'Load Tracking',
      icon: <Truck className="h-6 w-6" />,
      description: 'Real-time load monitoring and route optimization',
      features: [
        'GPS tracking with live updates',
        'Route optimization algorithms', 
        'Delivery time predictions',
        'Multi-stop route planning'
      ]
    },
    {
      id: 'analytics',
      title: 'Analytics Dashboard',
      icon: <BarChart3 className="h-6 w-6" />,
      description: 'Comprehensive performance insights and reporting',
      features: [
        'Performance metrics visualization',
        'Cost analysis and optimization',
        'Historical trend analysis',
        'Custom report generation'
      ]
    },
    {
      id: 'ai-chat',
      title: 'Nukie AI Assistant',
      icon: <MessageSquare className="h-6 w-6" />,
      description: '24/7 intelligent chat support for logistics queries',
      features: [
        'Natural language processing',
        'Instant problem resolution',
        'Load matching suggestions',
        'Market insights and trends'
      ]
    },
    {
      id: 'insights',
      title: 'AI Insights',
      icon: <Brain className="h-6 w-6" />,
      description: 'Machine learning powered business intelligence',
      features: [
        'Predictive load analysis',
        'Market demand forecasting',
        'Automated recommendations',
        'Risk assessment tools'
      ]
    }
  ];

  const benefits = [
    {
      icon: <Zap className="h-8 w-8 text-yellow-400" />,
      title: 'Lightning Fast',
      description: 'Process thousands of loads in seconds'
    },
    {
      icon: <Shield className="h-8 w-8 text-green-400" />,
      title: 'Enterprise Security',
      description: 'Bank-level encryption and data protection'
    },
    {
      icon: <Globe className="h-8 w-8 text-blue-400" />,
      title: 'Global Coverage',
      description: 'Worldwide logistics network integration'
    },
    {
      icon: <Clock className="h-8 w-8 text-purple-400" />,
      title: '24/7 Support',
      description: 'Round-the-clock AI assistance and monitoring'
    }
  ];

  return (
    <div className="py-20 bg-gradient-to-b from-slate-900 to-black relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 circuit-bg opacity-10" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-6xl font-bold text-white mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent neon-text">
              Integrated Capabilities
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            Experience the full power of AI-driven logistics management with our comprehensive suite of integrated tools
          </p>
        </div>

        <Tabs defaultValue="tracking" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800/50 mb-8 glass">
            {capabilities.map((cap) => (
              <TabsTrigger 
                key={cap.id} 
                value={cap.id} 
                className="text-white data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white"
              >
                <div className="flex items-center gap-2">
                  {cap.icon}
                  <span className="hidden sm:inline">{cap.title}</span>
                </div>
              </TabsTrigger>
            ))}
          </TabsList>

          {capabilities.map((cap) => (
            <TabsContent key={cap.id} value={cap.id}>
              <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-purple-500/20 glass backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="p-4 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl text-white animate-pulse-glow">
                      {cap.icon}
                    </div>
                    <div>
                      <CardTitle className="text-white text-3xl">{cap.title}</CardTitle>
                      <CardDescription className="text-gray-300 text-lg mt-2">
                        {cap.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {cap.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-3 p-4 bg-slate-700/30 rounded-lg glass hover:bg-slate-700/50 transition-all">
                        <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>

        {/* Benefits Section */}
        <div className="mt-20">
          <h3 className="text-4xl font-bold text-white text-center mb-12">
            <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Why Choose AI Nukie?
            </span>
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 glass backdrop-blur-sm hover:transform hover:scale-105">
                <CardHeader className="text-center">
                  <div className="flex justify-center mb-4 animate-float" style={{animationDelay: `${index * 0.3}s`}}>
                    {benefit.icon}
                  </div>
                  <CardTitle className="text-white text-xl">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-300 text-center leading-relaxed">
                    {benefit.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Tech Stack */}
        <div className="mt-20 text-center">
          <h3 className="text-3xl font-bold text-white mb-8">
            Powered by Advanced Technology
          </h3>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {['Machine Learning', 'Real-time Analytics', 'Cloud Computing', 'Blockchain Security', 'IoT Integration', 'Predictive AI'].map((tech) => (
              <Badge key={tech} variant="secondary" className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 text-purple-300 px-6 py-3 text-sm font-medium glass">
                {tech}
              </Badge>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div className="mt-20 text-center">
          <div className="glass p-12 rounded-2xl bg-gradient-to-r from-purple-900/20 to-blue-900/20">
            <h3 className="text-4xl font-bold text-white mb-6">
              Ready to Transform Your Logistics?
            </h3>
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Join thousands of logistics professionals who trust AI Nukie for their operations. 
              Experience the future of logistics management today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-4 text-lg font-semibold animate-pulse-glow"
                onClick={() => console.log('Dashboard access requested')}
              >
                Try Dashboard Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white px-8 py-4 text-lg font-semibold glass"
              >
                Schedule Demo
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeatureShowcase;