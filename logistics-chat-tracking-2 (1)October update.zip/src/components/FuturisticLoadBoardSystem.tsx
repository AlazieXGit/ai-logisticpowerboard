import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Truck, MapPin, DollarSign, Clock, Zap, Brain, 
  Target, TrendingUp, Shield, Gauge, Bot, Star
} from 'lucide-react';
import { AutomatedFeeSystem } from './AutomatedFeeSystem';

interface Load {
  id: string;
  origin: string;
  destination: string;
  distance: number;
  rate: number;
  weight: number;
  type: 'freight' | 'medical' | 'courier';
  urgency: 'low' | 'medium' | 'high' | 'critical';
  aiScore: number;
  negotiated: boolean;
  autoBooked: boolean;
}

const FuturisticLoadBoardSystem: React.FC = () => {
  const [loads, setLoads] = useState<Load[]>([]);
  const [aiActive, setAiActive] = useState(true);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [autoBookingRate, setAutoBookingRate] = useState(87);

  useEffect(() => {
    // Simulate real-time load generation
    const generateLoads = () => {
      const newLoads: Load[] = Array.from({ length: 15 }, (_, i) => ({
        id: `LOAD-${Date.now()}-${i}`,
        origin: ['Dallas, TX', 'Atlanta, GA', 'Chicago, IL', 'Phoenix, AZ'][Math.floor(Math.random() * 4)],
        destination: ['Miami, FL', 'Seattle, WA', 'New York, NY', 'Los Angeles, CA'][Math.floor(Math.random() * 4)],
        distance: Math.floor(Math.random() * 2000) + 200,
        rate: Math.floor(Math.random() * 5000) + 1500,
        weight: Math.floor(Math.random() * 40000) + 5000,
        type: ['freight', 'medical', 'courier'][Math.floor(Math.random() * 3)] as Load['type'],
        urgency: ['low', 'medium', 'high', 'critical'][Math.floor(Math.random() * 4)] as Load['urgency'],
        aiScore: Math.floor(Math.random() * 100) + 1,
        negotiated: Math.random() > 0.6,
        autoBooked: Math.random() > 0.3
      }));
      setLoads(newLoads);
      setTotalRevenue(newLoads.reduce((sum, load) => sum + load.rate, 0));
    };

    generateLoads();
    const interval = setInterval(generateLoads, 5000);
    return () => clearInterval(interval);
  }, []);

  const getUrgencyColor = (urgency: Load['urgency']) => {
    switch (urgency) {
      case 'critical': return 'bg-red-600';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const getTypeIcon = (type: Load['type']) => {
    switch (type) {
      case 'medical': return <Shield className="h-4 w-4" />;
      case 'courier': return <Zap className="h-4 w-4" />;
      default: return <Truck className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-cyan-500">
        <CardHeader>
          <CardTitle className="text-2xl text-cyan-400 flex items-center gap-3">
            <Brain className="h-8 w-8" />
            AI-Powered Load Board 2029
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">${totalRevenue.toLocaleString()}</div>
              <div className="text-sm text-gray-300">Total Revenue</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400">{loads.length}</div>
              <div className="text-sm text-gray-300">Active Loads</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400">{autoBookingRate}%</div>
              <div className="text-sm text-gray-300">Auto-Booking Rate</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                <Bot className="h-6 w-6 text-cyan-400" />
                <Badge className={aiActive ? 'bg-green-600' : 'bg-red-600'}>
                  AI {aiActive ? 'ACTIVE' : 'OFFLINE'}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="live-board" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="live-board">Live Board</TabsTrigger>
          <TabsTrigger value="auto-booking">Auto Booking</TabsTrigger>
          <TabsTrigger value="negotiations">Negotiations</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="live-board" className="space-y-4">
          {loads.map((load) => (
            <Card key={load.id} className="bg-gray-800/50 border-gray-600 hover:border-cyan-500 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(load.type)}
                      <Badge className={getUrgencyColor(load.urgency)}>
                        {load.urgency.toUpperCase()}
                      </Badge>
                    </div>
                    <div>
                      <div className="text-white font-semibold">{load.id}</div>
                      <div className="text-sm text-gray-400">
                        {load.origin} → {load.destination}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-green-400 font-bold">${load.rate.toLocaleString()}</div>
                      <div className="text-sm text-gray-400">{load.distance} miles</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-400" />
                      <span className="text-yellow-400">{load.aiScore}</span>
                    </div>
                    {load.autoBooked && (
                      <Badge className="bg-purple-600">AUTO-BOOKED</Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="auto-booking">
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="text-cyan-400">Autonomous Booking Engine</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-white">AI Booking Status</span>
                <Button
                  onClick={() => setAiActive(!aiActive)}
                  className={aiActive ? 'bg-green-600' : 'bg-red-600'}
                >
                  {aiActive ? 'ACTIVE' : 'INACTIVE'}
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-gray-300">Min Rate Threshold</label>
                  <Input defaultValue="$2,500" className="bg-gray-700 text-white" />
                </div>
                <div>
                  <label className="text-gray-300">Max Distance</label>
                  <Input defaultValue="1,500 miles" className="bg-gray-700 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="negotiations">
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="text-orange-400">AI Negotiation Engine</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-green-400 text-xl">+$127,500 Additional Revenue</div>
                <div className="text-sm text-gray-300">Generated through AI negotiations this month</div>
                <div className="grid grid-cols-3 gap-4 mt-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">342</div>
                    <div className="text-sm text-gray-400">Successful Negotiations</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">23%</div>
                    <div className="text-sm text-gray-400">Avg Rate Increase</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">1.2s</div>
                    <div className="text-sm text-gray-400">Avg Response Time</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800/50 border-gray-600">
              <CardHeader>
                <CardTitle className="text-green-400">Revenue Optimization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">This Month</span>
                    <span className="text-green-400">$2,847,592</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Projected</span>
                    <span className="text-blue-400">$3,200,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">AI Enhancement</span>
                    <span className="text-purple-400">+47%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gray-800/50 border-gray-600">
              <CardHeader>
                <CardTitle className="text-blue-400">Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Load Completion Rate</span>
                    <span className="text-green-400">98.7%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Customer Satisfaction</span>
                    <span className="text-yellow-400">4.9/5</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Profit Margin</span>
                    <span className="text-purple-400">34.2%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FuturisticLoadBoardSystem;