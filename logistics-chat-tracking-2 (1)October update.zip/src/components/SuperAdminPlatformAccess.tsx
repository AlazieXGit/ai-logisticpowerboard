import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Settings, Shield, Database, Building2, Truck, CreditCard, Users, FileText, BarChart3 } from 'lucide-react';
import LoginUsersDisplay from './LoginUsersDisplay';
import BankingMasterView from './BankingMasterView';
import ACHNetworkRegistration from './ACHNetworkRegistration';
import BankingInstitutionManager from './BankingInstitutionManager';
import SuperAdminAIAssistant from './SuperAdminAIAssistant';
import ComprehensiveDataBreakdown from './ComprehensiveDataBreakdown';

interface PlatformTab {
  id: string;
  name: string;
  icon: React.ReactNode;
  status: 'active' | 'inactive' | 'maintenance';
  accessLevel: 'full' | 'read' | 'restricted';
}

const SuperAdminPlatformAccess: React.FC = () => {
  const [platformTabs, setPlatformTabs] = useState<PlatformTab[]>([
    { id: 'banking', name: 'Banking System', icon: <Building2 className="h-4 w-4" />, status: 'active', accessLevel: 'full' },
    { id: 'tms', name: 'TMS System', icon: <Truck className="h-4 w-4" />, status: 'active', accessLevel: 'full' },
    { id: 'payments', name: 'Payment Processor', icon: <CreditCard className="h-4 w-4" />, status: 'active', accessLevel: 'full' },
    { id: 'database', name: 'Database Admin', icon: <Database className="h-4 w-4" />, status: 'active', accessLevel: 'full' },
    { id: 'users', name: 'User Management', icon: <Users className="h-4 w-4" />, status: 'active', accessLevel: 'full' },
    { id: 'documents', name: 'Document System', icon: <FileText className="h-4 w-4" />, status: 'active', accessLevel: 'full' },
    { id: 'analytics', name: 'Analytics Dashboard', icon: <BarChart3 className="h-4 w-4" />, status: 'active', accessLevel: 'full' },
    { id: 'security', name: 'Security Center', icon: <Shield className="h-4 w-4" />, status: 'active', accessLevel: 'full' }
  ]);

  const toggleTabStatus = (tabId: string) => {
    setPlatformTabs(tabs => 
      tabs.map(tab => 
        tab.id === tabId 
          ? { ...tab, status: tab.status === 'active' ? 'inactive' : 'active' }
          : tab
      )
    );
  };

  const changeAccessLevel = (tabId: string, level: 'full' | 'read' | 'restricted') => {
    setPlatformTabs(tabs => 
      tabs.map(tab => 
        tab.id === tabId ? { ...tab, accessLevel: level } : tab
      )
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-600';
      case 'inactive': return 'bg-red-600';
      case 'maintenance': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  const getAccessColor = (level: string) => {
    switch (level) {
      case 'full': return 'bg-blue-600';
      case 'read': return 'bg-orange-600';
      case 'restricted': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Super Admin Platform Control Center
          </CardTitle>
          <Badge className="bg-blue-600 w-fit">MASTER ADMIN - ALUCIUS ALFORD</Badge>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="users" className="w-full">
            <TabsList className="grid w-full grid-cols-7">
              <TabsTrigger value="users">Login Users</TabsTrigger>
              <TabsTrigger value="banking">Banking System</TabsTrigger>
              <TabsTrigger value="ach">ACH Network</TabsTrigger>
              <TabsTrigger value="institutions">Bank Manager</TabsTrigger>
              <TabsTrigger value="ai-assistant">AI Assistant</TabsTrigger>
              <TabsTrigger value="overview">Platform Tabs</TabsTrigger>
              <TabsTrigger value="data-breakdown">Data Breakdown</TabsTrigger>
            </TabsList>
            
            <TabsContent value="users" className="space-y-4">
              <LoginUsersDisplay />
            </TabsContent>
            
            <TabsContent value="banking" className="space-y-4">
              <BankingMasterView />
            </TabsContent>
            
            <TabsContent value="ach" className="space-y-4">
              <ACHNetworkRegistration />
            </TabsContent>
            
            <TabsContent value="institutions" className="space-y-4">
              <BankingInstitutionManager />
            </TabsContent>
            
            <TabsContent value="ai-assistant" className="space-y-4">
              <SuperAdminAIAssistant />
            </TabsContent>
            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4">
                {platformTabs.map((tab) => (
                  <div key={tab.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg border border-gray-600">
                    <div className="flex items-center gap-3">
                      {tab.icon}
                      <div>
                        <h3 className="text-white font-medium">{tab.name}</h3>
                        <p className="text-gray-400 text-sm">Platform Tab ID: {tab.id}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <Badge className={getStatusColor(tab.status)}>
                        {tab.status.toUpperCase()}
                      </Badge>
                      <Badge className={getAccessColor(tab.accessLevel)}>
                        {tab.accessLevel.toUpperCase()}
                      </Badge>
                      
                      <div className="flex items-center gap-2">
                        <Label htmlFor={`toggle-${tab.id}`} className="text-sm text-gray-300">
                          Active
                        </Label>
                        <Switch
                          id={`toggle-${tab.id}`}
                          checked={tab.status === 'active'}
                          onCheckedChange={() => toggleTabStatus(tab.id)}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="permissions" className="space-y-4">
              <div className="grid gap-4">
                {platformTabs.map((tab) => (
                  <Card key={tab.id} className="bg-gray-800/30 border-gray-600">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white text-lg flex items-center gap-2">
                        {tab.icon}
                        {tab.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant={tab.accessLevel === 'full' ? 'default' : 'outline'}
                          onClick={() => changeAccessLevel(tab.id, 'full')}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Full Access
                        </Button>
                        <Button
                          size="sm"
                          variant={tab.accessLevel === 'read' ? 'default' : 'outline'}
                          onClick={() => changeAccessLevel(tab.id, 'read')}
                          className="bg-orange-600 hover:bg-orange-700"
                        >
                          Read Only
                        </Button>
                        <Button
                          size="sm"
                          variant={tab.accessLevel === 'restricted' ? 'default' : 'outline'}
                          onClick={() => changeAccessLevel(tab.id, 'restricted')}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Restricted
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="data-breakdown" className="space-y-4">
              <ComprehensiveDataBreakdown />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminPlatformAccess;