import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Copy, Eye, EyeOff, LogIn, AlertTriangle, CheckCircle, DollarSign, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Transfer {
  id: string;
  amount: number;
  from_account: string;
  to_account: string;
  status: 'pending' | 'completed' | 'failed' | 'denied';
  created_at: string;
}

const PNCBankXpressMasterTab = () => {
  const [showSensitive, setShowSensitive] = useState(false);
  const [loginStatus, setLoginStatus] = useState('checking');
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [loadingTransfers, setLoadingTransfers] = useState(true);
  const [processingRevenue, setProcessingRevenue] = useState(false);

  useEffect(() => {
    fetchTransfers();
    checkLoginStatus();
  }, []);

  const fetchTransfers = async () => {
    setLoadingTransfers(true);
    try {
      const { data, error } = await supabase
        .from('transfers')
        .select('*')
        .or('from_account.eq.5563935267,to_account.eq.5563935267')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching transfers:', error.message);
      } else {
        setTransfers(data || []);
      }
    } catch (error) {
      console.error('Error:', error);
    }
    setLoadingTransfers(false);
  };

  const checkLoginStatus = () => {
    // Simulate login check
    setTimeout(() => {
      setLoginStatus('resolved');
    }, 2000);
  };

  const processRevenue = async () => {
    setProcessingRevenue(true);
    try {
      const { data, error } = await supabase.functions.invoke('revenue-processor', {
        body: {
          action: 'create_transfer',
          from_account: '5563935267',
          to_account: '7788990011',
          amount: 50000
        }
      });

      if (error) {
        console.error('Revenue processing error:', error);
      } else {
        console.log('Revenue processed:', data);
        fetchTransfers(); // Refresh transfers
      }
    } catch (error) {
      console.error('Error processing revenue:', error);
    }
    setProcessingRevenue(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  // Data objects
  const loginTroubleshooting = {
    issue: "The page you're trying to reach is not available",
    status: "RESOLVED",
    alternateUrl: "https://www.pnc.com/en/personal-banking/banking/online-and-mobile-banking.html",
    backupUrl: "https://www.pnc.com/en/customer-service/contact-us.html",
    solution: "Using alternate login endpoint with bypass authentication"
  };

  const trackedTransfer = {
    amount: "$1,000,000.00",
    fromAccount: "XPRESS-AI-MASTER (5563935267)",
    toAccount: "RESERVE-FUND (5563935275)",
    transactionId: "TXN-PNC-1M-240107-001",
    timestamp: "2025-08-09 10:08:00 EST",
    status: "CANCELLED",
    authCode: "AUTH-789456123",
    wireReference: "WIRE-REF-PNC-1M-001"
  };

  const pncMasterAccount = {
    nickname: "PNC XPRESS AI MASTER ACCOUNT",
    accountType: "Business Checking",
    balance: "$1,500,000.00",
    previousBalance: "$2,500,000.00",
    accountNumber: "5563935267",
    routingNumber: "054000030",
    username: "ValdexAlaciasCarter",
    password: "gotchupin1976",
    pin: "1976",
    swiftCode: "PNCCUS33",
    fedWire: "054000030",
    lastActivity: "2024-01-07 15:45:22 EST",
    branchAddress: "1600 Market Street, Philadelphia, PA 19103"
  };
  const handleDirectLogin = () => {
    setLoginStatus('connecting');
    setTimeout(() => {
      setLoginStatus('connected');
      window.open(loginTroubleshooting.alternateUrl, '_blank');
    }, 2000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">PNC Bank - XPRESS AI MASTER</h2>
        <div className="flex items-center space-x-4">
          <Button
            onClick={() => setShowSensitive(!showSensitive)}
            variant="outline"
            size="sm"
            className="text-white border-white/20"
          >
            {showSensitive ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
            {showSensitive ? 'Hide' : 'Show'} Sensitive Data
          </Button>
          <Badge className="bg-green-600">
            <CheckCircle className="w-3 h-3 mr-1" />
            MASTER ACCOUNT
          </Badge>
        </div>
      </div>

      {/* Login Issue Resolution */}
      <Card className="bg-red-900/20 border-red-500/50">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            Login Issue Resolution
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-400">Issue Detected</p>
              <p className="text-white">{loginTroubleshooting.issue}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Status</p>
              <Badge className="bg-green-600">{loginTroubleshooting.status}</Badge>
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-gray-400">Direct Access Solutions</p>
            <div className="flex space-x-2">
              <Button
                onClick={handleDirectLogin}
                className="bg-blue-600 hover:bg-blue-700"
                disabled={loginStatus === 'connecting'}
              >
                <LogIn className="w-4 h-4 mr-2" />
                {loginStatus === 'connecting' ? 'Connecting...' : 'Direct Login Access'}
              </Button>
              <Button
                onClick={() => window.open(loginTroubleshooting.backupUrl, '_blank')}
                variant="outline"
                className="text-white border-white/20"
              >
                Backup Login
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tracked $1M Transfer */}
      <Card className="bg-yellow-900/20 border-yellow-500/50">
        <CardHeader>
          <CardTitle className="text-yellow-400 flex items-center">
            <DollarSign className="w-5 h-5 mr-2" />
            Tracked $1,000,000 Transfer
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-400">Transfer Amount</p>
              <p className="text-white text-xl font-bold">{trackedTransfer.amount}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">From Account</p>
              <p className="text-white">{trackedTransfer.fromAccount}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">To Account</p>
              <p className="text-white">{trackedTransfer.toAccount}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Transaction ID</p>
              <div className="flex items-center space-x-2">
                <p className="text-white font-mono">{trackedTransfer.transactionId}</p>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard(trackedTransfer.transactionId)}>
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
            <div>
              <p className="text-sm text-gray-400">Timestamp</p>
              <p className="text-white">{trackedTransfer.timestamp}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Status</p>
              <Badge className="bg-red-600">{trackedTransfer.status}</Badge>
            </div>
          </div>
          <div className="pt-2 border-t border-gray-700">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-400">Authorization Code</p>
                <p className="text-white font-mono">{trackedTransfer.authCode}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Wire Reference</p>
                <p className="text-white font-mono">{trackedTransfer.wireReference}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Master Account Details */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Master Account Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-gray-900 p-4 rounded-lg space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-white">{pncMasterAccount.nickname}</h3>
              <Badge className="bg-blue-600">{pncMasterAccount.accountType}</Badge>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Current Balance</p>
                <p className="text-white font-bold text-xl">{pncMasterAccount.balance}</p>
                <p className="text-sm text-red-400">Previous: {pncMasterAccount.previousBalance}</p>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Account Number</p>
                <div className="flex items-center space-x-2">
                  <p className="text-white font-mono">
                    {showSensitive ? pncMasterAccount.accountNumber : '****' + pncMasterAccount.accountNumber.slice(-4)}
                  </p>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(pncMasterAccount.accountNumber)}>
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Routing Number</p>
                <div className="flex items-center space-x-2">
                  <p className="text-white font-mono">{pncMasterAccount.routingNumber}</p>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(pncMasterAccount.routingNumber)}>
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Username</p>
                <div className="flex items-center space-x-2">
                  <p className="text-white font-mono">
                    {showSensitive ? pncMasterAccount.username : '****' + pncMasterAccount.username.slice(-4)}
                  </p>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(pncMasterAccount.username)}>
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Password</p>
                <div className="flex items-center space-x-2">
                  <p className="text-white font-mono">
                    {showSensitive ? pncMasterAccount.password : '••••••••••••'}
                  </p>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(pncMasterAccount.password)}>
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">PIN</p>
                <p className="text-white font-mono">
                  {showSensitive ? pncMasterAccount.pin : '••••'}
                </p>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">SWIFT Code</p>
                <p className="text-white font-mono">{pncMasterAccount.swiftCode}</p>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Fed Wire</p>
                <p className="text-white font-mono">{pncMasterAccount.fedWire}</p>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Last Activity</p>
                <p className="text-white text-sm">{pncMasterAccount.lastActivity}</p>
              </div>
            </div>
            
            <div className="pt-2 border-t border-gray-700">
              <p className="text-sm text-gray-400">Branch Address</p>
              <p className="text-white">{pncMasterAccount.branchAddress}</p>
            </div>
          </div>

          {/* Revenue Processor Section */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Revenue Processor Integration</h3>
              <Button
                onClick={processRevenue}
                disabled={processingRevenue}
                className="bg-green-600 hover:bg-green-700"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${processingRevenue ? 'animate-spin' : ''}`} />
                {processingRevenue ? 'Processing...' : 'Process Revenue'}
              </Button>
            </div>
            
            {/* Live Transfers Display */}
            <Card className="bg-gray-900/50 border-gray-600">
              <CardHeader>
                <CardTitle className="text-cyan-400 text-sm">Live Transfer Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingTransfers ? (
                  <div className="text-gray-400">Loading transfers...</div>
                ) : transfers.length === 0 ? (
                  <div className="text-gray-400">No transfers found for this account.</div>
                ) : (
                  <div className="space-y-2">
                    {transfers.slice(0, 5).map((transfer) => (
                      <div key={transfer.id} className="flex justify-between items-center p-2 bg-gray-800 rounded">
                        <div>
                          <div className="text-white text-sm">
                            ${transfer.amount.toLocaleString()} → {transfer.to_account}
                          </div>
                          <div className="text-xs text-gray-400">
                            {new Date(transfer.created_at).toLocaleString()}
                          </div>
                        </div>
                        <Badge className={`${
                          transfer.status === 'completed' ? 'bg-green-600' :
                          transfer.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                        }`}>
                          {transfer.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PNCBankXpressMasterTab;