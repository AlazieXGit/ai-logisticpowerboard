import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { User, MapPin, Shield, Mail } from 'lucide-react';

interface PlaceOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: any;
  vendor: any;
  onConfirmOrder: (orderData: any) => void;
}

const PlaceOrderModal: React.FC<PlaceOrderModalProps> = ({
  isOpen,
  onClose,
  product,
  vendor,
  onConfirmOrder
}) => {
  const [quantity, setQuantity] = useState(1);
  const [shippingAddress, setShippingAddress] = useState({
    name: 'Alucius Alford',
    company: 'AI Alazie Xpress',
    address: '123 Business District',
    city: 'Atlanta',
    state: 'GA',
    zip: '30309',
    country: 'USA'
  });
  const [needsInsurance, setNeedsInsurance] = useState(true);
  const [expeditedShipping, setExpeditedShipping] = useState(false);
  const [specialInstructions, setSpecialInstructions] = useState('');

  const calculateTotal = () => {
    const basePrice = parseFloat(product?.price?.replace('$', '').replace(',', '') || '0');
    const subtotal = basePrice * quantity;
    const shipping = parseFloat(vendor?.shippingCost?.replace('$', '').replace(',', '') || '0');
    const insurance = needsInsurance ? subtotal * 0.02 : 0;
    const expedited = expeditedShipping ? 500 : 0;
    return subtotal + shipping + insurance + expedited;
  };

  const handleSubmitOrder = () => {
    const orderData = {
      product,
      vendor,
      quantity,
      shippingAddress,
      needsInsurance,
      expeditedShipping,
      specialInstructions,
      total: calculateTotal(),
      buyer: 'Alucius Alford',
      orderDate: new Date().toISOString()
    };
    onConfirmOrder(orderData);
  };

  if (!product) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-gray-900 text-white border-green-500">
        <DialogHeader>
          <DialogTitle className="text-2xl text-green-400">
            Place Order - {product.name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <Card className="bg-gray-800/50 border-gray-600">
            <CardContent className="p-4">
              <h3 className="font-semibold mb-2 text-white">Order Summary</h3>
              <div className="flex justify-between items-center mb-2">
                <span>{product.name}</span>
                <span className="text-green-400">{product.price}</span>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="quantity" className="text-sm">Quantity:</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                  className="w-20 bg-gray-700 border-gray-600"
                />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-600">
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-white flex items-center gap-2">
                <User className="h-4 w-4" />
                Buyer Information
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-sm">Full Name</Label>
                  <Input 
                    value={shippingAddress.name}
                    onChange={(e) => setShippingAddress({...shippingAddress, name: e.target.value})}
                    className="bg-gray-700 border-gray-600"
                  />
                </div>
                <div>
                  <Label className="text-sm">Company</Label>
                  <Input 
                    value={shippingAddress.company}
                    onChange={(e) => setShippingAddress({...shippingAddress, company: e.target.value})}
                    className="bg-gray-700 border-gray-600"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-600">
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-white flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Shipping Address
              </h3>
              <div className="space-y-3">
                <Input 
                  placeholder="Address"
                  value={shippingAddress.address}
                  onChange={(e) => setShippingAddress({...shippingAddress, address: e.target.value})}
                  className="bg-gray-700 border-gray-600"
                />
                <div className="grid grid-cols-3 gap-2">
                  <Input 
                    placeholder="City"
                    value={shippingAddress.city}
                    onChange={(e) => setShippingAddress({...shippingAddress, city: e.target.value})}
                    className="bg-gray-700 border-gray-600"
                  />
                  <Input 
                    placeholder="State"
                    value={shippingAddress.state}
                    onChange={(e) => setShippingAddress({...shippingAddress, state: e.target.value})}
                    className="bg-gray-700 border-gray-600"
                  />
                  <Input 
                    placeholder="ZIP"
                    value={shippingAddress.zip}
                    onChange={(e) => setShippingAddress({...shippingAddress, zip: e.target.value})}
                    className="bg-gray-700 border-gray-600"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="insurance"
                checked={needsInsurance}
                onCheckedChange={setNeedsInsurance}
              />
              <Label htmlFor="insurance" className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Add Insurance Coverage (+2% of order value)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="expedited"
                checked={expeditedShipping}
                onCheckedChange={setExpeditedShipping}
              />
              <Label htmlFor="expedited">Expedited Shipping (+$500)</Label>
            </div>
          </div>

          <div>
            <Label className="text-sm">Special Instructions</Label>
            <Textarea 
              placeholder="Any special delivery or handling instructions..."
              value={specialInstructions}
              onChange={(e) => setSpecialInstructions(e.target.value)}
              className="bg-gray-700 border-gray-600"
            />
          </div>

          <Card className="bg-green-900/20 border-green-500">
            <CardContent className="p-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>${(parseFloat(product.price.replace('$', '').replace(',', '')) * quantity).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping:</span>
                  <span>{vendor?.shippingCost}</span>
                </div>
                {needsInsurance && (
                  <div className="flex justify-between">
                    <span>Insurance:</span>
                    <span>${(parseFloat(product.price.replace('$', '').replace(',', '')) * quantity * 0.02).toFixed(2)}</span>
                  </div>
                )}
                {expeditedShipping && (
                  <div className="flex justify-between">
                    <span>Expedited:</span>
                    <span>$500.00</span>
                  </div>
                )}
                <hr className="border-gray-600" />
                <div className="flex justify-between font-bold text-lg text-green-400">
                  <span>Total:</span>
                  <span>${calculateTotal().toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleSubmitOrder}
              className="bg-green-600 hover:bg-green-700 flex-1"
            >
              <Mail className="h-4 w-4 mr-2" />
              Confirm Order & Send Emails
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PlaceOrderModal;