import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Shield, DollarSign, TrendingUp, Zap, Building2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { PNCVirtualAccountsOverview } from './PNCVirtualAccountsOverview';
import { ComprehensiveDepositMonitor } from './ComprehensiveDepositMonitor';
export const UrgentPNCBankingSystem = () => {
  const [systemStatus, setSystemStatus] = useState('active');
  const [revenueTotal, setRevenueTotal] = useState(0);
  const [dailyDeposits, setDailyDeposits] = useState(0);

  const pncCredentials = {
    username: "alazieuser2024",
    password: "gotchupin1976",
    directAccessPassword: "gotchupin1976",
    securityCode: "PNC2024"
  };

  const pncAccounts = [
    {
      id: 'primary',
      name: 'PNC Virtual Primary',
      accountNumber: '5563935267',
      routingNumber: '054000030',
      balance: 2847592.45,
      status: 'ACTIVE'
    },
    {
      id: 'reserve',
      name: 'PNC Reserve Account',
      accountNumber: '5563935275',
      routingNumber: '054000030',
      balance: 1456789.23,
      status: 'ACTIVE'
    },
    {
      id: 'growth',
      name: 'PNC Growth Account',
      accountNumber: '5563935283',
      routingNumber: '054000030',
      balance: 987654.12,
      status: 'ACTIVE'
    }
  ];

  const wellsFargoIntegration = {
    accountNumber: '4567891234',
    routingNumber: '121000248',
    trialDeposits: [
      { amount: 0.32, date: '09/03/2020', description: 'PNC Bank Trial Deposit' },
      { amount: 0.67, date: '09/03/2020', description: 'PNC Bank Trial Deposit' }
    ]
  };

  const handleDepositConfirmation = () => {
    setDepositReceived(true);
    toast({
      title: "URGENT: Trial Deposits Confirmed",
      description: "PNC Bank trial deposits acknowledged in Wells Fargo account",
    });
  };

  return (
    <div className="space-y-6">
      <Alert className="border-red-500 bg-red-900/50">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="text-red-200">
          <strong>URGENT SYSTEM OVERRIDE:</strong> PNC Bank trial deposits must be acknowledged before platform entry
        </AlertDescription>
      </Alert>

      <Card className="bg-gradient-to-r from-red-900 to-orange-900 border-red-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            URGENT PNC BANKING SYSTEM
            <Badge className="bg-red-600 animate-pulse">PRIORITY ACCESS</Badge>
          </CardTitle>
        </CardHeader>
      </Card>
      <Tabs defaultValue="deposits" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-gray-800">
          <TabsTrigger value="deposits">
            <div className="flex items-center gap-2 bg-orange-500 px-2 py-1 rounded">
              <AlertTriangle className="h-4 w-4" />
              Live Deposits
            </div>
          </TabsTrigger>
          <TabsTrigger value="accounts">PNC Accounts</TabsTrigger>
          <TabsTrigger value="credentials">Direct Access</TabsTrigger>
          <TabsTrigger value="integration">Wells Fargo</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Routing</TabsTrigger>
        </TabsList>

        <TabsContent value="deposits" className="space-y-4">
          <ComprehensiveDepositMonitor />
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <PNCVirtualAccountsOverview />
        </TabsContent>

        <TabsContent value="credentials" className="space-y-4">
          <Card className="bg-blue-900/50 border-blue-500">
            <CardHeader>
              <CardTitle className="text-blue-200">PNC Direct Access Credentials</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-800/30 p-4 rounded">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-blue-300 text-sm">Username</p>
                    <p className="text-white font-mono">{pncCredentials.username}</p>
                  </div>
                  <div>
                    <p className="text-blue-300 text-sm">Password</p>
                    <p className="text-white font-mono">{pncCredentials.password}</p>
                  </div>
                  <div>
                    <p className="text-blue-300 text-sm">Security Code</p>
                    <p className="text-white font-mono">{pncCredentials.securityCode}</p>
                  </div>
                  <div>
                    <p className="text-blue-300 text-sm">Direct Access Password</p>
                    <p className="text-white font-mono">{pncCredentials.directAccessPassword}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integration" className="space-y-4">
          <Card className="bg-purple-900/50 border-purple-500">
            <CardHeader>
              <CardTitle className="text-purple-200">Wells Fargo Integration Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-purple-800/30 p-4 rounded">
                <h3 className="text-purple-200 font-semibold mb-2">Integration Details</h3>
                <div className="space-y-2">
                  <p className="text-white">Wells Fargo Account: {wellsFargoIntegration.accountNumber}</p>
                  <p className="text-white">Routing Number: {wellsFargoIntegration.routingNumber}</p>
                  <p className="text-green-400">✅ Trial deposits received and processed</p>
                  <p className="text-green-400">✅ Account verification completed</p>
                  <p className="text-green-400">✅ PNC-Wells Fargo link established</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card className="bg-green-900/50 border-green-500">
            <CardHeader>
              <CardTitle className="text-green-200 flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                AI ALAZIE XPRESS Revenue Routing
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-800/30 p-4 rounded">
                <h3 className="text-green-200 font-semibold mb-3">Revenue Destination</h3>
                <div className="space-y-2">
                  <p className="text-white">Target Account: PNC Growth Account (5563935283)</p>
                  <p className="text-white">Routing: 054000030</p>
                  <p className="text-white">API Endpoint: /api/payment-routing/combined-total</p>
                  <p className="text-green-400">✅ Auto-routing ACTIVE</p>
                </div>
              </div>
              
              <div className="bg-orange-500/20 p-4 rounded border border-orange-500">
                <h4 className="text-orange-300 font-medium mb-2">Revenue Sources</h4>
                <ul className="text-orange-200 text-sm space-y-1">
                  <li>• Load management platform fees</li>
                  <li>• Advanced booking subscriptions</li>
                  <li>• Performance boost charges</li>
                  <li>• Premium user upgrades</li>
                  <li>• Transaction processing fees</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};