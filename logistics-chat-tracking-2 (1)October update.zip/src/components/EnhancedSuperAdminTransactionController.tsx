import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DollarSign, CreditCard, Shield, Infinity, ArrowUpDown, Mail, Clock, History, CheckCircle, Link, Building, Zap, Activity, Building2, TrendingUp } from 'lucide-react';
import MainTrustAccountBankingSystem from './MainTrustAccountBankingSystem';
export const EnhancedSuperAdminTransactionController: React.FC = () => {
  const [selectedAccountHolder, setSelectedAccountHolder] = useState('alucius');
  const [processingPayment, setProcessingPayment] = useState(false);
  const [mailingStatus, setMailingStatus] = useState<Record<string, string>>({});
  const [realTimeTransfers, setRealTimeTransfers] = useState<Array<{id: string, amount: number, timestamp: Date, status: string}>>([]);
  const [securityTransferCompleted, setSecurityTransferCompleted] = useState(false);
  const [trustAccountRouting, setTrustAccountRouting] = useState(false);

  const accountHolders = {
    alucius: {
      name: 'Alucius Alford',
      address: '2408 Yanceyville St Greensboro N.C. 27405',
      debitCards: [
        { id: 'dc001', number: '4521-8934-2176-7845', bank: 'PNC Bank', balance: 5000.00, cvv: '847', exp: '12/28', priority: 'HIGH', routedToTrust: true }
      ],
      virtualAccounts: [
        { id: 'va001', type: 'PNC Virtual', accountNumber: '026009593-****5678', balance: 5000.00, stripeId: 'acct_1234567890', routedToTrust: true },
        { id: 'va002', type: 'Ace Flare', accountNumber: '124003116-****9012', balance: 5000.00, stripeId: 'acct_ace_flare_001', routedToTrust: true },
        { id: 'va003', type: 'Chime', accountNumber: '103100195-****3456', balance: 5000.00, stripeId: 'acct_chime_001', routedToTrust: true },
        { id: 'va004', type: 'Cash App', accountNumber: 'CASH-****7890', balance: 5000.00, stripeId: 'acct_cashapp_001', routedToTrust: true },
        { id: 'va005', type: 'PayPal Business', accountNumber: 'PP-****1234', balance: 5000.00, stripeId: 'acct_paypal_001', routedToTrust: true },
        { id: 'va006', type: 'Venmo Business', accountNumber: 'VEN-****5678', balance: 5000.00, stripeId: 'acct_venmo_001', routedToTrust: true }
      ]
    },
    khiamo: {
      name: 'Khiamo Valdez Bethea',
      address: '1205 Summit Ave Greensboro N.C. 27405',
      debitCards: [
        { id: 'dc002', number: '4532-1098-7654-3210', bank: 'Wells Fargo', balance: 5000.00, cvv: '234', exp: '08/27', priority: 'HIGH', routedToTrust: true }
      ],
      virtualAccounts: [
        { id: 'va007', type: 'Wells Virtual', accountNumber: '121000248-****9876', balance: 5000.00, stripeId: 'acct_wells_001', routedToTrust: true },
        { id: 'va008', type: 'Zelle Business', accountNumber: 'ZEL-****4321', balance: 5000.00, stripeId: 'acct_zelle_001', routedToTrust: true }
      ]
    },
    alacias: {
      name: 'Alacias J. Bethea',
      address: '9876 Financial District, Tower 3, New York, NY 10004',
      contact: '(555) 123-4567',
      email: 'alacias.bethea@alaziegroup.com',
      debitCards: [
        { id: 'dc003', number: '4000-1234-5678-9012', bank: 'JPMorgan Chase', balance: 5000.00, cvv: '321', exp: '09/28', priority: 'HIGH', routedToTrust: true },
        { id: 'dc004', number: '5432-1098-7654-3210', bank: 'US Bank', balance: 5000.00, cvv: '654', exp: '11/27', priority: 'HIGH', routedToTrust: true },
        { id: 'dc005', number: '6789-0123-4567-8901', bank: 'TD Bank', balance: 5000.00, cvv: '987', exp: '02/29', priority: 'HIGH', routedToTrust: true }
      ],
      virtualAccounts: []
    },
    brysen: {
      name: 'Brysen Carter Alford',
      address: '2408 Yanceyville St Greensboro N.C. 27405',
      debitCards: [],
      virtualAccounts: []
    }
  };

  useEffect(() => {
    // Route all funds to trust account on component mount
    setTrustAccountRouting(true);
  }, []);

  useEffect(() => {
    // One-time security transfer on component mount for Alucius accounts
    if (selectedAccountHolder === 'alucius' && !securityTransferCompleted) {
      const oneTimeTransfer = {
        id: `security_transfer_${Date.now()}`,
        amount: 5000,
        timestamp: new Date(),
        status: 'COMPLETED'
      };
      setRealTimeTransfers([oneTimeTransfer]);
      setSecurityTransferCompleted(true);
    }
  }, [selectedAccountHolder, securityTransferCompleted]);

  const handleSecurityTransfer = () => {
    if (selectedAccountHolder === 'alucius') {
      const newTransfer = {
        id: `manual_transfer_${Date.now()}`,
        amount: 5000,
        timestamp: new Date(),
        status: 'PROCESSING'
      };
      setRealTimeTransfers(prev => [newTransfer, ...prev.slice(0, 4)]);
      
      // Update status to completed after 2 seconds
      setTimeout(() => {
        setRealTimeTransfers(prev => 
          prev.map(transfer => 
            transfer.id === newTransfer.id 
              ? { ...transfer, status: 'COMPLETED' }
              : transfer
          )
        );
      }, 2000);
    }
  };

  const handleInstantTransfer = async (accountId: string) => {
    setProcessingPayment(true);
    setTimeout(() => setProcessingPayment(false), 2000);
  };

  const currentAccountHolder = accountHolders[selectedAccountHolder as keyof typeof accountHolders];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900 to-blue-900 border-purple-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Enhanced Super Admin Transaction Controller
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-emerald-500 bg-emerald-900/20">
            <Building2 className="h-4 w-4" />
            <AlertDescription className="text-emerald-300">
              ALL FUNDS ROUTED TO MAIN TRUST ACCOUNT - CENTRALIZED PAYMENT OPERATIONS
            </AlertDescription>
          </Alert>

          <Card className="bg-gradient-to-r from-emerald-900 to-teal-900 border-emerald-500">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-6 w-6 text-emerald-400" />
                  <div>
                    <p className="text-white font-semibold">Fund Routing Status</p>
                    <p className="text-emerald-300 text-sm">All accounts → Main Trust Account Banking System</p>
                  </div>
                </div>
                <Badge className="bg-emerald-600 text-white">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  ROUTED
                </Badge>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2 mb-4 flex-wrap">
            <Button
              onClick={() => setSelectedAccountHolder('alucius')}
              variant={selectedAccountHolder === 'alucius' ? 'default' : 'outline'}
              className="text-white text-xs"
            >
              Alucius Alford
            </Button>
            <Button
              onClick={() => setSelectedAccountHolder('khiamo')}
              variant={selectedAccountHolder === 'khiamo' ? 'default' : 'outline'}
              className="text-white text-xs"
            >
              Khiamo Valdez Bethea
            </Button>
            <Button
              onClick={() => setSelectedAccountHolder('alacias')}
              variant={selectedAccountHolder === 'alacias' ? 'default' : 'outline'}
              className="text-white text-xs"
            >
              Alacias J. Bethea
            </Button>
            <Button
              onClick={() => setSelectedAccountHolder('brysen')}
              variant={selectedAccountHolder === 'brysen' ? 'default' : 'outline'}
              className="text-white text-xs"
            >
              Brysen Carter Alford
            </Button>
          </div>

          <div className="bg-black/20 p-4 rounded-lg">
            <h3 className="text-white font-bold mb-2">Account Holder: {currentAccountHolder.name}</h3>
            <p className="text-gray-300">Address: {currentAccountHolder.address}</p>
            <p className="text-emerald-400 text-sm mt-1">✓ All funds routed to Main Trust Account</p>
          </div>

          <Tabs defaultValue="trust" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="trust" className="text-white">Trust Account</TabsTrigger>
              <TabsTrigger value="virtual" className="text-white">Virtual Accounts</TabsTrigger>
              <TabsTrigger value="debit" className="text-white">Debit Cards</TabsTrigger>
              <TabsTrigger value="routing" className="text-white">Routing Status</TabsTrigger>
            </TabsList>

            <TabsContent value="trust">
              <MainTrustAccountBankingSystem />
            </TabsContent>

            <TabsContent value="virtual" className="space-y-4">
              {currentAccountHolder.virtualAccounts.map((account) => (
                <Card key={account.id} className="bg-black/40 border-emerald-500">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-3">
                      <div className="flex items-center gap-2">
                        <Building className="h-5 w-5 text-emerald-400" />
                        <span className="text-white font-semibold">{account.type}</span>
                      </div>
                      <Badge className="bg-emerald-600">ROUTED TO TRUST</Badge>
                    </div>
                    <div className="bg-gray-800 p-3 rounded mb-3">
                      <p className="text-emerald-400 font-mono">Account: {account.accountNumber}</p>
                      <p className="text-gray-300">Stripe ID: {account.stripeId}</p>
                      <p className="text-emerald-300 text-sm">→ Main Trust Account</p>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-xl">
                        Balance: $0.00 (Routed)
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="debit" className="space-y-4">
              {currentAccountHolder.debitCards.map((card) => (
                <Card key={card.id} className="bg-black/40 border-emerald-500">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-3">
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-5 w-5 text-emerald-400" />
                        <span className="text-white font-semibold">{card.bank}</span>
                      </div>
                      <Badge className="bg-emerald-600">ROUTED TO TRUST</Badge>
                    </div>
                    <div className="bg-gray-800 p-3 rounded mb-3">
                      <p className="text-emerald-400 font-mono">Card: {card.number}</p>
                      <p className="text-gray-300">CVV: {card.cvv} | Exp: {card.exp}</p>
                      <p className="text-emerald-300 text-sm">→ Main Trust Account</p>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-xl">
                        Balance: $0.00 (Routed)
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="routing" className="space-y-4">
              <Card className="bg-black/40 border-emerald-500">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Centralized Fund Routing Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">JP Morgan Checking</span>
                        <span className="text-emerald-400">✓ ROUTED TO TRUST</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">US Bank Checking</span>
                        <span className="text-emerald-400">✓ ROUTED TO TRUST</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">TD Bank Checking</span>
                        <span className="text-emerald-400">✓ ROUTED TO TRUST</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">Credit/Debit Card Fees</span>
                        <span className="text-emerald-400">✓ ROUTED TO TRUST</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">Platform Fees & Charges</span>
                        <span className="text-emerald-400">✓ ROUTED TO TRUST</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">Revenue & Profit</span>
                        <span className="text-emerald-400">✓ ROUTED TO TRUST</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedSuperAdminTransactionController;