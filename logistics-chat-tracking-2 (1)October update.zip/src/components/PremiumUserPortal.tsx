import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Truck, BarChart3, CreditCard, User, Star, TrendingUp } from 'lucide-react';

export const PremiumUserPortal: React.FC = () => {
  const [subscription] = useState('premium');
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="bg-white rounded-lg shadow-lg p-6 border-t-4 border-purple-500">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Premium User Portal</h1>
              <p className="text-gray-600">Advanced logistics management platform</p>
            </div>
            <Badge className="bg-purple-100 text-purple-800 border-purple-200">
              <Star className="h-3 w-3 mr-1" />
              PREMIUM Plan
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-4">
          <TabsList className="grid w-full grid-cols-6 bg-white">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="loads">Load Board</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="ai-tools">AI Tools</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4">
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="border-purple-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Loads</CardTitle>
                  <Truck className="h-4 w-4 text-purple-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-700">45</div>
                  <p className="text-xs text-green-600">+15 from last week</p>
                </CardContent>
              </Card>
              
              <Card className="border-blue-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
                  <BarChart3 className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-700">$87,450</div>
                  <p className="text-xs text-green-600">+28% from last month</p>
                </CardContent>
              </Card>
              
              <Card className="border-green-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">AI Efficiency</CardTitle>
                  <TrendingUp className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-700">97%</div>
                  <p className="text-xs text-green-600">AI-optimized routes</p>
                </CardContent>
              </Card>
              
              <Card className="border-orange-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Profit Margin</CardTitle>
                  <CreditCard className="h-4 w-4 text-orange-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-700">23.5%</div>
                  <p className="text-xs text-green-600">+3.2% improvement</p>
                </CardContent>
              </Card>
            </div>
            
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-green-600" />
                  <p className="text-sm text-green-700">Premium features active: AI Load Matching, Advanced Analytics, Priority Support</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="loads">
            <Card>
              <CardHeader>
                <CardTitle>Premium Load Board - Unlimited Access</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">AI-powered load matching with unlimited daily access</p>
                <div className="space-y-3">
                  {[1,2,3,4,5].map((i) => (
                    <div key={i} className="p-4 border rounded-lg bg-white hover:bg-gray-50 transition-colors">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">Load #{String(i).padStart(3, '0')} - Premium Route</p>
                          <p className="text-sm text-gray-600">AI Match Score: 95% | Distance optimized</p>
                        </div>
                        <Badge className="bg-purple-100 text-purple-800">High Priority</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Analytics Dashboard</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Real-time performance insights and predictive analytics</p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <h4 className="font-medium text-purple-800">Route Optimization</h4>
                    <p className="text-sm text-purple-600">AI-powered route suggestions saving 15% fuel costs</p>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-800">Demand Forecasting</h4>
                    <p className="text-sm text-blue-600">Predictive analytics for load availability</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai-tools">
            <Card>
              <CardHeader>
                <CardTitle>AI-Powered Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <Button className="h-20 flex-col bg-purple-600 hover:bg-purple-700">
                    <Star className="h-6 w-6 mb-2" />
                    Load Matcher AI
                  </Button>
                  <Button className="h-20 flex-col bg-blue-600 hover:bg-blue-700">
                    <TrendingUp className="h-6 w-6 mb-2" />
                    Price Optimizer
                  </Button>
                  <Button className="h-20 flex-col bg-green-600 hover:bg-green-700">
                    <BarChart3 className="h-6 w-6 mb-2" />
                    Analytics AI
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing">
            <Card>
              <CardHeader>
                <CardTitle>Premium Billing</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Current Plan: Premium ($199/month)</p>
                <div className="flex gap-4">
                  <Button variant="outline">Manage Subscription</Button>
                  <Button>Upgrade to Enterprise</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Premium Profile Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Advanced profile management with API access</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};