import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Shield, Lock, User, Eye, EyeOff } from 'lucide-react';

interface AuthModalProps {
  onAuthenticated: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ onAuthenticated }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pin, setPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const MASTER_CREDENTIALS = {
    email: 'alaziellc.innovation@gmail.com',
    password: 'gotchupin1976',
    pin: '1976'
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Validate master credentials
    if (
      email === MASTER_CREDENTIALS.email &&
      password === MASTER_CREDENTIALS.password &&
      pin === MASTER_CREDENTIALS.pin
    ) {
      setTimeout(() => {
        onAuthenticated();
        setLoading(false);
      }, 1000);
    } else {
      setError('Invalid credentials. Only Super Admin access is permitted.');
      setLoading(false);
    }
  };

  const fillMasterCredentials = () => {
    setEmail(MASTER_CREDENTIALS.email);
    setPassword(MASTER_CREDENTIALS.password);
    setPin(MASTER_CREDENTIALS.pin);
  };
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md bg-gray-900 border-red-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Super Admin Access Only
            </CardTitle>
            <Badge className="bg-red-600">RESTRICTED</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Alert className="mb-4 border-red-500 bg-red-900/20">
            <Lock className="h-4 w-4" />
            <AlertDescription className="text-red-300">
              🔒 Platform restricted to Super Admin Alucius Alford only
            </AlertDescription>
          </Alert>
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-red-300">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-gray-800 border-red-500/50 text-white"
                placeholder="alaziellc.innovation@gmail.com"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-red-300">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-gray-800 border-red-500/50 text-white pr-10"
                  placeholder="Enter password"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="pin" className="text-red-300">PIN</Label>
              <Input
                id="pin"
                type="text"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                className="bg-gray-800 border-red-500/50 text-white"
                placeholder="Enter PIN"
                maxLength={4}
                required
              />
            </div>
            
            {error && (
              <Alert className="border-red-500 bg-red-900/20">
                <AlertDescription className="text-red-300">{error}</AlertDescription>
              </Alert>
            )}
            
            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" disabled={loading}>
              {loading ? 'Authenticating...' : 'Access Super Admin Dashboard'}
            </Button>
          </form>
          
          <div className="mt-4 text-center">
            <Button
              variant="outline"
              onClick={fillMasterCredentials}
              className="text-blue-400 border-blue-500 hover:bg-blue-500/20"
              size="sm"
            >
              <User className="h-4 w-4 mr-2" />
              Fill Master Credentials
            </Button>
          </div>
          
          <div className="text-xs text-gray-500 text-center mt-4">
            All user accounts suspended - Super Admin access only
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AuthModal;