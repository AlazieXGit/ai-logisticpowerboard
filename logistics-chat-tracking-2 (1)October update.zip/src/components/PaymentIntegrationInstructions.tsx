import React from 'react';
import ExpandedPaymentIntegrationInstructions from './ExpandedPaymentIntegrationInstructions';

const PaymentIntegrationInstructions = () => {
  return <ExpandedPaymentIntegrationInstructions />;
};

export default PaymentIntegrationInstructions;
