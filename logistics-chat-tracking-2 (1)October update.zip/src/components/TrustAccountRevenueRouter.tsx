import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowDownToLine, ArrowUpFromLine, RefreshCw, TrendingUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const TrustAccountRevenueRouter = () => {
  const { toast } = useToast();
  const [autoRouting, setAutoRouting] = useState(true);
  const [routingProgress, setRoutingProgress] = useState(0);
  const [dailyRevenue, setDailyRevenue] = useState(0);

  const revenueCategories = [
    { name: 'Platform Fees', amount: 2500, percentage: 25 },
    { name: 'Subscription Payments', amount: 4900, percentage: 49 },
    { name: 'AI Service Fees', amount: 1200, percentage: 12 },
    { name: 'Admin Fees', amount: 800, percentage: 8 },
    { name: 'Transaction Fees', amount: 600, percentage: 6 }
  ];

  const totalRevenue = revenueCategories.reduce((sum, cat) => sum + cat.amount, 0);

  useEffect(() => {
    if (autoRouting) {
      const interval = setInterval(() => {
        setRoutingProgress(prev => {
          if (prev >= 100) {
            setDailyRevenue(prev => prev + totalRevenue);
            toast({
              title: 'Revenue Routed',
              description: `$${totalRevenue.toLocaleString()} automatically deposited to Trust Account`
            });
            return 0;
          }
          return prev + 10;
        });
      }, 500);

      return () => clearInterval(interval);
    }
  }, [autoRouting, totalRevenue, toast]);

  const manualRouteRevenue = () => {
    setRoutingProgress(100);
    setDailyRevenue(prev => prev + totalRevenue);
    toast({
      title: 'Manual Route Complete',
      description: `$${totalRevenue.toLocaleString()} manually routed to Trust Account`
    });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-blue-900 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-green-300 flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Trust Account Revenue Router
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-green-300 font-semibold">Auto-Routing Status</span>
                <Badge className={autoRouting ? "bg-green-600" : "bg-red-600"}>
                  {autoRouting ? 'Active' : 'Inactive'}
                </Badge>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Current Progress</span>
                  <span className="text-green-400">{routingProgress}%</span>
                </div>
                <Progress value={routingProgress} className="h-2" />
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Daily Revenue Routed</span>
                  <span className="text-green-400">${dailyRevenue.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <Button
                onClick={() => setAutoRouting(!autoRouting)}
                className={`w-full ${autoRouting ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
              >
                {autoRouting ? 'Disable Auto-Routing' : 'Enable Auto-Routing'}
              </Button>
              
              <Button
                onClick={manualRouteRevenue}
                variant="outline"
                className="w-full border-green-500 text-green-400 hover:bg-green-900"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Manual Route Revenue
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-blue-400">Revenue Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {revenueCategories.map((category, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-blue-900/20 rounded-lg">
                  <div>
                    <p className="font-semibold text-blue-300">{category.name}</p>
                    <p className="text-xs text-gray-400">{category.percentage}% of total</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-400">${category.amount.toLocaleString()}</p>
                    <div className="flex items-center gap-1 text-xs text-green-400">
                      <ArrowDownToLine className="h-3 w-3" />
                      To Trust
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-purple-400">Account Flow</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-purple-900/20 rounded-lg">
                <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                <span className="text-yellow-300">Primary Account (Pass-through)</span>
              </div>
              
              <div className="flex justify-center">
                <ArrowUpFromLine className="h-6 w-6 text-green-400" />
              </div>
              
              <div className="flex items-center gap-3 p-3 bg-purple-900/20 rounded-lg">
                <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                <span className="text-green-300">Trust Account (Final Destination)</span>
              </div>
              
              <div className="mt-4 p-3 bg-emerald-900/20 rounded-lg border border-emerald-500/30">
                <p className="text-emerald-300 text-sm font-semibold">Final Account Balance:</p>
                <p className="text-2xl font-bold text-emerald-400 mt-1">
                  ${(dailyRevenue - (dailyRevenue * 0.15)).toLocaleString()}
                </p>
                <p className="text-xs text-emerald-200 mt-1">
                  After all fees, admin costs, and platform charges
                </p>
              </div>
              
              <div className="mt-4 p-3 bg-red-900/20 rounded-lg border border-red-500/30">
                <p className="text-red-300 text-sm font-semibold">Override Settings:</p>
                <ul className="text-xs text-red-200 mt-2 space-y-1">
                  <li>• 24hr deposit limits bypassed</li>
                  <li>• All revenue categories included</li>
                  <li>• Escrow maintains $100K minimum</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TrustAccountRevenueRouter;