import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Building, DollarSign, Square, Zap, CheckCircle, Home, FileText, ExternalLink, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import PropertyModal from './PropertyModal';

export default function AIRealEstatePurchasingAgent() {
  const { toast } = useToast();
  const [processingPurchase, setProcessingPurchase] = useState<number | null>(null);
  const [propertyModalOpen, setPropertyModalOpen] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<any>(null);

  const [properties] = useState([
    { id: 1, address: "1234 Wendover Ave, Greensboro, NC 27405", price: "$450,000", agency: "Keller Williams", sqft: 3200, type: "RESIDENTIAL WITH LAND", owner: "Greensboro Properties LLC", beds: 4, baths: 3, year: 2019, acres: 2.5 },
    { id: 2, address: "5678 High Point Rd, Greensboro, NC 27405", price: "$650,000", agency: "Coldwell Banker", sqft: 4800, type: "COMMERCIAL DUPLEX", owner: "Triad Investments", units: 2, parking: 8, year: 2020 },
    { id: 3, address: "456 Ocean Blvd, Myrtle Beach, SC 29577", price: "$750,000", agency: "Beach Properties", sqft: 3800, type: "COMMERCIAL DUPLEX", owner: "Coastal Investments", units: 2, parking: 10, year: 2019 }
  ]);

  const [purchasedProperties] = useState([
    { id: 1, address: "123 Main St, Dillon, SC 29536", price: "$285,000", agency: "Carolina Realty", purchaseDate: "2025-08-09", status: "Closed", type: "RESIDENTIAL WITH LAND", description: "3BR/2BA residential property with 3.2 acres", projectDetails: "Rental property development project - estimated ROI 12%", image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400", documents: ["deed.pdf", "survey.pdf", "inspection.pdf"] },
    { id: 2, address: "789 Conway Rd, Conway, SC 29526", price: "$420,000", agency: "Horry County Realty", purchaseDate: "2025-08-09", status: "Closed", type: "MULTIFAMILY COMPLEX", description: "4-unit multifamily complex with parking", projectDetails: "Multi-family investment - projected monthly income $3,200", image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400", documents: ["deed.pdf", "lease_agreements.pdf", "financial_analysis.pdf"] }
  ]);

  const [agencies] = useState([
    { name: "Keller Williams", website: "kw.com", specialty: "Local Residential & Land", status: "Registered & Active" },
    { name: "Century 21", website: "century21.com", specialty: "Residential & Commercial", status: "Registered & Active" },
    { name: "Carolina Realty", website: "carolinarealty.com", specialty: "Dillon SC Properties", status: "Registered & Active" },
    { name: "Beach Properties", website: "beachproperties.com", specialty: "Myrtle Beach SC Coastal", status: "Registered & Active" }
  ]);

  const handleAIPurchase = async (property: any) => {
    setProcessingPurchase(property.id);
    try {
      const contractData = {
        type: 'real_estate_purchase',
        item: property.address,
        price: property.price,
        recipient: 'Alucius Alford',
        company: 'Alazie LLC',
        agency: property.agency,
        owner: property.owner,
        delivery_address: '2408 Yanceyville St. Greensboro N.C. 27405',
        email: 'alaziellc.innovation@gmail.com'
      };

      const { data, error } = await supabase.functions.invoke('contract-generator', {
        body: contractData
      });

      if (error) throw error;

      toast({
        title: "AI Purchase Initiated",
        description: `${property.address} purchase contract generated and sent to email`
      });
    } catch (error) {
      toast({
        title: "Purchase Failed",
        description: "Failed to process AI purchase",
        variant: "destructive"
      });
    } finally {
      setProcessingPurchase(null);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-6 w-6 text-blue-500" />
            AI Real Estate Purchasing Agent
            <Badge variant="outline" className="ml-2">AI Assistant Active</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="properties" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="properties">Available Properties</TabsTrigger>
          <TabsTrigger value="purchased">Purchased Properties</TabsTrigger>
          <TabsTrigger value="agencies">Agencies</TabsTrigger>
          <TabsTrigger value="contracts">Contracts</TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="properties">
          <div className="grid gap-4">
            {properties.map((property) => (
              <Card key={property.id} className="border-l-4 border-l-blue-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-3">
                      <Badge variant="outline" className="text-green-600">{property.type}</Badge>
                      <h4 className="font-semibold text-lg">{property.address}</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />
                          {property.price}
                        </div>
                        <div>Agency: {property.agency}</div>
                        <div>Owner: {property.owner}</div>
                        {property.sqft && <div className="flex items-center gap-1">
                          <Square className="h-4 w-4" />
                          {property.sqft.toLocaleString()} sq ft
                        </div>}
                        {property.acres && <div>{property.acres} acres</div>}
                        {property.beds && <div>{property.beds} beds, {property.baths} baths</div>}
                        {property.year && <div>Built: {property.year}</div>}
                      </div>
                    </div>
                    <Button
                      onClick={() => handleAIPurchase(property)}
                      disabled={processingPurchase === property.id}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Zap className="h-4 w-4 mr-2" />
                      {processingPurchase === property.id ? 'Processing...' : 'AI Purchase'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="purchased">
          <div className="space-y-4">
            <Card className="bg-orange-50 border-orange-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-700">
                  <Home className="h-5 w-5" />
                  Purchased Properties & Project Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                {purchasedProperties.map((property) => (
                  <Card key={property.id} className="mb-4">
                    <CardContent className="p-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-semibold">{property.address}</h4>
                          <p className="text-sm text-gray-600">{property.description}</p>
                          <div className="mt-2 space-y-1 text-sm">
                            <div>Price: {property.price}</div>
                            <div>Purchase Date: {property.purchaseDate}</div>
                            <div>Status: <Badge variant="outline">{property.status}</Badge></div>
                            <div>Type: {property.type}</div>
                          </div>
                        </div>
                        <div>
                          <h5 className="font-medium">Project Details</h5>
                          <p className="text-sm text-gray-600">{property.projectDetails}</p>
                          <div className="flex gap-2 mt-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setSelectedProperty(property);
                                setPropertyModalOpen(true);
                              }}
                            >
                              <ExternalLink className="h-4 w-4 mr-1" />
                              View Property
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setSelectedProperty(property);
                                setPropertyModalOpen(true);
                              }}
                            >
                              <Download className="h-4 w-4 mr-1" />
                              Documents
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="agencies">
          <div className="grid gap-4">
            {agencies.map((agency, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-semibold">{agency.name}</h4>
                      <p className="text-sm text-gray-600">Website: {agency.website}</p>
                      <p className="text-sm">Specialty: {agency.specialty}</p>
                    </div>
                    <div className="flex gap-2">
                      <Badge className="bg-green-600">{agency.status}</Badge>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => window.open(`https://${agency.website}`, '_blank')}
                      >
                        <ExternalLink className="h-4 w-4 mr-1" />
                        Visit Site
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contracts">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-6 w-6 text-blue-500" />
                Contract Management - Real Estate Purchases
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {purchasedProperties.map((property) => (
                  <Card key={property.id} className="border-l-4 border-l-green-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <h4 className="font-semibold">{property.address}</h4>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>Purchase Price: {property.price}</div>
                            <div>Purchase Date: {property.purchaseDate}</div>
                            <div>Agency: {property.agency}</div>
                            <div>Status: <Badge variant="outline">{property.status}</Badge></div>
                            <div>Contract Owner: Alucius Alford</div>
                            <div>Company: Alazie LLC</div>
                            <div>Email: alaziellc.innovation@gmail.com</div>
                            <div>Account Debited: PNC Business Account ***4521</div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Download className="h-4 w-4 mr-1" />
                            Download Contract
                          </Button>
                          <Button size="sm" variant="outline">
                            <ExternalLink className="h-4 w-4 mr-1" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                <div className="text-center py-4 border-t">
                  <div className="flex justify-center gap-2">
                    <Button variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Download All Contracts
                    </Button>
                    <Button variant="outline">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Super Admin View
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Super Admin Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Property Portfolio</h4>
                  <div className="space-y-2 text-sm">
                    <div>Total Properties: 2</div>
                    <div>Total Investment: $705,000</div>
                    <div>Active Projects: 2</div>
                    <div>Projected ROI: 12%</div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Contract Details</h4>
                  <div className="space-y-2 text-sm">
                    <div>Owner: Alucius Alford</div>
                    <div>Company: Alazie LLC</div>
                    <div>Email: alaziellc.innovation@gmail.com</div>
                    <div>Address: 2408 Yanceyville St. Greensboro N.C.</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Auto-Purchase Enabled</span>
                  <Badge className="bg-green-600">Active</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Email Notifications</span>
                  <Badge className="bg-green-600">alaziellc.innovation@gmail.com</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Contract Owner</span>
                  <Badge variant="outline">Alucius Alford</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {selectedProperty && (
        <PropertyModal
          isOpen={propertyModalOpen}
          onClose={() => setPropertyModalOpen(false)}
          property={selectedProperty}
        />
      )}
    </div>
  );
}