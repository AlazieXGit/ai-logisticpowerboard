import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, XCircle, Loader2 } from 'lucide-react';

interface BulkActionsModalProps {
  open: boolean;
  onClose: () => void;
  action: 'approve' | 'reject' | 'payout' | 'note';
  selectedIds: string[];
  onConfirm: (data: any) => Promise<any>;
  title: string;
}

export function BulkActionsModal({ open, onClose, action, selectedIds, onConfirm, title }: BulkActionsModalProps) {
  const [notes, setNotes] = useState('');
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<any[]>([]);

  const handleConfirm = async () => {
    setProcessing(true);
    setProgress(0);
    const data = action === 'reject' || action === 'note' ? { notes } : {};
    const result = await onConfirm(data);
    
    if (result?.results) {
      setResults(result.results);
      const successCount = result.results.filter((r: any) => r.success).length;
      setProgress((successCount / selectedIds.length) * 100);
    }
    
    setTimeout(() => {
      setProcessing(false);
      onClose();
      setNotes('');
      setResults([]);
    }, 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            You are about to {action} {selectedIds.length} item(s). This action cannot be undone.
          </p>

          {(action === 'reject' || action === 'note') && (
            <Textarea
              placeholder={action === 'reject' ? 'Rejection reason...' : 'Add note...'}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          )}

          {processing && (
            <div className="space-y-2">
              <Progress value={progress} />
              <div className="max-h-40 overflow-y-auto space-y-1">
                {results.map((r, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    {r.success ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
                    <span>{r.success ? 'Success' : `Failed: ${r.error}`}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose} disabled={processing}>Cancel</Button>
            <Button onClick={handleConfirm} disabled={processing || (action === 'reject' && !notes)}>
              {processing ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Processing</> : 'Confirm'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
