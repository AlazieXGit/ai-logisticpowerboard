import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Building2, CreditCard, ArrowRight } from 'lucide-react';
import StripeToPNCPaymentRouter from './StripeToPNCPaymentRouter';
import EnhancedStripePaymentSystem from './EnhancedStripePaymentSystem';

export const PNCBankPaymentIntegration = () => {
  const [activeTab, setActiveTab] = useState('router');

  return (
    <div className="space-y-6 p-6">
      <Card className="bg-gradient-to-r from-indigo-900 to-blue-900 border-indigo-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            PNC Bank Payment Integration Hub
            <Badge className="bg-green-600">PRODUCTION READY</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-100">
            Complete payment routing system connecting Stripe payments to PNC Bank accounts
          </p>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="router" className="text-white">
            <ArrowRight className="h-4 w-4 mr-2" />
            Payment Router
          </TabsTrigger>
          <TabsTrigger value="stripe" className="text-white">
            <CreditCard className="h-4 w-4 mr-2" />
            Stripe System
          </TabsTrigger>
          <TabsTrigger value="accounts" className="text-white">
            <Building2 className="h-4 w-4 mr-2" />
            PNC Accounts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="router" className="mt-6">
          <StripeToPNCPaymentRouter />
        </TabsContent>

        <TabsContent value="stripe" className="mt-6">
          <EnhancedStripePaymentSystem />
        </TabsContent>

        <TabsContent value="accounts" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800 border-blue-500">
              <CardHeader>
                <CardTitle className="text-white">Primary Operating Account</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="bg-blue-900/20 p-3 rounded">
                  <p className="text-blue-400 font-bold text-lg">XPRESS-AI-MASTER</p>
                  <p className="text-gray-300 text-sm">Primary Operating</p>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Account Number</span>
                    <span className="text-white font-mono">5563935267</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Routing Number</span>
                    <span className="text-white font-mono">054000030</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Balance</span>
                    <span className="text-green-400 font-bold">$2,847,592.45</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Daily Limit</span>
                    <span className="text-yellow-400">$1,000,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Transaction Fee</span>
                    <span className="text-white">$0.50</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-purple-500">
              <CardHeader>
                <CardTitle className="text-white">Reserve Fund Account</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="bg-purple-900/20 p-3 rounded">
                  <p className="text-purple-400 font-bold text-lg">RESERVE-FUND</p>
                  <p className="text-gray-300 text-sm">Reserve Account</p>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Account Number</span>
                    <span className="text-white font-mono">5563935275</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Routing Number</span>
                    <span className="text-white font-mono">054000030</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Balance</span>
                    <span className="text-green-400 font-bold">$1,456,789.23</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Daily Limit</span>
                    <span className="text-yellow-400">$500,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Transaction Fee</span>
                    <span className="text-white">$0.25</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gray-800 border-gray-700 mt-6">
            <CardHeader>
              <CardTitle className="text-white">Bank Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Bank Name</span>
                <span className="text-white">PNC Bank, National Association</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">SWIFT Code</span>
                <span className="text-white font-mono">PNCCUS33</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Fed Wire</span>
                <span className="text-white font-mono">054000030</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Bank Address</span>
                <span className="text-white">300 Fifth Avenue, Pittsburgh, PA 15222</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PNCBankPaymentIntegration;
