import React from "react";
import { Card, CardContent } from "@/components/ui/card";

interface Totals {
  totalRevenue: number;
  automatedServiceFees: number;
  platformFees: number;
  opsAdminFees: number;
  dispatchFees: number;
  savings: number;
  profit: number;
}

interface SummaryCardsProps {
  totals: Totals;
}

export default function SummaryCards({ totals }: SummaryCardsProps) {
  const items = [
    { label: "Total Revenue", value: totals.totalRevenue, tone: "primary" },
    { label: "Automated Service Fees", value: totals.automatedServiceFees },
    { label: "Platform Fees", value: totals.platformFees },
    { label: "Operations & Admin Fees", value: totals.opsAdminFees },
    { label: "Dispatch Fees", value: totals.dispatchFees },
    { label: "Savings", value: totals.savings, tone: "positive" },
    { label: "Profit", value: totals.profit, tone: "positive" },
  ];

  const fmt = (n: number) => n.toLocaleString(undefined, { 
    style: "currency", 
    currency: "USD" 
  });

  const getToneClass = (tone?: string) => {
    switch (tone) {
      case "primary":
        return "border-cyan-500 bg-cyan-950";
      case "positive":
        return "border-green-500 bg-green-950";
      default:
        return "border-slate-600 bg-slate-800";
    }
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
      {items.map((item) => (
        <Card 
          key={item.label} 
          className={`${getToneClass(item.tone)} border`}
        >
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">
              {fmt(item.value)}
            </div>
            <div className="text-sm text-slate-400 mt-1">
              {item.label}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}