import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, ArrowRight, CheckCircle, DollarSign, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PNCAccount {
  name: string;
  type: string;
  accountNumber: string;
  routingNumber: string;
  balance: string;
  swiftCode: string;
  fedWire: string;
  dailyLimit: string;
  bankAddress: string;
  monthlyFee: string;
  transactionFee: string;
}

export const StripeToPNCPaymentRouter = () => {
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [selectedAccount, setSelectedAccount] = useState('primary');
  const [processing, setProcessing] = useState(false);
  const [routeActive, setRouteActive] = useState(true);

  const pncAccounts: Record<string, PNCAccount> = {
    primary: {
      name: 'XPRESS-AI-MASTER',
      type: 'Primary Operating',
      accountNumber: '5563935267',
      routingNumber: '054000030',
      balance: '$2,847,592.45',
      swiftCode: 'PNCCUS33',
      fedWire: '054000030',
      dailyLimit: '$1,000,000',
      bankAddress: '300 Fifth Avenue, Pittsburgh, PA 15222',
      monthlyFee: '$25',
      transactionFee: '$0.50'
    },
    reserve: {
      name: 'RESERVE-FUND',
      type: 'Reserve Account',
      accountNumber: '5563935275',
      routingNumber: '054000030',
      balance: '$1,456,789.23',
      swiftCode: 'PNCCUS33',
      fedWire: '054000030',
      dailyLimit: '$500,000',
      bankAddress: '300 Fifth Avenue, Pittsburgh, PA 15222',
      monthlyFee: '$15',
      transactionFee: '$0.25'
    }
  };

  const processStripePayment = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive"
      });
      return;
    }

    const account = pncAccounts[selectedAccount];
    const dailyLimit = parseFloat(account.dailyLimit.replace(/[$,]/g, ''));
    
    if (parseFloat(amount) > dailyLimit) {
      toast({
        title: "Amount Exceeds Daily Limit",
        description: `Maximum daily limit is ${account.dailyLimit}`,
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    
    setTimeout(() => {
      toast({
        title: "Payment Route Established",
        description: `$${amount} routed to PNC ${account.name}`,
      });
      setProcessing(false);
      setAmount('');
    }, 2000);
  };

  const account = pncAccounts[selectedAccount];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            Stripe → PNC Bank Payment Router
            <Badge className={routeActive ? "bg-green-600" : "bg-red-600"}>
              {routeActive ? "ACTIVE" : "INACTIVE"}
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Payment Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Target PNC Account</label>
              <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="primary" className="text-white">
                    Primary Operating - {pncAccounts.primary.accountNumber}
                  </SelectItem>
                  <SelectItem value="reserve" className="text-white">
                    Reserve Fund - {pncAccounts.reserve.accountNumber}
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Amount ($)</label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <Button
              onClick={processStripePayment}
              disabled={processing || !routeActive}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {processing ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Processing...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Route Payment via Stripe
                  <ArrowRight className="h-4 w-4" />
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Account Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-blue-900/20 p-3 rounded border border-blue-500">
              <p className="text-blue-400 font-semibold">{account.name}</p>
              <p className="text-gray-300 text-sm">{account.type}</p>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Account Number</span>
                <span className="text-white font-mono">{account.accountNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Routing Number</span>
                <span className="text-white font-mono">{account.routingNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Current Balance</span>
                <span className="text-green-400 font-bold">{account.balance}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">SWIFT Code</span>
                <span className="text-white font-mono">{account.swiftCode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Fed Wire</span>
                <span className="text-white font-mono">{account.fedWire}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Daily Limit</span>
                <span className="text-yellow-400">{account.dailyLimit}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Transaction Fee</span>
                <span className="text-white">{account.transactionFee}</span>
              </div>
            </div>

            <div className="bg-gray-700 p-2 rounded">
              <p className="text-gray-300 text-xs">{account.bankAddress}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-green-900 border-green-500">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="h-5 w-5 text-green-400 mt-0.5" />
            <div className="flex-1">
              <p className="text-green-100 font-semibold">Payment Route Active</p>
              <p className="text-green-200 text-sm">
                All Stripe payments are automatically routed to the selected PNC Bank account with real-time processing.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StripeToPNCPaymentRouter;
