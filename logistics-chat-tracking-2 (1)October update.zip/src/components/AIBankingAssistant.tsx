import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, Eye, EyeOff, Bot, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const AIBankingAssistant: React.FC = () => {
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSensitive, setShowSensitive] = useState(false);
  const [input, setInput] = useState('');
  const [automationLogs, setAutomationLogs] = useState<any[]>([]);

  useEffect(() => {
    initializeChat();
    fetchAutomationLogs();
  }, []);

  const initializeChat = () => {
    const welcomeMessage = {
      id: 1,
      role: 'assistant',
      content: '🧠 Alaziel AI Banking Assistant initialized. I provide comprehensive banking automation, payment processing, and financial insights. All data is encrypted and secured.',
      timestamp: new Date().toISOString(),
      contains_banking_info: true
    };
    setMessages([welcomeMessage]);
  };

  const fetchAutomationLogs = async () => {
    try {
      const mockLogs = [
        {
          id: 1,
          action: 'payment_processed',
          amount: '$2,500.00',
          status: 'completed',
          timestamp: new Date().toISOString(),
          details: 'Automated payment processing via Alaziel AI'
        },
        {
          id: 2,
          action: 'invoice_generated',
          amount: '$1,200.00',
          status: 'completed',
          timestamp: new Date().toISOString(),
          details: 'AI-generated invoice with smart routing'
        },
        {
          id: 3,
          action: 'fraud_detection',
          amount: '$850.00',
          status: 'flagged',
          timestamp: new Date().toISOString(),
          details: 'Alaziel AI detected suspicious transaction'
        }
      ];
      setAutomationLogs(mockLogs);
    } catch (error) {
      console.error('Error fetching automation logs:', error);
    }
  };

  const sendMessage = async () => {
    if (!input.trim()) return;
    
    const userMessage = {
      id: messages.length + 1,
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
      contains_banking_info: false
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('banking-email-processor', {
        body: {
          prompt: `Alaziel AI Banking: ${input}`,
          context: 'secure_banking',
          user_role: 'super_admin'
        }
      });
      
      if (error) throw error;
      
      const aiResponse = {
        id: messages.length + 2,
        role: 'assistant',
        content: data?.response || 'Alaziel AI is processing your banking request. I can help with payments, fraud detection, and financial automation.',
        timestamp: new Date().toISOString(),
        contains_banking_info: true
      };
      
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Error sending message:', error);
      const errorResponse = {
        id: messages.length + 2,
        role: 'assistant',
        content: '🧠 Alaziel AI is currently processing your request. Please try again.',
        timestamp: new Date().toISOString(),
        contains_banking_info: false
      };
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setLoading(false);
    }
  };

  const maskBankingContent = (content: string) => {
    if (!showSensitive && content) {
      return content.replace(/\$[\d,]+\.\d{2}/g, '$***.**')
                   .replace(/\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g, '****-****-****-****')
                   .replace(/\b\d{9,}\b/g, '*'.repeat(9));
    }
    return content;
  };

  return (
    <div className="space-y-6 h-full">
      <Card className="bg-emerald-950/20 border-emerald-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-emerald-400 flex items-center gap-2">
              <Bot className="h-5 w-5" />
              🧠 ALAZIEL AI BANKING SYSTEM
            </CardTitle>
            <Button
              onClick={() => setShowSensitive(!showSensitive)}
              variant={showSensitive ? "destructive" : "secondary"}
              size="sm"
            >
              {showSensitive ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
              {showSensitive ? 'Hide Banking Data' : 'Show Banking Data'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Alert className="border-emerald-500 bg-emerald-900/20">
            <Lock className="h-4 w-4" />
            <AlertDescription className="text-emerald-300">
              🔒 SECURE ACCESS: Alaziel AI banking operations for authorized personnel only
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-400px)]">
        <div className="lg:col-span-2">
          <Card className="bg-black/40 border-emerald-500 h-full flex flex-col">
            <CardHeader>
              <CardTitle className="text-emerald-400">Alaziel AI Banking Chat</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3 rounded-lg ${
                      message.role === 'user' 
                        ? 'bg-emerald-600 text-white' 
                        : 'bg-gray-800 text-emerald-300 border border-emerald-500'
                    }`}>
                      <p>{maskBankingContent(message.content)}</p>
                      {message.contains_banking_info && (
                        <Badge className="bg-emerald-500 text-xs mt-2">🏦 BANKING</Badge>
                      )}
                      <p className="text-xs opacity-70 mt-1">
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-800 text-emerald-300 border border-emerald-500 p-3 rounded-lg">
                      <p>🧠 Alaziel AI processing secure banking request...</p>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  className="bg-gray-900 border-emerald-500 text-white"
                  placeholder="Ask Alaziel AI about banking operations..."
                  disabled={loading}
                />
                <Button 
                  onClick={sendMessage}
                  disabled={loading || !input.trim()}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card className="bg-black/40 border-emerald-500 h-full">
            <CardHeader>
              <CardTitle className="text-emerald-400">🧠 Alaziel AI Logs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {automationLogs.map((log) => (
                  <div key={log.id} className="bg-gray-900 p-3 rounded border border-emerald-500">
                    <div className="flex items-center justify-between mb-2">
                      <Badge className={log.status === 'completed' ? 'bg-green-600' : log.status === 'flagged' ? 'bg-yellow-600' : 'bg-emerald-600'}>
                        {log.status.toUpperCase()}
                      </Badge>
                      <span className="text-xs text-gray-400">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-emerald-300 text-sm font-semibold">{log.action}</p>
                    <p className="text-white text-sm">{maskBankingContent(log.amount)}</p>
                    <p className="text-gray-400 text-xs">{log.details}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AIBankingAssistant;