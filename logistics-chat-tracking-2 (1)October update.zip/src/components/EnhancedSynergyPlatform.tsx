import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Bot, CreditCard, Activity, Brain, Zap, DollarSign } from 'lucide-react';
import SynergyAIAssistant from './SynergyAIAssistant';
import CreditRepairSystem from './CreditRepairSystem';

import { SynergyPlatformAnalytics } from './SynergyPlatformAnalytics';
import { IntelligentAutomationHub } from './IntelligentAutomationHub';
import { SynergyPlatformSettings } from './SynergyPlatformSettings';
import FinalDestinationAccountTotal from './FinalDestinationAccountTotal';
import { default as RealtimeTransactionMonitor } from './RealtimeTransactionMonitor';
const EnhancedSynergyPlatform: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-purple-400 to-pink-400 p-3 rounded-full mr-4">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              SYNERGY AI PLATFORM
            </h1>
          </div>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto">
            Complete AI-powered business automation platform with credit repair, transaction monitoring, and intelligent assistance
          </p>
        </div>

        <Tabs defaultValue="ai-assistant" className="w-full">
          <TabsList className="grid w-full grid-cols-7 mb-8">
            <TabsTrigger value="ai-assistant" className="flex items-center">
              <Bot className="h-4 w-4 mr-2" />
              AI Assistant
            </TabsTrigger>
            <TabsTrigger value="credit-repair" className="flex items-center">
              <CreditCard className="h-4 w-4 mr-2" />
              Credit Repair
            </TabsTrigger>
            <TabsTrigger value="transactions" className="flex items-center">
              <Activity className="h-4 w-4 mr-2" />
              Transactions
            </TabsTrigger>
            <TabsTrigger value="account-flow" className="flex items-center">
              <DollarSign className="h-4 w-4 mr-2" />
              Account Flow
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center">
              <Brain className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="automation" className="flex items-center">
              <Zap className="h-4 w-4 mr-2" />
              Automation
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center">
              <Sparkles className="h-4 w-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ai-assistant">
            <SynergyAIAssistant />
          </TabsContent>

          <TabsContent value="credit-repair">
            <CreditRepairSystem />
          </TabsContent>

          <TabsContent value="transactions">
            <RealtimeTransactionMonitor />
          </TabsContent>
          <TabsContent value="account-flow">
            <FinalDestinationAccountTotal />
          </TabsContent>

          <TabsContent value="analytics">
            <SynergyPlatformAnalytics />
          </TabsContent>


          <TabsContent value="automation">
            <IntelligentAutomationHub />
          </TabsContent>

          <TabsContent value="settings">
            <SynergyPlatformSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default EnhancedSynergyPlatform;