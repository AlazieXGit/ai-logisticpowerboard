import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { TrendingUp, DollarSign, Users, Target, BarChart3, PieChart } from 'lucide-react';

const ExecutiveOverviewTab = () => {
  const executiveMetrics = [
    { title: 'Total Revenue', value: '$2.4M', change: '+12.5%', icon: DollarSign, color: 'text-green-600' },
    { title: 'Active Users', value: '45,231', change: '+8.2%', icon: Users, color: 'text-blue-600' },
    { title: 'Market Share', value: '23.4%', change: '+2.1%', icon: Target, color: 'text-purple-600' },
    { title: 'Growth Rate', value: '18.7%', change: '+3.4%', icon: TrendingUp, color: 'text-orange-600' }
  ];

  const quarterlyData = [
    { quarter: 'Q1 2024', revenue: 520000, profit: 89000, customers: 12400 },
    { quarter: 'Q2 2024', revenue: 580000, profit: 102000, customers: 13800 },
    { quarter: 'Q3 2024', revenue: 640000, profit: 118000, customers: 15200 },
    { quarter: 'Q4 2024', revenue: 680000, profit: 125000, customers: 16500 }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {executiveMetrics.map((metric, index) => (
          <Card key={index} className="bg-gradient-to-br from-white to-gray-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                  <p className={`text-sm ${metric.color}`}>{metric.change} from last month</p>
                </div>
                <metric.icon className={`h-8 w-8 ${metric.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Quarterly Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {quarterlyData.map((data, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium">{data.quarter}</span>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Revenue: ${(data.revenue / 1000).toFixed(0)}K</div>
                    <div className="text-sm text-green-600">Profit: ${(data.profit / 1000).toFixed(0)}K</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Strategic Objectives Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span>Market Expansion</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{width: '85%'}}></div>
                  </div>
                  <span className="text-sm text-green-600">85%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span>Digital Transformation</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{width: '72%'}}></div>
                  </div>
                  <span className="text-sm text-blue-600">72%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span>Cost Optimization</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-orange-600 h-2 rounded-full" style={{width: '91%'}}></div>
                  </div>
                  <span className="text-sm text-orange-600">91%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ExecutiveOverviewTab;