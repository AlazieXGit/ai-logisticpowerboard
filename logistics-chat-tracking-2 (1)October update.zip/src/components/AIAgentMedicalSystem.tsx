import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Heart, Truck, Car, Package, Zap, Target } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface ServiceRate {
  vehicleType: string;
  baseRate: number;
  minimumRate: number;
  icon: React.ReactNode;
}

export const AIAgentMedicalSystem: React.FC = () => {
  const [activeServices, setActiveServices] = useState<string[]>(['medical', 'rideshare']);
  const [contractStatus, setContractStatus] = useState<string>('ready');

  const serviceRates: ServiceRate[] = [
    { vehicleType: 'Hotshot Trucks', baseRate: 4.0, minimumRate: 3.0, icon: <Truck className="h-4 w-4" /> },
    { vehicleType: 'Box Trucks', baseRate: 3.5, minimumRate: 3.0, icon: <Package className="h-4 w-4" /> },
    { vehicleType: 'Cargo Vans', baseRate: 3.2, minimumRate: 3.0, icon: <Car className="h-4 w-4" /> },
    { vehicleType: 'Mini Vans', baseRate: 3.0, minimumRate: 3.0, icon: <Car className="h-4 w-4" /> },
    { vehicleType: 'Express Delivery', baseRate: 3.0, minimumRate: 3.0, icon: <Zap className="h-4 w-4" /> }
  ];

  const generateMedicalContract = async (serviceType: string, vehicleType: string) => {
    try {
      setContractStatus('generating');
      
      const { data, error } = await supabase.functions.invoke('contract-generator', {
        body: {
          contractType: 'medical-transport',
          companyName: 'Medical Transport Services',
          serviceType: serviceType,
          vehicleType: vehicleType.toLowerCase().replace(' ', '-')
        }
      });

      if (error) throw error;
      
      setContractStatus('completed');
      return data;
    } catch (error) {
      console.error('Contract generation error:', error);
      setContractStatus('error');
      return null;
    }
  };

  const toggleService = (service: string) => {
    setActiveServices(prev => 
      prev.includes(service) 
        ? prev.filter(s => s !== service)
        : [...prev, service]
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-red-500" />
            AI Agent Medical & Transportation Control System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button
              variant={activeServices.includes('medical') ? 'default' : 'outline'}
              onClick={() => toggleService('medical')}
              className="flex items-center gap-2"
            >
              <Heart className="h-4 w-4" />
              Medical Supplies
            </Button>
            <Button
              variant={activeServices.includes('rideshare') ? 'default' : 'outline'}
              onClick={() => toggleService('rideshare')}
              className="flex items-center gap-2"
            >
              <Car className="h-4 w-4" />
              Rideshare
            </Button>
            <Button
              variant={activeServices.includes('courier') ? 'default' : 'outline'}
              onClick={() => toggleService('courier')}
              className="flex items-center gap-2"
            >
              <Package className="h-4 w-4" />
              Courier Services
            </Button>
            <Button
              variant={activeServices.includes('express') ? 'default' : 'outline'}
              onClick={() => toggleService('express')}
              className="flex items-center gap-2"
            >
              <Zap className="h-4 w-4" />
              Express Delivery
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="rates" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="rates">Vehicle Rates</TabsTrigger>
          <TabsTrigger value="contracts">Contracts</TabsTrigger>
          <TabsTrigger value="optimization">AI Optimization</TabsTrigger>
        </TabsList>

        <TabsContent value="rates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {serviceRates.map((rate, index) => (
              <Card key={index} className="border-l-4 border-l-blue-500">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    {rate.icon}
                    {rate.vehicleType}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Market Rate:</span>
                      <Badge variant="secondary">{rate.baseRate}%</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Minimum Rate:</span>
                      <Badge className="bg-green-500">{rate.minimumRate}%</Badge>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => generateMedicalContract('medical', rate.vehicleType)}
                      className="w-full mt-2"
                    >
                      Generate Contract
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contracts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Contract Generation Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Contract Status:</span>
                  <Badge 
                    className={
                      contractStatus === 'completed' ? 'bg-green-500' :
                      contractStatus === 'generating' ? 'bg-blue-500' :
                      contractStatus === 'error' ? 'bg-red-500' : 'bg-gray-500'
                    }
                  >
                    {contractStatus.toUpperCase()}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">AI Auto Dispatch Fee:</span>
                    <Badge variant="outline">5%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Load Matching Fee:</span>
                    <Badge variant="outline">1% (Optional)</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">AI Forecasting Fee:</span>
                    <Badge variant="outline">2% (Optional)</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Minimum Rate Floor:</span>
                    <Badge className="bg-red-500">3% (Non-negotiable)</Badge>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Insurance Requirements:</strong> Alaziel LLC must be listed as authorized policy holder for all contracted D.B.A dispatch services with comprehensive medical transport and cargo coverage.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                100x AI Super Optimization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">100x</div>
                    <p className="text-sm text-gray-600">Performance Multiplier</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">99.9%</div>
                    <p className="text-sm text-gray-600">Optimization Level</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Next-Gen AI Processing:</span>
                    <Badge className="bg-purple-500">ACTIVE</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Super Optimization Mode:</span>
                    <Badge className="bg-green-500">ENABLED</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Market Rate Adjustment:</span>
                    <Badge className="bg-blue-500">DYNAMIC</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Rate Floor Protection:</span>
                    <Badge className="bg-red-500">3% MINIMUM</Badge>
                  </div>
                </div>

                <Button className="w-full bg-gradient-to-r from-purple-500 to-blue-500">
                  <Zap className="h-4 w-4 mr-2" />
                  Activate Super Optimization
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};