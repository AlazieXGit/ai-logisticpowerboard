import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  DollarSign, ArrowRight, Shield, AlertTriangle, 
  CheckCircle, CreditCard, Building2 
} from 'lucide-react';

export const BankingInstructionsGuide: React.FC = () => {
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Super Admin Banking System Instructions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-100">
            Complete guide for managing funds, withdrawals, and transfers across all Alazie LLC accounts
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <DollarSign className="h-5 w-5" />
              Fund Withdrawal Process
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Badge className="bg-green-100 text-green-800">Step 1</Badge>
              <p className="text-sm">Access the Revenue Total tab in Super Admin Dashboard</p>
            </div>
            <div className="space-y-2">
              <Badge className="bg-green-100 text-green-800">Step 2</Badge>
              <p className="text-sm">Navigate to Alazie Banking System</p>
            </div>
            <div className="space-y-2">
              <Badge className="bg-green-100 text-green-800">Step 3</Badge>
              <p className="text-sm">Select source account (Wells Fargo or Alaziel Internal)</p>
            </div>
            <div className="space-y-2">
              <Badge className="bg-green-100 text-green-800">Step 4</Badge>
              <p className="text-sm">Enter withdrawal amount and destination</p>
            </div>
            <div className="space-y-2">
              <Badge className="bg-green-100 text-green-800">Step 5</Badge>
              <p className="text-sm">Confirm transaction with master credentials</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-600">
              <ArrowRight className="h-5 w-5" />
              Fund Transfer Instructions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Badge className="bg-blue-100 text-blue-800">Internal Transfers</Badge>
              <p className="text-sm">Use Revenue Account Router for internal account transfers</p>
            </div>
            <div className="space-y-2">
              <Badge className="bg-blue-100 text-blue-800">External Transfers</Badge>
              <p className="text-sm">Access Fund Request System for external transfers</p>
            </div>
            <div className="space-y-2">
              <Badge className="bg-blue-100 text-blue-800">Bulk Transfers</Badge>
              <p className="text-sm">Use Payments tab for multiple recipient transfers</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-600">
            <Building2 className="h-5 w-5" />
            Account Access Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold text-blue-600">Wells Fargo Business Account</h4>
              <div className="space-y-1 text-sm">
                <p><span className="font-medium">Username:</span> alaziellc</p>
                <p><span className="font-medium">Account:</span> 4532116540123456</p>
                <p><span className="font-medium">Routing:</span> 121000248</p>
              </div>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold text-green-600">Alaziel Internal Banking</h4>
              <div className="space-y-1 text-sm">
                <p><span className="font-medium">Account:</span> 1234567890123456</p>
                <p><span className="font-medium">Routing:</span> 021000021</p>
                <p><span className="font-medium">Type:</span> Internal Processing</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Security Notice:</strong> All banking operations require Super Admin authentication. 
          Master credentials are available in the Back Office platform for authorized access only.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-600">
            <CreditCard className="h-5 w-5" />
            Quick Access Links
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-3 rounded">
              <p className="font-medium text-sm">Direct Banking</p>
              <p className="text-xs text-gray-600">banking-operations endpoint</p>
            </div>
            <div className="bg-gray-50 p-3 rounded">
              <p className="font-medium text-sm">Revenue Router</p>
              <p className="text-xs text-gray-600">Internal account routing</p>
            </div>
            <div className="bg-gray-50 p-3 rounded">
              <p className="font-medium text-sm">Payment System</p>
              <p className="text-xs text-gray-600">External payment processing</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};