import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CreditCard, DollarSign, ArrowRight, Copy, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import ManualPaymentCenter from './ManualPaymentCenter';

interface PaymentAccount {
  id: string;
  name: string;
  routing: string;
  account: string;
  amount: string;
  frequency: string;
  type: 'recurring' | 'daily';
}

const StripePaymentSystem: React.FC = () => {
  const [paymentAccounts] = useState<PaymentAccount[]>([
    {
      id: '1',
      name: 'Primary Withdrawal Account',
      routing: '041215663',
      account: '2079529306039',
      amount: '$5,000',
      frequency: 'Weekly',
      type: 'recurring'
    },
    {
      id: '2',
      name: 'Secondary ACH Account',
      routing: '041215663',
      account: '3236618840224',
      amount: '$50,000',
      frequency: 'Daily',
      type: 'daily'
    },
    {
      id: '3',
      name: 'Tertiary Transfer Account',
      routing: '031101279',
      account: '169111467356',
      amount: 'Variable',
      frequency: 'As Needed',
      type: 'daily'
    }
  ]);

  const { toast } = useToast();

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: `${type} copied to clipboard` });
  };

  const processPayment = (accountId: string) => {
    toast({ 
      title: 'Payment Initiated', 
      description: `Payment processing started for account ${accountId}` 
    });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-emerald-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            STRIPE INTEGRATED PAYMENT SYSTEM
            <Badge className="bg-emerald-600 text-white">LIVE</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <Label className="text-gray-300">Stripe Public Key</Label>
              <p className="text-emerald-400 font-mono text-xs">pk_live_51Nel9QESMiZyND6V5ixJK2PkqjlaMSG58kfYMAjcAs3X7AIEKbWQyIevTZq4KIuTJ96uvdjxVWzkuw3gFUfdfsgA00fQaqC5Gu</p>
            </div>
            <div>
              <Label className="text-gray-300">API Base URL</Label>
              <p className="text-emerald-400 font-mono text-xs">https://render-backend.onrender.com</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="automated" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 bg-gray-800">
          <TabsTrigger value="automated">Automated Payments</TabsTrigger>
          <TabsTrigger value="manual">Manual Payment Center</TabsTrigger>
        </TabsList>

        <TabsContent value="automated" className="space-y-4">
          <div className="grid gap-4">
            {paymentAccounts.map((account) => (
              <Card key={account.id} className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-emerald-400 flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      {account.name}
                    </CardTitle>
                    <Badge className={account.type === 'recurring' ? 'bg-blue-600' : 'bg-purple-600'}>
                      {account.type.toUpperCase()}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-gray-300">Routing Number</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          value={account.routing}
                          readOnly
                          className="bg-gray-700 border-emerald-500/30 text-white font-mono"
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(account.routing, 'Routing')}
                          className="text-emerald-400"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-gray-300">Account Number</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          value={account.account}
                          readOnly
                          className="bg-gray-700 border-emerald-500/30 text-white font-mono"
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(account.account, 'Account')}
                          className="text-emerald-400"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label className="text-gray-300">Amount</Label>
                      <p className="text-emerald-400 font-semibold">{account.amount}</p>
                    </div>
                    <div>
                      <Label className="text-gray-300">Frequency</Label>
                      <p className="text-emerald-400">{account.frequency}</p>
                    </div>
                    <div className="flex items-end">
                      <Button
                        onClick={() => processPayment(account.id)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white w-full"
                      >
                        Process Payment <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="manual" className="space-y-4">
          <ManualPaymentCenter />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default StripePaymentSystem;