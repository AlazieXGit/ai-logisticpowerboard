import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, DollarSign, Activity } from 'lucide-react';

interface RevenueData {
  todayTotal: number;
  monthlyBoost: number;
  automationFees: number;
  liveTransactions: number;
}

const RealtimeRevenueTicker: React.FC = () => {
  const [revenueData, setRevenueData] = useState<RevenueData>({
    todayTotal: 0,
    monthlyBoost: 47000,
    automationFees: 0,
    liveTransactions: 0
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setRevenueData(prev => ({
        ...prev,
        todayTotal: prev.todayTotal + Math.random() * 500,
        automationFees: prev.automationFees + Math.random() * 100,
        liveTransactions: prev.liveTransactions + Math.floor(Math.random() * 3)
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-gradient-to-r from-emerald-900/30 to-blue-900/30 border-emerald-500/50">
      <CardContent className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <DollarSign className="h-5 w-5 text-emerald-400" />
              <Badge className="bg-emerald-600 text-white">TODAY'S TOTAL</Badge>
            </div>
            <p className="text-2xl font-bold text-emerald-400">
              ${revenueData.todayTotal.toFixed(2)}
            </p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <TrendingUp className="h-5 w-5 text-blue-400" />
              <Badge className="bg-blue-600 text-white">MONTHLY BOOST</Badge>
            </div>
            <p className="text-2xl font-bold text-blue-400">
              +${revenueData.monthlyBoost.toLocaleString()}
            </p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Activity className="h-5 w-5 text-purple-400" />
              <Badge className="bg-purple-600 text-white">AUTO FEES +12%</Badge>
            </div>
            <p className="text-2xl font-bold text-purple-400">
              ${revenueData.automationFees.toFixed(2)}
            </p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Activity className="h-5 w-5 text-orange-400 animate-pulse" />
              <Badge className="bg-orange-600 text-white">LIVE TXN</Badge>
            </div>
            <p className="text-2xl font-bold text-orange-400">
              {revenueData.liveTransactions}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RealtimeRevenueTicker;