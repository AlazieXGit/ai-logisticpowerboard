import { useState, useEffect } from 'react';
import { AlertTriangle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { sessionManager } from '@/services/SessionService';

export function SessionTimeoutWarning() {
  const [isOpen, setIsOpen] = useState(false);
  const [countdown, setCountdown] = useState(300); // 5 minutes

  useEffect(() => {
    sessionManager.onSessionWarning(() => {
      setIsOpen(true);
      setCountdown(300);
    });

    sessionManager.onSessionExpired(() => {
      setIsOpen(false);
      window.location.href = '/';
    });
  }, []);

  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen]);

  const handleContinue = () => {
    sessionManager.refreshToken();
    setIsOpen(false);
  };

  const handleLogout = () => {
    sessionManager.logout();
    setIsOpen(false);
  };

  const minutes = Math.floor(countdown / 60);
  const seconds = countdown % 60;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-yellow-600">
            <AlertTriangle className="h-5 w-5" />
            Session Expiring Soon
          </DialogTitle>
          <DialogDescription>
            Your session will expire due to inactivity
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center gap-4 py-6">
          <Clock className="h-16 w-16 text-yellow-500" />
          <div className="text-center">
            <div className="text-4xl font-bold text-yellow-600">
              {minutes}:{seconds.toString().padStart(2, '0')}
            </div>
            <p className="text-sm text-slate-600 mt-2">
              Click "Continue Session" to stay logged in
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <Button onClick={handleLogout} variant="outline" className="flex-1">
            Logout
          </Button>
          <Button onClick={handleContinue} className="flex-1 bg-blue-600 hover:bg-blue-700">
            Continue Session
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
