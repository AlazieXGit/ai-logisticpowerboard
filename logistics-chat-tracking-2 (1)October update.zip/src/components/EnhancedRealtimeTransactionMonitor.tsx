import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { 
  Activity, DollarSign, TrendingUp, Eye, Zap, 
  Clock, ArrowUpRight, ArrowDownRight, Settings,
  CreditCard, Building2, Shield, Database, Save, Edit
} from 'lucide-react';

interface Transaction {
  id: string;
  timestamp: string;
  amount: number;
  type: 'credit' | 'debit';
  platform: string;
  status: 'completed' | 'pending' | 'failed';
  account: string;
}

interface RevenueSource {
  name: string;
  amount: number;
  percentage: number;
  growth: number;
}

const EnhancedRealtimeTransactionMonitor: React.FC = () => {
  const [liveTransactions, setLiveTransactions] = useState<Transaction[]>([]);
  const [previousDayBalance, setPreviousDayBalance] = useState(0);
  const [currentBalance, setCurrentBalance] = useState(0);
  const [isEditing, setIsEditing] = useState(false);

  const mockTransactions: Transaction[] = [
    { id: '1', timestamp: '2024-01-15 14:30:25', amount: 2500.00, type: 'credit', platform: 'TMS System', status: 'completed', account: 'Primary Revenue' },
    { id: '2', timestamp: '2024-01-15 14:28:15', amount: 150.00, type: 'debit', platform: 'Banking Fees', status: 'completed', account: 'Operating' },
    { id: '3', timestamp: '2024-01-15 14:25:10', amount: 1800.00, type: 'credit', platform: 'Load Board AI', status: 'completed', account: 'Primary Revenue' },
    { id: '4', timestamp: '2024-01-15 14:22:05', amount: 750.00, type: 'credit', platform: 'AI Services', status: 'pending', account: 'AI Services' },
    { id: '5', timestamp: '2024-01-15 14:20:00', amount: 500.00, type: 'credit', platform: 'Credit Repair', status: 'completed', account: 'Credit Repair' }
  ];

  const revenueSources: RevenueSource[] = [
    { name: 'TMS System', amount: 85000, percentage: 35.2, growth: 12.5 },
    { name: 'Banking Services', amount: 65000, percentage: 26.9, growth: 8.3 },
    { name: 'Load Board AI', amount: 45000, percentage: 18.6, growth: 15.7 },
    { name: 'AI Services', amount: 28000, percentage: 11.6, growth: 22.1 },
    { name: 'Credit Repair', amount: 18500, percentage: 7.7, growth: 9.4 }
  ];

  const platformFees = [
    { platform: 'TMS System', processingFee: 4250, serviceFee: 1500, totalFee: 5750 },
    { platform: 'Banking Services', processingFee: 3250, serviceFee: 2100, totalFee: 5350 },
    { platform: 'Load Board AI', processingFee: 2250, serviceFee: 800, totalFee: 3050 },
    { platform: 'AI Services', processingFee: 1400, serviceFee: 600, totalFee: 2000 },
    { platform: 'Credit Repair', processingFee: 925, serviceFee: 400, totalFee: 1325 }
  ];
  const [routingEndpoint, setRoutingEndpoint] = useState('primary-revenue-routing');

  const fetchLiveData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('realtime-transaction-processor', {
        body: { action: 'getLiveTransactions' }
      });
      
      if (data && !error) {
        setLiveTransactions(prev => [...data.transactions, ...prev.slice(0, 9)]);
        setCurrentBalance(data.currentBalance);
        setPreviousDayBalance(data.previousDayBalance);
      }
    } catch (error) {
      console.error('Error fetching live data:', error);
    }
  };

  useEffect(() => {
    setLiveTransactions(mockTransactions);
    setPreviousDayBalance(425750.50);
    setCurrentBalance(485750.50);

    // Fetch live data immediately
    fetchLiveData();

    // Set up real-time updates
    const interval = setInterval(fetchLiveData, 5000);
    return () => clearInterval(interval);
  }, []);

  const totalRevenue = revenueSources.reduce((sum, source) => sum + source.amount, 0);
  const totalFees = platformFees.reduce((sum, fee) => sum + fee.totalFee, 0);
  const netRevenue = totalRevenue - totalFees;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900/20 to-blue-900/20 border-green-500">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl text-green-400 flex items-center gap-2">
                <Activity className="h-6 w-6" />
                Real-Time Transaction Monitor
              </CardTitle>
              <p className="text-gray-300">Live transaction feed & revenue analytics</p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-300">Previous Day Ending Balance</div>
              <div className="text-2xl font-bold text-blue-400">
                ${previousDayBalance.toLocaleString()}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="live-feed" className="w-full">
        <TabsList className="grid w-full grid-cols-6 bg-gray-800">
          <TabsTrigger value="live-feed">Live Feed</TabsTrigger>
          <TabsTrigger value="revenue-sources">Revenue Sources</TabsTrigger>
          <TabsTrigger value="platform-fees">Platform Fees</TabsTrigger>
          <TabsTrigger value="payment-routing">Payment Routing</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="live-feed" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-green-900/20 border-green-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-400 text-sm">Current Balance</p>
                    <p className="text-2xl font-bold text-white">
                      ${currentBalance.toLocaleString()}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-900/20 border-blue-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-400 text-sm">Daily Change</p>
                    <p className="text-2xl font-bold text-white">
                      +${(currentBalance - previousDayBalance).toLocaleString()}
                    </p>
                  </div>
                  <ArrowUpRight className="h-8 w-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-purple-900/20 border-purple-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-400 text-sm">Active Transactions</p>
                    <p className="text-2xl font-bold text-white">
                      {liveTransactions.filter(t => t.status === 'pending').length}
                    </p>
                  </div>
                  <Clock className="h-8 w-8 text-purple-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Live Transaction Feed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {liveTransactions.map((transaction) => (
                  <div key={transaction.id} className="p-3 bg-gray-700/30 rounded border border-gray-600">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        {transaction.type === 'credit' ? 
                          <ArrowUpRight className="h-5 w-5 text-green-400" /> : 
                          <ArrowDownRight className="h-5 w-5 text-red-400" />
                        }
                        <div>
                          <p className="text-white font-semibold">{transaction.platform}</p>
                          <p className="text-gray-400 text-sm">{transaction.timestamp}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-xl font-bold ${transaction.type === 'credit' ? 'text-green-400' : 'text-red-400'}`}>
                          {transaction.type === 'credit' ? '+' : '-'}${transaction.amount.toLocaleString()}
                        </p>
                        <Badge className={`${transaction.status === 'completed' ? 'bg-green-600' : transaction.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'}`}>
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedRealtimeTransactionMonitor;