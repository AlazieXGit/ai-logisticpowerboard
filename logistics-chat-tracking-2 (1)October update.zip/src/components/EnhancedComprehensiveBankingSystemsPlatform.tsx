import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Copy, Eye, EyeOff, LogIn, Shield } from 'lucide-react';

const EnhancedComprehensiveBankingSystemsPlatform = () => {
  const [showSensitive, setShowSensitive] = useState(false);
  const [activeBank, setActiveBank] = useState('pnc');

  const bankingProfiles = {
    pnc: {
      name: 'PNC Bank - XPRESS AI MASTER',
      loginUrl: 'https://www.pnc.com/en/personal-banking/virtual-wallet.html',
      accounts: [
        {
          nickname: 'XPRESS-AI-MASTER',
          accountNumber: '5563935267',
          routingNumber: '054000030',
          username: 'ValdexAlaciasCarter',
          password: 'gotchupin1976',
          directAccessPassword: 'gotchupin1976',
          pin: '1976',
          securityQuestions: {
            q1: 'First pet name?',
            a1: 'Alazie',
            q2: 'Mother maiden name?',
            a2: 'XpressAI'
          },
          accountType: 'Primary Operating',
          balance: '$2,847,592.45',
          swiftCode: 'PNCCUS33',
          fedWire: '054000030',
          address: '300 Fifth Avenue, Pittsburgh, PA 15222'
        },
        {
          nickname: 'RESERVE-FUND',
          accountNumber: '5563935275',
          routingNumber: '054000030',
          username: 'pnc_reserve_fund_2024',
          password: 'gotchupin1976',
          directAccessPassword: 'gotchupin1976',
          pin: '7592',
          accountType: 'Reserve Account',
          balance: '$1,456,789.23',
          swiftCode: 'PNCCUS33',
          fedWire: '054000030',
          address: '300 Fifth Avenue, Pittsburgh, PA 15222'
        },
        {
          nickname: 'GROWTH-INVESTMENT',
          accountNumber: '5563935283',
          routingNumber: '054000030',
          username: 'pnc_growth_inv_2024',
          password: 'gotchupin1976',
          directAccessPassword: 'gotchupin1976',
          pin: '8461',
          accountType: 'Investment Account',
          balance: '$987,654.12'
        }
      ]
    },
    wellsfargo: {
      name: 'Wells Fargo - Corporate Banking',
      loginUrl: 'https://connect.wellsfargo.com',
      accounts: [
        {
          nickname: 'WF-CORPORATE-MAIN',
          accountNumber: '4567891234',
          routingNumber: '121000248',
          username: 'wf_corporate_main_2024',
          password: 'W3lls#Corp@Main2024!',
          pin: '5678',
          accountType: 'Business Checking',
          balance: '$3,245,678.90'
        },
        {
          nickname: 'WF-SAVINGS-CORP',
          accountNumber: '4567895432',
          routingNumber: '121000248',
          username: 'wf_savings_corp_2024',
          password: 'W3lls#Sav!ngs@2024',
          pin: '9876',
          accountType: 'Corporate Savings',
          balance: '$1,876,543.21'
        }
      ]
    },
    chase: {
      name: 'JPMorgan Chase - Business Elite',
      loginUrl: 'https://secure01a.chase.com',
      accounts: [
        {
          nickname: 'CHASE-ELITE-CORP',
          accountNumber: '7891234567',
          routingNumber: '021000021',
          username: 'chase_elite_corp_2024',
          password: 'Ch@s3#Elite!Corp2024',
          pin: '1234',
          accountType: 'Corporate Elite',
          balance: '$5,678,901.23'
        },
        {
          nickname: 'CHASE-INVESTMENT-FUND',
          accountNumber: '7891237654',
          routingNumber: '021000021',
          username: 'chase_inv_fund_2024',
          password: 'Ch@s3!Inv3st@Fund24',
          pin: '4321',
          accountType: 'Investment Fund',
          balance: '$2,345,678.90'
        }
      ]
    },
    internal: {
      name: 'Internal Platform Accounts',
      accounts: [
        {
          nickname: 'SUPER-ADMIN-MASTER',
          platform: 'XpressAI Platform',
          username: 'superadmin_master_2024',
          password: 'Sup3r@Admin#Master2024!',
          accessLevel: 'LEVEL 10 - UNRESTRICTED',
          lastLogin: '2024-12-19 14:30:25'
        },
        {
          nickname: 'SYNERGY-AI-ADMIN',
          platform: 'Synergy AI Platform',
          username: 'synergy_ai_admin_2024',
          password: 'Syn3rgy@AI#Admin2024!',
          accessLevel: 'LEVEL 9 - FULL ACCESS',
          lastLogin: '2024-12-19 13:45:12'
        },
        {
          nickname: 'TMS-SYSTEM-ADMIN',
          platform: 'TMS Dispatch System',
          username: 'tms_system_admin_2024',
          password: 'TMS#Syst3m@Admin24!',
          accessLevel: 'LEVEL 8 - SYSTEM ADMIN',
          lastLogin: '2024-12-19 12:15:08'
        }
      ]
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Enhanced Banking Systems & Internal Accounts</h2>
        <Button
          onClick={() => setShowSensitive(!showSensitive)}
          variant="outline"
          size="sm"
          className="text-white border-white/20"
        >
          {showSensitive ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
          {showSensitive ? 'Hide' : 'Show'} Sensitive Data
        </Button>
      </div>

      <Tabs value={activeBank} onValueChange={setActiveBank} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="pnc" className="text-white">PNC Bank</TabsTrigger>
          <TabsTrigger value="wellsfargo" className="text-white">Wells Fargo</TabsTrigger>
          <TabsTrigger value="chase" className="text-white">Chase Bank</TabsTrigger>
          <TabsTrigger value="internal" className="text-white">Internal Accounts</TabsTrigger>
        </TabsList>

        {Object.entries(bankingProfiles).map(([key, bank]) => (
          <TabsContent key={key} value={key} className="space-y-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  {bank.name}
                  <div className="flex items-center space-x-2">
                    {bank.loginUrl && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(bank.loginUrl, '_blank')}
                        className="text-white border-white/20"
                      >
                        <LogIn className="w-4 h-4 mr-1" />
                        Login
                      </Button>
                    )}
                    <Badge variant="secondary">{bank.accounts.length} Account{bank.accounts.length > 1 ? 's' : ''}</Badge>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {bank.accounts.map((account, index) => (
                  <div key={index} className="bg-gray-900 p-4 rounded-lg space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-semibold text-white">{account.nickname}</h3>
                      <div className="flex items-center space-x-2">
                        {account.accessLevel && (
                          <Badge className="bg-red-600">
                            <Shield className="w-3 h-3 mr-1" />
                            {account.accessLevel}
                          </Badge>
                        )}
                        {account.accountType && (
                          <Badge className="bg-green-600">{account.accountType}</Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Username</p>
                        <div className="flex items-center space-x-2">
                          <p className="text-white font-mono">
                            {showSensitive ? account.username : '****' + account.username.slice(-4)}
                          </p>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(account.username)}
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Password</p>
                        <div className="flex items-center space-x-2">
                          <p className="text-white font-mono">
                            {showSensitive ? account.password : '••••••••••••'}
                          </p>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(account.password)}
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      
                      {account.accountNumber && (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-400">Account Number</p>
                          <div className="flex items-center space-x-2">
                            <p className="text-white font-mono">
                              {showSensitive ? account.accountNumber : '****' + account.accountNumber.slice(-4)}
                            </p>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyToClipboard(account.accountNumber)}
                            >
                              <Copy className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      )}
                      
                      {account.routingNumber && (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-400">Routing Number</p>
                          <p className="text-white font-mono">{account.routingNumber}</p>
                        </div>
                      )}
                      
                      {account.pin && (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-400">PIN</p>
                          <p className="text-white font-mono">
                            {showSensitive ? account.pin : '••••'}
                          </p>
                        </div>
                      )}
                      
                      {account.balance && (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-400">Balance</p>
                          <p className="text-white font-semibold text-lg">{account.balance}</p>
                        </div>
                      )}
                      
                      {account.platform && (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-400">Platform</p>
                          <p className="text-white">{account.platform}</p>
                        </div>
                      )}
                      
                      {account.lastLogin && (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-400">Last Login</p>
                          <p className="text-white text-sm">{account.lastLogin}</p>
                        </div>
                      )}
                    </div>
                    
                    {account.securityQuestions && showSensitive && (
                      <div className="pt-2 border-t border-gray-700">
                        <p className="text-sm text-gray-400 mb-2">Security Questions</p>
                        <div className="space-y-1 text-sm">
                          <p className="text-white">{account.securityQuestions.q1} <span className="text-green-400">{account.securityQuestions.a1}</span></p>
                          <p className="text-white">{account.securityQuestions.q2} <span className="text-green-400">{account.securityQuestions.a2}</span></p>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default EnhancedComprehensiveBankingSystemsPlatform;