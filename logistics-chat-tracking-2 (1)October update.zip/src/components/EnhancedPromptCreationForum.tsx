import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Code, Play, Save, History, Settings, 
  Zap, Brain, Target, FileText, Users
} from 'lucide-react';

const EnhancedPromptCreationForum = () => {
  const [currentPrompt, setCurrentPrompt] = useState('');
  const [promptTitle, setPromptTitle] = useState('');
  const [actionHistory, setActionHistory] = useState([
    {
      id: '1',
      timestamp: '2025-01-15 14:30:22',
      action: 'Prompt Created',
      title: 'AI Banking Assistant Prompt',
      user: 'Alucius Alford',
      status: 'Success',
      tokens: 1250
    },
    {
      id: '2',
      timestamp: '2025-01-15 14:25:11',
      action: 'Template Applied',
      title: 'Customer Service Bot Template',
      user: 'System',
      status: 'Applied',
      tokens: 850
    }
  ]);

  const [promptTemplates] = useState([
    {
      id: '1',
      name: 'AI Banking Assistant',
      category: 'Financial',
      description: 'Advanced banking operations prompt',
      template: 'You are an AI banking assistant specialized in financial operations, compliance, and customer service. Handle transactions, account management, and regulatory requirements with precision.'
    },
    {
      id: '2',
      name: 'Code Generator',
      category: 'Development',
      description: 'Generate clean, efficient code',
      template: 'Generate production-ready code that follows best practices, includes error handling, and is well-documented. Focus on performance, security, and maintainability.'
    },
    {
      id: '3',
      name: 'Data Analysis',
      category: 'Analytics',
      description: 'Analyze complex datasets',
      template: 'Analyze the following data and provide actionable insights. Include statistical analysis, trend identification, and recommendations for business decisions.'
    },
    {
      id: '4',
      name: 'Customer Support Bot',
      category: 'Support',
      description: 'Intelligent customer service assistant',
      template: 'You are a customer support specialist. Provide helpful, empathetic responses while following company policies. Escalate complex issues appropriately.'
    },
    {
      id: '5',
      name: 'Legal Document Reviewer',
      category: 'Legal',
      description: 'Review and analyze legal documents',
      template: 'Review legal documents for compliance, identify potential risks, and suggest improvements. Focus on accuracy and regulatory adherence.'
    },
    {
      id: '6',
      name: 'Marketing Content Creator',
      category: 'Marketing',
      description: 'Create compelling marketing content',
      template: 'Create engaging marketing content that resonates with the target audience. Focus on brand voice, value proposition, and call-to-action effectiveness.'
    },
    {
      id: '7',
      name: 'Risk Assessment Analyst',
      category: 'Risk Management',
      description: 'Comprehensive risk evaluation',
      template: 'Analyze potential risks in business operations, financial transactions, or strategic decisions. Provide risk scores and mitigation strategies.'
    },
    {
      id: '8',
      name: 'Technical Documentation',
      category: 'Documentation',
      description: 'Create detailed technical documentation',
      template: 'Generate comprehensive technical documentation that is clear, accurate, and accessible to the intended audience. Include examples and best practices.'
    }
  ]);

  const [aiModels] = useState([
    { id: 'gpt-4', name: 'GPT-4 Turbo', status: 'Active', cost: '$0.03/1K' },
    { id: 'claude', name: 'Claude 3.5', status: 'Active', cost: '$0.025/1K' },
    { id: 'gemini', name: 'Gemini Pro', status: 'Active', cost: '$0.02/1K' }
  ]);

  const handleSavePrompt = () => {
    const newAction = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleString(),
      action: 'Prompt Saved',
      title: promptTitle || 'Untitled Prompt',
      user: 'Alucius Alford',
      status: 'Success',
      tokens: currentPrompt.length * 0.75
    };
    setActionHistory([newAction, ...actionHistory]);
  };

  const handleTestRun = () => {
    const newAction = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleString(),
      action: 'Test Execution',
      title: promptTitle || 'Untitled Prompt',
      user: 'Alucius Alford',
      status: 'Running',
      tokens: currentPrompt.length * 0.75
    };
    setActionHistory([newAction, ...actionHistory]);
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="editor" className="w-full">
        <TabsList className="grid grid-cols-6 bg-gray-800/50">
          <TabsTrigger value="editor">Prompt Editor</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="history">Action History</TabsTrigger>
          <TabsTrigger value="models">AI Models</TabsTrigger>
          <TabsTrigger value="analytics">Performance</TabsTrigger>
          <TabsTrigger value="collaboration">Team</TabsTrigger>
        </TabsList>

        <TabsContent value="editor" className="space-y-4">
          <Card className="bg-gray-800/30 border-cyan-500">
            <CardHeader>
              <CardTitle className="text-cyan-400 flex items-center gap-2">
                <Code className="h-5 w-5" />
                AI ALAZIE XPRESS ENTERPRISE - Advanced Prompt Editor
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Input
                  placeholder="Enter prompt title..."
                  value={promptTitle}
                  onChange={(e) => setPromptTitle(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
                <div className="flex gap-2">
                  <Button onClick={handleSavePrompt} className="bg-green-600 hover:bg-green-700">
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                  <Button onClick={handleTestRun} className="bg-blue-600 hover:bg-blue-700">
                    <Play className="h-4 w-4 mr-2" />
                    Test Run
                  </Button>
                </div>
              </div>
              <Textarea
                placeholder="Enter your AI prompt here..."
                value={currentPrompt}
                onChange={(e) => setCurrentPrompt(e.target.value)}
                className="min-h-[300px] bg-gray-700 border-gray-600 text-white font-mono"
              />
              <div className="flex justify-between items-center text-sm text-gray-400">
                <span>Characters: {currentPrompt.length}</span>
                <span>Estimated Tokens: {Math.ceil(currentPrompt.length * 0.75)}</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card className="bg-gray-800/30 border-purple-500">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Prompt Templates Library
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {promptTemplates.map((template) => (
                  <div key={template.id} className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="text-white font-semibold">{template.name}</h4>
                        <p className="text-gray-400 text-sm">{template.description}</p>
                      </div>
                      <Badge className="bg-blue-500">{template.category}</Badge>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => setCurrentPrompt(template.template)}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      Use Template
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card className="bg-gray-800/30 border-green-500">
            <CardHeader>
              <CardTitle className="text-green-400 flex items-center gap-2">
                <History className="h-5 w-5" />
                Action History & Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {actionHistory.map((action) => (
                  <div key={action.id} className="bg-gray-700/30 p-3 rounded-lg border border-gray-600">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={
                            action.status === 'Success' ? 'bg-green-500' :
                            action.status === 'Running' ? 'bg-yellow-500' : 'bg-blue-500'
                          }>
                            {action.status}
                          </Badge>
                          <span className="text-white font-medium">{action.action}</span>
                        </div>
                        <p className="text-gray-400 text-sm">{action.title}</p>
                        <div className="flex gap-4 text-xs text-gray-500 mt-1">
                          <span>User: {action.user}</span>
                          <span>Time: {action.timestamp}</span>
                          <span>Tokens: {Math.ceil(action.tokens)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="models" className="space-y-4">
          <Card className="bg-gray-800/30 border-orange-500">
            <CardHeader>
              <CardTitle className="text-orange-400 flex items-center gap-2">
                <Brain className="h-5 w-5" />
                AI Model Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {aiModels.map((model) => (
                  <div key={model.id} className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="text-white font-semibold">{model.name}</h4>
                        <p className="text-gray-400 text-sm">Cost: {model.cost} tokens</p>
                      </div>
                      <Badge className="bg-green-500">{model.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <Card className="bg-gray-800/30 border-yellow-500">
            <CardHeader>
              <CardTitle className="text-yellow-400 flex items-center gap-2">
                <Target className="h-5 w-5" />
                Performance Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Total Prompts</h4>
                  <p className="text-2xl font-bold text-green-400">1,247</p>
                  <p className="text-gray-400 text-sm">+23% this month</p>
                </div>
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Success Rate</h4>
                  <p className="text-2xl font-bold text-blue-400">97.8%</p>
                  <p className="text-gray-400 text-sm">Above target</p>
                </div>
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Avg Response</h4>
                  <p className="text-2xl font-bold text-purple-400">1.2s</p>
                  <p className="text-gray-400 text-sm">Optimal speed</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="collaboration" className="space-y-4">
          <Card className="bg-gray-800/30 border-pink-500">
            <CardHeader>
              <CardTitle className="text-pink-400 flex items-center gap-2">
                <Users className="h-5 w-5" />
                Team Collaboration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Active Team Members</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Alucius Alford (Master Admin)</span>
                      <Badge className="bg-green-500">Online</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>AI Development Team</span>
                      <Badge className="bg-blue-500">Active</Badge>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Shared Prompts</h4>
                  <p className="text-gray-400">47 prompts shared across team</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedPromptCreationForum;