import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Lock, Eye, EyeOff, Copy, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const PNCLoginCredentials = () => {
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);

  const pncCredentials = {
    username: 'ValdexAlaciasCarter',
    password: 'gotchupin1976',
    directAccessPassword: 'gotchupin1976',
    pin: '1976',
    accountNumber: '5563935267',
    routingNumber: '054000030',
    email: 'alaziellc.innovation@gmail.com'
  };
  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: `${label} copied successfully`,
    });
  };

  return (
    <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Shield className="h-6 w-6" />
          PNC DIRECT ACCESS SOLUTION
          <Badge className="bg-green-600">UPDATED CREDENTIALS</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4">
          <div className="space-y-2">
            <Label className="text-blue-300">Username</Label>
            <div className="flex gap-2">
              <Input
                value={pncCredentials.username}
                readOnly
                className="bg-gray-800 border-blue-500 text-white font-mono"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(pncCredentials.username, 'Username')}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-blue-300">Password</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={pncCredentials.password}
                  readOnly
                  className="bg-gray-800 border-blue-500 text-white font-mono pr-10"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(pncCredentials.password, 'Password')}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-blue-300">Direct Access Password</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={pncCredentials.directAccessPassword}
                  readOnly
                  className="bg-gray-800 border-blue-500 text-white font-mono pr-10"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(pncCredentials.directAccessPassword, 'Direct Access Password')}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-blue-300">PIN</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showPin ? "text" : "password"}
                  value={pncCredentials.pin}
                  readOnly
                  className="bg-gray-800 border-blue-500 text-white font-mono pr-10"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPin(!showPin)}
                >
                  {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(pncCredentials.pin, 'PIN')}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="border-t border-gray-600 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-400 text-sm">Account Number</Label>
                <p className="text-white font-mono text-lg">{pncCredentials.accountNumber}</p>
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Routing Number</Label>
                <p className="text-white font-mono text-lg">{pncCredentials.routingNumber}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-green-900/20 border border-green-600 rounded p-4">
          <div className="flex items-center gap-2 mb-2">
            <Lock className="h-4 w-4 text-green-400" />
            <p className="text-green-400 font-semibold">Security Status</p>
          </div>
          <p className="text-green-300 text-sm">
            ✅ Credentials Updated: gotchupin1976 | PIN: 1976 | Account: 5563935267
          </p>
        </div>
      </CardContent>
    </Card>
  );
};