import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Activity, Play, Pause, Square, Zap, TrendingUp, 
  Shield, Truck, DollarSign, Users, Server, Eye
} from 'lucide-react';

const MasterPlatformCenter: React.FC = () => {
  const [allSystemsActive, setAllSystemsActive] = useState(true);
  const [liveMetrics, setLiveMetrics] = useState({
    activeLoads: 847,
    revenue: 234567.89,
    activeUsers: 156,
    systemHealth: 98.7,
    transactions: 1234,
    securityThreats: 0
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveMetrics(prev => ({
        activeLoads: prev.activeLoads + Math.floor(Math.random() * 10 - 5),
        revenue: prev.revenue + Math.random() * 1000,
        activeUsers: prev.activeUsers + Math.floor(Math.random() * 6 - 3),
        systemHealth: Math.max(95, Math.min(100, prev.systemHealth + (Math.random() - 0.5))),
        transactions: prev.transactions + Math.floor(Math.random() * 5),
        securityThreats: Math.max(0, prev.securityThreats + Math.floor(Math.random() * 2 - 1))
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleSystemControl = (action: 'start' | 'pause' | 'stop' | 'boost') => {
    switch (action) {
      case 'start':
        setAllSystemsActive(true);
        break;
      case 'pause':
        setAllSystemsActive(false);
        break;
      case 'stop':
        setAllSystemsActive(false);
        break;
      case 'boost':
        // Trigger boost functionality
        break;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900 to-blue-900 border-purple-500">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-3">
            <Server className="h-8 w-8 text-purple-400" />
            MASTER PLATFORM CONTROL CENTER
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Button
              onClick={() => handleSystemControl('start')}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Play className="h-4 w-4 mr-2" />
              START ALL
            </Button>
            <Button
              onClick={() => handleSystemControl('pause')}
              className="bg-yellow-600 hover:bg-yellow-700 text-white"
            >
              <Pause className="h-4 w-4 mr-2" />
              PAUSE ALL
            </Button>
            <Button
              onClick={() => handleSystemControl('stop')}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              <Square className="h-4 w-4 mr-2" />
              STOP ALL
            </Button>
            <Button
              onClick={() => handleSystemControl('boost')}
              className="bg-purple-600 hover:bg-purple-700 text-white animate-pulse"
            >
              <Zap className="h-4 w-4 mr-2" />
              SUPER BOOST
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-black/80 border-green-500">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center gap-2">
              <Truck className="h-5 w-5" />
              Live Load Boards
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Active Loads:</span>
                <Badge className="bg-green-600 animate-pulse">
                  {liveMetrics.activeLoads.toLocaleString()}
                </Badge>
              </div>
              <div className="text-sm text-gray-400">
                FTL: 234 | LTL: 156 | Drayage: 89 | International: 45
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full w-4/5 animate-pulse"></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black/80 border-blue-500">
          <CardHeader>
            <CardTitle className="text-blue-400 flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Live Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-2xl font-bold text-green-400">
                ${liveMetrics.revenue.toLocaleString(undefined, {minimumFractionDigits: 2})}
              </div>
              <div className="text-sm text-gray-400">
                PNC: $89K | Wells: $67K | Trust: $78K
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-400" />
                <span className="text-green-400 text-sm">+12.5% today</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black/80 border-red-500">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Security Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">System Health:</span>
                <Badge className="bg-green-600">
                  {liveMetrics.systemHealth.toFixed(1)}%
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Threats:</span>
                <Badge className={liveMetrics.securityThreats > 0 ? "bg-red-600" : "bg-green-600"}>
                  {liveMetrics.securityThreats}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Alert className="border-purple-500 bg-purple-900/20">
        <Eye className="h-4 w-4" />
        <AlertDescription className="text-purple-300">
          🔴 LIVE MONITORING: All systems operational - Real-time data streaming active
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default MasterPlatformCenter;