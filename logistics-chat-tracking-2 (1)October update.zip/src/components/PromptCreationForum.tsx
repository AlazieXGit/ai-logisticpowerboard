import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  MessageSquare, Eye, Clock, User, CheckCircle, 
  AlertCircle, Play, Save, History
} from 'lucide-react';

const PromptCreationForum = () => {
  const [prompt, setPrompt] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('general');
  
  const [actionHistory] = useState([
    {
      id: '1',
      timestamp: '2024-01-15 14:30:22',
      user: 'admin@alazie.com',
      action: 'Created AI Load Matching Prompt',
      status: 'success',
      details: 'Integrated GPT-4 for intelligent load matching'
    },
    {
      id: '2', 
      timestamp: '2024-01-15 14:25:15',
      user: 'dev@alazie.com',
      action: 'Updated Payment Processing Prompt',
      status: 'pending',
      details: 'Enhanced Stripe integration prompts'
    },
    {
      id: '3',
      timestamp: '2024-01-15 14:20:08',
      user: 'admin@alazie.com', 
      action: 'Deployed Banking AI Assistant',
      status: 'success',
      details: 'Live banking automation prompts activated'
    },
    {
      id: '4',
      timestamp: '2024-01-15 14:15:33',
      user: 'editor@alazie.com',
      action: 'Modified TMS Dispatch Prompts',
      status: 'error',
      details: 'Validation failed - requires admin approval'
    }
  ]);

  const categories = [
    { id: 'general', label: 'General AI', color: 'bg-blue-600' },
    { id: 'banking', label: 'Banking AI', color: 'bg-green-600' },
    { id: 'logistics', label: 'Logistics AI', color: 'bg-purple-600' },
    { id: 'automation', label: 'Automation', color: 'bg-orange-600' }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-400" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-400" />;
      default: return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const handleSavePrompt = () => {
    console.log('Saving prompt:', { title, prompt, category });
  };

  const handleTestPrompt = () => {
    console.log('Testing prompt:', prompt);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Prompt Creation Forum</h2>
        <Badge className="bg-cyan-600">AI Editor Access</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Prompt Editor */}
        <Card className="bg-gray-800/30 border-cyan-500">
          <CardHeader>
            <CardTitle className="text-cyan-400 flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Prompt Editor
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Input
                placeholder="Prompt Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-gray-700 border-gray-600"
              />
              
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Category</label>
                <div className="flex gap-2 flex-wrap">
                  {categories.map((cat) => (
                    <Button
                      key={cat.id}
                      variant={category === cat.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCategory(cat.id)}
                      className={category === cat.id ? cat.color : ""}
                    >
                      {cat.label}
                    </Button>
                  ))}
                </div>
              </div>

              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-64 bg-gray-900 border-gray-600 font-mono text-sm"
                placeholder="Enter your AI prompt here..."
              />
              
              <div className="flex gap-2">
                <Button onClick={handleSavePrompt} className="bg-green-600 hover:bg-green-700">
                  <Save className="h-4 w-4 mr-2" />
                  Save Prompt
                </Button>
                <Button onClick={handleTestPrompt} className="bg-blue-600 hover:bg-blue-700">
                  <Play className="h-4 w-4 mr-2" />
                  Test Prompt
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action History */}
        <Card className="bg-gray-800/30 border-purple-500">
          <CardHeader>
            <CardTitle className="text-purple-400 flex items-center gap-2">
              <History className="h-5 w-5" />
              Action History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-3">
                {actionHistory.map((action) => (
                  <div key={action.id} className="bg-gray-700/30 p-3 rounded-lg border border-gray-600">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(action.status)}
                        <span className="text-white font-medium text-sm">{action.action}</span>
                      </div>
                      <Badge className={`text-xs ${
                        action.status === 'success' ? 'bg-green-600' :
                        action.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                      }`}>
                        {action.status}
                      </Badge>
                    </div>
                    <div className="text-xs text-gray-400 mb-1">
                      <User className="h-3 w-3 inline mr-1" />
                      {action.user}
                    </div>
                    <div className="text-xs text-gray-500 mb-2">
                      <Clock className="h-3 w-3 inline mr-1" />
                      {action.timestamp}
                    </div>
                    <p className="text-xs text-gray-300">{action.details}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PromptCreationForum;