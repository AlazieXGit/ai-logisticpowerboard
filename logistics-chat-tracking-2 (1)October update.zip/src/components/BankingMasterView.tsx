import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, DollarSign, CreditCard, TrendingDown, Wallet } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface BankingAccount {
  id: string;
  account_number: string;
  account_type: string;
  balance: number;
  status: string;
  owner: string;
}

interface WithdrawalTransaction {
  id: string;
  account_id: string;
  amount: number;
  recipient: string;
  status: string;
  timestamp: string;
  method: string;
}

const BankingMasterView: React.FC = () => {
  const [accounts, setAccounts] = useState<BankingAccount[]>([
    {
      id: '1',
      account_number: 'ALZ-001-2024',
      account_type: 'Business Checking',
      balance: 2500000.00,
      status: 'active',
      owner: 'Alaziel LLC'
    },
    {
      id: '2',
      account_number: 'ALZ-002-2024',
      account_type: 'Treasury Account',
      balance: 5750000.00,
      status: 'active',
      owner: 'Alaziel LLC'
    },
    {
      id: '3',
      account_number: 'ALZ-003-2024',
      account_type: 'Escrow Account',
      balance: 1250000.00,
      status: 'active',
      owner: 'Alaziel LLC'
    }
  ]);

  const [withdrawals, setWithdrawals] = useState<WithdrawalTransaction[]>([
    {
      id: 'WD001',
      account_id: 'ALZ-001-2024',
      amount: 50000.00,
      recipient: 'Vendor Payment - Transport Co',
      status: 'completed',
      timestamp: '2024-01-15 14:30:00',
      method: 'ACH Transfer'
    },
    {
      id: 'WD002',
      account_id: 'ALZ-002-2024',
      amount: 125000.00,
      recipient: 'Equipment Purchase',
      status: 'pending',
      timestamp: '2024-01-15 15:45:00',
      method: 'Wire Transfer'
    },
    {
      id: 'WD003',
      account_id: 'ALZ-001-2024',
      amount: 25000.00,
      recipient: 'Payroll Distribution',
      status: 'completed',
      timestamp: '2024-01-15 16:20:00',
      method: 'Direct Deposit'
    }
  ]);

  const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0);
  const totalWithdrawals = withdrawals.reduce((sum, wd) => sum + wd.amount, 0);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': case 'completed': return 'bg-green-600';
      case 'pending': return 'bg-yellow-600';
      case 'failed': case 'inactive': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <Card className="bg-gray-900/50 border-gray-600">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          Alaziel LLC Banking System - Master View
        </CardTitle>
        <Badge className="bg-blue-600 w-fit">SUPER ADMIN ACCESS ONLY</Badge>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="accounts" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="accounts">Accounts</TabsTrigger>
            <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
            <TabsTrigger value="overview">Overview</TabsTrigger>
          </TabsList>
          
          <TabsContent value="accounts" className="space-y-4">
            <div className="grid gap-4">
              {accounts.map((account) => (
                <div key={account.id} className="p-4 bg-gray-800/50 rounded-lg border border-gray-600">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Wallet className="h-5 w-5 text-blue-400" />
                      <div>
                        <h3 className="text-white font-medium">{account.account_type}</h3>
                        <p className="text-gray-400 text-sm">{account.account_number}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(account.status)}>
                      {account.status.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="text-gray-300">
                      <span className="text-gray-400">Balance: </span>
                      <span className="text-green-400 font-medium">
                        ${account.balance.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-gray-300">
                      <span className="text-gray-400">Owner: </span>
                      <span>{account.owner}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="withdrawals" className="space-y-4">
            <div className="grid gap-4">
              {withdrawals.map((withdrawal) => (
                <div key={withdrawal.id} className="p-4 bg-gray-800/50 rounded-lg border border-gray-600">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <TrendingDown className="h-5 w-5 text-red-400" />
                      <div>
                        <h3 className="text-white font-medium">{withdrawal.recipient}</h3>
                        <p className="text-gray-400 text-sm">ID: {withdrawal.id}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(withdrawal.status)}>
                      {withdrawal.status.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div className="text-gray-300">
                      <span className="text-gray-400">Amount: </span>
                      <span className="text-red-400 font-medium">
                        -${withdrawal.amount.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-gray-300">
                      <span className="text-gray-400">Method: </span>
                      <span>{withdrawal.method}</span>
                    </div>
                    <div className="text-gray-300">
                      <span className="text-gray-400">Time: </span>
                      <span>{withdrawal.timestamp}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-green-900/20 border-green-500/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-green-400 text-lg flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Total Balance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-green-400">
                    ${totalBalance.toLocaleString()}
                  </p>
                  <p className="text-gray-400 text-sm">Across {accounts.length} accounts</p>
                </CardContent>
              </Card>
              
              <Card className="bg-red-900/20 border-red-500/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-red-400 text-lg flex items-center gap-2">
                    <TrendingDown className="h-5 w-5" />
                    Total Withdrawals
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-red-400">
                    ${totalWithdrawals.toLocaleString()}
                  </p>
                  <p className="text-gray-400 text-sm">{withdrawals.length} transactions</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default BankingMasterView;