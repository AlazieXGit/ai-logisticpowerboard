import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { Shield, Lock, AlertTriangle, Ban, Users, Eye, EyeOff } from 'lucide-react';

interface ThreatAccount {
  id: string;
  ip_address: string;
  username: string;
  password: string;
  email: string;
  threat_level: 'HIGH' | 'CRITICAL';
  status: 'ACTIVE' | 'BLOCKED';
  incident_type: string;
  timestamp: string;
  failed_attempts: number;
  login_credentials: {
    attempted_username: string;
    attempted_password: string;
    attempted_email: string;
  };
}

const ThreatAccountLockdown: React.FC = () => {
  const [threatAccounts, setThreatAccounts] = useState<ThreatAccount[]>([]);
  const [systemLockdown, setSystemLockdown] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [showCredentials, setShowCredentials] = useState<{[key: string]: boolean}>({});

  useEffect(() => {
    loadThreatData();
    const interval = setInterval(loadThreatData, 3000);
    return () => clearInterval(interval);
  }, []);

  const loadThreatData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('fraud-detection', {
        body: { action: 'get_threat_accounts' }
      });
      
      if (error) throw error;
      
      setThreatAccounts(data.threats || []);
      setSystemLockdown(data.system_lockdown || true);
    } catch (error) {
      console.error('Error loading threat data:', error);
      // Mock data with login credentials as requested
      setThreatAccounts([
        {
          id: '1',
          ip_address: '192.168.1.100',
          username: 'admin_user',
          password: 'admin123',
          email: 'admin@company.com',
          threat_level: 'HIGH',
          status: 'ACTIVE',
          incident_type: 'Suspicious Login',
          timestamp: '7/25/2025, 3:45:21 PM',
          failed_attempts: 3,
          login_credentials: {
            attempted_username: 'admin_user',
            attempted_password: 'admin123',
            attempted_email: 'admin@company.com'
          }
        },
        {
          id: '2',
          ip_address: '10.0.0.50',
          username: 'banking_admin',
          password: 'bank_pass_2025',
          email: 'banking@alaziel.com',
          threat_level: 'HIGH',
          status: 'ACTIVE',
          incident_type: 'Multiple Failed Attempts',
          timestamp: '7/25/2025, 3:40:21 PM',
          failed_attempts: 8,
          login_credentials: {
            attempted_username: 'banking_admin',
            attempted_password: 'bank_pass_2025',
            attempted_email: 'banking@alaziel.com'
          }
        }
      ]);
      setSystemLockdown(true);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleCredentialVisibility = (accountId: string) => {
    setShowCredentials(prev => ({
      ...prev,
      [accountId]: !prev[accountId]
    }));
  };

  const blockThreatAccount = async (accountId: string) => {
    try {
      const { error } = await supabase.functions.invoke('fraud-detection', {
        body: { 
          action: 'block_account',
          account_id: accountId
        }
      });
      
      if (error) throw error;
      await loadThreatData();
    } catch (error) {
      console.error('Error blocking account:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Critical Security Alert */}
      <Alert className="bg-red-900/30 border-red-500 border-2">
        <AlertTriangle className="h-5 w-5 text-red-400" />
        <AlertDescription>
          <div className="space-y-2">
            <h2 className="text-xl font-bold text-red-400">🚨 SECURITY THREAT DETECTED</h2>
            <div className="text-white space-y-1">
              <p>• Suspicious Login from 192.168.1.100 at 7/25/2025, 3:45:21 PM</p>
              <p>• Multiple Failed Attempts from 10.0.0.50 at 7/25/2025, 3:40:21 PM</p>
              <p>• Threat Level: <span className="text-red-400 font-bold">HIGH</span></p>
              <p>• Active Incidents: <span className="text-red-400 font-bold">2</span></p>
            </div>
            <div className="bg-red-800/50 p-3 rounded mt-3">
              <p className="text-red-200 font-semibold">ALL USER ACCESS RESTRICTED - SUPER ADMIN ONLY</p>
            </div>
          </div>
        </AlertDescription>
      </Alert>

      {/* Threat Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-red-900/20 border-red-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-300">Active Threats</p>
                <p className="text-3xl font-bold text-red-400">2</p>
              </div>
              <AlertTriangle className="w-10 h-10 text-red-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-orange-900/20 border-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-300">System Status</p>
                <p className="text-lg font-bold text-red-400">LOCKDOWN</p>
              </div>
              <Lock className="w-10 h-10 text-red-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900/50 border-gray-600">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-300">Access Level</p>
                <p className="text-lg font-bold text-yellow-400">SUPER ADMIN</p>
              </div>
              <Shield className="w-10 h-10 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Threat Accounts with Login Credentials */}
      <Card className="bg-gray-900 border-red-500">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Security Threat Details - Login Credentials Used
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {threatAccounts.map((account) => (
              <Alert key={account.id} className="bg-red-900/20 border-red-500">
                <AlertDescription>
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <h4 className="font-bold text-red-400 text-lg">{account.incident_type}</h4>
                          <Badge className="bg-red-600 text-white">{account.threat_level}</Badge>
                          <Badge className="bg-yellow-600 text-white">{account.status}</Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                          <div className="text-gray-300">
                            <span className="text-red-400 font-semibold">Source IP:</span> {account.ip_address}
                          </div>
                          <div className="text-gray-300">
                            <span className="text-red-400 font-semibold">Time:</span> {account.timestamp}
                          </div>
                          <div className="text-gray-300">
                            <span className="text-red-400 font-semibold">Failed Attempts:</span> {account.failed_attempts}
                          </div>
                          <div className="text-gray-300">
                            <span className="text-red-400 font-semibold">Threat Level:</span> {account.threat_level}
                          </div>
                        </div>

                        {/* Login Credentials Section */}
                        <div className="bg-gray-800/50 p-4 rounded border border-red-500/30">
                          <div className="flex items-center justify-between mb-3">
                            <h5 className="font-semibold text-red-400">🔐 Login Credentials Used by Threat:</h5>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleCredentialVisibility(account.id)}
                              className="border-red-500 text-red-400 hover:bg-red-900/20"
                            >
                              {showCredentials[account.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                              {showCredentials[account.id] ? 'Hide' : 'Show'}
                            </Button>
                          </div>
                          
                          {showCredentials[account.id] && (
                            <div className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <span className="text-gray-400">Username:</span>
                                <span className="text-white font-mono bg-gray-700 px-2 py-1 rounded">
                                  {account.login_credentials.attempted_username}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-400">Password:</span>
                                <span className="text-white font-mono bg-gray-700 px-2 py-1 rounded">
                                  {account.login_credentials.attempted_password}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-400">Email:</span>
                                <span className="text-white font-mono bg-gray-700 px-2 py-1 rounded">
                                  {account.login_credentials.attempted_email}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex flex-col gap-2 ml-4">
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => blockThreatAccount(account.id)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Ban className="w-4 h-4 mr-2" />
                          Block Account
                        </Button>
                      </div>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ThreatAccountLockdown;