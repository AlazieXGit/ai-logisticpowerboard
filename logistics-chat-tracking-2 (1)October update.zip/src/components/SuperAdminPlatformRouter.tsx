import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Building2, Database, Shield, ArrowRight } from 'lucide-react';
import SuperAdminAuth from './SuperAdminAuth';
import SuperAdminDashboard from './SuperAdminDashboard';

const SuperAdminPlatformRouter: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);

  const handleAuthentication = (authenticated: boolean) => {
    setIsAuthenticated(authenticated);
    if (authenticated) {
      setShowDashboard(true);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setShowDashboard(false);
  };

  if (showDashboard && isAuthenticated) {
    return <SuperAdminDashboard onLogout={handleLogout} />;
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-gray-900 to-black">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-blue-400 mb-4">
              🔐 ALAZIEL PLATFORM ACCESS
            </h1>
            <p className="text-gray-300 text-lg">
              Super Admin Portal - Back Office & Platform Integration
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-blue-900/20 border-blue-500/50">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Back Office System
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-4">
                  Administrative operations and management console
                </p>
                <Badge className="bg-blue-600">REQUIRES AUTH</Badge>
              </CardContent>
            </Card>

            <Card className="bg-green-900/20 border-green-500/50">
              <CardHeader>
                <CardTitle className="text-green-400 flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  Main Platform
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-4">
                  Core platform services and database management
                </p>
                <Badge className="bg-green-600">REQUIRES AUTH</Badge>
              </CardContent>
            </Card>

            <Card className="bg-red-900/20 border-red-500/50">
              <CardHeader>
                <CardTitle className="text-red-400 flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Super Admin Only
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-4">
                  Restricted to alaziellc.innovation@gmail.com
                </p>
                <Badge className="bg-red-600">SECURED</Badge>
              </CardContent>
            </Card>
          </div>

          <div className="max-w-md mx-auto">
            <SuperAdminAuth onAuthenticated={handleAuthentication} />
          </div>

          <div className="text-center mt-8">
            <div className="flex items-center justify-center gap-2 text-gray-400">
              <span>Authenticate</span>
              <ArrowRight className="h-4 w-4" />
              <span>Access Dashboard</span>
              <ArrowRight className="h-4 w-4" />
              <span>Connect to Systems</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-gray-900 to-black flex items-center justify-center">
      <Card className="bg-green-900/20 border-green-500/50 max-w-md">
        <CardHeader>
          <CardTitle className="text-green-400 text-center">
            ✅ Authentication Successful
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-gray-300">
            Welcome, Super Admin Alucius Alford
          </p>
          <Button 
            onClick={() => setShowDashboard(true)}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            Access Dashboard
            <ExternalLink className="h-4 w-4 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminPlatformRouter;