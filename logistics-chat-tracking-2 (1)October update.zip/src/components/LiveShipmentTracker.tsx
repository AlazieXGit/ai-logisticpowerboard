import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Truck, MapPin, Clock, Package, User, Phone, Mail } from 'lucide-react';

interface LiveShipment {
  id: string;
  orderNumber: string;
  product: string;
  value: string;
  recipient: string;
  recipientAddress: string;
  recipientPhone: string;
  recipientEmail: string;
  currentLocation: string;
  status: 'preparing' | 'shipped' | 'in_transit' | 'out_for_delivery' | 'delivered';
  estimatedDelivery: string;
  carrier: string;
  trackingNumber: string;
}

const LiveShipmentTracker: React.FC = () => {
  const [shipments, setShipments] = useState<LiveShipment[]>([
    {
      id: 'LS001',
      orderNumber: 'ORD-H001-2024',
      product: 'Tesla Assembly Line Humanoid Robot',
      value: '$125,000',
      recipient: 'Alucius Alford',
      recipientAddress: '2408 yanceyville St greensboro NC 27405',
      recipientPhone: '336-458-8449',
      recipientEmail: 'alaziellc.innovation@gmail.com',
      currentLocation: 'Hamburg Port, Germany',
      status: 'in_transit',
      estimatedDelivery: '2025-01-20 14:30 EST',
      carrier: 'Tesla International Robotics',
      trackingNumber: 'TIR-2024-001'
    },
    {
      id: 'LS002',
      orderNumber: 'ORD-H004-2024',
      product: 'BMW Quality Control Humanoid Robot',
      value: '$98,000',
      recipient: 'Alucius Alford',
      recipientAddress: '2408 yanceyville St greensboro NC 27405',
      recipientPhone: '336-458-8449',
      recipientEmail: 'alaziellc.innovation@gmail.com',
      currentLocation: 'Munich Distribution Center',
      status: 'shipped',
      estimatedDelivery: '2025-01-22 09:15 EST',
      carrier: 'BMW Robotics Division',
      trackingNumber: 'BMW-ROB-2024-004'
    },
    {
      id: 'LS003',
      orderNumber: 'RR-PHANTOM-2024',
      product: 'Rolls-Royce Phantom',
      value: '$450,000',
      recipient: 'Alucius Alford',
      recipientAddress: '2408 yanceyville St greensboro NC 27405',
      recipientPhone: '336-458-8449',
      recipientEmail: 'alaziellc.innovation@gmail.com',
      currentLocation: 'Rolls-Royce London Showroom',
      status: 'preparing',
      estimatedDelivery: '2025-01-25 16:00 EST',
      carrier: 'Rolls-Royce Premium Delivery',
      trackingNumber: 'RR-PREM-2024-001'
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'preparing': return 'bg-yellow-600';
      case 'shipped': return 'bg-blue-600';
      case 'in_transit': return 'bg-purple-600';
      case 'out_for_delivery': return 'bg-orange-600';
      case 'delivered': return 'bg-green-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'preparing': return <Package className="h-4 w-4" />;
      case 'shipped': return <Truck className="h-4 w-4" />;
      case 'in_transit': return <MapPin className="h-4 w-4" />;
      case 'out_for_delivery': return <Truck className="h-4 w-4" />;
      case 'delivered': return <Package className="h-4 w-4" />;
      default: return <Package className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Truck className="h-6 w-6 text-blue-400" />
        <h2 className="text-2xl font-bold text-white">Live Shipment Tracking</h2>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {shipments.map((shipment) => (
          <Card key={shipment.id} className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-white flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  {shipment.orderNumber}
                </CardTitle>
                <Badge className={`${getStatusColor(shipment.status)} flex items-center gap-1`}>
                  {getStatusIcon(shipment.status)}
                  {shipment.status.replace('_', ' ').toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="text-white font-medium mb-1">Product Details</h4>
                    <p className="text-gray-300 text-sm">{shipment.product}</p>
                    <p className="text-green-400 font-bold">{shipment.value}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-white font-medium mb-1">Current Location</h4>
                    <p className="text-gray-300 text-sm">{shipment.currentLocation}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-white font-medium mb-1">Carrier</h4>
                    <p className="text-gray-300 text-sm">{shipment.carrier}</p>
                    <p className="text-gray-400 text-xs">Tracking: {shipment.trackingNumber}</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div>
                    <h4 className="text-white font-medium mb-1 flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Delivery Recipient
                    </h4>
                    <p className="text-gray-300 text-sm font-medium">{shipment.recipient}</p>
                    <p className="text-gray-400 text-xs">{shipment.recipientAddress}</p>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <Phone className="h-3 w-3" />
                      {shipment.recipientPhone}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <Mail className="h-3 w-3" />
                      {shipment.recipientEmail}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 pt-2">
                    <Clock className="h-4 w-4 text-yellow-400" />
                    <div className="text-sm">
                      <span className="text-gray-400">ETA:</span>
                      <span className="text-white ml-2">{shipment.estimatedDelivery}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-4 border-t border-gray-600">
                <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
                  Track Package
                </Button>
                <Button variant="outline" className="flex-1">
                  Contact Carrier
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default LiveShipmentTracker;