import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';

export default function PayoutTestPanel() {
  const [amount, setAmount] = useState('');
  const [userId, setUserId] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');

  const handlePayout = async () => {
    if (!amount || !userId) {
      setError('Please fill in all fields');
      return;
    }

    setLoading(true);
    setError('');
    setResult(null);

    try {
      const { data, error: functionError } = await supabase.functions.invoke('payout', {
        body: {
          amount: parseFloat(amount),
          userId: userId,
        },
      });

      if (functionError) {
        throw functionError;
      }

      setResult(data);
      console.log('✅ Payout success:', data);
    } catch (err: any) {
      console.error('❌ Payout failed:', err);
      setError(err.message || 'Payout failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Payout Test Panel</CardTitle>
        <CardDescription>
          Test the Supabase payout edge function
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="amount">Amount ($)</Label>
          <Input
            id="amount"
            type="number"
            placeholder="100.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="userId">User ID</Label>
          <Input
            id="userId"
            placeholder="user_abc123"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
          />
        </div>

        <Button 
          onClick={handlePayout} 
          disabled={loading}
          className="w-full"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            'Initiate Payout'
          )}
        </Button>

        {error && (
          <Alert variant="destructive">
            <XCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-1">
                <p><strong>Status:</strong> {result.status}</p>
                <p><strong>Message:</strong> {result.message}</p>
                {result.payoutId && <p><strong>ID:</strong> {result.payoutId}</p>}
                {result.timestamp && <p><strong>Time:</strong> {new Date(result.timestamp).toLocaleString()}</p>}
              </div>
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}