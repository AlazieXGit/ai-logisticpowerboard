import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Truck, MapPin, Clock, Navigation, Phone, CheckCircle } from 'lucide-react';

interface Driver {
  id: string;
  name: string;
  phone: string;
  location: string;
  status: 'available' | 'dispatched' | 'delivering' | 'offline';
  rating: number;
}

interface DispatchLoad {
  id: string;
  origin: string;
  destination: string;
  pickupTime: string;
  deliveryTime: string;
  driver?: Driver;
  status: 'pending' | 'assigned' | 'picked_up' | 'in_transit' | 'delivered';
  rate: number;
  distance: number;
}

const TMSDispatch = () => {
  const [loads, setLoads] = useState<DispatchLoad[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [selectedLoad, setSelectedLoad] = useState<string>('');
  const [autoDispatch, setAutoDispatch] = useState(true);

  useEffect(() => {
    // Initialize drivers
    const initialDrivers: Driver[] = [
      { id: 'D001', name: 'John Smith', phone: '555-0101', location: 'Chicago, IL', status: 'available', rating: 4.8 },
      { id: 'D002', name: 'Maria Garcia', phone: '555-0102', location: 'Dallas, TX', status: 'available', rating: 4.9 },
      { id: 'D003', name: 'Mike Johnson', phone: '555-0103', location: 'Atlanta, GA', status: 'dispatched', rating: 4.7 },
      { id: 'D004', name: 'Sarah Wilson', phone: '555-0104', location: 'Phoenix, AZ', status: 'available', rating: 4.6 },
      { id: 'D005', name: 'David Brown', phone: '555-0105', location: 'Denver, CO', status: 'delivering', rating: 4.8 }
    ];
    setDrivers(initialDrivers);

    // Generate loads
    const interval = setInterval(() => {
      const newLoad: DispatchLoad = {
        id: `DISP-${Date.now()}`,
        origin: `City ${Math.floor(Math.random() * 50)}`,
        destination: `City ${Math.floor(Math.random() * 50)}`,
        pickupTime: new Date(Date.now() + Math.random() * 86400000).toLocaleString(),
        deliveryTime: new Date(Date.now() + Math.random() * 172800000 + 86400000).toLocaleString(),
        status: 'pending',
        rate: Math.floor(Math.random() * 3000) + 1500,
        distance: Math.floor(Math.random() * 1000) + 100
      };
      
      setLoads(prev => [newLoad, ...prev.slice(0, 9)]);
      
      // Auto-dispatch if enabled
      if (autoDispatch) {
        setTimeout(() => autoAssignDriver(newLoad.id), 2000);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [autoDispatch]);

  const autoAssignDriver = (loadId: string) => {
    const availableDrivers = drivers.filter(d => d.status === 'available');
    if (availableDrivers.length > 0) {
      const bestDriver = availableDrivers.sort((a, b) => b.rating - a.rating)[0];
      assignDriver(loadId, bestDriver.id);
    }
  };

  const assignDriver = (loadId: string, driverId: string) => {
    setLoads(prev => prev.map(load => {
      if (load.id === loadId) {
        const driver = drivers.find(d => d.id === driverId);
        return { ...load, driver, status: 'assigned' };
      }
      return load;
    }));
    
    setDrivers(prev => prev.map(driver => {
      if (driver.id === driverId) {
        return { ...driver, status: 'dispatched' };
      }
      return driver;
    }));
  };

  const updateLoadStatus = (loadId: string, newStatus: DispatchLoad['status']) => {
    setLoads(prev => prev.map(load => {
      if (load.id === loadId) {
        return { ...load, status: newStatus };
      }
      return load;
    }));
  };

  const availableDriversCount = drivers.filter(d => d.status === 'available').length;
  const activeLoadsCount = loads.filter(l => l.status !== 'delivered').length;

  return (
    <div className="space-y-6">
      {/* Dispatch Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Truck className="h-4 w-4 mr-2" />
              Available Drivers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{availableDriversCount}</div>
            <p className="text-xs text-gray-400">Ready for dispatch</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Navigation className="h-4 w-4 mr-2" />
              Active Loads
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{activeLoadsCount}</div>
            <p className="text-xs text-gray-400">In progress</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Auto Dispatch
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Badge className={autoDispatch ? 'bg-green-600' : 'bg-red-600'}>
              {autoDispatch ? 'ENABLED' : 'DISABLED'}
            </Badge>
            <Button 
              size="sm" 
              className="mt-2 w-full" 
              onClick={() => setAutoDispatch(!autoDispatch)}
            >
              Toggle
            </Button>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              Delivered Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {loads.filter(l => l.status === 'delivered').length}
            </div>
            <p className="text-xs text-gray-400">Completed loads</p>
          </CardContent>
        </Card>
      </div>

      {/* Active Loads */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center">
            <Navigation className="h-5 w-5 mr-2" />
            Active Dispatch Board
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {loads.slice(0, 6).map((load) => (
              <div key={load.id} className="p-4 bg-gray-700 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <MapPin className="h-5 w-5 text-emerald-400" />
                    <div>
                      <div className="text-white font-medium">{load.id}</div>
                      <div className="text-gray-400 text-sm">
                        {load.origin} → {load.destination} ({load.distance} mi)
                      </div>
                      <div className="text-gray-500 text-xs">
                        Pickup: {load.pickupTime}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <Badge className={`${
                      load.status === 'pending' ? 'bg-yellow-600' :
                      load.status === 'assigned' ? 'bg-blue-600' :
                      load.status === 'picked_up' ? 'bg-purple-600' :
                      load.status === 'in_transit' ? 'bg-orange-600' :
                      'bg-green-600'
                    }`}>
                      {load.status.replace('_', ' ').toUpperCase()}
                    </Badge>
                    
                    {load.driver && (
                      <div className="text-right">
                        <div className="text-white text-sm font-medium">{load.driver.name}</div>
                        <div className="text-gray-400 text-xs flex items-center">
                          <Phone className="h-3 w-3 mr-1" />
                          {load.driver.phone}
                        </div>
                      </div>
                    )}
                    
                    <div className="text-right">
                      <div className="text-white font-bold">${load.rate}</div>
                      <div className="text-gray-400 text-sm">Rate</div>
                    </div>
                    
                    {load.status === 'pending' && (
                      <Select onValueChange={(driverId) => assignDriver(load.id, driverId)}>
                        <SelectTrigger className="w-32">
                          <SelectValue placeholder="Assign" />
                        </SelectTrigger>
                        <SelectContent>
                          {drivers.filter(d => d.status === 'available').map(driver => (
                            <SelectItem key={driver.id} value={driver.id}>
                              {driver.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    
                    {load.status === 'assigned' && (
                      <Button 
                        size="sm" 
                        onClick={() => updateLoadStatus(load.id, 'picked_up')}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        Pickup
                      </Button>
                    )}
                    
                    {load.status === 'picked_up' && (
                      <Button 
                        size="sm" 
                        onClick={() => updateLoadStatus(load.id, 'in_transit')}
                        className="bg-orange-600 hover:bg-orange-700"
                      >
                        In Transit
                      </Button>
                    )}
                    
                    {load.status === 'in_transit' && (
                      <Button 
                        size="sm" 
                        onClick={() => updateLoadStatus(load.id, 'delivered')}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        Deliver
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TMSDispatch;