import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { DollarSign, TrendingUp, MapPin, Clock } from 'lucide-react';

interface FeeCollection {
  id: string;
  source: string;
  amount: number;
  feeType: string;
  destination: string;
  timestamp: Date;
  status: 'collected' | 'pending' | 'processing';
}

export const RevenueFeesDisplay: React.FC = () => {
  const [fees, setFees] = useState<FeeCollection[]>([]);
  const [totalCollected, setTotalCollected] = useState(0);

  useEffect(() => {
    const generateFees = () => {
      const sources = ['Auto Dispatch', 'Load Matching', 'AI Forecasting', 'Weather Navigation', 'Contract Processing'];
      const destinations = ['Alaziel LLC Operating', 'Alaziel LLC Reserve', 'Client Escrow', 'Insurance Fund'];
      
      const newFees: FeeCollection[] = Array.from({ length: 10 }, (_, i) => ({
        id: `fee-${Date.now()}-${i}`,
        source: sources[Math.floor(Math.random() * sources.length)],
        amount: Math.floor(Math.random() * 500) + 50,
        feeType: ['5% AI Dispatch', '1% Load Match', '2% Forecasting', '3% Minimum'][Math.floor(Math.random() * 4)],
        destination: destinations[Math.floor(Math.random() * destinations.length)],
        timestamp: new Date(Date.now() - Math.random() * 3600000),
        status: ['collected', 'pending', 'processing'][Math.floor(Math.random() * 3)] as 'collected' | 'pending' | 'processing'
      }));

      setFees(newFees);
      setTotalCollected(newFees.reduce((sum, fee) => sum + (fee.status === 'collected' ? fee.amount : 0), 0));
    };

    generateFees();
    const interval = setInterval(generateFees, 5000);
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'collected': return 'bg-green-500';
      case 'pending': return 'bg-yellow-500';
      case 'processing': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-green-500" />
              Total Collected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              ${totalCollected.toLocaleString()}
            </div>
            <p className="text-sm text-gray-600">Real-time fee collection</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-blue-500" />
              Processing Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {Math.floor(Math.random() * 20) + 80}%
            </div>
            <Progress value={Math.floor(Math.random() * 20) + 80} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Clock className="h-5 w-5 text-purple-500" />
              Avg Processing Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {Math.floor(Math.random() * 5) + 1}s
            </div>
            <p className="text-sm text-gray-600">Lightning fast processing</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Live Fee Collections
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {fees.map((fee) => (
              <div key={fee.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(fee.status)}`} />
                  <div>
                    <div className="font-medium">{fee.source}</div>
                    <div className="text-sm text-gray-600">{fee.feeType}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-green-600">${fee.amount}</div>
                  <div className="text-xs text-gray-500 flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {fee.destination}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};