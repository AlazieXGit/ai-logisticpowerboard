import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  ArrowRight, CheckCircle, Clock, AlertTriangle, 
  Settings, Shield, Database, Copy
} from 'lucide-react';
import LiveClock from './LiveClock';

const PaymentRoutingSystem: React.FC = () => {
  const [routingEngineActive, setRoutingEngineActive] = useState(true);

  const activeRoutes = [
    {
      id: 'route-001',
      name: 'Stripe Connect → Wells Fargo Business',
      status: 'Active',
      route: 'acct_1234567890 → 121000248-****7892',
      lastTransfer: '2025-01-15 14:30:22',
      amount: '$2,450.00'
    },
    {
      id: 'route-002',
      name: 'Square Payments → Plaid Connected Account',
      status: 'Active',
      route: 'sq0idp-1234567890 → 026009593-****5678',
      lastTransfer: '2025-01-15 13:45:11',
      amount: '$1,875.50'
    },
    {
      id: 'route-003',
      name: 'Ace Flare Account → Wells Fargo Business',
      status: 'Pending',
      route: 'ACE-DIRECT → 121000248-****7892',
      lastTransfer: '2025-01-15 12:15:33',
      amount: '$950.25'
    },
    {
      id: 'route-004',
      name: 'Plaid Connected → Stripe Connect',
      status: 'Completed',
      route: '026009593-****5678 → acct_1234567890',
      lastTransfer: '2025-01-15 11:22:44',
      amount: '$3,200.75'
    }
  ];

  const platformInstructions = [
    {
      platform: 'Stripe Connect',
      type: 'API Integration',
      endpoint: '/v1/transfers',
      authKey: 'sk_live_51234567890...',
      instructions: 'Use Stripe Dashboard → Transfers → Create Transfer → Enter amount and destination'
    },
    {
      platform: 'Square Payments',
      type: 'Square Dashboard',
      endpoint: '/v2/payments',
      authKey: 'EAAAl1234567890...',
      instructions: 'Square Dashboard → Payments → Transfer Funds → Select account and amount'
    },
    {
      platform: 'Plaid Banking',
      type: 'ACH Transfer',
      endpoint: '/transfer/create',
      authKey: 'access-sandbox-1234567890...',
      instructions: 'Plaid Console → ACH → Initiate Transfer → Verify account and process'
  }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <LiveClock />
      </div>
      
      <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-500/50">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <ArrowRight className="h-5 w-5" />
            Payment Routing System - Complete Transfer Network
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="text-green-400 text-lg">Active Routing Paths</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {activeRoutes.map((route) => (
                <div key={route.id} className="p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <ArrowRight className="h-4 w-4 text-blue-400" />
                      <span className="text-white font-semibold">{route.name}</span>
                    </div>
                    <Badge className={
                      route.status === 'Active' ? 'bg-green-600' :
                      route.status === 'Pending' ? 'bg-orange-600' : 'bg-blue-600'
                    }>
                      {route.status}
                    </Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <p className="text-gray-300">Route: <span className="text-blue-300 font-mono">{route.route}</span></p>
                    <p className="text-gray-300">Last Transfer: <span className="text-white">{route.lastTransfer}</span></p>
                    <p className="text-gray-300">Amount: <span className="text-green-400 font-bold">{route.amount}</span></p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-blue-500">
            <CardHeader>
              <CardTitle className="text-blue-400 text-lg">Manual Fund Distribution - Platform Instructions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {platformInstructions.map((instruction, index) => (
                <div key={index} className="p-4 bg-blue-900/20 rounded-lg border border-blue-500/30">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="text-white font-semibold flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      {instruction.platform}
                    </h4>
                    <Badge className="bg-blue-600">{instruction.type}</Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <p className="text-gray-300">Endpoint: <span className="text-blue-300 font-mono">{instruction.endpoint}</span></p>
                    <p className="text-gray-300">Auth Key: <span className="text-yellow-300 font-mono">{instruction.authKey}</span></p>
                    <Alert className="border-blue-500 bg-blue-900/20 mt-3">
                      <AlertDescription className="text-blue-300 text-xs">
                        <strong>Instructions:</strong> {instruction.instructions}
                      </AlertDescription>
                    </Alert>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-yellow-500">
            <CardHeader>
              <CardTitle className="text-yellow-400 text-lg">Platform Access & Credentials</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="border-yellow-500 bg-yellow-900/20">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-yellow-300">
                  <strong>SECURE ACCESS REQUIRED:</strong> All platform credentials are encrypted and require Super Admin authorization for manual fund distribution.
                </AlertDescription>
              </Alert>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-700/50 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Back Office Access</h4>
                  <div className="space-y-1 text-sm">
                    <p className="text-gray-300">Portal: AI ALAZIE XPRESS Back Office</p>
                    <p className="text-gray-300">Access Level: Fund Distribution</p>
                    <p className="text-gray-300">Authorization: Super Admin Required</p>
                    <Button size="sm" className="mt-2 bg-green-600 hover:bg-green-700">
                      Access Fund Distribution
                    </Button>
                  </div>
                </div>
                
                <div className="p-4 bg-gray-700/50 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Super Admin Platform</h4>
                  <div className="space-y-1 text-sm">
                    <p className="text-gray-300">Portal: Super Admin Transaction Control</p>
                    <p className="text-gray-300">Access Level: Full Control</p>
                    <p className="text-gray-300">Authorization: Master Admin</p>
                    <Button size="sm" className="mt-2 bg-blue-600 hover:bg-blue-700">
                      Access Super Admin
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentRoutingSystem;