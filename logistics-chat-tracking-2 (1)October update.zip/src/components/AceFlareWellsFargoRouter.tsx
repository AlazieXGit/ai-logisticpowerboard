import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { ArrowRight, Zap, Building2, CheckCircle, AlertTriangle } from 'lucide-react';

interface RoutingResult {
  success: boolean;
  message: string;
  amount: number;
  fromAccount: string;
  toAccount: string;
}

export function AceFlareWellsFargoRouter() {
  const [routing, setRouting] = useState(false);
  const [result, setResult] = useState<RoutingResult | null>(null);

  const executeRouting = async () => {
    setRouting(true);
    try {
      const { data, error } = await supabase.functions.invoke('ace-flare-wells-fargo-router', {
        body: { 
          action: 'redirect_ace_to_wells',
          amount: 50000 // $500.00 in cents
        }
      });
      
      if (error) throw error;
      setResult(data);
    } catch (error) {
      console.error('Routing error:', error);
      setResult({
        success: false,
        message: 'Routing failed: ' + (error as Error).message,
        amount: 0,
        fromAccount: 'Ace Flare',
        toAccount: 'Wells Fargo Business'
      });
    } finally {
      setRouting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-blue-900/30 to-purple-800/20 border-blue-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="h-6 w-6 text-yellow-400" />
            Ace Flare → Wells Fargo Business Router
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-500/20 rounded-lg">
                <Building2 className="h-6 w-6 text-red-400" />
              </div>
              <div>
                <p className="text-white font-medium">Ace Flare Account</p>
                <p className="text-gray-400 text-sm">Source Account</p>
              </div>
            </div>
            
            <ArrowRight className="h-8 w-8 text-blue-400 animate-pulse" />
            
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <Building2 className="h-6 w-6 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium">Wells Fargo Business</p>
                <p className="text-gray-400 text-sm">Destination Account</p>
              </div>
            </div>
          </div>

          <Button 
            onClick={executeRouting}
            disabled={routing}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            {routing ? 'Processing Route...' : 'Execute Direct Routing'}
          </Button>

          {result && (
            <div className={`p-4 rounded-lg ${
              result.success ? 'bg-green-900/20 border border-green-500' : 'bg-red-900/20 border border-red-500'
            }`}>
              <div className="flex items-center gap-2 mb-2">
                {result.success ? (
                  <CheckCircle className="h-5 w-5 text-green-400" />
                ) : (
                  <AlertTriangle className="h-5 w-5 text-red-400" />
                )}
                <Badge className={result.success ? 'bg-green-500' : 'bg-red-500'}>
                  {result.success ? 'Success' : 'Failed'}
                </Badge>
              </div>
              <p className="text-white text-sm">{result.message}</p>
              {result.success && (
                <p className="text-gray-300 text-xs mt-1">
                  Routed ${(result.amount / 100).toLocaleString()} from {result.fromAccount} to {result.toAccount}
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}