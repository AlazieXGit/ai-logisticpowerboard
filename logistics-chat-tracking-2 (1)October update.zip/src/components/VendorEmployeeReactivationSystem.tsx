import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, Ban, Shield, Users, Building2, UserCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const VendorEmployeeReactivationSystem: React.FC = () => {
  const [reactivating, setReactivating] = useState(false);
  const [systemStatus, setSystemStatus] = useState({
    vendorPayments: 'suspended',
    employeePayments: 'suspended', 
    contractorPayments: 'suspended'
  });
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  const suspendedTargets = [
    { name: 'John Smith', type: 'Employee', status: 'TARGETED_SUSPENSION', reason: 'Security Review' }
  ];

  const reactivatableAccounts = [
    { name: 'Jane Doe', type: 'Employee', department: 'Engineering', status: 'ready' },
    { name: 'Mike Johnson', type: 'Employee', department: 'Sales', status: 'ready' },
    { name: 'ABC Vendor Corp', type: 'Vendor', category: 'Technology', status: 'ready' },
    { name: 'XYZ Logistics', type: 'Vendor', category: 'Transportation', status: 'ready' },
    { name: 'Sarah Wilson', type: 'Contractor', specialty: 'Design', status: 'ready' },
    { name: 'Tech Freelancer LLC', type: 'Contractor', specialty: 'Development', status: 'ready' }
  ];

  useEffect(() => {
    const checkAdminStatus = () => {
      const adminStatus = localStorage.getItem('superAdminAuth');
      setIsSuperAdmin(adminStatus === 'authenticated');
    };
    checkAdminStatus();
  }, []);

  const reactivateAllPayments = async () => {
    if (!isSuperAdmin) {
      alert('Super Admin access required');
      return;
    }

    setReactivating(true);
    try {
      const { data } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'reactivate_vendor_employee_contractor_payments',
          data: {
            exclude_targeted: ['john_smith'],
            reactivate_vendors: true,
            reactivate_employees: true,
            reactivate_contractors: true
          }
        }
      });

      setSystemStatus({
        vendorPayments: 'active',
        employeePayments: 'active',
        contractorPayments: 'active'
      });

      alert('✅ All vendor, employee, and contractor payments reactivated (except targeted suspensions)!');
    } catch (error) {
      console.error('Reactivation error:', error);
      alert('❌ Reactivation failed');
    }
    setReactivating(false);
  };

  if (!isSuperAdmin) {
    return (
      <Alert className="border-red-500 bg-red-900/20">
        <Ban className="h-4 w-4" />
        <AlertDescription className="text-red-400 font-semibold">
          🚫 Super Admin access required for payment reactivation
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Alert className="border-emerald-500 bg-emerald-900/20">
        <Shield className="h-4 w-4" />
        <AlertDescription className="text-emerald-400 font-semibold">
          🔐 Vendor, Employee & Contractor Payment Reactivation - Super Admin Mode
        </AlertDescription>
      </Alert>

      <Card className="bg-gradient-to-r from-emerald-600 to-blue-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Reactivate All Payments (Except Targeted Suspensions)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-white/90">
              Reactivate vendor, employee, and contractor payments while maintaining targeted account suspensions.
            </p>
            <Button
              onClick={reactivateAllPayments}
              disabled={reactivating}
              className="w-full bg-white text-emerald-600 hover:bg-gray-100"
            >
              {reactivating ? 'Reactivating...' : '🔄 Reactivate All Non-Targeted Payments'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className={systemStatus.vendorPayments === 'active' ? 'bg-emerald-900/20 border-emerald-500/50' : 'bg-red-900/20 border-red-500/50'}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${systemStatus.vendorPayments === 'active' ? 'text-emerald-400' : 'text-red-400'}`}>
              <Building2 className="h-5 w-5" />
              Vendor Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Badge className={systemStatus.vendorPayments === 'active' ? 'bg-emerald-600' : 'bg-red-600'}>
              {systemStatus.vendorPayments.toUpperCase()}
            </Badge>
          </CardContent>
        </Card>

        <Card className={systemStatus.employeePayments === 'active' ? 'bg-emerald-900/20 border-emerald-500/50' : 'bg-red-900/20 border-red-500/50'}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${systemStatus.employeePayments === 'active' ? 'text-emerald-400' : 'text-red-400'}`}>
              <Users className="h-5 w-5" />
              Employee Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Badge className={systemStatus.employeePayments === 'active' ? 'bg-emerald-600' : 'bg-red-600'}>
              {systemStatus.employeePayments.toUpperCase()}
            </Badge>
          </CardContent>
        </Card>

        <Card className={systemStatus.contractorPayments === 'active' ? 'bg-emerald-900/20 border-emerald-500/50' : 'bg-red-900/20 border-red-500/50'}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${systemStatus.contractorPayments === 'active' ? 'text-emerald-400' : 'text-red-400'}`}>
              <UserCheck className="h-5 w-5" />
              Contractor Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Badge className={systemStatus.contractorPayments === 'active' ? 'bg-emerald-600' : 'bg-red-600'}>
              {systemStatus.contractorPayments.toUpperCase()}
            </Badge>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-red-900/20 border-red-500/50">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Ban className="h-5 w-5" />
              Targeted Suspensions (Remain Suspended)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {suspendedTargets.map((account, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-red-950/30 rounded border border-red-500/30">
                  <div>
                    <div className="font-semibold text-white">{account.name}</div>
                    <div className="text-sm text-gray-400">{account.type} • {account.reason}</div>
                  </div>
                  <Badge className="bg-red-600">
                    SUSPENDED
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-emerald-900/20 border-emerald-500/50">
          <CardHeader>
            <CardTitle className="text-emerald-400 flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              Reactivated Accounts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {reactivatableAccounts.map((account, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 bg-emerald-950/30 rounded border border-emerald-500/30">
                  <div>
                    <div className="font-semibold text-white text-sm">{account.name}</div>
                    <div className="text-xs text-gray-400">{account.type} • {account.department || account.category || account.specialty}</div>
                  </div>
                  <Badge className={systemStatus.vendorPayments === 'active' ? 'bg-emerald-600' : 'bg-yellow-600'}>
                    {systemStatus.vendorPayments === 'active' ? 'ACTIVE' : 'READY'}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default VendorEmployeeReactivationSystem;