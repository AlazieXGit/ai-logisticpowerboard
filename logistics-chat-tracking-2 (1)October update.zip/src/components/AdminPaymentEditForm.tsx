import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { editPaymentSchema, EditPaymentInput } from '@/lib/adminValidation';
import { adminOperationsService } from '@/services/adminOperationsService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

interface AdminPaymentEditFormProps {
  adminId: string;
  adminEmail: string;
  onSuccess?: () => void;
}

export function AdminPaymentEditForm({ adminId, adminEmail, onSuccess }: AdminPaymentEditFormProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  
  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm<EditPaymentInput>({
    resolver: zodResolver(editPaymentSchema),
    defaultValues: { admin_id: adminId, admin_email: adminEmail }
  });

  const onSubmit = async (data: EditPaymentInput) => {
    setLoading(true);
    try {
      await adminOperationsService.editPayment(data);
      toast({ title: 'Success', description: 'Payment edited successfully' });
      reset();
      onSuccess?.();
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to edit payment', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="payment_id">Payment ID</Label>
        <Input id="payment_id" {...register('payment_id')} placeholder="pay_xxxxx" />
        {errors.payment_id && <p className="text-red-500 text-sm">{errors.payment_id.message}</p>}
      </div>
      
      <div>
        <Label htmlFor="new_amount">New Amount (optional)</Label>
        <Input id="new_amount" type="number" step="0.01" {...register('new_amount', { valueAsNumber: true })} />
        {errors.new_amount && <p className="text-red-500 text-sm">{errors.new_amount.message}</p>}
      </div>
      
      <div>
        <Label htmlFor="new_status">New Status (optional)</Label>
        <Select onValueChange={(value) => setValue('new_status', value as any)}>
          <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="refunded">Refunded</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="reason">Reason</Label>
        <Textarea id="reason" {...register('reason')} placeholder="Reason for editing..." />
        {errors.reason && <p className="text-red-500 text-sm">{errors.reason.message}</p>}
      </div>
      
      <Button type="submit" disabled={loading}>{loading ? 'Saving...' : 'Edit Payment'}</Button>
    </form>
  );
}
