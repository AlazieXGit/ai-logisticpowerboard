import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Plus, Trash2, Edit3, Check, X } from 'lucide-react';

interface CardInfo {
  id: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardholderName: string;
  cardType: 'Credit' | 'Debit';
  isActive: boolean;
}

interface CardManagementSectionProps {
  cards: CardInfo[];
  onCardsUpdate: (cards: CardInfo[]) => void;
  selectedCardId?: string;
  onCardSelect: (cardId: string) => void;
}

const CardManagementSection: React.FC<CardManagementSectionProps> = ({
  cards,
  onCardsUpdate,
  selectedCardId,
  onCardSelect
}) => {
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [newCard, setNewCard] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: '',
    cardType: 'Credit' as 'Credit' | 'Debit'
  });

  const handleAddCard = () => {
    if (newCard.cardNumber && newCard.expiryDate && newCard.cvv && newCard.cardholderName) {
      const card: CardInfo = {
        id: `card-${Date.now()}`,
        ...newCard,
        isActive: true
      };
      onCardsUpdate([...cards, card]);
      setNewCard({ cardNumber: '', expiryDate: '', cvv: '', cardholderName: '', cardType: 'Credit' });
      setIsAddingCard(false);
    }
  };

  const handleDeleteCard = (cardId: string) => {
    onCardsUpdate(cards.filter(card => card.id !== cardId));
  };

  const handleEditCard = (cardId: string, updatedCard: Partial<CardInfo>) => {
    onCardsUpdate(cards.map(card => 
      card.id === cardId ? { ...card, ...updatedCard } : card
    ));
    setEditingCardId(null);
  };

  const maskCardNumber = (cardNumber: string) => {
    return `**** **** **** ${cardNumber.slice(-4)}`;
  };

  return (
    <Card className="border-2 border-purple-200">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-purple-800">
            <CreditCard className="w-5 h-5" />
            Card Management
          </div>
          <Button
            onClick={() => setIsAddingCard(true)}
            size="sm"
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Plus className="w-4 h-4 mr-1" />
            Add Card
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {/* Add New Card Form */}
        {isAddingCard && (
          <div className="mb-6 p-4 border-2 border-dashed border-purple-200 rounded-lg">
            <h4 className="font-medium mb-3">Add New Card</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Card Number</Label>
                <Input
                  placeholder="1234 5678 9012 3456"
                  value={newCard.cardNumber}
                  onChange={(e) => setNewCard({...newCard, cardNumber: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Cardholder Name</Label>
                <Input
                  placeholder="John Doe"
                  value={newCard.cardholderName}
                  onChange={(e) => setNewCard({...newCard, cardholderName: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Expiry Date</Label>
                <Input
                  placeholder="MM/YY"
                  value={newCard.expiryDate}
                  onChange={(e) => setNewCard({...newCard, expiryDate: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>CVV</Label>
                <Input
                  placeholder="123"
                  value={newCard.cvv}
                  onChange={(e) => setNewCard({...newCard, cvv: e.target.value})}
                />
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <Button onClick={handleAddCard} size="sm">
                <Check className="w-4 h-4 mr-1" />
                Add Card
              </Button>
              <Button 
                onClick={() => setIsAddingCard(false)} 
                variant="outline" 
                size="sm"
              >
                <X className="w-4 h-4 mr-1" />
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Cards List */}
        <div className="space-y-3">
          {cards.map((card) => (
            <div 
              key={card.id}
              className={`p-4 border rounded-lg cursor-pointer transition-all ${
                selectedCardId === card.id 
                  ? 'border-purple-500 bg-purple-50' 
                  : 'border-gray-200 hover:border-purple-300'
              }`}
              onClick={() => onCardSelect(card.id)}
            >
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <div className="font-mono text-lg font-bold">
                      {maskCardNumber(card.cardNumber)}
                    </div>
                    <Badge variant={card.cardType === 'Credit' ? 'default' : 'secondary'}>
                      {card.cardType}
                    </Badge>
                    {selectedCardId === card.id && (
                      <Badge variant="outline" className="bg-purple-100 text-purple-800">
                        Selected
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm text-gray-600">
                    {card.cardholderName} • Expires {card.expiryDate}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingCardId(card.id);
                    }}
                    size="sm"
                    variant="outline"
                  >
                    <Edit3 className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteCard(card.id);
                    }}
                    size="sm"
                    variant="outline"
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {cards.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <CreditCard className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No cards added yet. Click "Add Card" to get started.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CardManagementSection;