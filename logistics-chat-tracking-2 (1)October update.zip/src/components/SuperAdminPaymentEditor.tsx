import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, Edit3, Save, AlertTriangle, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const SuperAdminPaymentEditor: React.FC = () => {
  const [paymentData, setPaymentData] = useState({
    transactionId: '',
    amount: '',
    recipient: '',
    status: 'pending',
    method: 'bank_transfer',
    description: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');

  const handleSave = async () => {
    setSaveStatus('saving');
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'manual_payment_edit',
          paymentData,
          adminId: 'alucius_alford'
        }
      });
      
      if (error) throw error;
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (error) {
      console.error('Payment edit error:', error);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 2000);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-red-900/20 border-red-500/50">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Edit3 className="h-5 w-5" />
            Manual Payment Processing Editor
          </CardTitle>
          <Badge className="bg-red-600 w-fit">SUPER ADMIN ACCESS - ALUCIUS ALFORD</Badge>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="edit" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="edit">Edit Payment</TabsTrigger>
              <TabsTrigger value="batch">Batch Operations</TabsTrigger>
            </TabsList>
            
            <TabsContent value="edit" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="transactionId">Transaction ID</Label>
                  <Input
                    id="transactionId"
                    value={paymentData.transactionId}
                    onChange={(e) => setPaymentData({...paymentData, transactionId: e.target.value})}
                    placeholder="Enter transaction ID"
                  />
                </div>
                <div>
                  <Label htmlFor="amount">Amount ($)</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={paymentData.amount}
                    onChange={(e) => setPaymentData({...paymentData, amount: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="recipient">Recipient</Label>
                  <Input
                    id="recipient"
                    value={paymentData.recipient}
                    onChange={(e) => setPaymentData({...paymentData, recipient: e.target.value})}
                    placeholder="Recipient name or ID"
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={paymentData.status} onValueChange={(value) => setPaymentData({...paymentData, status: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={paymentData.description}
                  onChange={(e) => setPaymentData({...paymentData, description: e.target.value})}
                  placeholder="Payment description or notes"
                  rows={3}
                />
              </div>
              
              <div className="flex gap-2">
                <Button 
                  onClick={handleSave}
                  disabled={saveStatus === 'saving'}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {saveStatus === 'saving' ? (
                    'Saving...'
                  ) : (
                    <><Save className="h-4 w-4 mr-2" />Save Changes</>
                  )}
                </Button>
                
                {saveStatus === 'success' && (
                  <Badge className="bg-green-600 flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" />Saved
                  </Badge>
                )}
                
                {saveStatus === 'error' && (
                  <Badge className="bg-red-600 flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />Error
                  </Badge>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="batch" className="space-y-4">
              <div className="p-4 bg-yellow-900/20 border border-yellow-500/50 rounded">
                <h3 className="text-yellow-400 font-semibold mb-2">Batch Payment Operations</h3>
                <p className="text-gray-300 text-sm mb-4">Process multiple payments simultaneously</p>
                <Button className="bg-yellow-600 hover:bg-yellow-700">
                  <CreditCard className="h-4 w-4 mr-2" />
                  Upload CSV
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminPaymentEditor;