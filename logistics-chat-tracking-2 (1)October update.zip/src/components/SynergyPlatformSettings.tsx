import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { 
  Settings, 
  Zap, 
  DollarSign, 
  Shield, 
  Bell,
  Database,
  Key,
  Save
} from 'lucide-react';

export const SynergyPlatformSettings: React.FC = () => {
  const [settings, setSettings] = useState({
    aiProcessingFee: 0.25,
    creditRepairFee: 99.99,
    automationFee: 15.00,
    transactionFee: 2.50,
    enableNotifications: true,
    enableAutoRouting: true,
    enableFraudDetection: true,
    maxDailyTransactions: 10000,
    apiRateLimit: 1000
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('Settings saved:', settings);
    } catch (error) {
      console.error('Save error:', error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Platform Settings</h2>
          <p className="text-gray-400">Configure Synergy AI Platform parameters and fees</p>
        </div>
        <Button onClick={handleSave} disabled={isSaving} className="bg-green-600 hover:bg-green-700">
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>

      <Tabs defaultValue="fees" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="fees">Fee Structure</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="api">API Config</TabsTrigger>
        </TabsList>

        <TabsContent value="fees" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <DollarSign className="h-5 w-5 mr-2 text-green-400" />
                  Service Fees
                </CardTitle>
                <CardDescription className="text-gray-400">Configure platform service charges</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ai-fee" className="text-gray-300">AI Processing Fee ($)</Label>
                  <Input
                    id="ai-fee"
                    type="number"
                    step="0.01"
                    value={settings.aiProcessingFee}
                    onChange={(e) => setSettings({...settings, aiProcessingFee: parseFloat(e.target.value)})}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="credit-fee" className="text-gray-300">Credit Repair Fee ($)</Label>
                  <Input
                    id="credit-fee"
                    type="number"
                    step="0.01"
                    value={settings.creditRepairFee}
                    onChange={(e) => setSettings({...settings, creditRepairFee: parseFloat(e.target.value)})}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="automation-fee" className="text-gray-300">Automation Fee ($)</Label>
                  <Input
                    id="automation-fee"
                    type="number"
                    step="0.01"
                    value={settings.automationFee}
                    onChange={(e) => setSettings({...settings, automationFee: parseFloat(e.target.value)})}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="transaction-fee" className="text-gray-300">Transaction Fee ($)</Label>
                  <Input
                    id="transaction-fee"
                    type="number"
                    step="0.01"
                    value={settings.transactionFee}
                    onChange={(e) => setSettings({...settings, transactionFee: parseFloat(e.target.value)})}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Revenue Projection</CardTitle>
                <CardDescription className="text-gray-400">Estimated monthly revenue based on current settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">AI Processing (10k/month)</span>
                    <Badge variant="secondary">${(settings.aiProcessingFee * 10000).toLocaleString()}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Credit Repair (500/month)</span>
                    <Badge variant="secondary">${(settings.creditRepairFee * 500).toLocaleString()}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Automation (2k/month)</span>
                    <Badge variant="secondary">${(settings.automationFee * 2000).toLocaleString()}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Transactions (50k/month)</span>
                    <Badge variant="secondary">${(settings.transactionFee * 50000).toLocaleString()}</Badge>
                  </div>
                  <hr className="border-gray-600" />
                  <div className="flex justify-between font-semibold">
                    <span className="text-white">Total Monthly Revenue</span>
                    <Badge className="bg-green-600">
                      ${((settings.aiProcessingFee * 10000) + (settings.creditRepairFee * 500) + (settings.automationFee * 2000) + (settings.transactionFee * 50000)).toLocaleString()}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="automation" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Zap className="h-5 w-5 mr-2 text-yellow-400" />
                Automation Settings
              </CardTitle>
              <CardDescription className="text-gray-400">Configure intelligent automation features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-gray-300">Enable Auto Revenue Routing</Label>
                  <p className="text-sm text-gray-400">Automatically route fees to trust accounts</p>
                </div>
                <Switch
                  checked={settings.enableAutoRouting}
                  onCheckedChange={(checked) => setSettings({...settings, enableAutoRouting: checked})}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-gray-300">Enable Fraud Detection</Label>
                  <p className="text-sm text-gray-400">AI-powered transaction fraud detection</p>
                </div>
                <Switch
                  checked={settings.enableFraudDetection}
                  onCheckedChange={(checked) => setSettings({...settings, enableFraudDetection: checked})}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-gray-300">Enable Notifications</Label>
                  <p className="text-sm text-gray-400">Real-time system notifications</p>
                </div>
                <Switch
                  checked={settings.enableNotifications}
                  onCheckedChange={(checked) => setSettings({...settings, enableNotifications: checked})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max-transactions" className="text-gray-300">Max Daily Transactions</Label>
                <Input
                  id="max-transactions"
                  type="number"
                  value={settings.maxDailyTransactions}
                  onChange={(e) => setSettings({...settings, maxDailyTransactions: parseInt(e.target.value)})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Shield className="h-5 w-5 mr-2 text-blue-400" />
                Security Configuration
              </CardTitle>
              <CardDescription className="text-gray-400">Platform security and access controls</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-700 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Encryption Status</h4>
                  <Badge className="bg-green-600">AES-256 Enabled</Badge>
                </div>
                <div className="p-4 bg-gray-700 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Authentication</h4>
                  <Badge className="bg-blue-600">Multi-Factor Active</Badge>
                </div>
                <div className="p-4 bg-gray-700 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Session Security</h4>
                  <Badge className="bg-purple-600">JWT + Refresh Tokens</Badge>
                </div>
                <div className="p-4 bg-gray-700 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Data Protection</h4>
                  <Badge className="bg-green-600">GDPR Compliant</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Key className="h-5 w-5 mr-2 text-purple-400" />
                API Configuration
              </CardTitle>
              <CardDescription className="text-gray-400">API limits and integration settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="rate-limit" className="text-gray-300">API Rate Limit (requests/hour)</Label>
                <Input
                  id="rate-limit"
                  type="number"
                  value={settings.apiRateLimit}
                  onChange={(e) => setSettings({...settings, apiRateLimit: parseInt(e.target.value)})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-700 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">API Version</h4>
                  <Badge variant="outline">v2.1.0</Badge>
                </div>
                <div className="p-4 bg-gray-700 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Webhook Status</h4>
                  <Badge className="bg-green-600">Active</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};