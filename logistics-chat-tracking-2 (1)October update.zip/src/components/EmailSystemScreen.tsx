import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, Eye, EyeOff, Mail, Send, Building2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const EmailSystemScreen: React.FC = () => {
  const [emails, setEmails] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSensitive, setShowSensitive] = useState(false);
  const [newEmail, setNewEmail] = useState({
    to: '',
    subject: '',
    body: '',
    priority: 'normal'
  });

  useEffect(() => {
    fetchEmails();
  }, []);

  const fetchEmails = async () => {
    setLoading(true);
    try {
      // Alaziel LLC email data
      const mockEmails = [
        {
          id: 1,
          from: 'banking@alaziellc.com',
          to: 'client@example.com',
          subject: 'Alaziel LLC - Payment Confirmation #ALZ-12345',
          body: 'Your payment of $2,500.00 has been processed through Alaziel LLC banking system.',
          status: 'sent',
          created_at: new Date().toISOString(),
          contains_banking_info: true
        },
        {
          id: 2,
          from: 'treasury@alaziellc.com',
          to: 'finance@alaziellc.com',
          subject: 'Alaziel LLC - Daily Treasury Report',
          body: 'Daily treasury operations summary for Alaziel LLC with transaction details.',
          status: 'sent',
          created_at: new Date().toISOString(),
          contains_banking_info: true
        },
        {
          id: 3,
          from: 'payments@alaziellc.com',
          to: 'vendor@example.com',
          subject: 'Alaziel LLC - Vendor Payment Processing',
          body: 'Your invoice payment from Alaziel LLC has been initiated via ACH transfer.',
          status: 'sent',
          created_at: new Date().toISOString(),
          contains_banking_info: true
        }
      ];
      setEmails(mockEmails);
    } catch (error) {
      console.error('Error fetching emails:', error);
    } finally {
      setLoading(false);
    }
  };

  const sendEmail = async () => {
    if (!newEmail.to || !newEmail.subject) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-email-processor', {
        body: {
          action: 'send_email',
          email_data: {
            ...newEmail,
            from: 'banking@alaziellc.com',
            timestamp: new Date().toISOString()
          }
        }
      });
      
      if (error) throw error;
      
      setNewEmail({
        to: '',
        subject: '',
        body: '',
        priority: 'normal'
      });
      
      await fetchEmails();
    } catch (error) {
      console.error('Error sending email:', error);
    } finally {
      setLoading(false);
    }
  };

  const maskEmailContent = (content: string) => {
    if (!showSensitive && content) {
      return content.replace(/\$[\d,]+\.\d{2}/g, '$***.**')
                   .replace(/\b\d{4}\s?\d{4}\s?\d{4}\s?\d{4}\b/g, '****-****-****-****')
                   .replace(/\b\d{9,}\b/g, '*'.repeat(9))
                   .replace(/ALZ-\d+/g, 'ALZ-****');
    }
    return content;
  };

  return (
    <div className="space-y-6">
      <Card className="bg-emerald-950/20 border-emerald-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-emerald-400 flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              🏦 ALAZIEL LLC EMAIL SYSTEM
            </CardTitle>
            <Button
              onClick={() => setShowSensitive(!showSensitive)}
              variant={showSensitive ? "destructive" : "secondary"}
              size="sm"
            >
              {showSensitive ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
              {showSensitive ? 'Hide Banking Data' : 'Show Banking Data'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Alert className="border-emerald-500 bg-emerald-900/20">
            <Lock className="h-4 w-4" />
            <AlertDescription className="text-emerald-300">
              🔒 ALAZIEL LLC SECURE COMMUNICATIONS: Corporate banking emails with enterprise security
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Tabs defaultValue="inbox" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="inbox">📥 LLC Inbox</TabsTrigger>
          <TabsTrigger value="compose">✍️ Compose</TabsTrigger>
          <TabsTrigger value="security">🛡️ Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="inbox">
          <div className="space-y-4">
            {emails.map((email) => (
              <Card key={email.id} className="bg-black/40 border-emerald-500">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-emerald-400 text-lg">{maskEmailContent(email.subject)}</CardTitle>
                      <p className="text-emerald-300 text-sm">From: {email.from}</p>
                      <p className="text-emerald-300 text-sm">To: {email.to}</p>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Badge className={email.status === 'sent' ? 'bg-green-600' : 'bg-yellow-600'}>
                        {email.status?.toUpperCase()}
                      </Badge>
                      {email.contains_banking_info && (
                        <Badge className="bg-emerald-600">
                          🏦 ALAZIEL LLC
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-white">{maskEmailContent(email.body)}</p>
                    <p className="text-gray-400 text-xs">
                      {new Date(email.created_at).toLocaleString()}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="compose">
          <Card className="bg-black/40 border-emerald-500">
            <CardHeader>
              <CardTitle className="text-emerald-400">Compose Alaziel LLC Email</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-emerald-300 text-sm">To:</label>
                <Input
                  value={newEmail.to}
                  onChange={(e) => setNewEmail({...newEmail, to: e.target.value})}
                  className="bg-gray-900 border-emerald-500 text-white"
                  placeholder="recipient@example.com"
                />
              </div>
              <div>
                <label className="text-emerald-300 text-sm">Subject:</label>
                <Input
                  value={newEmail.subject}
                  onChange={(e) => setNewEmail({...newEmail, subject: e.target.value})}
                  className="bg-gray-900 border-emerald-500 text-white"
                  placeholder="Alaziel LLC - Email subject"
                />
              </div>
              <div>
                <label className="text-emerald-300 text-sm">Message:</label>
                <Textarea
                  value={newEmail.body}
                  onChange={(e) => setNewEmail({...newEmail, body: e.target.value})}
                  className="bg-gray-900 border-emerald-500 text-white min-h-[120px]"
                  placeholder="Email message content from Alaziel LLC"
                />
              </div>
              <Button 
                onClick={sendEmail}
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
              >
                <Send className="h-4 w-4 mr-2" />
                {loading ? 'Sending...' : 'Send Alaziel LLC Email'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card className="bg-black/40 border-emerald-500">
            <CardHeader>
              <CardTitle className="text-emerald-400">Alaziel LLC Email Security</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert className="border-emerald-500 bg-emerald-900/20">
                  <Shield className="h-4 w-4" />
                  <AlertDescription className="text-emerald-300">
                    All Alaziel LLC banking emails are encrypted and secured with corporate-grade security protocols.
                  </AlertDescription>
                </Alert>
                <div className="grid grid-cols-2 gap-4">
                  <Badge className="bg-green-600 p-2">🔒 End-to-End Encryption</Badge>
                  <Badge className="bg-green-600 p-2">🛡️ LLC Admin Access</Badge>
                  <Badge className="bg-green-600 p-2">📧 Secure SMTP</Badge>
                  <Badge className="bg-green-600 p-2">🔐 Banking Data Masked</Badge>
                </div>
                <div className="mt-4">
                  <h4 className="text-emerald-300 font-semibold mb-2">Alaziel LLC Email Addresses:</h4>
                  <div className="space-y-2">
                    <Badge className="bg-emerald-600 p-2">📧 banking@alaziellc.com (Primary)</Badge>
                    <Badge className="bg-teal-600 p-2">💼 treasury@alaziellc.com (Treasury)</Badge>
                    <Badge className="bg-cyan-600 p-2">💳 payments@alaziellc.com (Payments)</Badge>
                    <Badge className="bg-blue-600 p-2">🤖 ai@alaziellc.com (AI Assistant)</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EmailSystemScreen;