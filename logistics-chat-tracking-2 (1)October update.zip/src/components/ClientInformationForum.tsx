import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { User, Mail, Phone, CreditCard, FileText, Send } from 'lucide-react';

interface ClientInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  ssn: string;
  currentScore: number;
  targetScore: number;
  issues: string;
  notes: string;
}

export default function ClientInformationForum() {
  const [clientInfo, setClientInfo] = useState<ClientInfo>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    ssn: '',
    currentScore: 0,
    targetScore: 0,
    issues: '',
    notes: ''
  });

  const [emailResults, setEmailResults] = useState('');

  const handleSubmit = async () => {
    console.log('Client info submitted:', clientInfo);
    // Integration with credit repair system
  };

  const sendEmailResults = async () => {
    if (!clientInfo.email || !emailResults) return;
    
    console.log('Sending email to:', clientInfo.email);
    // Email integration logic
  };

  return (
    <div className="space-y-6">
      <Card className="border-blue-200">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-blue-600" />
            Complete Client Information Forum
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              placeholder="First Name"
              value={clientInfo.firstName}
              onChange={(e) => setClientInfo({...clientInfo, firstName: e.target.value})}
            />
            <Input
              placeholder="Last Name"
              value={clientInfo.lastName}
              onChange={(e) => setClientInfo({...clientInfo, lastName: e.target.value})}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Input
              placeholder="Email Address"
              type="email"
              value={clientInfo.email}
              onChange={(e) => setClientInfo({...clientInfo, email: e.target.value})}
            />
            <Input
              placeholder="Phone Number"
              value={clientInfo.phone}
              onChange={(e) => setClientInfo({...clientInfo, phone: e.target.value})}
            />
          </div>

          <Input
            placeholder="SSN (Last 4 digits)"
            value={clientInfo.ssn}
            onChange={(e) => setClientInfo({...clientInfo, ssn: e.target.value})}
          />

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Current Credit Score</label>
              <Input
                type="number"
                value={clientInfo.currentScore}
                onChange={(e) => setClientInfo({...clientInfo, currentScore: parseInt(e.target.value)})}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Target Credit Score</label>
              <Input
                type="number"
                value={clientInfo.targetScore}
                onChange={(e) => setClientInfo({...clientInfo, targetScore: parseInt(e.target.value)})}
              />
            </div>
          </div>

          <Textarea
            placeholder="Credit Issues & Challenges"
            value={clientInfo.issues}
            onChange={(e) => setClientInfo({...clientInfo, issues: e.target.value})}
            rows={3}
          />

          <Textarea
            placeholder="Additional Notes"
            value={clientInfo.notes}
            onChange={(e) => setClientInfo({...clientInfo, notes: e.target.value})}
            rows={2}
          />

          <Button onClick={handleSubmit} className="w-full bg-blue-600 hover:bg-blue-700">
            <FileText className="h-4 w-4 mr-2" />
            Submit Client Information
          </Button>
        </CardContent>
      </Card>

      <Card className="border-green-200">
        <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-green-600" />
            Email Results to Client
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <Textarea
            placeholder="Email results and updates to client..."
            value={emailResults}
            onChange={(e) => setEmailResults(e.target.value)}
            rows={4}
          />
          <Button 
            onClick={sendEmailResults} 
            className="w-full bg-green-600 hover:bg-green-700"
            disabled={!clientInfo.email || !emailResults}
          >
            <Send className="h-4 w-4 mr-2" />
            Send Email Results
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}