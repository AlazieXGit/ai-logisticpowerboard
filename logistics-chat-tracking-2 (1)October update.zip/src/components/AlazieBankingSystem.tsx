import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Building2, Shield, DollarSign, Users, 
  CheckCircle, AlertTriangle, Zap 
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import AlazieAccountFlowTotal from './AlazieAccountFlowTotal';

interface BankingClient {
  id: string;
  name: string;
  type: string;
  balance: number;
  status: 'active' | 'pending' | 'restricted';
  aiCompliance: boolean;
}

const AlazieBankingSystem: React.FC = () => {
  const [clients, setClients] = useState<BankingClient[]>([
    { id: '1', name: 'Alazie LLC Primary', type: 'Corporate', balance: 2847592, status: 'active', aiCompliance: true },
    { id: '2', name: 'TMS Operations', type: 'Business', balance: 1234567, status: 'active', aiCompliance: true },
    { id: '3', name: 'AI Development Fund', type: 'Trust', balance: 987654, status: 'active', aiCompliance: true },
    { id: '4', name: 'Revenue Collection', type: 'Escrow', balance: 3456789, status: 'active', aiCompliance: true }
  ]);

  const [totalBalance, setTotalBalance] = useState(0);
  const [complianceRate, setComplianceRate] = useState(100);

  useEffect(() => {
    const total = clients.reduce((sum, client) => sum + client.balance, 0);
    setTotalBalance(total);
    
    const compliant = clients.filter(c => c.aiCompliance).length;
    setComplianceRate((compliant / clients.length) * 100);
  }, [clients]);

  const processTransaction = async (clientId: string, amount: number) => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'internal_transfer',
          client_id: clientId,
          amount: amount,
          compliance_check: true
        }
      });

      if (error) throw error;
      console.log('Internal transaction processed:', data);
    } catch (error) {
      console.error('Transaction failed:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-lime-900 to-green-900 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            Alazie LLC Internal Banking System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <div className="text-2xl font-bold">${totalBalance.toLocaleString()}</div>
              <div className="text-lime-200">Total Client Assets</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{clients.length}</div>
              <div className="text-lime-200">Active Accounts</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{complianceRate}%</div>
              <div className="text-lime-200">AI Compliance Rate</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="accounts" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="accounts">Client Accounts</TabsTrigger>
          <TabsTrigger value="compliance">AI Compliance</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Routing</TabsTrigger>
          <TabsTrigger value="account-flow">Account Flow</TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {clients.map((client) => (
              <Card key={client.id} className="bg-gray-800/30 border-lime-500/30">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lime-400">{client.name}</CardTitle>
                    <Badge className={client.status === 'active' ? 'bg-green-600' : 'bg-yellow-600'}>
                      {client.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Balance:</span>
                      <span className="text-white font-bold">${client.balance.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Type:</span>
                      <span className="text-blue-400">{client.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">AI Compliant:</span>
                      {client.aiCompliance ? (
                        <CheckCircle className="h-5 w-5 text-green-400" />
                      ) : (
                        <AlertTriangle className="h-5 w-5 text-yellow-400" />
                      )}
                    </div>
                    <Button 
                      size="sm" 
                      className="w-full bg-lime-600 hover:bg-lime-700"
                      onClick={() => processTransaction(client.id, 1000)}
                    >
                      Process Internal Transfer
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-4">
          <Card className="bg-gray-800/30 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400 flex items-center gap-2">
                <Shield className="h-5 w-5" />
                AI Banking Compliance Monitor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg">
                  <span className="text-green-300">KYC Verification</span>
                  <CheckCircle className="h-5 w-5 text-green-400" />
                </div>
                <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg">
                  <span className="text-green-300">AML Screening</span>
                  <CheckCircle className="h-5 w-5 text-green-400" />
                </div>
                <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg">
                  <span className="text-green-300">AI Risk Assessment</span>
                  <CheckCircle className="h-5 w-5 text-green-400" />
                </div>
                <div className="flex items-center justify-between p-3 bg-blue-900/20 rounded-lg">
                  <span className="text-blue-300">Real-time Monitoring</span>
                  <Zap className="h-5 w-5 text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card className="bg-gray-800/30 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400 flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Revenue Account Assignment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between p-3 bg-green-900/20 rounded-lg">
                  <span className="text-green-300">Subscription Revenue</span>
                  <span className="text-white">→ Alazie LLC Primary</span>
                </div>
                <div className="flex justify-between p-3 bg-blue-900/20 rounded-lg">
                  <span className="text-blue-300">TMS Fees</span>
                  <span className="text-white">→ TMS Operations</span>
                </div>
                <div className="flex justify-between p-3 bg-purple-900/20 rounded-lg">
                  <span className="text-purple-300">AI Services</span>
                  <span className="text-white">→ AI Development Fund</span>
                </div>
                <div className="flex justify-between p-3 bg-orange-900/20 rounded-lg">
                  <span className="text-orange-300">Platform Fees</span>
                  <span className="text-white">→ Revenue Collection</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account-flow" className="space-y-4">
          <AlazieAccountFlowTotal />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AlazieBankingSystem;