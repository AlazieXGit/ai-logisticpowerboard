import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PaymentTermsService, PAYMENT_TERMS_CONFIG } from '@/services/PaymentTermsConfig';
import { DollarSign, Shield, CheckCircle, AlertTriangle } from 'lucide-react';

export const UnifiedPaymentTermsSystem = () => {
  const [selectedComponent, setSelectedComponent] = useState('');
  const [showTerms, setShowTerms] = useState(false);

  const generateFullTerms = () => {
    if (!selectedComponent) return '';
    return PaymentTermsService.generatePaymentTerms(selectedComponent);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Unified Payment Terms Configuration System
          </CardTitle>
          <div className="text-sm text-gray-300">
            <p><strong>{PAYMENT_TERMS_CONFIG.companyInfo.name}</strong></p>
            <p>{PAYMENT_TERMS_CONFIG.companyInfo.contact}</p>
            <p>{PAYMENT_TERMS_CONFIG.companyInfo.address}, {PAYMENT_TERMS_CONFIG.companyInfo.city}, {PAYMENT_TERMS_CONFIG.companyInfo.state} {PAYMENT_TERMS_CONFIG.companyInfo.zip}</p>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PAYMENT_TERMS_CONFIG.components.map((component) => (
          <Card 
            key={component.componentName}
            className={`cursor-pointer transition-all ${
              selectedComponent === component.componentName 
                ? 'bg-blue-900/30 border-blue-400' 
                : 'bg-gray-900/50 border-gray-600 hover:border-blue-500/50'
            }`}
            onClick={() => setSelectedComponent(component.componentName)}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center justify-between">
                {component.componentName}
                <Badge className="bg-green-600">${component.basePrice}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 text-xs mb-2">{component.description}</p>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Base Price:</span>
                  <span className="text-white">${component.basePrice}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Processing:</span>
                  <span className="text-white">${component.processingFee}</span>
                </div>
                <div className="flex justify-between text-xs font-semibold border-t border-gray-600 pt-1">
                  <span className="text-gray-300">Total:</span>
                  <span className="text-green-400">${PaymentTermsService.calculateTotal(component.basePrice, component.processingFee)}</span>
                </div>
              </div>
              <Badge 
                className={`mt-2 ${
                  component.paymentDue === 'immediate' 
                    ? 'bg-red-600' 
                    : 'bg-yellow-600'
                }`}
              >
                {component.paymentDue === 'immediate' ? 'IMMEDIATE' : 'NEGOTIATION'}
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gray-900/50 border-gray-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Payment Processing Requirements
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-yellow-900/20 border border-yellow-500/50 rounded p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
              <h4 className="text-yellow-400 font-semibold">Check Processing Policy</h4>
            </div>
            <p className="text-gray-300 text-sm">
              <strong>IMPORTANT:</strong> {PAYMENT_TERMS_CONFIG.terms.checkProcessing}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-900/20 border border-green-500/50 rounded p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="h-4 w-4 text-green-400" />
                <h4 className="text-green-400 font-semibold">Payment Terms</h4>
              </div>
              <div className="text-sm text-gray-300 space-y-1">
                <p><strong>Due:</strong> {PAYMENT_TERMS_CONFIG.terms.paymentDue}</p>
                <p><strong>Late Fee:</strong> ${PAYMENT_TERMS_CONFIG.terms.lateFee}</p>
                <p><strong>Processing Fee:</strong> ${PAYMENT_TERMS_CONFIG.terms.processingFee}</p>
              </div>
            </div>

            <div className="bg-blue-900/20 border border-blue-500/50 rounded p-4">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-blue-400" />
                <h4 className="text-blue-400 font-semibold">Security & Compliance</h4>
              </div>
              <div className="text-sm text-gray-300 space-y-1">
                <p><strong>Encryption:</strong> {PAYMENT_TERMS_CONFIG.terms.encryption}</p>
                <p><strong>Compliance:</strong> {PAYMENT_TERMS_CONFIG.terms.compliance.join(", ")}</p>
              </div>
            </div>
          </div>

          {selectedComponent && (
            <div className="mt-4">
              <Button 
                onClick={() => setShowTerms(!showTerms)}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {showTerms ? 'Hide' : 'Show'} Full Terms for {selectedComponent}
              </Button>
              
              {showTerms && (
                <div className="mt-4 bg-gray-800 p-4 rounded border border-gray-600">
                  <pre className="text-xs text-gray-300 whitespace-pre-wrap">
                    {generateFullTerms()}
                  </pre>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UnifiedPaymentTermsSystem;