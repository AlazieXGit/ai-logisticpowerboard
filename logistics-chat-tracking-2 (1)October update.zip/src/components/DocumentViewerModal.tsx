import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Copy, Download, FileText, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DocumentViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: {
    name: string;
    type: string;
    content: string;
    downloadUrl?: string;
  };
}

export default function DocumentViewerModal({ isOpen, onClose, document }: DocumentViewerModalProps) {
  const { toast } = useToast();
  const [copiedText, setCopiedText] = useState('');

  const handleDownload = () => {
    if (document.downloadUrl) {
      const link = document.createElement('a');
      link.href = document.downloadUrl;
      link.download = document.name;
      link.click();
    } else {
      // Create blob for text content
      const blob = new Blob([document.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = document.name;
      link.click();
      URL.revokeObjectURL(url);
    }
    
    toast({
      title: 'Download Complete',
      description: `${document.name} downloaded successfully`
    });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(document.content);
    setCopiedText(document.content);
    toast({
      title: 'Copied to Clipboard',
      description: 'Document content copied successfully'
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Document Viewer: {document.name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={handleDownload} className="bg-blue-600 hover:bg-blue-700">
              <Download className="h-4 w-4 mr-2" />
              Download Complete
            </Button>
            <Button onClick={handleCopy} variant="outline">
              <Copy className="h-4 w-4 mr-2" />
              Copy Content
            </Button>
            <Button variant="outline">
              <Eye className="h-4 w-4 mr-2" />
              View Original
            </Button>
          </div>

          <Card>
            <CardContent className="p-4">
              <div className="mb-4">
                <h4 className="font-semibold mb-2">Document Information</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">File Name:</span> {document.name}
                  </div>
                  <div>
                    <span className="font-medium">Document Type:</span> {document.type}
                  </div>
                  <div>
                    <span className="font-medium">Delivery Address:</span> 2408 yanceyville St greensboro NC 27405
                  </div>
                  <div>
                    <span className="font-medium">Contact:</span> alaziellc.innovation@gmail.com | 336-458-8449
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Document Content</h4>
                <Textarea
                  value={document.content}
                  readOnly
                  className="min-h-[300px] font-mono text-sm"
                  placeholder="Document content will appear here..."
                />
              </div>

              <div className="mt-4">
                <h4 className="font-semibold mb-2">Copy & Paste Information</h4>
                <div className="bg-gray-50 p-3 rounded text-sm space-y-1">
                  <div><strong>Property Owner:</strong> Alucius Alford</div>
                  <div><strong>Delivery Address:</strong> 2408 yanceyville St greensboro NC 27405</div>
                  <div><strong>Email:</strong> alaziellc.innovation@gmail.com</div>
                  <div><strong>Phone:</strong> 336-458-8449</div>
                  <div><strong>File Path:</strong> file:///C:/Users/VALUED~1/AppData/Local/Temp/MicrosoftEdgeDownloads/d8462cfa-1de0-4912-a1b5-4ee28f1e47c0/deed.pdf</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}