import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Send, Users, Building2, Truck } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface CardTransactionSystemProps {
  onTransactionComplete?: (transaction: any) => void;
}

const CardTransactionSystem: React.FC<CardTransactionSystemProps> = ({ onTransactionComplete }) => {
  const [amount, setAmount] = useState('');
  const [recipientType, setRecipientType] = useState('');
  const [recipientId, setRecipientId] = useState('');
  const [accountType, setAccountType] = useState('');
  const [description, setDescription] = useState('');
  const [processing, setProcessing] = useState(false);

  const handleImmediateTransfer = async () => {
    if (!amount || !recipientType || !recipientId || !accountType) return;
    
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'immediate_transfer',
          amount: parseFloat(amount),
          recipientType,
          recipientId,
          accountType,
          description,
          timestamp: new Date().toISOString()
        }
      });
      
      if (error) throw error;
      onTransactionComplete?.(data);
      
      setAmount('');
      setRecipientType('');
      setRecipientId('');
      setAccountType('');
      setDescription('');
    } catch (error) {
      console.error('Transfer failed:', error);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <Card className="bg-gray-800 border-emerald-500/30">
      <CardHeader>
        <CardTitle className="text-emerald-400 flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Card Transaction & Immediate Transfer System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-gray-300 text-sm mb-2 block">Transfer Amount</label>
            <Input
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-2 block">Account Type</label>
            <Select value={accountType} onValueChange={setAccountType}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select account" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="checking">Main Checking</SelectItem>
                <SelectItem value="escrow">Escrow Account</SelectItem>
                <SelectItem value="trust">Trust Account</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-gray-300 text-sm mb-2 block">Recipient Type</label>
            <Select value={recipientType} onValueChange={setRecipientType}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select recipient type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="contractor">
                  <div className="flex items-center gap-2">
                    <Truck className="h-4 w-4" />
                    Contractor
                  </div>
                </SelectItem>
                <SelectItem value="employee">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Employee
                  </div>
                </SelectItem>
                <SelectItem value="vendor">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    Vendor
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-gray-300 text-sm mb-2 block">Recipient ID</label>
            <Input
              placeholder="Enter recipient ID"
              value={recipientId}
              onChange={(e) => setRecipientId(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
        </div>
        
        <div>
          <label className="text-gray-300 text-sm mb-2 block">Description</label>
          <Input
            placeholder="Payment description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="bg-gray-700 border-gray-600 text-white"
          />
        </div>
        
        <Button
          onClick={handleImmediateTransfer}
          disabled={processing || !amount || !recipientType || !recipientId || !accountType}
          className="w-full bg-emerald-600 hover:bg-emerald-700"
        >
          <Send className="h-4 w-4 mr-2" />
          {processing ? 'Processing...' : 'Send Immediate Transfer'}
        </Button>
        
        <div className="flex gap-2 flex-wrap">
          <Badge className="bg-emerald-600">Real-time Processing</Badge>
          <Badge className="bg-blue-600">Super Admin Only</Badge>
          <Badge className="bg-red-600">Secure Transfer</Badge>
        </div>
      </CardContent>
    </Card>
  );
};

export default CardTransactionSystem;