import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Cloud, Navigation, DollarSign } from 'lucide-react';

interface LoadMatch {
  id: string;
  origin: string;
  destination: string;
  distance: number;
  rate: number;
  weather: string;
  trafficDelay: number;
  matchScore: number;
}

export const LoadMatchingSystem: React.FC = () => {
  const [matches, setMatches] = useState<LoadMatch[]>([]);
  const [weatherEnabled, setWeatherEnabled] = useState(false);
  const [loading, setLoading] = useState(false);

  const generateMatches = () => {
    setLoading(true);
    const mockMatches: LoadMatch[] = [
      {
        id: '1',
        origin: 'Dallas, TX',
        destination: 'Atlanta, GA',
        distance: 925,
        rate: 2850,
        weather: 'Clear',
        trafficDelay: 15,
        matchScore: 95
      },
      {
        id: '2',
        origin: 'Phoenix, AZ',
        destination: 'Denver, CO',
        distance: 602,
        rate: 1950,
        weather: 'Partly Cloudy',
        trafficDelay: 8,
        matchScore: 88
      },
      {
        id: '3',
        origin: 'Miami, FL',
        destination: 'Nashville, TN',
        distance: 662,
        rate: 2100,
        weather: 'Rain',
        trafficDelay: 25,
        matchScore: 82
      }
    ];
    
    setTimeout(() => {
      setMatches(mockMatches);
      setLoading(false);
    }, 1500);
  };

  const bookLoad = (loadId: string) => {
    console.log(`Booking load ${loadId} with weather navigation`);
    setMatches(prev => prev.filter(m => m.id !== loadId));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">AI Load Matching System</h2>
        <div className="flex gap-4">
          <Button
            variant={weatherEnabled ? "default" : "outline"}
            onClick={() => setWeatherEnabled(!weatherEnabled)}
            className="flex items-center gap-2"
          >
            <Cloud className="h-4 w-4" />
            Weather Navigation (+1%)
          </Button>
          <Button onClick={generateMatches} disabled={loading}>
            {loading ? 'Matching...' : 'Find Loads'}
          </Button>
        </div>
      </div>

      <div className="grid gap-4">
        {matches.map((match) => (
          <Card key={match.id} className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  {match.origin} → {match.destination}
                </CardTitle>
                <Badge variant="secondary">Score: {match.matchScore}%</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-600">Distance</p>
                  <p className="font-semibold">{match.distance} miles</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Rate</p>
                  <p className="font-semibold text-green-600">${match.rate}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Weather</p>
                  <p className="font-semibold">{match.weather}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Traffic Delay</p>
                  <p className="font-semibold">{match.trafficDelay} min</p>
                </div>
              </div>
              
              {weatherEnabled && (
                <div className="bg-blue-50 p-3 rounded-lg mb-4">
                  <div className="flex items-center gap-2 text-blue-700">
                    <Navigation className="h-4 w-4" />
                    <span className="font-medium">Enhanced Navigation Active</span>
                  </div>
                  <p className="text-sm text-blue-600 mt-1">
                    Live weather and traffic routing (+1% fee applied)
                  </p>
                </div>
              )}

              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <DollarSign className="h-4 w-4" />
                  <span>Fees: 5% dispatch + {weatherEnabled ? '1% navigation + ' : ''}2% forecasting</span>
                </div>
                <Button onClick={() => bookLoad(match.id)} className="bg-green-600 hover:bg-green-700">
                  Auto Book Load
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {matches.length === 0 && !loading && (
        <Card className="text-center py-8">
          <CardContent>
            <p className="text-gray-500">No load matches found. Click "Find Loads" to search.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};