import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, TrendingUp, Shield, Calculator, FileText } from 'lucide-react';
import { 
  taxCorrectionInstructions, 
  commonTaxErrors, 
  taxOptimizationTips, 
  auditRiskFactors,
  TaxValidationService,
  type CorrectionInstruction 
} from '@/data/correction-instructions';

export const TaxCorrectionInstructionsPanel: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [validationResults, setValidationResults] = useState<CorrectionInstruction[]>([]);

  const filteredInstructions = selectedCategory === 'all' 
    ? taxCorrectionInstructions 
    : taxCorrectionInstructions.filter(inst => inst.category === selectedCategory);

  const runValidation = () => {
    const mockFormData = {
      personalInfo: { ssn: '123456789', filingStatus: 'single', dependents: 0 },
      income: { w2Income: 0, selfEmployment: 0, investments: 0 }
    };
    const results = TaxValidationService.validateTaxForm(mockFormData);
    setValidationResults(results);
  };

  return (
    <div className="p-6 space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/30 to-blue-800/20 border-blue-500">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Tax Correction Instructions & Validation System
            <Badge className="bg-blue-600 text-white ml-2">ACTIVE</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="instructions" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="instructions">Instructions</TabsTrigger>
          <TabsTrigger value="errors">Common Errors</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
          <TabsTrigger value="audit">Audit Risks</TabsTrigger>
          <TabsTrigger value="validation">Validation</TabsTrigger>
        </TabsList>

        <TabsContent value="instructions">
          <div className="space-y-4">
            <div className="flex gap-2 mb-4">
              {['all', 'validation', 'calculation', 'compliance', 'optimization'].map(cat => (
                <Button 
                  key={cat}
                  variant={selectedCategory === cat ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(cat)}
                >
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </Button>
              ))}
            </div>

            <div className="grid gap-4">
              {filteredInstructions.map((instruction) => (
                <Card key={instruction.id}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{instruction.title}</CardTitle>
                      <div className="flex gap-2">
                        <Badge variant={instruction.priority === 'high' ? 'destructive' : 
                                     instruction.priority === 'medium' ? 'default' : 'secondary'}>
                          {instruction.priority}
                        </Badge>
                        <Badge variant="outline">{instruction.category}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-3">{instruction.description}</p>
                    <div className="bg-green-50 p-3 rounded border-l-4 border-green-500">
                      <p className="text-sm"><strong>Solution:</strong> {instruction.solution}</p>
                    </div>
                    <div className="mt-2">
                      <p className="text-xs text-gray-500">
                        <strong>Affected Fields:</strong> {instruction.affectedFields.join(', ')}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="errors">
          <div className="grid gap-4">
            {commonTaxErrors.map((error, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-red-500 mt-1" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">{error.error}</h3>
                        <Badge variant="destructive">{error.frequency}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{error.solution}</p>
                      <p className="text-xs text-blue-600">{error.prevention}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="optimization">
          <div className="grid gap-4">
            {taxOptimizationTips.map((tip, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <TrendingUp className="h-5 w-5 text-green-500 mt-1" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">{tip.tip}</h3>
                        <Badge variant="secondary">{tip.category}</Badge>
                      </div>
                      <p className="text-sm text-green-600 font-medium mb-1">{tip.impact}</p>
                      <p className="text-xs text-gray-600">{tip.eligibility}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="audit">
          <div className="grid gap-4">
            {auditRiskFactors.map((risk, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-yellow-500 mt-1" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">{risk.factor}</h3>
                        <div className="flex gap-2">
                          <Badge variant={risk.riskLevel === 'High' ? 'destructive' : 'default'}>
                            {risk.riskLevel}
                          </Badge>
                          <Badge variant="outline">{risk.percentage}</Badge>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">{risk.mitigation}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="validation">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Tax Form Validation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button onClick={runValidation} className="mb-4">
                  Run Validation Test
                </Button>
                
                {validationResults.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-red-600">Validation Errors Found:</h4>
                    {validationResults.map((result) => (
                      <div key={result.id} className="p-3 bg-red-50 border border-red-200 rounded">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                          <span className="font-medium">{result.title}</span>
                        </div>
                        <p className="text-sm text-red-700 mt-1">{result.description}</p>
                      </div>
                    ))}
                  </div>
                )}
                
                {validationResults.length === 0 && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Click "Run Validation Test" to check for errors</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TaxCorrectionInstructionsPanel;