import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, Shield, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface ACHRegistration {
  institutionName: string;
  routingNumber: string;
  federalTaxId: string;
  contactEmail: string;
  contactPhone: string;
  institutionType: string;
  status: 'pending' | 'approved' | 'rejected' | 'under_review';
  odfiStatus: boolean;
  rdfiStatus: boolean;
  nachaCompliant: boolean;
}

const ACHNetworkRegistration: React.FC = () => {
  const [registrations, setRegistrations] = useState<ACHRegistration[]>([
    {
      institutionName: 'Wells Fargo Bank',
      routingNumber: '121000248',
      federalTaxId: '94-1347393',
      contactEmail: 'ach@wellsfargo.com',
      contactPhone: '1-800-869-3557',
      institutionType: 'Commercial Bank',
      status: 'approved',
      odfiStatus: true,
      rdfiStatus: true,
      nachaCompliant: true
    }
  ]);

  const [newRegistration, setNewRegistration] = useState<Partial<ACHRegistration>>({
    institutionName: '',
    routingNumber: '',
    federalTaxId: '',
    contactEmail: '',
    contactPhone: '',
    institutionType: 'Commercial Bank',
    status: 'pending',
    odfiStatus: false,
    rdfiStatus: false,
    nachaCompliant: false
  });

  const handleSubmitRegistration = () => {
    if (newRegistration.institutionName && newRegistration.routingNumber) {
      setRegistrations([...registrations, newRegistration as ACHRegistration]);
      setNewRegistration({
        institutionName: '',
        routingNumber: '',
        federalTaxId: '',
        contactEmail: '',
        contactPhone: '',
        institutionType: 'Commercial Bank',
        status: 'pending',
        odfiStatus: false,
        rdfiStatus: false,
        nachaCompliant: false
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'under_review': return <AlertCircle className="h-4 w-4 text-blue-500" />;
      case 'rejected': return <AlertCircle className="h-4 w-4 text-red-500" />;
      default: return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            ACH Network Registration System
          </CardTitle>
          <Badge className="bg-blue-600 w-fit">NACHA Compliant • ODFI/RDFI Management</Badge>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="register" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="register">New Registration</TabsTrigger>
              <TabsTrigger value="institutions">Registered Institutions</TabsTrigger>
              <TabsTrigger value="compliance">NACHA Compliance</TabsTrigger>
            </TabsList>
            
            <TabsContent value="register" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="institutionName">Institution Name</Label>
                  <Input
                    id="institutionName"
                    value={newRegistration.institutionName}
                    onChange={(e) => setNewRegistration({...newRegistration, institutionName: e.target.value})}
                    placeholder="Enter bank name"
                  />
                </div>
                <div>
                  <Label htmlFor="routingNumber">ABA Routing Number</Label>
                  <Input
                    id="routingNumber"
                    value={newRegistration.routingNumber}
                    onChange={(e) => setNewRegistration({...newRegistration, routingNumber: e.target.value})}
                    placeholder="9-digit routing number"
                  />
                </div>
                <div>
                  <Label htmlFor="federalTaxId">Federal Tax ID (EIN)</Label>
                  <Input
                    id="federalTaxId"
                    value={newRegistration.federalTaxId}
                    onChange={(e) => setNewRegistration({...newRegistration, federalTaxId: e.target.value})}
                    placeholder="XX-XXXXXXX"
                  />
                </div>
                <div>
                  <Label htmlFor="institutionType">Institution Type</Label>
                  <Select value={newRegistration.institutionType} onValueChange={(value) => setNewRegistration({...newRegistration, institutionType: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Commercial Bank">Commercial Bank</SelectItem>
                      <SelectItem value="Credit Union">Credit Union</SelectItem>
                      <SelectItem value="Savings Bank">Savings Bank</SelectItem>
                      <SelectItem value="Investment Bank">Investment Bank</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="contactEmail">Contact Email</Label>
                  <Input
                    id="contactEmail"
                    type="email"
                    value={newRegistration.contactEmail}
                    onChange={(e) => setNewRegistration({...newRegistration, contactEmail: e.target.value})}
                    placeholder="ach@bank.com"
                  />
                </div>
                <div>
                  <Label htmlFor="contactPhone">Contact Phone</Label>
                  <Input
                    id="contactPhone"
                    value={newRegistration.contactPhone}
                    onChange={(e) => setNewRegistration({...newRegistration, contactPhone: e.target.value})}
                    placeholder="1-800-XXX-XXXX"
                  />
                </div>
              </div>
              <Button onClick={handleSubmitRegistration} className="bg-blue-600 hover:bg-blue-700">
                Submit ACH Registration
              </Button>
            </TabsContent>
            
            <TabsContent value="institutions" className="space-y-4">
              {registrations.map((reg, index) => (
                <Card key={index} className="bg-gray-800/30 border-gray-600">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-white text-lg">{reg.institutionName}</CardTitle>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(reg.status)}
                        <Badge className={reg.status === 'approved' ? 'bg-green-600' : 'bg-yellow-600'}>
                          {reg.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-400">Routing Number:</p>
                        <p className="text-white font-mono">{reg.routingNumber}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Federal Tax ID:</p>
                        <p className="text-white font-mono">{reg.federalTaxId}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Institution Type:</p>
                        <p className="text-white">{reg.institutionType}</p>
                      </div>
                      <div className="flex gap-2">
                        <Badge className={reg.odfiStatus ? 'bg-green-600' : 'bg-gray-600'}>
                          ODFI {reg.odfiStatus ? 'Enabled' : 'Disabled'}
                        </Badge>
                        <Badge className={reg.rdfiStatus ? 'bg-green-600' : 'bg-gray-600'}>
                          RDFI {reg.rdfiStatus ? 'Enabled' : 'Disabled'}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
            
            <TabsContent value="compliance" className="space-y-4">
              <Card className="bg-green-900/20 border-green-500/50">
                <CardHeader>
                  <CardTitle className="text-green-400 flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    NACHA Compliance Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="text-white font-medium">Compliance Metrics</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Return Rate:</span>
                          <span className="text-green-400">0.8%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Unauthorized Return Rate:</span>
                          <span className="text-green-400">0.2%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Overall Return Rate:</span>
                          <span className="text-green-400">1.0%</span>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h4 className="text-white font-medium">Network Status</h4>
                      <div className="space-y-1">
                        <Badge className="bg-green-600">NACHA Compliant</Badge>
                        <Badge className="bg-blue-600">Fed ACH Network Connected</Badge>
                        <Badge className="bg-purple-600">Same Day ACH Enabled</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ACHNetworkRegistration;