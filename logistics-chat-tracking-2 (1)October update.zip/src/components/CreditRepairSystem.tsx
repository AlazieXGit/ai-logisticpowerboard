import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Shield, Users, TrendingUp, Settings } from 'lucide-react';
import ClientInformationForum from './ClientInformationForum';
import CreditRepairControlCenter from './CreditRepairControlCenter';
import RealTimeCreditMonitor from './RealTimeCreditMonitor';

export default function CreditRepairSystem() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <Card className="border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-indigo-700 text-2xl">
              <Shield className="h-8 w-8" />
              Complete Credit Repair Platform - Manual Client Service
            </CardTitle>
          </CardHeader>
        </Card>

        <Tabs defaultValue="client-forum" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="client-forum">
              <Users className="h-4 w-4 mr-2" />
              Client Forum
            </TabsTrigger>
            <TabsTrigger value="control-center">
              <Settings className="h-4 w-4 mr-2" />
              Control Center
            </TabsTrigger>
            <TabsTrigger value="real-time">
              <TrendingUp className="h-4 w-4 mr-2" />
              Real-Time AI
            </TabsTrigger>
            <TabsTrigger value="performance">
              <Shield className="h-4 w-4 mr-2" />
              Performance
            </TabsTrigger>
          </TabsList>

          <TabsContent value="client-forum">
            <ClientInformationForum />
          </TabsContent>

          <TabsContent value="control-center">
            <CreditRepairControlCenter />
          </TabsContent>

          <TabsContent value="real-time">
            <RealTimeCreditMonitor />
          </TabsContent>

          <TabsContent value="performance">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-600" />
                  Platform Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">800x</div>
                    <div className="text-sm text-gray-600">Optimization Level</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">200x</div>
                    <div className="text-sm text-gray-600">Assurance Level</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">97.3%</div>
                    <div className="text-sm text-gray-600">Success Rate</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">2.4s</div>
                    <div className="text-sm text-gray-600">Avg Response Time</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}