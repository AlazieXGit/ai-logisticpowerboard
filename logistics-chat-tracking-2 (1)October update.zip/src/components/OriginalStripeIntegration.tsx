import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { CreditCard, DollarSign, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

export const OriginalStripeIntegration = () => {
  const { toast } = useToast();
  const [paymentAmount, setPaymentAmount] = useState('');
  const [processing, setProcessing] = useState(false);
  
  // Original test keys configuration
  const stripeConfig = {
    publishableKey: 'pk_test_51HdSGwESMiZyND6V5ixJK2PkqjlaMSG58kfYMAjcAs3X7AIEKbWQyIevTZq4KIuTJ96uvdjxVWzkuw3gFUfdfsgA00fQaqC5Gu',
    secretKey: 'sk_test_...',
    webhookEndpoint: 'whsec_test_...',
    mode: 'test'
  };

  const processPayment = async () => {
    if (!paymentAmount || parseFloat(paymentAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid payment amount",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('stripe-webhook-processor', {
        body: { 
          amount: parseFloat(paymentAmount) * 100,
          currency: 'usd',
          payment_method: 'stripe',
          description: `XPRESS Payment - $${paymentAmount}`
        }
      });

      if (error) throw error;

      toast({
        title: "Payment Processed",
        description: `Successfully processed $${paymentAmount}`,
      });
      
      setPaymentAmount('');
    } catch (error) {
      console.error('Payment error:', error);
      toast({
        title: "Payment Failed",
        description: "Unable to process payment. Please try again.",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="h-6 w-6" />
            STRIPE PAYMENT INTEGRATION
            <Badge className="bg-yellow-600">TEST MODE</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Payment Processor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Payment Amount ($)</label>
              <Input
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <Button 
              onClick={processPayment}
              disabled={processing}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {processing ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Processing...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Process Payment
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Stripe Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-yellow-400" />
                <span className="text-yellow-400 text-sm">Test Mode Active</span>
              </div>
              <div className="space-y-2">
                <label className="text-gray-400 text-sm">Publishable Key</label>
                <code className="block bg-gray-700 p-2 rounded text-xs text-blue-400 break-all">
                  {stripeConfig.publishableKey.substring(0, 20)}...
                </code>
              </div>
              <div className="space-y-2">
                <label className="text-gray-400 text-sm">Webhook Status</label>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span className="text-green-400 text-sm">Connected</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Test Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { id: 'pi_test_1234567890', amount: 125.00, status: 'succeeded', date: '2025-01-07 14:30' },
              { id: 'pi_test_0987654321', amount: 75.50, status: 'succeeded', date: '2025-01-07 13:15' },
              { id: 'pi_test_1122334455', amount: 200.00, status: 'processing', date: '2025-01-07 12:45' }
            ].map((transaction) => (
              <div key={transaction.id} className="flex justify-between items-center p-3 border border-gray-600 rounded">
                <div>
                  <p className="text-white font-mono text-sm">{transaction.id}</p>
                  <p className="text-gray-400 text-xs">{transaction.date}</p>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold">${transaction.amount.toLocaleString()}</p>
                  <Badge className={
                    transaction.status === 'succeeded' ? 'bg-green-600' : 
                    transaction.status === 'processing' ? 'bg-yellow-600' : 'bg-red-600'
                  }>
                    {transaction.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OriginalStripeIntegration;