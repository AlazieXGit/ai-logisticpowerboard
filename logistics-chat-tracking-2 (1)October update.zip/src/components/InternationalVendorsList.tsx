import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Globe, Building2, Phone, Mail, MapPin, Star } from 'lucide-react';

const InternationalVendorsList = () => {
  const [selectedRegion, setSelectedRegion] = useState('europe');

  const vendors = {
    europe: [
      {
        id: 'EUR001',
        name: 'BMW Munich Premium',
        type: 'Automotive Dealer',
        country: 'Germany',
        address: 'Petuelring 130, 80788 München, Germany',
        phone: '+49-89-382-0',
        email: 'premium@bmw.de',
        website: 'https://www.bmw.de',
        rating: 5,
        specialties: ['Luxury Vehicles', 'Executive Cars', 'Performance Models'],
        contractValue: '$2.5M',
        status: 'Active'
      },
      {
        id: 'EUR002',
        name: 'Ferrari Maranello',
        type: 'Supercar Manufacturer',
        country: 'Italy',
        address: 'Via Abetone Inferiore 4, 41053 Maranello MO, Italy',
        phone: '+39-0536-949111',
        email: 'sales@ferrari.com',
        website: 'https://www.ferrari.com',
        rating: 5,
        specialties: ['Supercars', 'Racing Vehicles', 'Limited Editions'],
        contractValue: '$4.2M',
        status: 'Active'
      },
      {
        id: 'EUR003',
        name: 'Rolls-Royce London',
        type: 'Luxury Automotive',
        country: 'United Kingdom',
        address: '15 Conduit St, Mayfair, London W1S 2XJ, UK',
        phone: '+44-20-7629-8230',
        email: 'london@rolls-royce.com',
        website: 'https://www.rolls-roycemotorcars.com',
        rating: 5,
        specialties: ['Ultra-Luxury', 'Bespoke Vehicles', 'Phantom Series'],
        contractValue: '$3.8M',
        status: 'Active'
      }
    ],
    asia: [
      {
        id: 'ASIA001',
        name: 'Toyota Tokyo Premium',
        type: 'Automotive Dealer',
        country: 'Japan',
        address: '1-4-18 Koraku, Bunkyo City, Tokyo 112-8701, Japan',
        phone: '+81-3-3817-9111',
        email: 'premium@toyota.jp',
        website: 'https://www.toyota.com',
        rating: 4,
        specialties: ['Lexus Premium', 'Hybrid Technology', 'Reliability'],
        contractValue: '$1.9M',
        status: 'Active'
      },
      {
        id: 'ASIA002',
        name: 'Tesla Shanghai Robotics',
        type: 'AI Robotics',
        country: 'China',
        address: 'Lingang Special Area, Shanghai, China',
        phone: '+86-21-3463-8000',
        email: 'robotics@tesla.cn',
        website: 'https://www.tesla.cn',
        rating: 5,
        specialties: ['Humanoid Robots', 'AI Technology', 'Automation'],
        contractValue: '$6.7M',
        status: 'Active'
      }
    ],
    americas: [
      {
        id: 'AM001',
        name: 'Tesla Austin Robotics',
        type: 'AI Manufacturing',
        country: 'United States',
        address: '13101 Harold Green Rd, Austin, TX 78724, USA',
        phone: '+1-512-516-8177',
        email: 'robotics@tesla.com',
        website: 'https://www.tesla.com',
        rating: 5,
        specialties: ['Optimus Robots', 'AI Development', 'Manufacturing'],
        contractValue: '$8.9M',
        status: 'Active'
      },
      {
        id: 'AM002',
        name: 'Boston Dynamics',
        type: 'Robotics Specialist',
        country: 'United States',
        address: '78 4th Ave, Waltham, MA 02451, USA',
        phone: '+1-781-684-4200',
        email: 'sales@bostondynamics.com',
        website: 'https://www.bostondynamics.com',
        rating: 5,
        specialties: ['Spot Robots', 'Atlas Humanoids', 'Industrial Robotics'],
        contractValue: '$5.4M',
        status: 'Active'
      }
    ]
  };

  const currentVendors = vendors[selectedRegion as keyof typeof vendors];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-orange-900 to-red-900 border-orange-500/30">
        <CardHeader>
          <CardTitle className="text-orange-300 flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Complete International Vendors List
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="europe" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="europe" onClick={() => setSelectedRegion('europe')}>
                Europe
              </TabsTrigger>
              <TabsTrigger value="asia" onClick={() => setSelectedRegion('asia')}>
                Asia Pacific
              </TabsTrigger>
              <TabsTrigger value="americas" onClick={() => setSelectedRegion('americas')}>
                Americas
              </TabsTrigger>
            </TabsList>

            <TabsContent value={selectedRegion} className="space-y-4">
              <div className="grid gap-4">
                {currentVendors.map((vendor) => (
                  <Card key={vendor.id} className="bg-gray-800 border-orange-500/30">
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-4">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center">
                              <Building2 className="h-6 w-6 text-white" />
                            </div>
                            <div>
                              <h3 className="text-orange-300 font-bold text-lg">{vendor.name}</h3>
                              <p className="text-gray-400 text-sm">{vendor.type}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className="bg-green-600">{vendor.status}</Badge>
                            <div className="flex items-center gap-1">
                              {[...Array(vendor.rating)].map((_, i) => (
                                <Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex items-start gap-2">
                            <MapPin className="h-4 w-4 text-blue-400 mt-1" />
                            <div>
                              <p className="text-white font-semibold">{vendor.country}</p>
                              <p className="text-gray-400 text-sm">{vendor.address}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-green-400" />
                            <p className="text-gray-300 text-sm">{vendor.phone}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-purple-400" />
                            <p className="text-gray-300 text-sm">{vendor.email}</p>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div>
                            <h4 className="text-white font-semibold mb-2">Specialties</h4>
                            <div className="space-y-1">
                              {vendor.specialties.map((specialty, index) => (
                                <Badge key={index} variant="outline" className="mr-1 mb-1 border-orange-400 text-orange-300">
                                  {specialty}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="bg-gray-900/50 p-3 rounded-lg">
                            <p className="text-gray-400 text-sm">Contract Value</p>
                            <p className="text-green-400 font-bold text-lg">{vendor.contractValue}</p>
                          </div>
                          <div className="space-y-2">
                            <Button 
                              className="w-full bg-orange-600 hover:bg-orange-700"
                              onClick={() => window.open(vendor.website, '_blank')}
                            >
                              <Globe className="h-4 w-4 mr-2" />
                              Visit Website
                            </Button>
                            <Button variant="outline" className="w-full border-blue-500 text-blue-300">
                              <Mail className="h-4 w-4 mr-2" />
                              Contact Vendor
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          <Card className="bg-gray-800 border-yellow-500/30 mt-6">
            <CardHeader>
              <CardTitle className="text-yellow-300">Vendor Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-yellow-800/20 p-4 rounded-lg">
                  <h4 className="text-yellow-300 font-semibold">Total Vendors</h4>
                  <p className="text-2xl font-bold text-white">
                    {Object.values(vendors).flat().length}
                  </p>
                  <p className="text-sm text-gray-400">Active partnerships</p>
                </div>
                <div className="bg-green-800/20 p-4 rounded-lg">
                  <h4 className="text-green-300 font-semibold">Total Value</h4>
                  <p className="text-2xl font-bold text-white">$32.4M</p>
                  <p className="text-sm text-gray-400">Combined contracts</p>
                </div>
                <div className="bg-blue-800/20 p-4 rounded-lg">
                  <h4 className="text-blue-300 font-semibold">Regions</h4>
                  <p className="text-2xl font-bold text-white">3</p>
                  <p className="text-sm text-gray-400">Global coverage</p>
                </div>
                <div className="bg-purple-800/20 p-4 rounded-lg">
                  <h4 className="text-purple-300 font-semibold">Avg Rating</h4>
                  <p className="text-2xl font-bold text-white">4.8</p>
                  <p className="text-sm text-gray-400">Vendor quality</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
};

export default InternationalVendorsList;