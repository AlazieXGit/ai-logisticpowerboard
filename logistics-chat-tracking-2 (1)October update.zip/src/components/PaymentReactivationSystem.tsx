import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, Ban, Shield, AlertTriangle, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const PaymentReactivationSystem: React.FC = () => {
  const [reactivating, setReactivating] = useState(false);
  const [systemStatus, setSystemStatus] = useState({
    vendorPayments: 'suspended',
    employeeDeposits: 'suspended',
    contractorPayments: 'suspended',
    superAdminAccess: 'active'
  });
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  const suspendedAccounts = [
    { name: 'John Smith', type: 'Employee', status: 'PERMANENTLY_SUSPENDED', reason: 'Fraud Alert' },
  ];

  const reactivatableEntities = [
    { name: 'Jane Contractor', type: 'Contractor', status: 'suspended' },
    { name: 'ABC Vendor Corp', type: 'Vendor', status: 'suspended' },
    { name: 'All Other Employees', type: 'Employee Group', status: 'suspended' },
    { name: 'All Other Vendors', type: 'Vendor Group', status: 'suspended' },
    { name: 'All Other Contractors', type: 'Contractor Group', status: 'suspended' }
  ];

  useEffect(() => {
    const checkAdminStatus = () => {
      const adminStatus = localStorage.getItem('superAdminAuth');
      setIsSuperAdmin(adminStatus === 'authenticated');
    };
    checkAdminStatus();
  }, []);

  const reactivatePayments = async () => {
    if (!isSuperAdmin) {
      alert('Super Admin access required');
      return;
    }

    setReactivating(true);
    try {
      const { data } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'reactivate_payments',
          data: {
            exclude_suspended: ['john_smith'],
            reactivate_all_others: true
          }
        }
      });

      setSystemStatus({
        vendorPayments: 'active',
        employeeDeposits: 'active',
        contractorPayments: 'active',
        superAdminAccess: 'active'
      });

      alert('✅ Payment system reactivated for all non-suspended accounts!');
    } catch (error) {
      console.error('Reactivation error:', error);
      alert('❌ Reactivation failed');
    }
    setReactivating(false);
  };

  if (!isSuperAdmin) {
    return (
      <Alert className="border-red-500 bg-red-900/20">
        <Ban className="h-4 w-4" />
        <AlertDescription className="text-red-400 font-semibold">
          🚫 Super Admin access required to manage payment reactivation
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Alert className="border-emerald-500 bg-emerald-900/20">
        <Shield className="h-4 w-4" />
        <AlertDescription className="text-emerald-400 font-semibold">
          🔐 Payment Reactivation Control - Super Admin Mode
        </AlertDescription>
      </Alert>

      <Card className="bg-gradient-to-r from-emerald-600 to-blue-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Payment System Reactivation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-white/90">
              Reactivate payment system for all accounts except permanently suspended ones.
            </p>
            <Button
              onClick={reactivatePayments}
              disabled={reactivating}
              className="w-full bg-white text-emerald-600 hover:bg-gray-100"
            >
              {reactivating ? 'Reactivating...' : '🔄 Reactivate All Non-Suspended Payments'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className={systemStatus.vendorPayments === 'active' ? 'bg-emerald-900/20 border-emerald-500/50' : 'bg-red-900/20 border-red-500/50'}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${systemStatus.vendorPayments === 'active' ? 'text-emerald-400' : 'text-red-400'}`}>
              {systemStatus.vendorPayments === 'active' ? <CheckCircle className="h-5 w-5" /> : <Ban className="h-5 w-5" />}
              Payment System Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Vendor Payments</span>
                <Badge className={systemStatus.vendorPayments === 'active' ? 'bg-emerald-600' : 'bg-red-600'}>
                  {systemStatus.vendorPayments.toUpperCase()}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Employee Deposits</span>
                <Badge className={systemStatus.employeeDeposits === 'active' ? 'bg-emerald-600' : 'bg-red-600'}>
                  {systemStatus.employeeDeposits.toUpperCase()}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Contractor Payments</span>
                <Badge className={systemStatus.contractorPayments === 'active' ? 'bg-emerald-600' : 'bg-red-600'}>
                  {systemStatus.contractorPayments.toUpperCase()}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-900/20 border-red-500/50">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Ban className="h-5 w-5" />
              Permanently Suspended
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {suspendedAccounts.map((account, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-red-950/30 rounded border border-red-500/30">
                  <div>
                    <div className="font-semibold text-white">{account.name}</div>
                    <div className="text-sm text-gray-400">{account.type} • {account.reason}</div>
                  </div>
                  <Badge className="bg-red-600">
                    EXCLUDED
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-emerald-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Reactivated Entities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {reactivatableEntities.map((entity, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-emerald-950/30 rounded border border-emerald-500/30">
                <div>
                  <div className="font-semibold text-white">{entity.name}</div>
                  <div className="text-sm text-gray-400">{entity.type}</div>
                </div>
                <Badge className={systemStatus.vendorPayments === 'active' ? 'bg-emerald-600' : 'bg-yellow-600'}>
                  {systemStatus.vendorPayments === 'active' ? 'REACTIVATED' : 'READY'}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentReactivationSystem;