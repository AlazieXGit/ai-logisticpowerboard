import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, DollarSign, ArrowRight, Eye } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface DepositTransaction {
  id: string;
  amount: number;
  account_number: string;
  routing_number: string;
  transaction_type: string;
  status: string;
  created_at: string;
  description?: string;
  bank_name?: string;
}

export const ComprehensiveDepositMonitor = () => {
  const [deposits, setDeposits] = useState<DepositTransaction[]>([]);
  const [revenueTotal, setRevenueTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  const pncAccounts = {
    "5563935267": { name: "PNC Virtual Primary", balance: "$2,847,592.45", type: "Primary Operating" },
    "5563935275": { name: "PNC Reserve Account", balance: "$1,456,789.23", type: "Reserve Fund" },
    "5563935283": { name: "PNC Growth Account", balance: "Auto-Updated", type: "AI ALAZIE Revenue" }
  };

  const wellsFargoAccount = {
    accountNumber: "4567891234",
    routingNumber: "121000248",
    name: "Wells Fargo Trial Deposits",
    balance: "$1,234.56"
  };

  useEffect(() => {
    fetchDeposits();
    const interval = setInterval(fetchDeposits, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchDeposits = async () => {
    try {
      const { data, error } = await supabase
        .from('banking_transactions')
        .select('*')
        .eq('transaction_type', 'incoming')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setDeposits(data || []);
      
      const total = data?.reduce((sum, deposit) => sum + deposit.amount, 0) || 0;
      setRevenueTotal(total);
    } catch (error) {
      console.error('Error fetching deposits:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      <Tabs defaultValue="deposits" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="deposits" className="text-white">
            <div className="flex items-center gap-2 bg-orange-500 px-3 py-1 rounded-lg">
              <AlertTriangle className="h-4 w-4" />
              Live Deposits
            </div>
          </TabsTrigger>
          <TabsTrigger value="accounts" className="text-white">Account Details</TabsTrigger>
          <TabsTrigger value="revenue" className="text-white">Revenue Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="deposits" className="space-y-4">
          <Card className="bg-orange-500/20 border-orange-500">
            <CardHeader>
              <CardTitle className="text-orange-300 flex items-center gap-2">
                <Eye className="h-5 w-5" />
                SENSITIVE: Complete Deposit Monitoring
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {loading ? (
                <div className="text-white">Loading deposits...</div>
              ) : deposits.length === 0 ? (
                <div className="text-gray-400">No deposits detected</div>
              ) : (
                deposits.map((deposit) => (
                  <div key={deposit.id} className="bg-gray-800 p-4 rounded-lg border border-orange-500">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <Badge className="bg-green-500 text-white mb-2">
                          DEPOSIT DETECTED
                        </Badge>
                        <h3 className="text-white font-bold text-lg">
                          ${deposit.amount.toFixed(2)}
                        </h3>
                      </div>
                      <div className="text-right text-sm text-gray-300">
                        {new Date(deposit.created_at).toLocaleString()}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">Account:</span>
                        <span className="text-white ml-2 font-mono">{deposit.account_number}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Routing:</span>
                        <span className="text-white ml-2 font-mono">{deposit.routing_number}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Status:</span>
                        <Badge variant="secondary" className="ml-2">{deposit.status}</Badge>
                      </div>
                      <div>
                        <span className="text-gray-400">Type:</span>
                        <span className="text-white ml-2">{deposit.transaction_type}</span>
                      </div>
                    </div>
                    
                    {deposit.description && (
                      <div className="mt-3 p-2 bg-gray-700 rounded">
                        <span className="text-gray-400">Description:</span>
                        <span className="text-white ml-2">{deposit.description}</span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <div className="grid gap-4">
            <Card className="bg-blue-500/20 border-blue-500">
              <CardHeader>
                <CardTitle className="text-blue-300">PNC Virtual Accounts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(pncAccounts).map(([accountNum, details]) => (
                  <div key={accountNum} className="bg-gray-800 p-3 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-white font-medium">{details.name}</h4>
                      <span className="text-green-400 font-bold">{details.balance}</span>
                    </div>
                    <div className="text-sm text-gray-300">
                      <div>Account: {accountNum} | Routing: 054000030</div>
                      <div>Type: {details.type}</div>
                      <div>Password: gotchupin1976</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-green-500/20 border-green-500">
              <CardHeader>
                <CardTitle className="text-green-300">Wells Fargo Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-800 p-3 rounded-lg">
                  <h4 className="text-white font-medium mb-2">{wellsFargoAccount.name}</h4>
                  <div className="text-sm text-gray-300 space-y-1">
                    <div>Account: {wellsFargoAccount.accountNumber}</div>
                    <div>Routing: {wellsFargoAccount.routingNumber}</div>
                    <div>Balance: {wellsFargoAccount.balance}</div>
                    <div>Status: Active - Trial Deposit Monitoring</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card className="bg-purple-500/20 border-purple-500">
            <CardHeader>
              <CardTitle className="text-purple-300 flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                AI ALAZIE XPRESS Revenue Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <div className="text-3xl font-bold text-green-400">
                  ${revenueTotal.toFixed(2)}
                </div>
                <div className="text-gray-400">Total Revenue Today</div>
              </div>
              
              <div className="bg-gray-800 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white">Revenue Routing</span>
                  <ArrowRight className="h-4 w-4 text-orange-400" />
                </div>
                <div className="text-sm text-gray-300">
                  <div>Destination: PNC Growth Account (5563935283)</div>
                  <div>Routing: 054000030</div>
                  <div>API Endpoint: /api/payment-routing/combined-total</div>
                  <div>Auto-Processing: ACTIVE</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};