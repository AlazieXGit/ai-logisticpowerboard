import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SuperAIParalegalPlatform } from './SuperAIParalegalPlatform';
import { TaxReturnAuditingAssistant } from './TaxReturnAuditingAssistant';
import { VirtualCheckingSystem } from './VirtualCheckingSystem';

export const CompletePlatformPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
      <div className="container mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-white mb-4">
            AI ALAZIE XPRESS COMPLETE PLATFORM
          </h1>
          <p className="text-xl text-gray-300">
            Super AI Paralegal • Tax Return Assistant • Virtual Banking • Synthetic AI Integration
          </p>
        </div>

        <Tabs defaultValue="paralegal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-black/20">
            <TabsTrigger value="paralegal" className="data-[state=active]:bg-purple-600">
              Super AI Paralegal
            </TabsTrigger>
            <TabsTrigger value="tax" className="data-[state=active]:bg-blue-600">
              Tax Return Assistant
            </TabsTrigger>
            <TabsTrigger value="banking" className="data-[state=active]:bg-green-600">
              Virtual Banking
            </TabsTrigger>
          </TabsList>

          <TabsContent value="paralegal">
            <SuperAIParalegalPlatform />
          </TabsContent>

          <TabsContent value="tax">
            <TaxReturnAuditingAssistant />
          </TabsContent>

          <TabsContent value="banking">
            <VirtualCheckingSystem />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};