import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowUpDown, Building2, CreditCard, Shield, Copy, Lock, DollarSign } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import TrustBankingVirtualAccount from './TrustBankingVirtualAccount';
import VirtualAccountManager from './VirtualAccountManager';
import EscrowAccountManager from './EscrowAccountManager';

interface BankingAccount {
  id: string;
  name: string;
  accountNumber: string;
  routingNumber: string;
  balance: number;
  type: 'main' | 'escrow' | 'trust' | 'virtual';
  status: 'active' | 'pending' | 'inactive';
  lastUpdated: string;
}

const UpdatedUnifiedBankingSystem: React.FC = () => {
  const [accounts, setAccounts] = useState<BankingAccount[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<string>('');
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [transactionType, setTransactionType] = useState<'deposit' | 'withdrawal' | 'transfer'>('deposit');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAllAccounts();
  }, []);

  const loadAllAccounts = async () => {
    try {
      const updatedAccounts: BankingAccount[] = [
        {
          id: 'alaziel-main-2024',
          name: 'Alaziel Banking - Main Operations',
          accountNumber: '5573-9012-4567-8901',
          routingNumber: '031176110',
          balance: 3247892.75,
          type: 'main',
          status: 'active',
          lastUpdated: new Date().toISOString()
        },
        {
          id: 'alaziel-trust-main-2024',
          name: 'Alaziel Trust Banking - Main Account',
          accountNumber: '4472-8901-3456-7890',
          routingNumber: '021000021',
          balance: 8750000.00,
          type: 'trust',
          status: 'active',
          lastUpdated: new Date().toISOString()
        },
        {
          id: 'alaziel-escrow-2024',
          name: 'Alaziel Escrow Services - Main Account',
          accountNumber: '5573-9012-4567-8901',
          routingNumber: '031176110',
          balance: 2450000.00,
          type: 'escrow',
          status: 'active',
          lastUpdated: new Date().toISOString()
        },
        {
          id: 'virtual-processing-001',
          name: 'Virtual Processing Account #1',
          accountNumber: '5573-9012-4567-9001',
          routingNumber: '031176110',
          balance: 185000.00,
          type: 'virtual',
          status: 'active',
          lastUpdated: new Date().toISOString()
        }
      ];
      setAccounts(updatedAccounts);
    } catch (error) {
      console.error('Error loading accounts:', error);
    }
  };

  const processTransaction = async () => {
    if (!selectedAccount || !amount || !recipient) {
      toast({ title: 'Error', description: 'Please fill all required fields', variant: 'destructive' });
      return;
    }

    setIsProcessing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({ 
        title: 'Transaction Complete', 
        description: `${transactionType.charAt(0).toUpperCase() + transactionType.slice(1)} of $${parseFloat(amount).toLocaleString()} processed successfully`,
        variant: 'default'
      });
      
      setAmount('');
      setRecipient('');
      await loadAllAccounts();
    } catch (error) {
      console.error('Transaction error:', error);
      toast({ title: 'Transaction Failed', description: 'Failed to process transaction', variant: 'destructive' });
    } finally {
      setIsProcessing(false);
    }
  };

  const copyAccountInfo = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: `${type} copied to clipboard` });
  };

  const getAccountIcon = (type: string) => {
    switch (type) {
      case 'main': return <Building2 className="h-4 w-4" />;
      case 'escrow': return <Shield className="h-4 w-4" />;
      case 'trust': return <CreditCard className="h-4 w-4" />;
      case 'virtual': return <DollarSign className="h-4 w-4" />;
      default: return <Building2 className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Alaziel Banking - Unified System (Updated)
            <Lock className="h-4 w-4 text-red-400" />
            <Badge className="bg-green-600">LIVE</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-emerald-300 text-sm">
            All accounts updated with current information • Trust banking and escrow services active • Legal compliance enabled
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="accounts" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="accounts" className="data-[state=active]:bg-emerald-600">
            All Accounts
          </TabsTrigger>
          <TabsTrigger value="trust" className="data-[state=active]:bg-blue-600">
            Trust Banking
          </TabsTrigger>
          <TabsTrigger value="escrow" className="data-[state=active]:bg-purple-600">
            Escrow Services
          </TabsTrigger>
          <TabsTrigger value="virtual" className="data-[state=active]:bg-orange-600">
            Virtual Accounts
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="accounts" className="space-y-6">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <ArrowUpDown className="h-5 w-5" />
                Updated Transaction System
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-emerald-300">Select Account</Label>
                  <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                    <SelectTrigger className="bg-gray-700 border-emerald-500/30">
                      <SelectValue placeholder="Choose account" />
                    </SelectTrigger>
                    <SelectContent>
                      {accounts.map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} - ${account.balance.toLocaleString()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-emerald-300">Amount ($)</Label>
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="bg-gray-700 border-emerald-500/30 text-white"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-emerald-300">Recipient</Label>
                  <Input
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    placeholder="Enter recipient"
                    className="bg-gray-700 border-emerald-500/30 text-white"
                  />
                </div>
              </div>

              <Button 
                onClick={processTransaction} 
                disabled={isProcessing}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
              >
                {isProcessing ? 'Processing...' : 'Process Transaction'}
              </Button>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {accounts.map((account) => (
              <Card key={account.id} className="bg-gray-800 border-emerald-500/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-emerald-400 text-sm flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getAccountIcon(account.type)}
                      {account.type.toUpperCase()}
                    </div>
                    <Badge className="bg-green-600 text-xs">ALAZIEL</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="text-white font-medium text-sm">{account.name}</div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300 text-xs">Account:</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => copyAccountInfo(account.accountNumber, 'Account number')}
                        className="text-emerald-400 hover:bg-emerald-900/20 p-1 h-auto"
                      >
                        <span className="text-xs font-mono">{account.accountNumber}</span>
                        <Copy className="h-2 w-2 ml-1" />
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300 text-xs">Balance:</span>
                      <span className="text-emerald-400 font-bold text-sm">
                        ${account.balance.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="trust" className="space-y-4">
          <TrustBankingVirtualAccount />
        </TabsContent>
        
        <TabsContent value="escrow" className="space-y-4">
          <EscrowAccountManager />
        </TabsContent>
        
        <TabsContent value="virtual" className="space-y-4">
          <VirtualAccountManager />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UpdatedUnifiedBankingSystem;