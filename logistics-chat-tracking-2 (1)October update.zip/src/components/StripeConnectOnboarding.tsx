import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { CheckCircle, Upload, AlertCircle } from 'lucide-react'
import { StripeConnectService } from '@/services/StripeConnectService'

export default function StripeConnectOnboarding() {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    account_type: 'carrier' as 'carrier' | 'vendor' | 'contractor',
    business_name: '',
    business_type: 'individual' as 'individual' | 'company',
    email: '',
    country: 'US',
  })
  const [stripeAccountId, setStripeAccountId] = useState('')

  const handleCreateAccount = async () => {
    setLoading(true)
    setError('')
    try {
      const result = await StripeConnectService.createConnectAccount(formData)
      setStripeAccountId(result.account.stripe_account_id)
      setStep(2)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleStartOnboarding = async () => {
    setLoading(true)
    try {
      const returnUrl = `${window.location.origin}/connect-onboarding-complete`
      const result = await StripeConnectService.createOnboardingLink(stripeAccountId, returnUrl)
      window.location.href = result.url
    } catch (err: any) {
      setError(err.message)
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle>Stripe Connect Onboarding</CardTitle>
          <CardDescription>Set up your account to receive direct payouts</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label>Account Type</Label>
                <Select value={formData.account_type} onValueChange={(v: any) => setFormData({ ...formData, account_type: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="carrier">Carrier</SelectItem>
                    <SelectItem value="vendor">Vendor</SelectItem>
                    <SelectItem value="contractor">Contractor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Business Name</Label>
                <Input value={formData.business_name} onChange={(e) => setFormData({ ...formData, business_name: e.target.value })} />
              </div>

              <div>
                <Label>Business Type</Label>
                <Select value={formData.business_type} onValueChange={(v: any) => setFormData({ ...formData, business_type: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="individual">Individual</SelectItem>
                    <SelectItem value="company">Company</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Email</Label>
                <Input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
              </div>

              <Button onClick={handleCreateAccount} disabled={loading} className="w-full">
                {loading ? 'Creating Account...' : 'Continue'}
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4 text-center">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
              <h3 className="text-xl font-semibold">Account Created!</h3>
              <p className="text-muted-foreground">Complete identity verification and bank account linking with Stripe</p>
              <Button onClick={handleStartOnboarding} disabled={loading} className="w-full">
                {loading ? 'Redirecting...' : 'Complete Onboarding'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
