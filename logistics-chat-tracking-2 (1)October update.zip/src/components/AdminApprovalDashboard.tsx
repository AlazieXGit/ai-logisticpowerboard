import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/lib/supabase';
import { CheckCircle, XCircle, Clock, AlertTriangle, FileText, DollarSign, CheckSquare } from 'lucide-react';
import { AccountReviewModal } from './AccountReviewModal';
import { DocumentReviewModal } from './DocumentReviewModal';
import { ManualPayoutModal } from './ManualPayoutModal';
import { BulkActionsModal } from './BulkActionsModal';
import { ApprovalFilters } from './ApprovalFilters';

interface FilterState {
  search: string;
  dateFrom: Date | undefined;
  dateTo: Date | undefined;
  businessType: string;
  priority: string;
  status: string;
  accountType: string;
}

export function AdminApprovalDashboard() {
  const [pendingApprovals, setPendingApprovals] = useState<any[]>([]);
  const [filteredApprovals, setFilteredApprovals] = useState<any[]>([]);
  const [pendingDocuments, setPendingDocuments] = useState<any[]>([]);
  const [filteredDocuments, setFilteredDocuments] = useState<any[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<any>(null);
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);
  const [selectedDocs, setSelectedDocs] = useState<string[]>([]);
  const [bulkModal, setBulkModal] = useState<{ open: boolean; action: any; type: string }>({ open: false, action: null, type: '' });
  const [currentFilters, setCurrentFilters] = useState<FilterState>({
    search: '',
    dateFrom: undefined,
    dateTo: undefined,
    businessType: 'all',
    priority: 'all',
    status: 'all',
    accountType: 'all',
  });


  useEffect(() => {
    loadPendingItems();
    const interval = setInterval(loadPendingItems, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    applyFilters();
  }, [pendingApprovals, pendingDocuments, currentFilters]);

  const loadPendingItems = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'get_pending_approvals',
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });

      if (error) throw error;
      setPendingApprovals(data.approvals || []);

      const { data: docs } = await supabase
        .from('compliance_documents')
        .select('*, stripe_connect_accounts(email, business_type)')
        .eq('verification_status', 'pending');
      
      setPendingDocuments(docs || []);
    } catch (error) {
      console.error('Error loading pending items:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...pendingApprovals];
    
    if (currentFilters.search) {
      filtered = filtered.filter(a => 
        a.stripe_connect_accounts?.email?.toLowerCase().includes(currentFilters.search.toLowerCase())
      );
    }
    
    if (currentFilters.businessType !== 'all') {
      filtered = filtered.filter(a => a.stripe_connect_accounts?.business_type === currentFilters.businessType);
    }
    
    if (currentFilters.priority !== 'all') {
      filtered = filtered.filter(a => a.priority === currentFilters.priority);
    }
    
    if (currentFilters.status !== 'all') {
      filtered = filtered.filter(a => a.status === currentFilters.status);
    }
    
    if (currentFilters.dateFrom) {
      filtered = filtered.filter(a => new Date(a.requested_at) >= currentFilters.dateFrom!);
    }
    
    if (currentFilters.dateTo) {
      filtered = filtered.filter(a => new Date(a.requested_at) <= currentFilters.dateTo!);
    }
    
    setFilteredApprovals(filtered);
    
    let filteredDocs = [...pendingDocuments];
    if (currentFilters.search) {
      filteredDocs = filteredDocs.filter(d => 
        d.file_name?.toLowerCase().includes(currentFilters.search.toLowerCase()) ||
        d.stripe_connect_accounts?.email?.toLowerCase().includes(currentFilters.search.toLowerCase())
      );
    }
    setFilteredDocuments(filteredDocs);
  };

  const handleFilterChange = (filters: FilterState) => {
    setCurrentFilters(filters);
  };

  const handleExport = async (filters: FilterState) => {
    const dataToExport = filteredApprovals.map(a => ({
      email: a.stripe_connect_accounts?.email,
      businessType: a.stripe_connect_accounts?.business_type,
      priority: a.priority,
      status: a.status,
      requestType: a.request_type,
      requestedAt: new Date(a.requested_at).toLocaleString(),
    }));
    
    const csv = [
      ['Email', 'Business Type', 'Priority', 'Status', 'Request Type', 'Requested At'],
      ...dataToExport.map(d => [d.email, d.businessType, d.priority, d.status, d.requestType, d.requestedAt])
    ].map(row => row.join(',')).join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `approval-export-${new Date().toISOString()}.csv`;
    a.click();
  };


  const handleBulkAction = async (action: string, data: any) => {
    const body = action === 'approve' 
      ? { action: 'bulk_approve_accounts', data: { accountIds: selectedAccounts, notes: data.notes }, adminId: 'admin', adminEmail: 'admin@ai.com' }
      : { action: 'bulk_reject_accounts', data: { accountIds: selectedAccounts, reason: data.notes }, adminId: 'admin', adminEmail: 'admin@ai.com' };
    
    const result = await supabase.functions.invoke('admin-approval-operations', { body });
    await loadPendingItems();
    setSelectedAccounts([]);
    return result.data;
  };

  const getPriorityColor = (priority: string) => {
    const colors = {
      urgent: 'bg-red-500',
      high: 'bg-orange-500',
      normal: 'bg-blue-500',
      low: 'bg-gray-500'
    };
    return colors[priority as keyof typeof colors] || colors.normal;
  };


  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Admin Approval Center</h1>
        <Button onClick={() => setShowPayoutModal(true)} className="bg-green-600">
          <DollarSign className="w-4 h-4 mr-2" />
          Manual Payout
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Pending Accounts</p>
                <p className="text-2xl font-bold">{pendingApprovals.length}</p>
              </div>
              <Clock className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Pending Documents</p>
                <p className="text-2xl font-bold">{pendingDocuments.length}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>


      <ApprovalFilters 
        onFilterChange={handleFilterChange}
        onExport={handleExport}
      />

      <Tabs defaultValue="accounts" className="space-y-4">
        <TabsList>
          <TabsTrigger value="accounts">
            Pending Accounts ({filteredApprovals.length}/{pendingApprovals.length})
          </TabsTrigger>
          <TabsTrigger value="documents">
            Pending Documents ({filteredDocuments.length}/{pendingDocuments.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="space-y-4">
          {selectedAccounts.length > 0 && (
            <div className="flex gap-2 p-4 bg-blue-50 rounded-lg">
              <Button size="sm" onClick={() => setBulkModal({ open: true, action: 'approve', type: 'accounts' })} className="bg-green-600">
                <CheckCircle className="w-4 h-4 mr-2" />Approve {selectedAccounts.length}
              </Button>
              <Button size="sm" variant="destructive" onClick={() => setBulkModal({ open: true, action: 'reject', type: 'accounts' })}>
                <XCircle className="w-4 h-4 mr-2" />Reject {selectedAccounts.length}
              </Button>
              <Button size="sm" variant="outline" onClick={() => setSelectedAccounts([])}>Clear</Button>
            </div>
          )}

          {filteredApprovals.map((approval) => (

            <Card key={approval.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Checkbox 
                    checked={selectedAccounts.includes(approval.account_id)}
                    onCheckedChange={(checked) => {
                      setSelectedAccounts(checked 
                        ? [...selectedAccounts, approval.account_id]
                        : selectedAccounts.filter(id => id !== approval.account_id)
                      );
                    }}
                  />
                   <div className="flex items-center justify-between flex-1">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-lg">
                          {approval.stripe_connect_accounts?.email}
                        </h3>
                        <Badge className={getPriorityColor(approval.priority)}>
                          {approval.priority}
                        </Badge>
                        <Badge variant="outline">{approval.request_type}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        Business Type: {approval.stripe_connect_accounts?.business_type || 'N/A'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Requested: {new Date(approval.requested_at).toLocaleString()}
                      </p>
                    </div>
                    <Button onClick={() => setSelectedAccount(approval)}>
                      Review Account
                    </Button>
                   </div>
                 </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>


        <TabsContent value="documents" className="space-y-4">
          {filteredDocuments.map((doc) => (

            <Card key={doc.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <FileText className="w-5 h-5 text-blue-500" />
                      <h3 className="font-semibold">{doc.file_name}</h3>
                      <Badge>{doc.document_type}</Badge>
                    </div>
                    <p className="text-sm text-gray-600">
                      Account: {doc.stripe_connect_accounts?.email}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Uploaded: {new Date(doc.uploaded_at).toLocaleString()}
                    </p>
                  </div>
                  <Button onClick={() => setSelectedDocument(doc)} variant="outline">
                    Review Document
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      {selectedAccount && (
        <AccountReviewModal
          approval={selectedAccount}
          onClose={() => {
            setSelectedAccount(null);
            loadPendingItems();
          }}
        />
      )}

      {selectedDocument && (
        <DocumentReviewModal
          document={selectedDocument}
          onClose={() => {
            setSelectedDocument(null);
            loadPendingItems();
          }}
        />
      )}
      {showPayoutModal && (
        <ManualPayoutModal onClose={() => setShowPayoutModal(false)} />
      )}

      <BulkActionsModal
        open={bulkModal.open}
        onClose={() => setBulkModal({ open: false, action: null, type: '' })}
        action={bulkModal.action}
        selectedIds={selectedAccounts}
        onConfirm={handleBulkAction}
        title={`Bulk ${bulkModal.action === 'approve' ? 'Approve' : 'Reject'} Accounts`}
      />
    </div>
  );
}
