import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeftRight, Building2, CreditCard, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface BankingAccount {
  id: string;
  name: string;
  accountNumber: string;
  balance: number;
  type: 'main' | 'escrow' | 'trust';
  status: 'active' | 'pending' | 'inactive';
}

const AccountTransferSystem: React.FC = () => {
  const [accounts, setAccounts] = useState<BankingAccount[]>([]);
  const [fromAccount, setFromAccount] = useState<string>('');
  const [toAccount, setToAccount] = useState<string>('');
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAccounts();
  }, []);

  const loadAccounts = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_all_accounts' }
      });
      
      if (error) throw error;
      setAccounts(data.accounts || []);
    } catch (error) {
      console.error('Error loading accounts:', error);
    }
  };

  const processTransfer = async () => {
    if (!fromAccount || !toAccount || !amount) {
      toast({ title: 'Error', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    if (fromAccount === toAccount) {
      toast({ title: 'Error', description: 'Cannot transfer to same account', variant: 'destructive' });
      return;
    }

    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'process_account_transfer',
          fromAccountId: fromAccount,
          toAccountId: toAccount,
          amount: parseFloat(amount)
        }
      });

      if (error) throw error;
      
      toast({ 
        title: 'Success', 
        description: `Transfer of $${amount} completed successfully` 
      });
      
      setAmount('');
      setFromAccount('');
      setToAccount('');
      loadAccounts();
    } catch (error) {
      toast({ title: 'Error', description: 'Transfer failed', variant: 'destructive' });
    } finally {
      setIsProcessing(false);
    }
  };

  const getAccountIcon = (type: string) => {
    switch (type) {
      case 'main': return <Building2 className="h-4 w-4" />;
      case 'escrow': return <Shield className="h-4 w-4" />;
      case 'trust': return <CreditCard className="h-4 w-4" />;
      default: return <Building2 className="h-4 w-4" />;
    }
  };

  const activeAccounts = accounts.filter(acc => acc.status === 'active');

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <ArrowLeftRight className="h-5 w-5" />
            ACCOUNTS ONLY TRANSFER - Alaziel Banking System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-emerald-300">From Account</Label>
              <Select value={fromAccount} onValueChange={setFromAccount}>
                <SelectTrigger className="bg-gray-700 border-emerald-500/30">
                  <SelectValue placeholder="Select source account" />
                </SelectTrigger>
                <SelectContent>
                  {activeAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      <div className="flex items-center gap-2">
                        {getAccountIcon(account.type)}
                        {account.name} - ${account.balance.toLocaleString()}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-emerald-300">To Account</Label>
              <Select value={toAccount} onValueChange={setToAccount}>
                <SelectTrigger className="bg-gray-700 border-emerald-500/30">
                  <SelectValue placeholder="Select destination account" />
                </SelectTrigger>
                <SelectContent>
                  {activeAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      <div className="flex items-center gap-2">
                        {getAccountIcon(account.type)}
                        {account.name} - ${account.balance.toLocaleString()}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-emerald-300">Transfer Amount ($)</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter transfer amount"
              className="bg-gray-700 border-emerald-500/30 text-white"
            />
          </div>

          <Button 
            onClick={processTransfer} 
            disabled={isProcessing || !fromAccount || !toAccount || !amount}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-lg py-3"
          >
            {isProcessing ? 'Processing Transfer...' : 'ACCOUNTS ONLY TRANSFER'}
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {activeAccounts.map((account) => (
          <Card key={account.id} className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getAccountIcon(account.type)}
                  {account.name}
                </div>
                <Badge className="bg-green-600">
                  {account.type.toUpperCase()}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-300">Account #:</span>
                  <span className="text-emerald-400">{account.accountNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Balance:</span>
                  <span className="text-emerald-400 font-bold">
                    ${account.balance.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Status:</span>
                  <Badge className="bg-green-600">{account.status}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AccountTransferSystem;