import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BarChart3, DollarSign, Percent, TrendingUp, Clock, Activity } from 'lucide-react';

interface AnalyticsData {
  totalTransactions: number;
  platformFees: number;
  aiAutoBookingFees: number;
  adminFees: number;
  processFees: number;
  aiGenFees: number;
  liveVolume: number;
  loadCount: number;
}

const TMSAnalytics = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalTransactions: 0,
    platformFees: 0,
    aiAutoBookingFees: 0,
    adminFees: 0,
    processFees: 0,
    aiGenFees: 0,
    liveVolume: 0,
    loadCount: 0
  });

  const [realtimeRevenue, setRealtimeRevenue] = useState(0);

  useEffect(() => {
    // Simulate real-time analytics updates
    const interval = setInterval(() => {
      setAnalytics(prev => {
        const newTransaction = Math.random() * 5000 + 1000;
        const fees = {
          aiAutoBooking: newTransaction * 0.05,
          admin: newTransaction * 0.05,
          process: newTransaction * 0.05,
          aiGen: newTransaction * 0.05,
          platform: newTransaction * 0.05
        };
        
        const totalFees = Object.values(fees).reduce((sum, fee) => sum + fee, 0);
        
        return {
          totalTransactions: prev.totalTransactions + newTransaction,
          platformFees: prev.platformFees + fees.platform,
          aiAutoBookingFees: prev.aiAutoBookingFees + fees.aiAutoBooking,
          adminFees: prev.adminFees + fees.admin,
          processFees: prev.processFees + fees.process,
          aiGenFees: prev.aiGenFees + fees.aiGen,
          liveVolume: prev.liveVolume + newTransaction + totalFees,
          loadCount: prev.loadCount + 1
        };
      });
      
      setRealtimeRevenue(prev => prev + Math.random() * 500 + 100);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const totalFeeRevenue = analytics.platformFees + analytics.aiAutoBookingFees + 
    analytics.adminFees + analytics.processFees + analytics.aiGenFees;

  const feePercentage = analytics.totalTransactions > 0 ? 
    (totalFeeRevenue / analytics.totalTransactions) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Real-time Revenue Clock */}
      <Card className="bg-gradient-to-r from-emerald-800 to-teal-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Clock className="h-5 w-5 mr-2" />
            Real-Time Revenue Tracker
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <div className="text-4xl font-bold text-white mb-2">
              ${realtimeRevenue.toFixed(2)}
            </div>
            <div className="text-emerald-200">
              Live Revenue • {new Date().toLocaleTimeString()}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fee Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Percent className="h-4 w-4 mr-2" />
              AI Auto-Booking (5%)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">
              ${analytics.aiAutoBookingFees.toFixed(2)}
            </div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Percent className="h-4 w-4 mr-2" />
              Admin Fee (5%)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">
              ${analytics.adminFees.toFixed(2)}
            </div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Percent className="h-4 w-4 mr-2" />
              Process Fee (5%)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">
              ${analytics.processFees.toFixed(2)}
            </div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Percent className="h-4 w-4 mr-2" />
              AI Gen Fee (5%)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">
              ${analytics.aiGenFees.toFixed(2)}
            </div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Percent className="h-4 w-4 mr-2" />
              Platform Fee (5%)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">
              ${analytics.platformFees.toFixed(2)}
            </div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Transaction Analytics */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Transaction Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{analytics.loadCount}</div>
              <div className="text-gray-400 text-sm">Load Count</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-white">
                ${analytics.liveVolume.toFixed(0)}
              </div>
              <div className="text-gray-400 text-sm">Live Volume</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">
                {feePercentage.toFixed(1)}%
              </div>
              <div className="text-gray-400 text-sm">Total Fee %</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-teal-400">
                ${totalFeeRevenue.toFixed(2)}
              </div>
              <div className="text-gray-400 text-sm">Fee Revenue</div>
            </div>
          </div>
          
          <div className="mt-6 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Total Transactions</span>
              <Badge className="bg-emerald-600">
                ${analytics.totalTransactions.toFixed(2)}
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Platform Fee Revenue (25% total)</span>
              <Badge className="bg-teal-600">
                ${totalFeeRevenue.toFixed(2)}
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Average Transaction</span>
              <Badge className="bg-cyan-600">
                ${analytics.loadCount > 0 ? (analytics.totalTransactions / analytics.loadCount).toFixed(2) : '0.00'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TMSAnalytics;