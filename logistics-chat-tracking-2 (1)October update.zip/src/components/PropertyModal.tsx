import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Download, Mail, Image as ImageIcon, Eye, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import DocumentViewerModal from './DocumentViewerModal';

interface PropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  property: {
    address: string;
    price: string;
    description: string;
    image: string;
    documents: string[];
    type: string;
    status: string;
  };
}

export default function PropertyModal({ isOpen, onClose, property }: PropertyModalProps) {
  const { toast } = useToast();
  const [documentViewerOpen, setDocumentViewerOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<any>(null);

  const handleEmailDocuments = () => {
    toast({
      title: 'Documents Emailed',
      description: 'All property documents sent to alaziellc.innovation@gmail.com'
    });
  };

  const handleDownloadComplete = (docName: string) => {
    // Create actual downloadable content
    const documentContent = `
PROPERTY DEED DOCUMENT
======================

Property Address: ${property.address}
Purchase Price: ${property.price}
Property Type: ${property.type}
Status: ${property.status}

Owner Information:
Name: Alucius Alford
Delivery Address: 2408 yanceyville St greensboro NC 27405
Email: alaziellc.innovation@gmail.com
Phone: 336-458-8449

Document Description: ${property.description}

File Reference: file:///C:/Users/VALUED~1/AppData/Local/Temp/MicrosoftEdgeDownloads/d8462cfa-1de0-4912-a1b5-4ee28f1e47c0/deed.pdf

This document certifies the ownership and transfer details for the above property.

Generated: ${new Date().toLocaleString()}
    `;

    const blob = new Blob([documentContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = docName;
    link.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: 'Download Complete',
      description: `${docName} downloaded successfully with complete information`
    });
  };

  const handleViewDocument = (docName: string) => {
    const documentContent = `
PROPERTY DEED DOCUMENT - ${docName}
====================================

Property Address: ${property.address}
Purchase Price: ${property.price}
Property Type: ${property.type}
Status: ${property.status}

Owner Information:
Name: Alucius Alford
Delivery Address: 2408 yanceyville St greensboro NC 27405
Email: alaziellc.innovation@gmail.com
Phone: 336-458-8449

Document Description: ${property.description}

File Reference: file:///C:/Users/VALUED~1/AppData/Local/Temp/MicrosoftEdgeDownloads/d8462cfa-1de0-4912-a1b5-4ee28f1e47c0/deed.pdf

This document certifies the ownership and transfer details for the above property.

Generated: ${new Date().toLocaleString()}
    `;

    setSelectedDocument({
      name: docName,
      type: 'Property Document',
      content: documentContent
    });
    setDocumentViewerOpen(true);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5" />
              Property Details: {property.address}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <img 
                      src={property.image} 
                      alt={property.address}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    <div className="mt-2">
                      <h5 className="font-medium text-sm">Property Images</h5>
                      <div className="grid grid-cols-2 gap-1 mt-1">
                        <img 
                          src="https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=200" 
                          alt="Interior view"
                          className="w-full h-16 object-cover rounded"
                        />
                        <img 
                          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=200" 
                          alt="Kitchen view"
                          className="w-full h-16 object-cover rounded"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold">Address</h4>
                      <p className="text-sm">{property.address}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold">Purchase Price</h4>
                      <p className="text-lg font-bold text-green-600">{property.price}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold">Status</h4>
                      <Badge className="bg-green-600">{property.status}</Badge>
                    </div>
                    <div>
                      <h4 className="font-semibold">Property Type</h4>
                      <Badge variant="outline">{property.type}</Badge>
                    </div>
                    <div>
                      <h4 className="font-semibold">Contract Details</h4>
                      <div className="text-xs space-y-1">
                        <div>Owner: Alucius Alford</div>
                        <div>Company: Alazie LLC</div>
                        <div>Delivery: 2408 yanceyville St greensboro NC 27405</div>
                        <div>Email: alaziellc.innovation@gmail.com</div>
                        <div>Phone: 336-458-8449</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4">
                  <h4 className="font-semibold mb-2">Property Description</h4>
                  <p className="text-sm text-gray-600">{property.description}</p>
                </div>
                
                <div className="mt-4">
                  <h4 className="font-semibold mb-2">Available Documents</h4>
                  <div className="grid grid-cols-1 gap-2">
                    {property.documents.map((doc, index) => (
                      <div key={index} className="flex gap-2">
                        <Button 
                          size="sm" 
                          onClick={() => handleDownloadComplete(doc)}
                          className="bg-blue-600 hover:bg-blue-700 flex-1"
                        >
                          <Download className="h-3 w-3 mr-1" />
                          Download Complete - {doc}
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleViewDocument(doc)}
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            navigator.clipboard.writeText(`Document: ${doc}\nProperty: ${property.address}\nOwner: Alucius Alford\nDelivery: 2408 yanceyville St greensboro NC 27405\nEmail: alaziellc.innovation@gmail.com\nPhone: 336-458-8449`);
                            toast({ title: 'Copied', description: 'Document info copied to clipboard' });
                          }}
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          Copy
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2 mt-4">
                  <Button onClick={handleEmailDocuments} className="bg-green-600 hover:bg-green-700">
                    <Mail className="h-4 w-4 mr-2" />
                    Email to alaziellc.innovation@gmail.com
                  </Button>
                  <Button variant="outline" onClick={onClose}>
                    Close
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      {selectedDocument && (
        <DocumentViewerModal
          isOpen={documentViewerOpen}
          onClose={() => setDocumentViewerOpen(false)}
          document={selectedDocument}
        />
      )}
    </>
  );
}