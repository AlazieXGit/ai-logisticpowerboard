import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, Users, Truck, Database, Scan } from 'lucide-react';
import AutoBookingPanel from './AutoBookingPanel';
import OnboardingSystem from './OnboardingSystem';
import SecurityBackupSystem from './SecurityBackupSystem';
import LoadboardIntegration from './LoadboardIntegration';
import TMSAnalytics from './TMSAnalytics';
import TMSRevenue from './TMSRevenue';

const EnhancedTMSSystem = () => {
  const [activeTab, setActiveTab] = useState('auto-booking');

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 text-xl">
            🚛 State-of-Art TMS - Super Admin Only
          </CardTitle>
          <p className="text-gray-400 text-sm">
            Complete Transportation Management System with AI Auto-Booking, Onboarding, Security & Analytics
          </p>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-6 bg-gray-700">
              <TabsTrigger value="auto-booking" className="text-white flex items-center gap-2">
                <Truck className="h-4 w-4" />
                Auto Booking
              </TabsTrigger>
              <TabsTrigger value="onboarding" className="text-white flex items-center gap-2">
                <Users className="h-4 w-4" />
                Onboarding
              </TabsTrigger>
              <TabsTrigger value="loadboard" className="text-white flex items-center gap-2">
                <Database className="h-4 w-4" />
                Loadboard
              </TabsTrigger>
              <TabsTrigger value="security" className="text-white flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Security
              </TabsTrigger>
              <TabsTrigger value="analytics" className="text-white flex items-center gap-2">
                <Scan className="h-4 w-4" />
                Analytics
              </TabsTrigger>
              <TabsTrigger value="revenue" className="text-white flex items-center gap-2">
                💰
                Revenue
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="auto-booking" className="mt-6">
              <AutoBookingPanel />
            </TabsContent>
            
            <TabsContent value="onboarding" className="mt-6">
              <OnboardingSystem />
            </TabsContent>
            
            <TabsContent value="loadboard" className="mt-6">
              <LoadboardIntegration />
            </TabsContent>
            
            <TabsContent value="security" className="mt-6">
              <SecurityBackupSystem />
            </TabsContent>
            
            <TabsContent value="analytics" className="mt-6">
              <TMSAnalytics />
            </TabsContent>
            
            <TabsContent value="revenue" className="mt-6">
              <TMSRevenue />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedTMSSystem;