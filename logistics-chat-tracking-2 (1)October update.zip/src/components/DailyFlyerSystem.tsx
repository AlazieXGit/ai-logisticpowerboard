import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, FileText, Send, Users, TrendingUp } from 'lucide-react';

export const DailyFlyerSystem: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [flyersGenerated, setFlyersGenerated] = useState(0);
  const [campaignsActive, setCampaignsActive] = useState(12);

  useEffect(() => {
    const interval = setInterval(() => {
      setFlyersGenerated(prev => prev + Math.floor(Math.random() * 5));
      setCampaignsActive(prev => prev + Math.floor(Math.random() * 3));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const dailyFlyers = [
    { title: 'Automotive Purchase Special', audience: '50K+', status: 'Active', reach: '95%' },
    { title: 'Real Estate Investment Alert', audience: '35K+', status: 'Active', reach: '87%' },
    { title: 'Banking Services Promotion', audience: '75K+', status: 'Active', reach: '92%' },
    { title: 'TMS Load Board Premium', audience: '25K+', status: 'Active', reach: '89%' },
    { title: 'AI Platform Integration', audience: '40K+', status: 'Active', reach: '94%' }
  ];

  const socialPlatforms = [
    'Facebook', 'Instagram', 'Twitter', 'LinkedIn', 'TikTok', 'YouTube',
    'TV Stations', 'Radio Networks', 'Business Networks', 'Industry Platforms'
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-indigo-900 to-purple-900 border-indigo-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="h-6 w-6" />
            Daily Flyer & Campaign Generator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-black/40 border-green-500">
              <CardContent className="p-4 text-center">
                <Calendar className="h-8 w-8 text-green-400 mx-auto mb-2" />
                <div className="text-xl font-bold text-green-400">{flyersGenerated}</div>
                <div className="text-sm text-gray-300">Flyers Generated Today</div>
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-blue-500">
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <div className="text-xl font-bold text-blue-400">{campaignsActive}</div>
                <div className="text-sm text-gray-300">Active Campaigns</div>
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-purple-500">
              <CardContent className="p-4 text-center">
                <TrendingUp className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                <div className="text-xl font-bold text-purple-400">2.5M+</div>
                <div className="text-sm text-gray-300">Daily Reach</div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <h3 className="text-white font-semibold">Today's Active Flyers</h3>
            {dailyFlyers.map((flyer, index) => (
              <Card key={index} className="bg-gray-800/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-white font-medium">{flyer.title}</div>
                      <div className="text-sm text-gray-300">Audience: {flyer.audience}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-green-600">{flyer.status}</Badge>
                      <Badge variant="outline" className="text-blue-400">
                        {flyer.reach} Reach
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="space-y-4">
            <h3 className="text-white font-semibold">Distribution Platforms</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
              {socialPlatforms.map((platform, index) => (
                <Badge key={index} className="bg-blue-600 text-white p-2 text-center">
                  {platform}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            <Button className="flex-1 bg-gradient-to-r from-green-600 to-blue-600">
              <Send className="h-4 w-4 mr-2" />
              Generate New Campaign
            </Button>
            <Button className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600">
              <FileText className="h-4 w-4 mr-2" />
              Create Daily Flyer
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};