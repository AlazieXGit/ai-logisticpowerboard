import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  FileText, DollarSign, TrendingUp, TrendingDown, Download, 
  Calendar, BarChart3, PieChart, Database, Activity, Shield,
  CreditCard, Building2, Truck, Bot, Heart, Users, Settings
} from 'lucide-react';

interface ComprehensiveData {
  date: string;
  totalRevenue: number;
  gains: number;
  losses: number;
  payments: number;
  netIncome: number;
  platforms: {
    [key: string]: {
      revenue: number;
      fees: number;
      transactions: number;
      status: string;
    };
  };
  aiServices: {
    [key: string]: {
      revenue: number;
      usage: number;
      efficiency: number;
    };
  };
  creditRepair: {
    totalClients: number;
    revenue: number;
    successRate: number;
    activeDisputes: number;
  };
  bankingServices: {
    totalAccounts: number;
    totalDeposits: number;
    totalWithdrawals: number;
    fees: number;
  };
}

const EnhancedComprehensiveDataPrintouts: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [comprehensiveData, setComprehensiveData] = useState<ComprehensiveData | null>(null);

  const mockComprehensiveData: ComprehensiveData = {
    date: selectedDate,
    totalRevenue: 485750.50,
    gains: 125200.25,
    losses: 18950.75,
    payments: 289500.00,
    netIncome: 466799.75,
    platforms: {
      'TMS System': { revenue: 85000, fees: 4250, transactions: 345, status: 'Active' },
      'Banking Services': { revenue: 142500, fees: 7125, transactions: 189, status: 'Active' },
      'Load Board AI': { revenue: 68750, fees: 3437.50, transactions: 534, status: 'Active' },
      'AI Agent System': { revenue: 45200, fees: 2260, transactions: 167, status: 'Active' },
      'Payment Processing': { revenue: 39800, fees: 1990, transactions: 456, status: 'Active' },
      'Synergy Platform': { revenue: 24500.50, fees: 1225, transactions: 145, status: 'Active' },
      'Credit Repair': { revenue: 35000, fees: 1750, transactions: 89, status: 'Active' },
      'Medical AI': { revenue: 28000, fees: 1400, transactions: 67, status: 'Active' },
      'Developer Platform': { revenue: 17000, fees: 850, transactions: 78, status: 'Active' }
    },
    aiServices: {
      'AI Banking Assistant': { revenue: 15000, usage: 2340, efficiency: 94.5 },
      'AI Code Generator': { revenue: 12500, usage: 1890, efficiency: 92.1 },
      'AI Medical System': { revenue: 18000, usage: 1456, efficiency: 96.2 },
      'AI Task Scheduler': { revenue: 8500, usage: 3200, efficiency: 89.7 }
    },
    creditRepair: {
      totalClients: 245,
      revenue: 35000,
      successRate: 87.3,
      activeDisputes: 156
    },
    bankingServices: {
      totalAccounts: 1247,
      totalDeposits: 2450000,
      totalWithdrawals: 1890000,
      fees: 24500
    }
  };

  const accountBreakdown = [
    { account: 'Primary Revenue Account', balance: 545750.50, type: 'Checking', routing: '021000021' },
    { account: 'Trust Account', balance: 289500.25, type: 'Trust', routing: '121000248' },
    { account: 'Escrow Account', balance: 425000.00, type: 'Escrow', routing: '021000021' },
    { account: 'Operating Account', balance: 167890.75, type: 'Business', routing: '121000248' },
    { account: 'Reserve Account', balance: 356000.00, type: 'Savings', routing: '021000021' },
    { account: 'AI Services Account', balance: 125000.00, type: 'Business', routing: '121000248' },
    { account: 'Credit Repair Account', balance: 89000.00, type: 'Business', routing: '021000021' }
  ];

  useEffect(() => {
    setComprehensiveData(mockComprehensiveData);
  }, [selectedDate]);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border-blue-500">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl text-blue-400 flex items-center gap-2">
                <Database className="h-6 w-6" />
                Enhanced Complete Data Printouts
              </CardTitle>
              <p className="text-gray-300">Comprehensive system analytics & revenue tracking</p>
            </div>
            <div className="flex gap-2">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-gray-700 text-white px-3 py-2 rounded border border-gray-600"
              />
              <Button className="bg-green-600 hover:bg-green-700">
                <Download className="h-4 w-4 mr-2" />
                Export All Data
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-8 bg-gray-800">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="platforms">All Platforms</TabsTrigger>
          <TabsTrigger value="ai-services">AI Services</TabsTrigger>
          <TabsTrigger value="credit-repair">Credit Repair</TabsTrigger>
          <TabsTrigger value="banking">Banking</TabsTrigger>
          <TabsTrigger value="accounts">Accounts</TabsTrigger>
          <TabsTrigger value="fees">Fees & Charges</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {comprehensiveData && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-green-900/20 border-green-500">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-400 text-sm">Total System Revenue</p>
                      <p className="text-2xl font-bold text-white">
                        ${comprehensiveData.totalRevenue.toLocaleString()}
                      </p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-blue-900/20 border-blue-500">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-400 text-sm">Net Income</p>
                      <p className="text-2xl font-bold text-white">
                        ${comprehensiveData.netIncome.toLocaleString()}
                      </p>
                    </div>
                    <DollarSign className="h-8 w-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-purple-900/20 border-purple-500">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-400 text-sm">Active Platforms</p>
                      <p className="text-2xl font-bold text-white">
                        {Object.keys(comprehensiveData.platforms).length}
                      </p>
                    </div>
                    <Building2 className="h-8 w-8 text-purple-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-orange-900/20 border-orange-500">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-orange-400 text-sm">Total Accounts</p>
                      <p className="text-2xl font-bold text-white">
                        {comprehensiveData.bankingServices.totalAccounts}
                      </p>
                    </div>
                    <Users className="h-8 w-8 text-orange-400" />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedComprehensiveDataPrintouts;