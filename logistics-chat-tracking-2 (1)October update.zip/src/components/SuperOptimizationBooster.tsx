import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Zap, Rocket, Activity, Timer } from 'lucide-react';

export const SuperOptimizationBooster: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [performanceMultiplier, setPerformanceMultiplier] = useState(1);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isActive && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            setIsActive(false);
            setPerformanceMultiplier(1);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isActive, timeRemaining]);

  const activateBooster = () => {
    setIsActive(true);
    setTimeRemaining(3600); // 1 hour in seconds
    setPerformanceMultiplier(100 * 700 + 3 * 99); // 70,297x multiplier
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-orange-900 to-red-900 border-orange-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Rocket className="h-6 w-6" />
            Super Optimization Booster
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {isActive && (
            <Alert className="border-orange-500 bg-orange-900/20">
              <Zap className="h-4 w-4" />
              <AlertDescription className="text-orange-300">
                SUPER BOOSTER ACTIVE - {performanceMultiplier.toLocaleString()}x PERFORMANCE MULTIPLIER
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-black/40 border-yellow-500">
              <CardContent className="p-4">
                <div className="text-center">
                  <Activity className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-yellow-400">
                    {isActive ? `${performanceMultiplier.toLocaleString()}x` : '1x'}
                  </div>
                  <div className="text-sm text-gray-300">Performance Boost</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-green-500">
              <CardContent className="p-4">
                <div className="text-center">
                  <Timer className="h-8 w-8 text-green-400 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-green-400">
                    {isActive ? formatTime(timeRemaining) : '00:00:00'}
                  </div>
                  <div className="text-sm text-gray-300">Time Remaining</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {isActive && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-300">
                <span>Boost Progress</span>
                <span>{Math.round(((3600 - timeRemaining) / 3600) * 100)}%</span>
              </div>
              <Progress value={((3600 - timeRemaining) / 3600) * 100} className="h-3" />
            </div>
          )}

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-gray-300">Revenue Boost:</div>
              <div className="text-green-400 font-bold">+{isActive ? '70,000' : '0'}%</div>
              
              <div className="text-gray-300">Processing Speed:</div>
              <div className="text-blue-400 font-bold">{isActive ? '800x800' : '1x1'}</div>
              
              <div className="text-gray-300">Efficiency Rate:</div>
              <div className="text-purple-400 font-bold">{isActive ? '1000x' : '1x'}</div>
              
              <div className="text-gray-300">System Clarity:</div>
              <div className="text-yellow-400 font-bold">{isActive ? 'MAXIMUM' : 'NORMAL'}</div>
            </div>

            <Button
              onClick={activateBooster}
              disabled={isActive}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
            >
              {isActive ? 'BOOSTER ACTIVE' : 'ACTIVATE SUPER BOOSTER (1 HOUR)'}
            </Button>

            <div className="text-center">
              <Badge className="bg-red-600 text-white px-4 py-2">
                100x700+3x99 PERFORMANCE MULTIPLIER
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};