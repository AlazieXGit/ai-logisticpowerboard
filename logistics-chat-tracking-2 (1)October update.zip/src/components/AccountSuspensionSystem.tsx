import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, CheckCircle, XCircle, Ban, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Account {
  id: string;
  name: string;
  type: 'employee' | 'contractor' | 'vendor';
  email: string;
  accountNumber: string;
  routingNumber: string;
  status: 'active' | 'suspended';
  suspendedAt?: string;
  fraudAlert?: boolean;
}

const AccountSuspensionSystem = () => {
  const { toast } = useToast();
  const [accounts, setAccounts] = useState<Account[]>([
    {
      id: '1',
      name: 'John Smith',
      type: 'employee',
      email: 'john@company.com',
      accountNumber: '****1234',
      routingNumber: '021000021',
      status: 'suspended',
      suspendedAt: new Date().toISOString(),
      fraudAlert: true
    },
    {
      id: '2',
      name: 'Jane Contractor',
      type: 'contractor',
      email: 'jane@contractor.com',
      accountNumber: '****5678',
      routingNumber: '021000022',
      status: 'active'
    },
    {
      id: '3',
      name: 'ABC Vendor Corp',
      type: 'vendor',
      email: 'billing@abcvendor.com',
      accountNumber: '****9012',
      routingNumber: '021000023',
      status: 'active'
    }
  ]);

  const suspendAccount = (accountId: string) => {
    const suspendedAt = new Date().toISOString();
    setAccounts(prev => prev.map(acc => 
      acc.id === accountId ? { ...acc, status: 'suspended', suspendedAt } : acc
    ));
    
    const suspendedAccount = accounts.find(acc => acc.id === accountId);
    if (suspendedAccount) {
      toast({
        title: "🚨 ACCOUNT PERMANENTLY SUSPENDED",
        description: `${suspendedAccount.name} has been IRREVERSIBLY suspended and REJECTED from platform infrastructure.`,
        variant: "destructive"
      });
    }
  };

  const suspendAllAccounts = () => {
    const activeAccounts = accounts.filter(acc => acc.status === 'active');
    const suspendedAt = new Date().toISOString();
    
    setAccounts(prev => prev.map(acc => 
      acc.status === 'active' ? { ...acc, status: 'suspended', suspendedAt } : acc
    ));
    
    toast({
      title: "🚨 ALL ACCOUNTS PERMANENTLY SUSPENDED",
      description: `${activeAccounts.length} accounts IRREVERSIBLY suspended and REJECTED from platform.`,
      variant: "destructive"
    });
  };

  const activeAccounts = accounts.filter(acc => acc.status === 'active');
  const suspendedAccounts = accounts.filter(acc => acc.status === 'suspended');

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-red-600">🚨 ACCOUNT SUSPENSION SYSTEM</h1>
          <p className="text-sm text-red-500 font-medium">⚠️ WARNING: All suspensions are IRREVERSIBLE and PERMANENT</p>
        </div>
        <Button 
          onClick={suspendAllAccounts}
          variant="destructive"
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700"
          disabled={activeAccounts.length === 0}
        >
          <AlertTriangle className="w-4 h-4" />
          🚨 SUSPEND ALL ({activeAccounts.length})
        </Button>
      </div>

      <Tabs defaultValue="suspended" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active" className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            Active Accounts ({activeAccounts.length})
          </TabsTrigger>
          <TabsTrigger 
            value="suspended" 
            className="flex items-center gap-2 bg-red-100 text-red-700 border-2 border-red-300 data-[state=active]:bg-red-200 data-[state=active]:text-red-800 font-bold"
          >
            <Ban className="w-4 h-4" />
            🚫 SUSPENDED - REJECTED ({suspendedAccounts.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="suspended">
          <Card className="border-red-300 border-2">
            <CardHeader className="bg-red-100 border-b-2 border-red-300">
              <CardTitle className="flex items-center gap-2 text-red-800">
                <Ban className="w-6 h-6 text-red-600" />
                🚫 SUSPENDED & REJECTED ACCOUNTS ({suspendedAccounts.length})
              </CardTitle>
              <p className="text-sm text-red-700 font-bold">⚠️ PERMANENTLY SUSPENDED - REJECTED FROM PLATFORM INFRASTRUCTURE</p>
            </CardHeader>
            <CardContent className="bg-red-50">
              <div className="space-y-4 mt-4">
                {suspendedAccounts.map(account => (
                  <div key={account.id} className="p-4 border-2 rounded-lg bg-red-100 border-red-400">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Ban className="w-6 h-6 text-red-700" />
                        <h3 className="font-bold text-red-900 text-lg">{account.name}</h3>
                        <Badge variant="destructive" className="bg-red-600">{account.type}</Badge>
                        <Badge className="bg-red-700 text-white border-red-800">🚫 SUSPENDED</Badge>
                        {account.fraudAlert && (
                          <Badge className="bg-orange-600 text-white animate-pulse">
                            <Shield className="w-3 h-3 mr-1" />
                            FRAUD ALERT
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-700 font-medium">{account.email}</p>
                      <p className="text-sm text-gray-600">{account.accountNumber} • {account.routingNumber}</p>
                      <div className="mt-3 p-2 bg-red-200 rounded border border-red-400">
                        <p className="text-xs text-red-800 font-bold">
                          🚨 SUSPENDED: {account.suspendedAt ? new Date(account.suspendedAt).toLocaleString() : 'Unknown'}
                        </p>
                        <p className="text-xs text-red-700 font-bold mt-1">
                          STATUS: PERMANENTLY REJECTED FROM PLATFORM INFRASTRUCTURE
                        </p>
                        <p className="text-xs text-red-600 font-bold mt-1">
                          ⚠️ ALL EMPLOYMENT & ASSOCIATIONS SUSPENDED INDEFINITELY
                        </p>
                        {account.fraudAlert && (
                          <p className="text-xs text-orange-700 font-bold mt-1">
                            🛡️ FRAUD ALERT: POTENTIAL FRAUDULENT ACTIVITY DETECTED
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                {suspendedAccounts.length === 0 && (
                  <div className="text-center py-8">
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <p className="text-gray-500">No suspended accounts</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                Active Accounts ({activeAccounts.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeAccounts.map(account => (
                  <div key={account.id} className="flex items-center justify-between p-4 border rounded-lg bg-green-50">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold">{account.name}</h3>
                        <Badge variant={account.type === 'employee' ? 'default' : account.type === 'contractor' ? 'secondary' : 'outline'}>
                          {account.type}
                        </Badge>
                        <Badge variant="outline" className="text-green-600 border-green-600">ACTIVE</Badge>
                      </div>
                      <p className="text-sm text-gray-600">{account.email}</p>
                      <p className="text-sm text-gray-500">{account.accountNumber} • {account.routingNumber}</p>
                    </div>
                    <Button 
                      onClick={() => suspendAccount(account.id)}
                      variant="destructive"
                      size="sm"
                      className="ml-4 bg-red-600 hover:bg-red-700"
                    >
                      🚨 SUSPEND & REJECT
                    </Button>
                  </div>
                ))}
                {activeAccounts.length === 0 && (
                  <div className="text-center py-8">
                    <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                    <p className="text-red-600 font-bold">🚨 ALL ACCOUNTS SUSPENDED & REJECTED</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AccountSuspensionSystem;