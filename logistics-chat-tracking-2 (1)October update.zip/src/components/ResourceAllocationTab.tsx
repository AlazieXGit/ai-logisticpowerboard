import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { PieChart, BarChart3, Users, DollarSign, Cpu, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

const ResourceAllocationTab = () => {
  const budgetAllocation = [
    { category: 'Personnel', allocated: 1200000, spent: 1050000, percentage: 48 },
    { category: 'Technology', allocated: 600000, spent: 520000, percentage: 24 },
    { category: 'Marketing', allocated: 400000, spent: 380000, percentage: 16 },
    { category: 'Operations', allocated: 300000, spent: 275000, percentage: 12 }
  ];

  const humanResources = [
    { department: 'Engineering', allocated: 25, current: 23, utilization: 92 },
    { department: 'Sales', allocated: 15, current: 14, utilization: 93 },
    { department: 'Marketing', allocated: 10, current: 9, utilization: 90 },
    { department: 'Support', allocated: 8, current: 8, utilization: 100 },
    { department: 'Operations', allocated: 12, current: 11, utilization: 92 }
  ];

  const technologyResources = [
    { resource: 'Cloud Infrastructure', capacity: '100TB', used: '78TB', cost: '$12,400' },
    { resource: 'Software Licenses', capacity: '200 seats', used: '156 seats', cost: '$8,900' },
    { resource: 'Development Tools', capacity: 'Unlimited', used: '45 users', cost: '$5,600' },
    { resource: 'Analytics Platform', capacity: '1M events', used: '750K events', cost: '$3,200' }
  ];

  const resourceOptimization = [
    { area: 'Underutilized Assets', savings: '$45,000', status: 'identified', priority: 'high' },
    { area: 'Process Automation', savings: '$78,000', status: 'in-progress', priority: 'medium' },
    { area: 'Vendor Consolidation', savings: '$23,000', status: 'completed', priority: 'low' },
    { area: 'Energy Efficiency', savings: '$12,000', status: 'planned', priority: 'medium' }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Budget Allocation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {budgetAllocation.map((item, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{item.category}</span>
                    <span className="text-sm text-gray-600">
                      ${(item.spent / 1000).toFixed(0)}K / ${(item.allocated / 1000).toFixed(0)}K
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="bg-blue-600 h-3 rounded-full" 
                      style={{width: `${(item.spent / item.allocated) * 100}%`}}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-500">
                    {item.percentage}% of total budget
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Human Resources Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {humanResources.map((dept, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium">{dept.department}</div>
                    <div className="text-sm text-gray-600">
                      {dept.current}/{dept.allocated} positions
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{dept.utilization}%</div>
                    <div className="text-xs text-gray-500">utilization</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cpu className="h-5 w-5" />
            Technology Resources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {technologyResources.map((resource, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">{resource.resource}</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Usage:</span>
                    <span>{resource.used} / {resource.capacity}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Monthly Cost:</span>
                    <span className="font-semibold text-green-600">{resource.cost}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Resource Optimization Opportunities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {resourceOptimization.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  {item.status === 'completed' ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : item.priority === 'high' ? (
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                  ) : (
                    <Clock className="h-5 w-5 text-yellow-600" />
                  )}
                  <div>
                    <div className="font-medium">{item.area}</div>
                    <div className="text-sm text-gray-600 capitalize">
                      Status: {item.status} • Priority: {item.priority}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-green-600">{item.savings}</div>
                  <div className="text-xs text-gray-500">potential savings</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ResourceAllocationTab;