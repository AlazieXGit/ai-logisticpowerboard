import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, CreditCard, DollarSign, TrendingUp, Link, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { StripeConnectIntegration } from './StripeConnectIntegration';
import { supabase } from '@/lib/supabase';
import AlazielBankingConfig from './AlazielBankingConfig';
import VirtualAccountManager from './VirtualAccountManager';
import EnhancedRevenueTab from './EnhancedRevenueTab';

interface BankingAccount {
  id: string;
  name: string;
  accountNumber: string;
  routingNumber: string;
  swiftCode: string;
  balance: number;
  type: 'main' | 'escrow' | 'trust' | 'virtual' | 'innovation';
  status: 'active' | 'pending' | 'inactive' | 'deleted';
  hardCopy: boolean;
  virtualProcessing?: boolean;
  email?: string;
  password?: string;
}

const UnifiedBankingSystem: React.FC = () => {
  const [accounts, setAccounts] = useState<BankingAccount[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<string>('');
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [transactionType, setTransactionType] = useState<'deposit' | 'withdrawal'>('deposit');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAllAccounts();
  }, []);

  const loadAllAccounts = async () => {
    try {
      const bankingAccounts: BankingAccount[] = [
        {
          id: 'alaziel-innovation-banking-2024',
          name: 'Innovation Banking - banking@alaziellc_innovation.com',
          accountNumber: '5573-9012-4567-8901',
          routingNumber: '031176110',
          swiftCode: 'INNVUS33',
          balance: 3500000.00,
          type: 'innovation',
          status: 'active',
          hardCopy: true,
          virtualProcessing: true,
          email: 'banking@alaziellc_innovation.com',
          password: 'gotchu!'
        },
        {
          id: 'alaziel-banking-2024',
          name: 'Alaziel Banking - banking@alaziellc.com',
          accountNumber: '5573-9012-4567-8902',
          routingNumber: '031176110',
          swiftCode: 'ALAZUS33',
          balance: 1250000.00,
          type: 'escrow',
          status: 'active',
          hardCopy: true,
          virtualProcessing: true,
          email: 'banking@alaziellc.com',
          password: 'gotchu!!'
        }
      ];
      setAccounts(bankingAccounts);
    } catch (error) {
      console.error('Error loading accounts:', error);
    }
  };

  const processTransaction = async () => {
    if (!selectedAccount || !amount || !recipient) {
      toast({ title: 'Error', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    setIsProcessing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({ 
        title: 'Processing Complete', 
        description: `${transactionType === 'deposit' ? 'Deposit' : 'Withdrawal'} processed via Updated Banking` 
      });
      
      setAmount('');
      setRecipient('');
      loadAllAccounts();
    } catch (error) {
      toast({ title: 'Error', description: 'Transaction failed', variant: 'destructive' });
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: 'Account information copied' });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-red-950/20 border-red-500">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Trash2 className="h-5 w-5" />
            BANKING SYSTEM UPDATE STATUS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Badge className="bg-red-600 text-white">
              ❌ DELETED: banking@nukieson.com - REMOVED FROM ALL SYSTEMS
            </Badge>
            <Badge className="bg-blue-600 text-white">
              ✅ NEW: banking@alaziellc_innovation.com - ACTIVE WITH PASSWORD: gotchu!
            </Badge>
            <Badge className="bg-green-600 text-white">
              🔒 UPDATED: banking@alaziellc.com - PASSWORD CHANGED TO: gotchu!!
            </Badge>
          </div>
        </CardContent>
      </Card>
      
      <AlazielBankingConfig />
      
      <Tabs defaultValue="transactions" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="transactions" className="data-[state=active]:bg-emerald-600">
            Transactions
          </TabsTrigger>
          <TabsTrigger value="stripe-connect" className="data-[state=active]:bg-blue-600">
            Stripe Connect
          </TabsTrigger>
          <TabsTrigger value="virtual" className="data-[state=active]:bg-emerald-600">
            Virtual Accounts
          </TabsTrigger>
          <TabsTrigger value="revenue" className="data-[state=active]:bg-emerald-600">
            Revenue Data
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="transactions" className="space-y-6">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <ArrowUpDown className="h-5 w-5" />
                Updated Banking Transaction System
                <Badge className="bg-blue-600 text-white">INNOVATION BANKING</Badge>
                <Badge className="bg-red-600 text-white">SECURE</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-emerald-300">Select Account</Label>
                  <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                    <SelectTrigger className="bg-gray-700 border-emerald-500/30">
                      <SelectValue placeholder="Choose account" />
                    </SelectTrigger>
                    <SelectContent>
                      {accounts.map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} - {account.type.toUpperCase()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-emerald-300">Transaction Type</Label>
                  <Select value={transactionType} onValueChange={(value: 'deposit' | 'withdrawal') => setTransactionType(value)}>
                    <SelectTrigger className="bg-gray-700 border-emerald-500/30">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="deposit">Direct Deposit</SelectItem>
                      <SelectItem value="withdrawal">Withdrawal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-emerald-300">Amount ($)</Label>
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="bg-gray-700 border-emerald-500/30 text-white"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-emerald-300">
                    {transactionType === 'deposit' ? 'From (Source)' : 'To (Recipient)'}
                  </Label>
                  <Input
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    placeholder={transactionType === 'deposit' ? 'Payment source' : 'Recipient details'}
                    className="bg-gray-700 border-emerald-500/30 text-white"
                  />
                </div>
              </div>

              <Button 
                onClick={processTransaction} 
                disabled={isProcessing}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
              >
                {isProcessing ? 'Processing...' : `Process ${transactionType}`}
              </Button>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {accounts.map((account) => (
              <Card key={account.id} className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {account.type === 'innovation' && <Building2 className="h-4 w-4" />}
                      {account.type === 'escrow' && <Shield className="h-4 w-4" />}
                      {account.name}
                    </div>
                    <div className="flex gap-1">
                      <Badge className={
                        account.type === 'innovation' ? 'bg-blue-600' : 'bg-green-600'
                      }>
                        {account.type === 'innovation' ? 'INNOVATION' : 'ALAZIEL'}
                      </Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Email:</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => copyToClipboard(account.email || '')}
                        className="text-emerald-400 hover:bg-emerald-900/20"
                      >
                        {account.email} <Copy className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                    
                    {account.password && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Password:</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => copyToClipboard(account.password || '')}
                          className="text-emerald-400 hover:bg-emerald-900/20"
                        >
                          {account.password} <Copy className="h-3 w-3 ml-1" />
                        </Button>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Account:</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => copyToClipboard(account.accountNumber)}
                        className="text-emerald-400 hover:bg-emerald-900/20"
                      >
                        {account.accountNumber} <Copy className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Balance:</span>
                      <span className="text-emerald-400 font-bold">
                        ${account.balance.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="stripe-connect" className="space-y-4">
          <StripeConnectIntegration />
        </TabsContent>
        
        <TabsContent value="virtual" className="space-y-4">
          <VirtualAccountManager />
        </TabsContent>
        
        <TabsContent value="revenue" className="space-y-4">
          <EnhancedRevenueTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UnifiedBankingSystem;