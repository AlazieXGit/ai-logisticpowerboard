import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Ban, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import { blockIP, unblockIP, getBlockedIPs, type BlockedIP } from '@/services/adminOperationsService';
import { useToast } from '@/hooks/use-toast';

const EnhancedIPBlockingSystem: React.FC = () => {
  const [blockedIPs, setBlockedIPs] = useState<BlockedIP[]>([]);
  const [loading, setLoading] = useState(false);
  const [newIP, setNewIP] = useState('');
  const [reason, setReason] = useState('');
  const { toast } = useToast();

  const loadBlockedIPs = async () => {
    setLoading(true);
    try {
      const ips = await getBlockedIPs();
      setBlockedIPs(ips);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load blocked IPs",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBlockedIPs();
    const interval = setInterval(loadBlockedIPs, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleBlockIP = async () => {
    if (!newIP || !reason) {
      toast({
        title: "Validation Error",
        description: "IP address and reason are required",
        variant: "destructive"
      });
      return;
    }

    try {
      await blockIP(newIP, reason, 'Super Admin');
      toast({
        title: "Success",
        description: `IP ${newIP} has been blocked`,
      });
      setNewIP('');
      setReason('');
      loadBlockedIPs();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to block IP",
        variant: "destructive"
      });
    }
  };

  const handleUnblock = async (ipAddress: string) => {
    try {
      await unblockIP(ipAddress, 'Super Admin');
      toast({
        title: "Success",
        description: `IP ${ipAddress} has been unblocked`,
      });
      loadBlockedIPs();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to unblock IP",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900/80 border-blue-500">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Shield className="h-6 w-6" />
            IP Blocking System - Real-Time Control
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              placeholder="IP Address (e.g., 192.168.1.1)"
              value={newIP}
              onChange={(e) => setNewIP(e.target.value)}
              className="bg-gray-800 border-gray-600 text-white"
            />
            <Input
              placeholder="Reason for blocking"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="bg-gray-800 border-gray-600 text-white"
            />
            <Button onClick={handleBlockIP} className="bg-red-600 hover:bg-red-700">
              <Ban className="h-4 w-4 mr-2" />
              Block IP
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-black/80 border-red-500">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <AlertTriangle className="h-6 w-6" />
            Active Blocked IPs ({blockedIPs.length})
            {loading && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {blockedIPs.map((blocked) => (
              <div key={blocked.id} className="bg-red-900/20 p-4 rounded border border-red-500">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-red-300 font-mono text-lg">{blocked.ip_address}</p>
                    <p className="text-gray-400 text-sm">{blocked.reason}</p>
                    <p className="text-gray-500 text-xs">
                      Blocked: {new Date(blocked.blocked_at).toLocaleString()}
                    </p>
                    <p className="text-gray-500 text-xs">By: {blocked.blocked_by}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleUnblock(blocked.ip_address)}
                    className="border-green-500 text-green-400 hover:bg-green-900/20"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Unblock
                  </Button>
                </div>
              </div>
            ))}
            {blockedIPs.length === 0 && !loading && (
              <Alert className="border-gray-600 bg-gray-800/30">
                <AlertDescription className="text-gray-400">
                  No blocked IPs found
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedIPBlockingSystem;
