import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CreditCard, Building2, DollarSign, ArrowRight } from 'lucide-react';
import EnhancedStripePaymentSystem from './EnhancedStripePaymentSystem';
import AlazielBankingConfig from './AlazielBankingConfig';
import WellsFargoBankingTab from './WellsFargoBankingTab';

const UnifiedPaymentSystem: React.FC = () => {
  const [activePayments, setActivePayments] = useState(0);

  const processUnifiedPayment = () => {
    setActivePayments(prev => prev + 1);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-emerald-900/20 to-blue-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            UNIFIED PAYMENT & BANKING SYSTEM
            <Badge className="bg-emerald-600 text-white animate-pulse">INTEGRATED</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">{activePayments}</div>
              <div className="text-sm text-gray-300">Active Payments</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">3</div>
              <div className="text-sm text-gray-300">Bank Accounts</div>
            </div>
            <div className="text-center">
              <Button
                onClick={processUnifiedPayment}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                Process Payment <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="stripe" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="stripe" className="text-emerald-400">Stripe Integration</TabsTrigger>
          <TabsTrigger value="alaziel" className="text-blue-400">Alaziel Banking</TabsTrigger>
          <TabsTrigger value="wells" className="text-purple-400">Wells Fargo</TabsTrigger>
        </TabsList>
        
        <TabsContent value="stripe" className="mt-6">
          <EnhancedStripePaymentSystem />
        </TabsContent>
        
        <TabsContent value="alaziel" className="mt-6">
          <AlazielBankingConfig />
        </TabsContent>
        
        <TabsContent value="wells" className="mt-6">
          <WellsFargoBankingTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UnifiedPaymentSystem;