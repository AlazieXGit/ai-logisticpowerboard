import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Shield } from 'lucide-react';
import SpaceAnimation from './SpaceAnimation';
import NukieChatPanel from './NukieChatPanel';
import TrackingDashboard from './TrackingDashboard';
import LoadAnalysisPanel from './LoadAnalysisPanel';
import InsightsPanel from './InsightsPanel';
import SuperAdminAuth from './SuperAdminAuth';
import SuperAdminDashboard from './SuperAdminDashboard';

const DashboardLayout: React.FC = () => {
  const [contextData, setContextData] = useState<any>({});
  const [aiMode, setAiMode] = useState('qna');
  const [isOnline, setIsOnline] = useState(true);
  const [showSuperAdminAuth, setShowSuperAdminAuth] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  const handleLoadUpdate = (loads: any[]) => {
    setContextData((ctx: any) => ({ ...ctx, loads }));
  };

  const handleLocationUpdate = (location: any) => {
    setContextData((ctx: any) => ({ ...ctx, location }));
  };

  const handleSuperAdminAccess = () => {
    setShowSuperAdminAuth(true);
  };

  const handleSuperAdminAuth = (isAuthenticated: boolean) => {
    setIsSuperAdmin(isAuthenticated);
    if (isAuthenticated) {
      setShowSuperAdminAuth(false);
    }
  };

  const handleSuperAdminLogout = () => {
    setIsSuperAdmin(false);
    setShowSuperAdminAuth(false);
  };

  // Show super admin authentication
  if (showSuperAdminAuth && !isSuperAdmin) {
    return <SuperAdminAuth onAuthenticated={handleSuperAdminAuth} />;
  }

  // Show super admin dashboard with integrated banking
  if (isSuperAdmin) {
    return <SuperAdminDashboard onLogout={handleSuperAdminLogout} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 relative">
      <SpaceAnimation />
      
      {/* Header */}
      <div className="mb-6 relative z-10">
        <div className="flex items-center justify-between bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-4 border-2 border-blue-200">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              🚛 LoadBoard AI Dashboard
            </h1>
            <p className="text-gray-600 mt-1">Complete logistics management with AI automation</p>
          </div>
          <div className="flex items-center gap-4">
            <Button 
              onClick={handleSuperAdminAccess}
              className="bg-red-600 hover:bg-red-700 text-white"
              size="sm"
            >
              <Shield className="h-4 w-4 mr-2" />
              🏦 Super Admin
            </Button>
            <Badge className={`${isOnline ? 'bg-green-500' : 'bg-red-500'} text-white`}>
              {isOnline ? '🟢 ONLINE' : '🔴 OFFLINE'}
            </Badge>
            <div className="text-sm text-gray-500">
              {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>

      {/* Main Dashboard with Tabs */}
      <div className="relative z-10">
        <Tabs defaultValue="logistics" className="h-[calc(100vh-140px)]">
          <TabsList className="grid w-full grid-cols-2 mb-6 bg-white/90 backdrop-blur-sm">
            <TabsTrigger value="logistics">🚛 Logistics</TabsTrigger>
            <TabsTrigger value="chat">💬 AI Assistant</TabsTrigger>
          </TabsList>
          
          <TabsContent value="logistics">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-white/90 backdrop-blur-sm rounded-lg">
                  <LoadAnalysisPanel onUpdate={handleLoadUpdate} />
                </div>
                <div className="bg-white/90 backdrop-blur-sm rounded-lg">
                  <TrackingDashboard onUpdate={handleLocationUpdate} />
                </div>
                <div className="bg-white/90 backdrop-blur-sm rounded-lg">
                  <InsightsPanel context={contextData} />
                </div>
              </div>
              <div className="lg:col-span-2">
                <div className="bg-white/90 backdrop-blur-sm rounded-lg h-full">
                  <NukieChatPanel context={contextData} aiMode={aiMode} />
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="chat">
            <div className="h-full">
              <div className="mb-4">
                <Select value={aiMode} onValueChange={setAiMode}>
                  <SelectTrigger className="w-64 bg-white/90 backdrop-blur-sm">
                    <SelectValue placeholder="Select AI Mode" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="qna">💬 Q&A Mode</SelectItem>
                    <SelectItem value="routing">🗺️ Routing Mode</SelectItem>
                    <SelectItem value="automation">⚡ Automation Mode</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="bg-white/90 backdrop-blur-sm rounded-lg h-full">
                <NukieChatPanel context={contextData} aiMode={aiMode} />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default DashboardLayout;