import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Save, Download, Play, Copy } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AICodeEditorProps {
  generatedCode: string;
  projectType: 'app' | 'website';
  command: string;
}

const AICodeEditor: React.FC<AICodeEditorProps> = ({ generatedCode, projectType, command }) => {
  const [code, setCode] = useState(generatedCode);
  const [projectName, setProjectName] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveProject = async () => {
    if (!projectName.trim() || !code.trim()) return;
    
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('ai_dev_projects')
        .insert({
          project_name: projectName,
          project_type: projectType,
          command_prompt: command,
          generated_code: code,
          enhancement_level: 100,
          status: 'generated'
        });

      if (error) throw error;
      alert('Project saved successfully!');
    } catch (error) {
      console.error('Save error:', error);
      alert('Failed to save project');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    alert('Code copied to clipboard!');
  };

  const handleDownload = () => {
    const fileExtension = projectType === 'website' ? '.html' : '.tsx';
    const fileName = `${projectName || 'ai-generated-project'}${fileExtension}`;
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="bg-gray-900/50 border-gray-500/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-gray-300 flex items-center gap-2">
            AI Code Editor - {projectType.toUpperCase()}
            <Badge className="bg-purple-600">Enhanced 100x</Badge>
          </CardTitle>
          <div className="flex gap-2">
            <Button size="sm" onClick={handleCopyCode} className="bg-blue-600 hover:bg-blue-700">
              <Copy className="h-4 w-4 mr-1" />
              Copy
            </Button>
            <Button size="sm" onClick={handleDownload} className="bg-green-600 hover:bg-green-700">
              <Download className="h-4 w-4 mr-1" />
              Download
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Project name..."
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            className="bg-gray-800 border-gray-600 text-white"
          />
          <Button 
            onClick={handleSaveProject}
            disabled={isSaving || !projectName.trim()}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Save className="h-4 w-4 mr-1" />
            {isSaving ? 'Saving...' : 'Save'}
          </Button>
        </div>
        
        <Textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="min-h-[400px] bg-black border-gray-600 text-green-400 font-mono text-sm"
          placeholder="Generated code will appear here..."
        />
        
        <div className="flex justify-between items-center text-sm text-gray-400">
          <span>Command: {command}</span>
          <span>Lines: {code.split('\n').length}</span>
        </div>
      </CardContent>
    </Card>
  );
};

export default AICodeEditor;