import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { 
  Building2, Shield, DollarSign, CreditCard, 
  Banknote, ArrowRightLeft, Copy, CheckCircle
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface InternalAccount {
  id: string;
  name: string;
  accountNumber: string;
  routingNumber: string;
  balance: number;
  type: 'primary' | 'escrow' | 'trust' | 'operational';
  status: 'active' | 'restricted';
}

interface ExternalConnection {
  id: string;
  bankName: string;
  accountNumber: string;
  routingNumber: string;
  type: 'wire' | 'ach' | 'direct_deposit';
  status: 'connected' | 'pending' | 'failed';
}

const PrivateInternalBankingSystem: React.FC = () => {
  const [internalAccounts] = useState<InternalAccount[]>([
    {
      id: '1',
      name: 'XPRESS AI ALAZIE Primary',
      accountNumber: '4429876543210001',
      routingNumber: '021000021',
      balance: 5847592,
      type: 'primary',
      status: 'active'
    },
    {
      id: '2', 
      name: 'Trust Operations Account',
      accountNumber: '4429876543210002',
      routingNumber: '021000021',
      balance: 2234567,
      type: 'trust',
      status: 'active'
    },
    {
      id: '3',
      name: 'Escrow Holdings',
      accountNumber: '4429876543210003', 
      routingNumber: '021000021',
      balance: 1987654,
      type: 'escrow',
      status: 'active'
    }
  ]);

  const [externalConnections] = useState<ExternalConnection[]>([
    {
      id: '1',
      bankName: 'Wells Fargo Business',
      accountNumber: '1234567890123456',
      routingNumber: '121000248',
      type: 'wire',
      status: 'connected'
    },
    {
      id: '2',
      bankName: 'Chase Commercial',
      accountNumber: '9876543210987654',
      routingNumber: '021000021',
      type: 'ach',
      status: 'connected'
    },
    {
      id: '3',
      bankName: 'Bank of America Business',
      accountNumber: '5555444433332222',
      routingNumber: '111000025',
      type: 'direct_deposit',
      status: 'connected'
    }
  ]);

  const [totalBalance, setTotalBalance] = useState(0);

  useEffect(() => {
    const total = internalAccounts.reduce((sum, account) => sum + account.balance, 0);
    setTotalBalance(total);
  }, [internalAccounts]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            XPRESS AI ALAZIE Private Internal Banking System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <div className="text-2xl font-bold">${totalBalance.toLocaleString()}</div>
              <div className="text-blue-200">Total Internal Assets</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{internalAccounts.length}</div>
              <div className="text-blue-200">Internal Accounts</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{externalConnections.length}</div>
              <div className="text-blue-200">External Connections</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="internal" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="internal">Internal Accounts</TabsTrigger>
          <TabsTrigger value="external">External Connections</TabsTrigger>
          <TabsTrigger value="transfers">Payment Routing</TabsTrigger>
          <TabsTrigger value="cards">Card Systems</TabsTrigger>
        </TabsList>

        <TabsContent value="internal" className="space-y-4">
          {internalAccounts.map((account) => (
            <Card key={account.id} className="bg-gray-800/30 border-blue-500/30">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-blue-400">{account.name}</CardTitle>
                  <Badge className="bg-green-600">{account.status}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Account Number:</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono">{account.accountNumber}</span>
                        <Button size="sm" variant="ghost" onClick={() => copyToClipboard(account.accountNumber)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Routing Number:</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono">{account.routingNumber}</span>
                        <Button size="sm" variant="ghost" onClick={() => copyToClipboard(account.routingNumber)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Balance:</span>
                      <span className="text-white font-bold">${account.balance.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Type:</span>
                      <span className="text-blue-400 capitalize">{account.type}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="external" className="space-y-4">
          {externalConnections.map((connection) => (
            <Card key={connection.id} className="bg-gray-800/30 border-green-500/30">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-green-400">{connection.bankName}</CardTitle>
                  <Badge className={connection.status === 'connected' ? 'bg-green-600' : 'bg-yellow-600'}>
                    {connection.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">External Account:</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono">{connection.accountNumber}</span>
                        <Button size="sm" variant="ghost" onClick={() => copyToClipboard(connection.accountNumber)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">External Routing:</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono">{connection.routingNumber}</span>
                        <Button size="sm" variant="ghost" onClick={() => copyToClipboard(connection.routingNumber)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Transfer Type:</span>
                      <span className="text-green-400 uppercase">{connection.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Status:</span>
                      <CheckCircle className="h-5 w-5 text-green-400" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="transfers" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gray-800/30 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-purple-400 flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5" />
                  Wire Transfer Endpoints
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-purple-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">Incoming Wire Account:</div>
                    <div className="text-white font-mono">4429876543210001</div>
                    <div className="text-sm text-gray-300">Routing: 021000021</div>
                  </div>
                  <div className="p-3 bg-blue-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">Outgoing Wire Account:</div>
                    <div className="text-white font-mono">4429876543210002</div>
                    <div className="text-sm text-gray-300">Routing: 021000021</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-green-400 flex items-center gap-2">
                  <Banknote className="h-5 w-5" />
                  ACH & Direct Deposit
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-green-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">ACH Collection Account:</div>
                    <div className="text-white font-mono">4429876543210003</div>
                    <div className="text-sm text-gray-300">Routing: 021000021</div>
                  </div>
                  <div className="p-3 bg-orange-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">Direct Deposit Account:</div>
                    <div className="text-white font-mono">4429876543210001</div>
                    <div className="text-sm text-gray-300">Routing: 021000021</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cards" className="space-y-4">
          <Card className="bg-gray-800/30 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-yellow-400 flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Card Processing Endpoints
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="p-3 bg-red-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">Debit Card Processing:</div>
                    <div className="text-white font-mono">Merchant ID: XPRESS_ALAZIE_001</div>
                    <div className="text-sm text-gray-300">Settlement Account: 4429876543210001</div>
                  </div>
                  <div className="p-3 bg-blue-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">Credit Card Processing:</div>
                    <div className="text-white font-mono">Merchant ID: XPRESS_ALAZIE_002</div>
                    <div className="text-sm text-gray-300">Settlement Account: 4429876543210002</div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="p-3 bg-green-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">Processing Rate:</div>
                    <div className="text-white">2.9% + $0.30 per transaction</div>
                  </div>
                  <div className="p-3 bg-purple-900/20 rounded-lg">
                    <div className="text-sm text-gray-300">Settlement Time:</div>
                    <div className="text-white">1-2 Business Days</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PrivateInternalBankingSystem;