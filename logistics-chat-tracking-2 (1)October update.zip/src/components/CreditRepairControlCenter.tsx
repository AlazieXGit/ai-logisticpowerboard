import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, Zap, Monitor, Users, TrendingUp, AlertTriangle } from 'lucide-react';

export default function CreditRepairControlCenter() {
  const [optimizationLevel, setOptimizationLevel] = useState(800);
  const [assuranceLevel, setAssuranceLevel] = useState(200);
  const [activeClients, setActiveClients] = useState(47);
  const [avgScoreIncrease, setAvgScoreIncrease] = useState(127);

  const [realTimeUpdates, setRealTimeUpdates] = useState([
    { client: 'John D.', score: 642, change: +12, time: '2 min ago' },
    { client: 'Sarah M.', score: 698, change: +8, time: '5 min ago' },
    { client: 'Mike R.', score: 721, change: +15, time: '7 min ago' },
    { client: 'Lisa K.', score: 589, change: +22, time: '12 min ago' }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeUpdates(prev => prev.map(update => ({
        ...update,
        score: update.score + Math.floor(Math.random() * 3),
        change: update.change + Math.floor(Math.random() * 2)
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const startScreenShare = (clientId: string) => {
    console.log('Starting screen share with client:', clientId);
    // Screen sharing integration logic
  };

  return (
    <div className="space-y-6">
      <Card className="border-red-200 bg-gradient-to-r from-red-50 to-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-700">
            <Shield className="h-6 w-6" />
            Credit Repair Control Center - 800x Optimization & 200x Assurance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{optimizationLevel}x</div>
              <div className="text-sm text-gray-600">Optimization Level</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{assuranceLevel}x</div>
              <div className="text-sm text-gray-600">Assurance Level</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{activeClients}</div>
              <div className="text-sm text-gray-600">Active Clients</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">+{avgScoreIncrease}</div>
              <div className="text-sm text-gray-600">Avg Score Increase</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="realtime" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="realtime">Real-Time AI</TabsTrigger>
          <TabsTrigger value="screening">Screen Share</TabsTrigger>
          <TabsTrigger value="challenges">Challenges</TabsTrigger>
          <TabsTrigger value="manual">Manual Control</TabsTrigger>
        </TabsList>

        <TabsContent value="realtime">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-600" />
                Live AI Credit Score Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {realTimeUpdates.map((update, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                      <div>
                        <div className="font-medium">{update.client}</div>
                        <div className="text-sm text-gray-600">{update.time}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold">{update.score}</div>
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        +{update.change} points
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="screening">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Monitor className="h-5 w-5 text-blue-600" />
                Screen Sharing During Credit Repair
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {realTimeUpdates.map((update, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <div className="font-medium">{update.client}</div>
                      <div className="text-sm text-gray-600">Score: {update.score}</div>
                    </div>
                    <Button 
                      onClick={() => startScreenShare(update.client)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Start Screen Share
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="challenges">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-orange-600" />
                Active Credit Challenges
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <div className="font-medium">Dispute Processing</div>
                  <Progress value={75} className="mt-2" />
                  <div className="text-sm text-gray-600 mt-1">3 of 4 disputes resolved</div>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="font-medium">Account Verification</div>
                  <Progress value={60} className="mt-2" />
                  <div className="text-sm text-gray-600 mt-1">6 of 10 accounts verified</div>
                </div>
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="font-medium">Score Optimization</div>
                  <Progress value={90} className="mt-2" />
                  <div className="text-sm text-gray-600 mt-1">18 of 20 optimizations complete</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="manual">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-purple-600" />
                Manual Platform Controls
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button className="h-16 bg-red-600 hover:bg-red-700">
                  <div className="text-center">
                    <Zap className="h-6 w-6 mx-auto mb-1" />
                    <div>800x Boost</div>
                  </div>
                </Button>
                <Button className="h-16 bg-orange-600 hover:bg-orange-700">
                  <div className="text-center">
                    <Shield className="h-6 w-6 mx-auto mb-1" />
                    <div>200x Assurance</div>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}