import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase';

const SquareInvoicePayment: React.FC = () => {
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'processing' | 'completed' | 'failed'>('pending');
  const [processing, setProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [amount, setAmount] = useState(0);

  const squareInvoiceUrl = 'https://square.link/u/awKG8dAO';

  const processInstantPayment = async (method: string) => {
    setProcessing(true);
    setPaymentMethod(method);
    setPaymentStatus('processing');

    try {
      const { data } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'process_square_payment',
          data: {
            invoice_url: squareInvoiceUrl,
            payment_method: method,
            priority: 'ASAP'
          }
        }
      });

      if (data.success) {
        setTransactionId(data.payment.transaction_id);
        setAmount(data.payment.amount);
        
        // Record in square_invoices table with error handling
        try {
          await supabase.from('square_invoices').insert({
            invoice_url: squareInvoiceUrl,
            amount: data.payment.amount,
            currency: data.payment.currency,
            status: 'completed',
            created_at: new Date().toISOString(),
            customer_email: data.customer?.email || 'unknown@example.com'
          });
        } catch (error) {
          console.error('Square invoice insert error:', error);
          // Continue execution even if database insert fails
        }

        // Also record in banking_transactions with error handling
        try {
          await supabase.from('banking_transactions').insert({
            amount: data.payment.amount,
            type: 'square_invoice_payment',
            status: 'completed',
            created_at: new Date().toISOString(),
            description: `Square Invoice Payment - ${squareInvoiceUrl}`
          });
        } catch (error) {
          console.error('Banking transaction insert error:', error);
          // Continue execution even if database insert fails
        }
        
        setPaymentStatus('completed');
      } else {
        throw new Error(data.error || 'Payment failed');
      }
    } catch (error) {
      console.error('Payment failed:', error);
      setPaymentStatus('failed');
    }
    setProcessing(false);
  };

  const paymentMethods = [
    { id: 'direct_deposit', name: 'Direct Deposit', icon: '🏦', speed: 'Instant' },
    { id: 'instant_transfer', name: 'Instant Transfer', icon: '⚡', speed: 'Real-time' },
    { id: 'bank_wire', name: 'Bank Wire', icon: '💸', speed: 'Same Day' },
    { id: 'ach_express', name: 'ACH Express', icon: '🚀', speed: 'Minutes' }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-orange-500 to-red-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            📄 Square Invoice Payment - URGENT
            <Badge className="bg-red-500 animate-pulse">ASAP</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert className="bg-white/20 border-white/30 mb-4">
            <AlertDescription className="text-white">
              🚨 Invoice requires immediate payment through best available method
            </AlertDescription>
          </Alert>
          
          <div className="mb-4">
            <p className="text-sm opacity-90">Invoice URL:</p>
            <a 
              href={squareInvoiceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-200 underline break-all text-sm"
            >
              {squareInvoiceUrl}
            </a>
          </div>

          {paymentStatus === 'pending' && (
            <div className="space-y-3">
              <h3 className="font-semibold">Select Best Payment Method:</h3>
              {paymentMethods.map(method => (
                <Button
                  key={method.id}
                  onClick={() => processInstantPayment(method.id)}
                  disabled={processing}
                  className="w-full bg-white/20 hover:bg-white/30 text-white border border-white/30 justify-between"
                >
                  <span className="flex items-center gap-2">
                    {method.icon} {method.name}
                  </span>
                  <Badge className="bg-green-500">{method.speed}</Badge>
                </Button>
              ))}
            </div>
          )}

          {paymentStatus === 'processing' && (
            <div className="text-center py-8">
              <div className="animate-spin text-4xl mb-4">⚡</div>
              <p className="text-lg font-semibold">Processing {paymentMethod} payment...</p>
              <p className="text-sm opacity-90">Executing instant transfer to business account</p>
            </div>
          )}

          {paymentStatus === 'completed' && (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">✅</div>
              <p className="text-lg font-semibold">Payment Completed Successfully!</p>
              <p className="text-sm opacity-90">Amount: ${amount.toFixed(2)}</p>
              <p className="text-sm opacity-90">Transaction ID: {transactionId}</p>
              <p className="text-sm opacity-90">Method: {paymentMethod}</p>
              <div className="mt-4 space-y-2">
                <Button 
                  onClick={() => window.open(squareInvoiceUrl, '_blank')}
                  className="bg-white text-green-600 hover:bg-gray-100 mr-2"
                >
                  View Invoice Status
                </Button>
                <Button 
                  onClick={() => setPaymentStatus('pending')}
                  className="bg-white/20 text-white hover:bg-white/30"
                >
                  Process Another Payment
                </Button>
              </div>
            </div>
          )}

          {paymentStatus === 'failed' && (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">❌</div>
              <p className="text-lg font-semibold">Payment Failed</p>
              <p className="text-sm opacity-90">Please try a different payment method</p>
              <Button 
                onClick={() => setPaymentStatus('pending')}
                className="mt-4 bg-white text-red-600 hover:bg-gray-100"
              >
                Try Again
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SquareInvoicePayment;