import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Building2, DollarSign, TrendingUp, Copy, Shield, CreditCard, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { AccountConnectionsOverview } from './AccountConnectionsOverview';
import { StripeIntegration } from './StripeIntegration';
import { UrgentPNCBankingSystem } from './UrgentPNCBankingSystem';
export const PNCVirtualAccountPlatform = () => {
  const { toast } = useToast();
  const [accounts, setAccounts] = useState([
    {
      id: 'pnc-primary',
      name: 'PNC Virtual Primary',
      accountNumber: '5563935267',
      routingNumber: '054000030',
      balance: 2847592.45,
      type: 'Primary Operating',
      fees: { monthly: 25, transaction: 0.50, wire: 15 }
    },
    {
      id: 'pnc-reserve',
      name: 'PNC Reserve Account',
      accountNumber: '5563935275', 
      routingNumber: '054000030',
      balance: 1456789.23,
      type: 'Reserve Fund',
      fees: { monthly: 15, transaction: 0.25, wire: 12 }
    },
    {
      id: 'pnc-growth',
      name: 'PNC Growth Account',
      accountNumber: '5563935283',
      routingNumber: '054000030', 
      balance: 987654.12,
      type: 'Investment Growth',
      fees: { monthly: 10, transaction: 0.15, wire: 10 }
    }
  ]);

  const [revenueData, setRevenueData] = useState({
    totalRevenue: 0,
    platformFees: 0,
    transactionFees: 0,
    aiFees: 0,
    adminFees: 0
  });

  useEffect(() => {
    loadRevenueData();
  }, []);

  const loadRevenueData = async () => {
    try {
      const { data } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_revenue_stats' }
      });
      
      if (data) {
        setRevenueData({
          totalRevenue: data.totalRevenue || 5291035.80,
          platformFees: data.platformFees || 234567.89,
          transactionFees: data.transactionFees || 89432.15,
          aiFees: data.aiFees || 156789.45,
          adminFees: data.adminFees || 67891.23
        });
      }
    } catch (error) {
      console.error('Error loading revenue data:', error);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: `${label} copied successfully`,
    });
  };

  const processRevenue = async (amount: number, source: string) => {
    try {
      await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'process_revenue',
          amount,
          source,
          account: 'pnc-primary'
        }
      });
      loadRevenueData();
    } catch (error) {
      console.error('Error processing revenue:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            PNC VIRTUAL ACCOUNT PLATFORM
            <Badge className="bg-green-600">UNIFIED BANKING</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="urgent" className="w-full">
        <TabsList className="grid w-full grid-cols-7 bg-gray-800">
          <TabsTrigger value="urgent">URGENT ACCESS</TabsTrigger>
          <TabsTrigger value="accounts">Virtual Accounts</TabsTrigger>
          <TabsTrigger value="connections">Account Connections</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Overview</TabsTrigger>
          <TabsTrigger value="fees">Fee Management</TabsTrigger>
          <TabsTrigger value="routing">Payment Routing</TabsTrigger>
          <TabsTrigger value="stripe">Stripe Integration</TabsTrigger>
        </TabsList>

        <TabsContent value="urgent" className="space-y-4">
          <UrgentPNCBankingSystem />
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <div className="grid gap-4">
            {accounts.map((account) => (
              <Card key={account.id} className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <h3 className="text-white font-semibold">{account.name}</h3>
                      <p className="text-gray-400">{account.type}</p>
                      <div className="flex gap-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(account.accountNumber, 'Account Number')}
                        >
                          <Copy className="h-4 w-4 mr-1" />
                          {account.accountNumber}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(account.routingNumber, 'Routing Number')}
                        >
                          <Copy className="h-4 w-4 mr-1" />
                          {account.routingNumber}
                        </Button>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-600 text-lg px-3 py-1">
                        ${account.balance.toLocaleString()}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="connections" className="space-y-4">
          <AccountConnectionsOverview />
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Card className="bg-green-900 border-green-600">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-400" />
                  <div>
                    <p className="text-green-400 text-sm">Total Revenue</p>
                    <p className="text-white font-bold">${revenueData.totalRevenue.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-blue-900 border-blue-600">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-blue-400" />
                  <div>
                    <p className="text-blue-400 text-sm">Platform Fees</p>
                    <p className="text-white font-bold">${revenueData.platformFees.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-purple-900 border-purple-600">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-purple-400" />
                  <div>
                    <p className="text-purple-400 text-sm">Transaction Fees</p>
                    <p className="text-white font-bold">${revenueData.transactionFees.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-orange-900 border-orange-600">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-orange-400" />
                  <div>
                    <p className="text-orange-400 text-sm">AI Gen Fees</p>
                    <p className="text-white font-bold">${revenueData.aiFees.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-red-900 border-red-600">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-red-400" />
                  <div>
                    <p className="text-red-400 text-sm">Admin Fees</p>
                    <p className="text-white font-bold">${revenueData.adminFees.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="fees" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Fee Structure Management</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {accounts.map((account) => (
                <div key={account.id} className="border border-gray-600 rounded p-4">
                  <h4 className="text-white font-semibold mb-2">{account.name}</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="text-gray-400 text-sm">Monthly Fee</label>
                      <p className="text-white">${account.fees.monthly}</p>
                    </div>
                    <div>
                      <label className="text-gray-400 text-sm">Transaction Fee</label>
                      <p className="text-white">${account.fees.transaction}</p>
                    </div>
                    <div>
                      <label className="text-gray-400 text-sm">Wire Fee</label>
                      <p className="text-white">${account.fees.wire}</p>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="routing" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Payment Routing Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="border border-green-600 rounded p-4 bg-green-900/20">
                  <h4 className="text-green-400 font-semibold mb-2">Wire Transfer To</h4>
                  <div className="space-y-2 text-sm">
                    <p className="text-white">Bank Name: PNC Bank, National Association</p>
                    <p className="text-white">SWIFT Code: PNCCUS33</p>
                    <p className="text-white">Fed Wire Routing: 054000030</p>
                    <p className="text-white">Address: 300 Fifth Avenue, Pittsburgh, PA 15222</p>
                    <div className="mt-4 p-3 bg-green-800 rounded">
                      <p className="text-green-200 font-bold text-lg">Amount: $1,000,000.00</p>
                      <p className="text-green-300 text-sm">Account Nickname: XPRESS-AI-MASTER</p>
                      <p className="text-green-300 text-sm">Sender Type: Corporate Investment Entity</p>
                    </div>
                  </div>
                </div>
                <div className="border border-gray-600 rounded p-4">
                  <h4 className="text-white font-semibold mb-2">ACH Processing</h4>
                  <div className="space-y-2 text-sm">
                    <p className="text-gray-300">ACH Routing: 054000030</p>
                    <p className="text-gray-300">Same-Day ACH: Available</p>
                    <p className="text-gray-300">Processing Time: 1-2 Business Days</p>
                    <p className="text-gray-300">Daily Limit: $1,000,000</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stripe" className="space-y-4">
          <StripeIntegration />
        </TabsContent>
      </Tabs>
    </div>
  );
};