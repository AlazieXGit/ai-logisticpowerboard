import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Activity, DollarSign, TrendingUp, TrendingDown, 
  Eye, Calendar, BarChart3, PieChart, Edit3, Save
} from 'lucide-react';

interface TransactionData {
  id: string;
  type: 'revenue' | 'fee' | 'deduction' | 'payment';
  amount: number;
  description: string;
  timestamp: Date;
  platform: string;
  status: 'completed' | 'pending' | 'failed';
}

const RealtimeTransactionMonitor: React.FC = () => {
  const [transactions, setTransactions] = useState<TransactionData[]>([]);
  const [editMode, setEditMode] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  // MOCK DATA - Highlighted in Orange
  const mockData = {
    todayTotal: 45750.25,
    yesterdayTotal: 38920.15,
    totalRevenue: 125000.75,
    totalFees: 8750.50,
    netIncome: 116250.25,
    activeTransactions: 1247,
    pendingTransactions: 89,
    completedTransactions: 3456
  };
  const revenueBreakdown = [
    { platform: 'TMS System', amount: 25000, percentage: 20 },
    { platform: 'Banking Services', amount: 35000, percentage: 28 },
    { platform: 'Load Board', amount: 18000, percentage: 14.4 },
    { platform: 'AI Services', amount: 22000, percentage: 17.6 },
    { platform: 'Payment Processing', amount: 15000, percentage: 12 },
    { platform: 'Other Services', amount: 10000.50, percentage: 8 }
  ];

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      const newTransaction: TransactionData = {
        id: Date.now().toString(),
        type: ['revenue', 'fee', 'deduction', 'payment'][Math.floor(Math.random() * 4)] as any,
        amount: Math.random() * 1000 + 50,
        description: 'Real-time transaction update',
        timestamp: new Date(),
        platform: 'Live System',
        status: 'completed'
      };
      setTransactions(prev => [newTransaction, ...prev.slice(0, 9)]);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Header with Previous Day Poster */}
      <Card className="bg-gradient-to-r from-green-900/20 to-blue-900/20 border-green-500">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl text-green-400 flex items-center gap-2">
                <Activity className="h-6 w-6" />
                Real-Time Transaction Monitor
              </CardTitle>
              <p className="text-gray-300">Live revenue tracking & analytics</p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-400">Previous Day Close</div>
              <div className="text-2xl font-bold text-green-400">
                ${mockData.yesterdayTotal.toLocaleString()}
              </div>
              <Badge className="bg-green-600 mt-1">
                +{((mockData.todayTotal - mockData.yesterdayTotal) / mockData.yesterdayTotal * 100).toFixed(1)}%
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="live-monitor" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-gray-800">
          <TabsTrigger value="live-monitor">Live Monitor</TabsTrigger>
          <TabsTrigger value="revenue-sources">Revenue Sources</TabsTrigger>
          <TabsTrigger value="fees-deductions">Fees & Deductions</TabsTrigger>
          <TabsTrigger value="daily-totals">Daily Totals</TabsTrigger>
          <TabsTrigger value="integration-hub">Integration Hub</TabsTrigger>
        </TabsList>

        <TabsContent value="live-monitor" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-green-900/20 border-green-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-400 text-sm">Today's Total</p>
                    <p className="text-2xl font-bold text-white">
                      ${mockData.todayTotal.toLocaleString()}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-900/20 border-blue-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-400 text-sm">Total Revenue</p>
                    <p className="text-2xl font-bold text-white">
                      ${mockData.totalRevenue.toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-yellow-900/20 border-yellow-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-400 text-sm">Platform Fees</p>
                    <p className="text-2xl font-bold text-white">
                      ${mockData.totalFees.toLocaleString()}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-yellow-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-purple-900/20 border-purple-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-400 text-sm">Net Income</p>
                    <p className="text-2xl font-bold text-white">
                      ${mockData.netIncome.toLocaleString()}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Live Transaction Feed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {transactions.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded border border-gray-600">
                    <div className="flex items-center gap-3">
                      <Badge className={
                        tx.type === 'revenue' ? 'bg-green-600' :
                        tx.type === 'fee' ? 'bg-yellow-600' :
                        tx.type === 'deduction' ? 'bg-red-600' : 'bg-blue-600'
                      }>
                        {tx.type.toUpperCase()}
                      </Badge>
                      <span className="text-white">{tx.description}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-green-400 font-bold">
                        ${tx.amount.toFixed(2)}
                      </div>
                      <div className="text-xs text-gray-400">
                        {tx.timestamp.toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue-sources" className="space-y-4">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Revenue Source Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {revenueBreakdown.map((source, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-700/30 rounded">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 bg-blue-500 rounded"></div>
                      <span className="text-white">{source.platform}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-green-400 font-bold">
                        ${source.amount.toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-400">
                        {source.percentage}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integration-hub" className="space-y-4">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-white">Payment System Integration</CardTitle>
                <Button 
                  onClick={() => setEditMode(!editMode)}
                  className={editMode ? 'bg-green-600' : 'bg-blue-600'}
                >
                  {editMode ? <Save className="h-4 w-4 mr-2" /> : <Edit3 className="h-4 w-4 mr-2" />}
                  {editMode ? 'Save Changes' : 'Edit Settings'}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-gray-300">Routing Endpoint</label>
                    <div className="p-3 bg-gray-700 rounded border">
                      <code className="text-green-400">
                        /api/payment-routing/combined-total
                      </code>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-gray-300">Integration Status</label>
                    <Badge className="bg-green-600">ACTIVE</Badge>
                  </div>
                </div>
                
                <div className="p-4 bg-blue-900/20 border border-blue-500 rounded">
                  <h4 className="text-blue-400 font-semibold mb-2">Saved Configuration</h4>
                  <p className="text-gray-300 text-sm">
                    Combined revenue routing system is configured to automatically process 
                    daily totals and route payments to designated banking endpoints.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RealtimeTransactionMonitor;