import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Zap, TrendingUp, Activity, DollarSign, BarChart3 } from 'lucide-react';

interface PerformanceMetrics {
  revenueMultiplier: number;
  processingSpeed: number;
  efficiency: number;
  totalRevenue: number;
  boostDuration: number;
  activeBoosts: number;
}

export default function EnhancedPerformanceAnalytics() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    revenueMultiplier: 1,
    processingSpeed: 100,
    efficiency: 85,
    totalRevenue: 0,
    boostDuration: 0,
    activeBoosts: 0
  });

  const [boostActive, setBoostActive] = useState(false);
  const [boostHistory, setBoostHistory] = useState<Array<{
    timestamp: string;
    multiplier: number;
    revenue: number;
    duration: number;
  }>>([]);

  const activate200xBoost = () => {
    setBoostActive(true);
    setMetrics(prev => ({
      ...prev,
      revenueMultiplier: 200,
      processingSpeed: prev.processingSpeed * 200,
      efficiency: Math.min(99.9, prev.efficiency + 15),
      activeBoosts: prev.activeBoosts + 1
    }));

    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      setMetrics(prev => ({
        ...prev,
        boostDuration: elapsed,
        totalRevenue: prev.totalRevenue + (Math.random() * 10000 * 200)
      }));
    }, 1000);

    setTimeout(() => {
      clearInterval(interval);
      setBoostActive(false);
      setBoostHistory(prev => [...prev, {
        timestamp: new Date().toLocaleString(),
        multiplier: 200,
        revenue: metrics.totalRevenue,
        duration: metrics.boostDuration
      }]);
      setMetrics(prev => ({
        ...prev,
        revenueMultiplier: 1,
        processingSpeed: 100,
        efficiency: 85,
        boostDuration: 0
      }));
    }, 30000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-blue-400">AI ALAZIE XPRESS - Performance Analytics</h3>
        <Button
          onClick={activate200xBoost}
          disabled={boostActive}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          <Zap className="w-4 h-4 mr-2" />
          {boostActive ? `BOOST ACTIVE (${metrics.boostDuration}s)` : '200X REVENUE BOOST'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Revenue Multiplier</p>
                <p className="text-2xl font-bold text-green-400">{metrics.revenueMultiplier}X</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Processing Speed</p>
                <p className="text-2xl font-bold text-blue-400">{metrics.processingSpeed.toLocaleString()}%</p>
              </div>
              <Activity className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Efficiency</p>
                <p className="text-2xl font-bold text-purple-400">{metrics.efficiency.toFixed(1)}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Revenue</p>
                <p className="text-2xl font-bold text-yellow-400">${metrics.totalRevenue.toLocaleString()}</p>
              </div>
              <BarChart3 className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Real-Time Performance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Revenue Generation Rate</span>
                <span className="text-white">{(metrics.revenueMultiplier * 100)}%</span>
              </div>
              <Progress value={Math.min(100, metrics.revenueMultiplier * 50)} className="h-3" />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">System Efficiency</span>
                <span className="text-white">{metrics.efficiency}%</span>
              </div>
              <Progress value={metrics.efficiency} className="h-3" />
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Processing Capacity</span>
                <span className="text-white">{Math.min(100, metrics.processingSpeed)}%</span>
              </div>
              <Progress value={Math.min(100, metrics.processingSpeed)} className="h-3" />
            </div>

            {boostActive && (
              <div className="p-3 bg-purple-900/20 border border-purple-700 rounded">
                <div className="flex items-center justify-between">
                  <span className="text-purple-400 font-semibold">200X Boost Active</span>
                  <Badge className="bg-purple-600 text-white animate-pulse">
                    {30 - metrics.boostDuration}s remaining
                  </Badge>
                </div>
                <div className="mt-2">
                  <Progress 
                    value={(metrics.boostDuration / 30) * 100} 
                    className="h-2" 
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Boost History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {boostHistory.length === 0 ? (
                <p className="text-gray-400 text-sm">No boost history yet</p>
              ) : (
                boostHistory.slice(-5).reverse().map((boost, index) => (
                  <div key={index} className="p-3 bg-gray-700 rounded">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-white font-semibold">{boost.multiplier}X Boost</p>
                        <p className="text-sm text-gray-400">{boost.timestamp}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 font-semibold">
                          +${boost.revenue.toLocaleString()}
                        </p>
                        <p className="text-sm text-gray-400">{boost.duration}s duration</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Performance Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400 mb-2">
                {metrics.activeBoosts}
              </div>
              <div className="text-sm text-gray-400">Total Boosts Activated</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-2">
                ${(boostHistory.reduce((acc, boost) => acc + boost.revenue, 0)).toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Total Boosted Revenue</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">
                {boostHistory.length > 0 ? 
                  Math.round(boostHistory.reduce((acc, boost) => acc + boost.duration, 0) / boostHistory.length) : 0}s
              </div>
              <div className="text-sm text-gray-400">Average Boost Duration</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}