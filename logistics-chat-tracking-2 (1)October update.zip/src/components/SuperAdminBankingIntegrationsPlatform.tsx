import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CreditCard, Building2, Shield, CheckCircle, AlertTriangle, Settings } from 'lucide-react';

const SuperAdminBankingIntegrationsPlatform = () => {
  const [integrations] = useState([
    {
      id: 'stripe-system',
      name: 'Stripe Payment System',
      type: 'Enhanced Payment Processor',
      status: 'Active',
      connectedBank: 'PNC Business ***4521',
      dailyLimit: 125000,
      processor: 'Stripe',
      accounts: ['Trust Banking Fee Collection', 'Platform Fee Collection', 'Escrow Reserve']
    },
    {
      id: 'square-system', 
      name: 'Square Invoice System',
      type: 'Square Integration',
      status: 'Active',
      connectedBank: 'Wells Fargo ***7892',
      dailyLimit: 75000,
      processor: 'Square',
      accounts: ['Revenue Collection', 'Invoice Processing']
    },
    {
      id: 'ach-network',
      name: 'ACH Network Registration',
      type: 'Direct Deposit System',
      status: 'Active',
      connectedBank: 'Trust Main ***8903',
      dailyLimit: 250000,
      processor: 'Dwolla ACH',
      accounts: ['Primary Revenue Account', 'Growth Investment Fund', 'Escrow Operating']
    },
    {
      id: 'synergy-router',
      name: 'Synergy Payment Router',
      type: 'Unified Payment System',
      status: 'Active',
      connectedBank: 'Multiple Routing',
      dailyLimit: 500000,
      processor: 'Multi-Processor',
      accounts: ['All Internal Accounts']
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800';
      case 'Inactive': return 'bg-red-100 text-red-800';
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProcessorIcon = (processor: string) => {
    switch (processor) {
      case 'Stripe': return <CreditCard className="w-4 h-4" />;
      case 'Dwolla ACH': return <Building2 className="w-4 h-4" />;
      case 'Square': return <Shield className="w-4 h-4" />;
      default: return <Settings className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-2 border-blue-200">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <Building2 className="w-6 h-6" />
            Super Admin Banking Integrations Platform
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {integrations.map((integration) => (
              <Card key={integration.id} className="border border-gray-200">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getProcessorIcon(integration.processor)}
                      <CardTitle className="text-lg">{integration.name}</CardTitle>
                    </div>
                    <Badge className={getStatusColor(integration.status)}>
                      {integration.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{integration.type}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Connected Bank:</span>
                      <span className="font-medium">{integration.connectedBank}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Daily Limit:</span>
                      <span className="font-bold text-green-600">
                        ${integration.dailyLimit.toLocaleString()}/day
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Processor:</span>
                      <Badge variant="outline">{integration.processor}</Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-sm font-medium text-gray-700">Connected Internal Accounts:</span>
                    <div className="space-y-1">
                      {integration.accounts.map((account, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-3 h-3 text-green-500" />
                          <span>{account}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Settings className="w-3 h-3 mr-1" />
                      Configure
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Integration Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Integration Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">4</div>
              <div className="text-sm text-gray-600">Active Integrations</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">$950K</div>
              <div className="text-sm text-gray-600">Total Daily Limit</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">12</div>
              <div className="text-sm text-gray-600">Connected Accounts</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">100%</div>
              <div className="text-sm text-gray-600">System Uptime</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminBankingIntegrationsPlatform;