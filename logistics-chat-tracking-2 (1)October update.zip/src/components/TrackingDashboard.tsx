import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Location {
  id: string;
  lat: number;
  lng: number;
  label: string;
  status: 'active' | 'idle' | 'delayed';
}

interface TrackingDashboardProps {
  onUpdate?: (location: Location) => void;
}

const TrackingDashboard: React.FC<TrackingDashboardProps> = ({ onUpdate }) => {
  const [locations, setLocations] = useState<Location[]>([
    { id: '1', lat: 32.7767, lng: -96.7970, label: 'Dallas Hub', status: 'active' },
    { id: '2', lat: 33.7490, lng: -84.3880, label: 'Atlanta Terminal', status: 'active' },
    { id: '3', lat: 41.8781, lng: -87.6298, label: 'Chicago Depot', status: 'idle' }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomLocation = locations[Math.floor(Math.random() * locations.length)];
      const updatedLocation = {
        ...randomLocation,
        lat: randomLocation.lat + (Math.random() - 0.5) * 0.1,
        lng: randomLocation.lng + (Math.random() - 0.5) * 0.1,
        status: ['active', 'idle', 'delayed'][Math.floor(Math.random() * 3)] as 'active' | 'idle' | 'delayed'
      };
      
      setLocations(prev => prev.map(loc => 
        loc.id === updatedLocation.id ? updatedLocation : loc
      ));
      
      onUpdate?.(updatedLocation);
    }, 3000);

    return () => clearInterval(interval);
  }, [onUpdate, locations]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'idle': return 'bg-yellow-500';
      case 'delayed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Card className="h-96 bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-200 shadow-xl">
      <div className="p-4 border-b bg-gradient-to-r from-green-600 to-emerald-600 text-white">
        <h2 className="text-lg font-bold flex items-center gap-2">
          🗺️ Live Tracking Dashboard
        </h2>
      </div>
      <div className="p-4 h-full">
        <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-lg h-full relative overflow-hidden border-2 border-blue-300">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-green-400/20"></div>
          <div className="relative h-full p-4">
            <div className="text-center text-gray-600 mb-4">
              <div className="text-sm font-semibold">🌍 US Logistics Network</div>
              <div className="text-xs">Real-time vehicle tracking</div>
            </div>
            <div className="space-y-3">
              {locations.map((location) => (
                <div key={location.id} className="flex items-center justify-between bg-white/80 backdrop-blur-sm p-3 rounded-lg border shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">🚛</div>
                    <div>
                      <div className="font-semibold text-sm">{location.label}</div>
                      <div className="text-xs text-gray-600">
                        {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                      </div>
                    </div>
                  </div>
                  <Badge className={`${getStatusColor(location.status)} text-white text-xs`}>
                    {location.status.toUpperCase()}
                  </Badge>
                </div>
              ))}
            </div>
            <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-lg border text-xs text-gray-600">
              📡 Live Updates Every 3s
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default TrackingDashboard;