import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Power, PowerOff, Users, Clock, Shield, Database } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface SystemControlPanelProps {
  onSystemToggle: (isActive: boolean) => void;
  systemActive: boolean;
}

const SystemControlPanel: React.FC<SystemControlPanelProps> = ({ onSystemToggle, systemActive }) => {
  const [loading, setLoading] = useState(false);
  const [activeSessions, setActiveSessions] = useState(0);
  const [sessionTimeLimit] = useState(10);
  const [lastAction, setLastAction] = useState('');

  useEffect(() => {
    if (systemActive) {
      const interval = setInterval(() => {
        setActiveSessions(Math.floor(Math.random() * 3));
      }, 5000);
      return () => clearInterval(interval);
    } else {
      setActiveSessions(0);
    }
  }, [systemActive]);

  const handleSystemControl = async (action: 'start_system' | 'stop_system') => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('system-control', {
        body: {
          action,
          adminEmail: 'alaziellc.innovation@gmail.com',
          password: 'gotchu!'
        }
      });

      if (error) throw error;

      if (data.success) {
        onSystemToggle(data.systemActive);
        setLastAction(data.message);
      }
    } catch (error) {
      console.error('System control error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-black/80 border-lime-500">
        <CardHeader>
          <CardTitle className="text-lime-400 flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Alucius Alford Super Admin Control Panel
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Button
              onClick={() => handleSystemControl('start_system')}
              disabled={systemActive || loading}
              className="bg-lime-600 hover:bg-lime-700 text-black font-bold"
            >
              <Power className="h-4 w-4 mr-2" />
              {loading ? 'STARTING...' : 'START SYSTEM'}
            </Button>
            <Button
              onClick={() => handleSystemControl('stop_system')}
              disabled={!systemActive || loading}
              className="bg-red-600 hover:bg-red-700 text-white font-bold"
            >
              <PowerOff className="h-4 w-4 mr-2" />
              {loading ? 'STOPPING...' : 'STOP SYSTEM'}
            </Button>
          </div>
          
          {lastAction && (
            <Alert className="border-lime-500 bg-lime-900/20">
              <AlertDescription className="text-lime-300">
                ✅ {lastAction}
              </AlertDescription>
            </Alert>
          )}
          
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-lime-400">
                {systemActive ? 'ACTIVE' : 'INACTIVE'}
              </div>
              <div className="text-sm text-gray-400">System Status</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-lime-400">
                {activeSessions}
              </div>
              <div className="text-sm text-gray-400">Live Sessions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-lime-400">
                {sessionTimeLimit}m
              </div>
              <div className="text-sm text-gray-400">Session Limit</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-black/80 border-lime-500">
        <CardHeader>
          <CardTitle className="text-lime-400 flex items-center gap-2">
            <Database className="h-6 w-6" />
            Portal Status & Resource Compilation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-red-500 bg-red-900/20">
            <AlertDescription className="text-red-300">
              🚫 ALL USER PORTALS SUSPENDED - Super Admin Access Only
            </AlertDescription>
          </Alert>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">User Portal Access:</span>
              <Badge variant="destructive">SUSPENDED</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Live Preview Access:</span>
              <Badge className={systemActive ? 'bg-lime-600' : 'bg-gray-600'}>
                {systemActive ? 'ACTIVE (10min limit)' : 'INACTIVE'}
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Super Admin Access:</span>
              <Badge className="bg-lime-600">ACTIVE</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SystemControlPanel;