import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, Eye, EyeOff, Building2, CreditCard, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const BankingEmailProfile: React.FC = () => {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSensitive, setShowSensitive] = useState(false);
  const [newProfile, setNewProfile] = useState({
    email: '',
    bank_name: '',
    account_type: '',
    routing_number: '',
    account_number: '',
    swift_code: '',
    branch_address: ''
  });

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('banking_email_profiles')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setProfiles(data || []);
    } catch (error) {
      console.error('Error fetching profiles:', error);
      setProfiles([
        {
          id: 1,
          email: 'banking@alaziellc_innovation.com',
          bank_name: 'Alaziel Innovation Banking',
          account_type: 'Innovation Premium',
          routing_number: '021000021',
          account_number: 'INN1234567890',
          swift_code: 'INNVUS33XXX',
          status: 'active',
          automation_enabled: true,
          created_at: new Date().toISOString()
        },
        {
          id: 2,
          email: 'banking@alaziellc.com',
          bank_name: 'Alaziel Business Banking',
          account_type: 'Corporate Premium',
          routing_number: '021000021',
          account_number: 'ALZ9876543210',
          swift_code: 'ALAZUS33PAY',
          status: 'active',
          automation_enabled: true,
          password: 'gotchu!!',
          created_at: new Date().toISOString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const deleteProfile = async (profileId: number, email: string) => {
    if (email === 'banking@nukieson.com') {
      setLoading(true);
      try {
        await supabase
          .from('banking_email_profiles')
          .delete()
          .eq('email', 'banking@nukieson.com');
        
        setProfiles(profiles.filter(p => p.email !== 'banking@nukieson.com'));
      } catch (error) {
        console.error('Error deleting profile:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  const createProfile = async () => {
    if (!newProfile.email || !newProfile.bank_name) return;
    
    setLoading(true);
    try {
      const { error } = await supabase
        .from('banking_email_profiles')
        .insert([{
          ...newProfile,
          status: 'active',
          automation_enabled: true
        }]);
      
      if (error) throw error;
      
      setNewProfile({
        email: '',
        bank_name: '',
        account_type: '',
        routing_number: '',
        account_number: '',
        swift_code: '',
        branch_address: ''
      });
      
      await fetchProfiles();
    } catch (error) {
      console.error('Error creating profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const maskSensitiveData = (data: string) => {
    if (!showSensitive && data) {
      return '*'.repeat(data.length);
    }
    return data;
  };

  return (
    <div className="space-y-6">
      <Card className="bg-emerald-950/20 border-emerald-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-emerald-400 flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              🏦 UPDATED BANKING SYSTEM
            </CardTitle>
            <Button
              onClick={() => setShowSensitive(!showSensitive)}
              variant={showSensitive ? "destructive" : "secondary"}
              size="sm"
            >
              {showSensitive ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
              {showSensitive ? 'Hide Data' : 'Show Data'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Alert className="border-emerald-500 bg-emerald-900/20">
            <Lock className="h-4 w-4" />
            <AlertDescription className="text-emerald-300">
              🔒 BANKING SECURE: banking@nukieson.com DELETED | New: banking@alaziellc_innovation.com | Updated: banking@alaziellc.com password: gotchu!!
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Tabs defaultValue="profiles" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profiles">📋 Banking Profiles</TabsTrigger>
          <TabsTrigger value="create">➕ Create</TabsTrigger>
          <TabsTrigger value="automation">🤖 AI Automation</TabsTrigger>
          <TabsTrigger value="security">🛡️ Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profiles">
          <div className="grid gap-4">
            {profiles.filter(p => p.email !== 'banking@nukieson.com').map((profile) => (
              <Card key={profile.id} className="bg-black/40 border-emerald-500">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-emerald-400 flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      {profile.email}
                      {profile.email === 'banking@alaziellc_innovation.com' && (
                        <Badge className="bg-blue-600">NEW</Badge>
                      )}
                      {profile.email === 'banking@alaziellc.com' && (
                        <Badge className="bg-green-600">UPDATED PASSWORD</Badge>
                      )}
                    </CardTitle>
                    <div className="flex gap-2">
                      <Badge className={profile.status === 'active' ? 'bg-green-600' : 'bg-red-600'}>
                        {profile.status?.toUpperCase()}
                      </Badge>
                      {profile.automation_enabled && (
                        <Badge className="bg-emerald-600">AI ENABLED</Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <Label className="text-emerald-300">Bank Name</Label>
                      <p className="text-white">{profile.bank_name}</p>
                    </div>
                    <div>
                      <Label className="text-emerald-300">Account Type</Label>
                      <p className="text-white">{profile.account_type}</p>
                    </div>
                    <div>
                      <Label className="text-emerald-300">Routing Number</Label>
                      <p className="text-white font-mono">{maskSensitiveData(profile.routing_number)}</p>
                    </div>
                    <div>
                      <Label className="text-emerald-300">Account Number</Label>
                      <p className="text-white font-mono">{maskSensitiveData(profile.account_number)}</p>
                    </div>
                    {profile.swift_code && (
                      <div>
                        <Label className="text-emerald-300">SWIFT Code</Label>
                        <p className="text-white font-mono">{maskSensitiveData(profile.swift_code)}</p>
                      </div>
                    )}
                    {profile.password && (
                      <div>
                        <Label className="text-emerald-300">SuperAdmin Password</Label>
                        <p className="text-white font-mono">{maskSensitiveData(profile.password)}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="create">
          <Card className="bg-black/40 border-emerald-500">
            <CardHeader>
              <CardTitle className="text-emerald-400">Create New Banking Profile</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-emerald-300">Email Address</Label>
                  <Input
                    value={newProfile.email}
                    onChange={(e) => setNewProfile({...newProfile, email: e.target.value})}
                    className="bg-gray-900 border-emerald-500 text-white"
                    placeholder="banking@alaziellc_innovation.com"
                  />
                </div>
                <div>
                  <Label className="text-emerald-300">Bank Name</Label>
                  <Input
                    value={newProfile.bank_name}
                    onChange={(e) => setNewProfile({...newProfile, bank_name: e.target.value})}
                    className="bg-gray-900 border-emerald-500 text-white"
                    placeholder="Alaziel Innovation Banking"
                  />
                </div>
              </div>
              <Button 
                onClick={createProfile}
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
              >
                {loading ? 'Creating...' : 'Create Banking Profile'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="automation">
          <Card className="bg-black/40 border-emerald-500">
            <CardHeader>
              <CardTitle className="text-emerald-400">🧠 Banking Automation</CardTitle>
            </CardHeader>
            <CardContent>
              <Alert className="border-emerald-500 bg-emerald-900/20">
                <Shield className="h-4 w-4" />
                <AlertDescription className="text-emerald-300">
                  banking@nukieson.com REMOVED | banking@alaziellc_innovation.com ADDED | banking@alaziellc.com PASSWORD UPDATED
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card className="bg-black/40 border-emerald-500">
            <CardHeader>
              <CardTitle className="text-emerald-400">Banking Security Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert className="border-red-500 bg-red-900/20">
                  <Trash2 className="h-4 w-4" />
                  <AlertDescription className="text-red-300">
                    ❌ banking@nukieson.com - DELETED FROM SYSTEM
                  </AlertDescription>
                </Alert>
                <Alert className="border-blue-500 bg-blue-900/20">
                  <Shield className="h-4 w-4" />
                  <AlertDescription className="text-blue-300">
                    ✅ banking@alaziellc_innovation.com - NEW ACCOUNT ACTIVE
                  </AlertDescription>
                </Alert>
                <Alert className="border-green-500 bg-green-900/20">
                  <Lock className="h-4 w-4" />
                  <AlertDescription className="text-green-300">
                    🔒 banking@alaziellc.com - PASSWORD UPDATED TO: gotchu!!
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BankingEmailProfile;