import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Shield, Settings, Database, Lock, Unlock,
  Eye, EyeOff, Power, AlertTriangle, CheckCircle
} from 'lucide-react';
import LiveClock from './LiveClock';

const SuperAdminTransactionControl: React.FC = () => {
  const [systemLocked, setSystemLocked] = useState(false);
  const [monitoringActive, setMonitoringActive] = useState(true);
  const [selectedTransaction, setSelectedTransaction] = useState('');

  const activeTransactions = [
    {
      id: 'TXN-001',
      type: 'ACH Transfer',
      amount: '$2,450.00',
      from: 'Wells Fargo Business',
      to: 'Vendor Account',
      status: 'Processing',
      timestamp: '2025-01-15 14:30:22'
    },
    {
      id: 'TXN-002',
      type: 'Wire Transfer',
      amount: '$1,875.50',
      from: 'Trust Account',
      to: 'Carrier Payment',
      status: 'Pending Auth',
      timestamp: '2025-01-15 13:45:11'
    },
    {
      id: 'TXN-003',
      type: 'Internal Transfer',
      amount: '$950.25',
      from: 'Revenue Pool',
      to: 'Operating Account',
      status: 'Completed',
      timestamp: '2025-01-15 12:15:33'
    }
  ];

  const systemControls = [
    { id: 'banking', name: 'Banking System', status: 'Active' },
    { id: 'payments', name: 'Payment Processor', status: 'Active' },
    { id: 'transfers', name: 'Transfer Engine', status: 'Active' },
    { id: 'monitoring', name: 'Transaction Monitor', status: 'Active' }
  ];

  const handleSystemLock = () => {
    setSystemLocked(!systemLocked);
  };

  const handleTransactionControl = (action: string, txnId: string) => {
    console.log(`${action} transaction ${txnId}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <LiveClock />
      </div>
      
      <Card className="bg-red-900/20 border-red-500/50">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Super Admin Transaction Control Center
          </CardTitle>
          <Badge className="bg-red-600 w-fit">MASTER ADMIN - FULL CONTROL</Badge>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert className="border-red-500 bg-red-900/20">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-red-300">
              CRITICAL SYSTEM ACCESS - All transaction controls available
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800/30 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  System Controls
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                  <span className="text-white">System Lock</span>
                  <Button
                    onClick={handleSystemLock}
                    className={systemLocked ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}
                  >
                    {systemLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
                    {systemLocked ? 'LOCKED' : 'UNLOCKED'}
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                  <span className="text-white">Transaction Monitoring</span>
                  <Button
                    onClick={() => setMonitoringActive(!monitoringActive)}
                    className={monitoringActive ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-600 hover:bg-gray-700'}
                  >
                    {monitoringActive ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                    {monitoringActive ? 'ACTIVE' : 'INACTIVE'}
                  </Button>
                </div>

                {systemControls.map((control) => (
                  <div key={control.id} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                    <span className="text-white">{control.name}</span>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-green-600">{control.status}</Badge>
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <Power className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  Transaction Override
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-white">Transaction ID</Label>
                  <Input
                    placeholder="Enter transaction ID"
                    value={selectedTransaction}
                    onChange={(e) => setSelectedTransaction(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => handleTransactionControl('approve', selectedTransaction)}
                  >
                    Force Approve
                  </Button>
                  <Button 
                    className="bg-red-600 hover:bg-red-700"
                    onClick={() => handleTransactionControl('cancel', selectedTransaction)}
                  >
                    Force Cancel
                  </Button>
                  <Button 
                    className="bg-yellow-600 hover:bg-yellow-700"
                    onClick={() => handleTransactionControl('hold', selectedTransaction)}
                  >
                    Place Hold
                  </Button>
                  <Button 
                    className="bg-blue-600 hover:bg-blue-700"
                    onClick={() => handleTransactionControl('review', selectedTransaction)}
                  >
                    Manual Review
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Live Transaction Monitor</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {activeTransactions.map((txn) => (
                  <div key={txn.id} className="p-4 bg-gray-700/50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        {txn.status === 'Completed' ? (
                          <CheckCircle className="h-5 w-5 text-green-400" />
                        ) : (
                          <AlertTriangle className="h-5 w-5 text-yellow-400" />
                        )}
                        <span className="text-white font-medium">{txn.id}</span>
                        <Badge className="bg-blue-600">{txn.type}</Badge>
                      </div>
                      <span className="text-green-400 font-bold">{txn.amount}</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                      <span className="text-gray-300">From: {txn.from}</span>
                      <span className="text-gray-300">To: {txn.to}</span>
                      <span className="text-gray-300">{txn.timestamp}</span>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <Badge className={
                        txn.status === 'Completed' ? 'bg-green-600' :
                        txn.status === 'Processing' ? 'bg-blue-600' : 'bg-yellow-600'
                      }>
                        {txn.status}
                      </Badge>
                      <div className="flex gap-2">
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          Approve
                        </Button>
                        <Button size="sm" className="bg-red-600 hover:bg-red-700">
                          Block
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminTransactionControl;