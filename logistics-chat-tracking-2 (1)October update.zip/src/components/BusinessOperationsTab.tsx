import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building, Download, Edit, Save, Plus, Users, FileText, Settings } from 'lucide-react';

const BusinessOperationsTab = () => {
  const [operations, setOperations] = useState([
    {
      id: 1,
      name: 'Payment Processing Operations',
      department: 'Finance',
      manager: 'John Smith',
      status: 'Active',
      budget: 250000,
      employees: 12,
      description: 'Managing all payment processing systems and integrations',
      kpis: ['99.9% Uptime', '2.5s Avg Response Time', '$2.3M Monthly Volume'],
      documents: ['SOP Manual', 'Compliance Guide', 'Training Materials']
    },
    {
      id: 2,
      name: 'TMS Platform Management',
      department: 'Technology',
      manager: 'Sarah Johnson',
      status: 'Active',
      budget: 180000,
      employees: 8,
      description: 'Transportation Management System operations and support',
      kpis: ['500+ Active Users', '95% Customer Satisfaction', '24/7 Support'],
      documents: ['User Manual', 'API Documentation', 'Support Procedures']
    },
    {
      id: 3,
      name: 'Asset Management Division',
      department: 'Operations',
      manager: 'Mike Davis',
      status: 'Expanding',
      budget: 320000,
      employees: 15,
      description: 'Managing vehicle acquisitions and asset portfolio',
      kpis: ['$8.5M Assets Under Management', '15.2% Annual Growth', '147 Vehicles'],
      documents: ['Asset Registry', 'Acquisition Procedures', 'Valuation Reports']
    }
  ]);

  const [newOperation, setNewOperation] = useState({
    name: '',
    department: '',
    manager: '',
    budget: '',
    employees: '',
    description: ''
  });

  const totalBudget = operations.reduce((sum, op) => sum + op.budget, 0);
  const totalEmployees = operations.reduce((sum, op) => sum + op.employees, 0);

  const addOperation = () => {
    if (newOperation.name && newOperation.department) {
      const operation = {
        id: Date.now(),
        ...newOperation,
        budget: parseFloat(newOperation.budget) || 0,
        employees: parseInt(newOperation.employees) || 0,
        status: 'Planning',
        kpis: ['New Operation'],
        documents: ['Initial Documentation']
      };
      setOperations([...operations, operation]);
      setNewOperation({
        name: '', department: '', manager: '', budget: '', employees: '', description: ''
      });
    }
  };

  const downloadOperationsReport = () => {
    const reportData = operations.map(op => 
      `${op.name} - ${op.department}\nManager: ${op.manager}\nBudget: $${op.budget.toLocaleString()}\nEmployees: ${op.employees}\nStatus: ${op.status}\n`
    ).join('\n');
    
    const element = document.createElement('a');
    element.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(
      `Business Operations Report\n\nTotal Budget: $${totalBudget.toLocaleString()}\nTotal Employees: ${totalEmployees}\n\nOperations:\n${reportData}`
    );
    element.download = 'business_operations_report.txt';
    element.click();
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-300 flex items-center gap-2">
            <Building className="h-5 w-5" />
            Business Operations Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-blue-300 font-semibold">Total Operations</span>
                <Building className="h-4 w-4 text-blue-400" />
              </div>
              <p className="text-2xl font-bold text-blue-400">{operations.length}</p>
            </div>
            <div className="bg-green-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-green-300 font-semibold">Total Budget</span>
              </div>
              <p className="text-2xl font-bold text-green-400">${(totalBudget / 1000).toFixed(0)}K</p>
            </div>
            <div className="bg-purple-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-purple-300 font-semibold">Total Employees</span>
                <Users className="h-4 w-4 text-purple-400" />
              </div>
              <p className="text-2xl font-bold text-purple-400">{totalEmployees}</p>
            </div>
            <div className="bg-orange-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-orange-300 font-semibold">Active Operations</span>
              </div>
              <p className="text-2xl font-bold text-orange-400">
                {operations.filter(op => op.status === 'Active').length}
              </p>
            </div>
          </div>
          <div className="mt-4">
            <Button onClick={downloadOperationsReport} className="bg-blue-600 hover:bg-blue-700">
              <Download className="h-4 w-4 mr-2" />
              Download Operations Report
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="operations" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="operations">Current Operations</TabsTrigger>
          <TabsTrigger value="add">Add Operation</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="operations" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {operations.map((operation) => (
              <Card key={operation.id} className="bg-gray-800 border-blue-500/30">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-blue-300">{operation.name}</CardTitle>
                      <div className="flex gap-2 mt-2">
                        <Badge className="bg-purple-600">{operation.department}</Badge>
                        <Badge className={
                          operation.status === 'Active' ? 'bg-green-600' :
                          operation.status === 'Expanding' ? 'bg-orange-600' : 'bg-gray-600'
                        }>
                          {operation.status}
                        </Badge>
                      </div>
                    </div>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300">{operation.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-400 text-sm">Manager</p>
                      <p className="text-white font-semibold">{operation.manager}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Budget</p>
                      <p className="text-green-400 font-bold">${operation.budget.toLocaleString()}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-gray-400 text-sm">Employees</p>
                    <p className="text-blue-400 font-bold">{operation.employees}</p>
                  </div>

                  <div>
                    <p className="text-gray-400 text-sm">Key Performance Indicators</p>
                    <div className="space-y-1 mt-1">
                      {operation.kpis.map((kpi, index) => (
                        <Badge key={index} className="bg-gray-700 text-gray-300 mr-2">
                          {kpi}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-gray-400 text-sm">Documents</p>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {operation.documents.map((doc, index) => (
                        <Button
                          key={index}
                          size="sm"
                          className="bg-gray-700 hover:bg-gray-600 text-xs"
                        >
                          <FileText className="h-3 w-3 mr-1" />
                          {doc}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="add" className="space-y-4">
          <Card className="bg-gray-800 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-300 flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Add New Business Operation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  placeholder="Operation Name"
                  value={newOperation.name}
                  onChange={(e) => setNewOperation({...newOperation, name: e.target.value})}
                  className="bg-gray-700 border-gray-600"
                />
                <Input
                  placeholder="Department"
                  value={newOperation.department}
                  onChange={(e) => setNewOperation({...newOperation, department: e.target.value})}
                  className="bg-gray-700 border-gray-600"
                />
                <Input
                  placeholder="Manager Name"
                  value={newOperation.manager}
                  onChange={(e) => setNewOperation({...newOperation, manager: e.target.value})}
                  className="bg-gray-700 border-gray-600"
                />
                <Input
                  placeholder="Budget"
                  type="number"
                  value={newOperation.budget}
                  onChange={(e) => setNewOperation({...newOperation, budget: e.target.value})}
                  className="bg-gray-700 border-gray-600"
                />
                <Input
                  placeholder="Number of Employees"
                  type="number"
                  value={newOperation.employees}
                  onChange={(e) => setNewOperation({...newOperation, employees: e.target.value})}
                  className="bg-gray-700 border-gray-600"
                />
              </div>
              <div className="mt-4">
                <Textarea
                  placeholder="Operation Description"
                  value={newOperation.description}
                  onChange={(e) => setNewOperation({...newOperation, description: e.target.value})}
                  className="bg-gray-700 border-gray-600"
                />
                <Button onClick={addOperation} className="mt-4 bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Operation
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-green-300">Budget Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                {operations.map((op, index) => (
                  <div key={index} className="flex justify-between items-center py-2">
                    <span className="text-gray-300">{op.name}</span>
                    <span className="text-green-400 font-bold">
                      ${op.budget.toLocaleString()}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-blue-300">Employee Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                {operations.map((op, index) => (
                  <div key={index} className="flex justify-between items-center py-2">
                    <span className="text-gray-300">{op.name}</span>
                    <span className="text-blue-400 font-bold">{op.employees} employees</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BusinessOperationsTab;