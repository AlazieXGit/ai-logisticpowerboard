import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface PaymentProcessor {
  id: string;
  name: string;
  status: 'connected' | 'disconnected' | 'pending';
  balance: string;
  accountId?: string;
}

const PaymentProcessorIntegration: React.FC = () => {
  const [processors, setProcessors] = useState<PaymentProcessor[]>([
    { id: 'dwolla', name: 'Dwolla ACH', status: 'connected', balance: '$125,000.00', accountId: 'dwolla_12345' },
    { id: 'stripe', name: 'Stripe Connect', status: 'connected', balance: '$89,500.00', accountId: 'acct_1234567890' },
    { id: 'plaid', name: 'Plaid Banking', status: 'pending', balance: '$0.00' },
    { id: 'square', name: 'Square Payments', status: 'disconnected', balance: '$0.00' }
  ]);

  const [cardForm, setCardForm] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    holderName: '',
    amount: '',
    transferType: 'debit'
  });

  const handleCardTransfer = () => {
    console.log('Processing card transfer:', cardForm);
    // Integration with payment processors would happen here
  };

  const connectProcessor = (processorId: string) => {
    setProcessors(prev => prev.map(p => 
      p.id === processorId ? { ...p, status: 'pending' } : p
    ));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Payment Processor Integration</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="processors">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="processors">Processors</TabsTrigger>
              <TabsTrigger value="card-transfer">Card Transfer</TabsTrigger>
              <TabsTrigger value="routing">Account Routing</TabsTrigger>
            </TabsList>

            <TabsContent value="processors" className="space-y-4">
              {processors.map((processor) => (
                <div key={processor.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">{processor.name}</h3>
                    <p className="text-sm text-gray-600">Balance: {processor.balance}</p>
                    {processor.accountId && (
                      <p className="text-xs text-gray-500">ID: {processor.accountId}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={processor.status === 'connected' ? 'default' : 'secondary'}>
                      {processor.status}
                    </Badge>
                    {processor.status !== 'connected' && (
                      <Button size="sm" onClick={() => connectProcessor(processor.id)}>
                        Connect
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="card-transfer" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Input
                  placeholder="Card Number"
                  value={cardForm.cardNumber}
                  onChange={(e) => setCardForm({...cardForm, cardNumber: e.target.value})}
                />
                <Input
                  placeholder="MM/YY"
                  value={cardForm.expiryDate}
                  onChange={(e) => setCardForm({...cardForm, expiryDate: e.target.value})}
                />
                <Input
                  placeholder="CVV"
                  value={cardForm.cvv}
                  onChange={(e) => setCardForm({...cardForm, cvv: e.target.value})}
                />
                <Input
                  placeholder="Cardholder Name"
                  value={cardForm.holderName}
                  onChange={(e) => setCardForm({...cardForm, holderName: e.target.value})}
                />
                <Input
                  placeholder="Amount"
                  value={cardForm.amount}
                  onChange={(e) => setCardForm({...cardForm, amount: e.target.value})}
                />
                <select 
                  className="px-3 py-2 border rounded-md"
                  value={cardForm.transferType}
                  onChange={(e) => setCardForm({...cardForm, transferType: e.target.value})}
                >
                  <option value="debit">Debit Transfer</option>
                  <option value="credit">Credit Transfer</option>
                </select>
              </div>
              <Button onClick={handleCardTransfer} className="w-full">
                Process {cardForm.transferType === 'debit' ? 'Debit' : 'Credit'} Transfer
              </Button>
            </TabsContent>

            <TabsContent value="routing" className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">Dwolla ACH Routing</h3>
                  <p className="text-sm">Account: dwolla_12345 → Trust Banking (****1234)</p>
                  <Badge variant="outline">Active</Badge>
                </div>
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">Stripe Connect Routing</h3>
                  <p className="text-sm">Account: acct_1234567890 → Operating Account (****5678)</p>
                  <Badge variant="outline">Active</Badge>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentProcessorIntegration;