import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import { DollarSign } from 'lucide-react';
import { toast } from 'sonner';

interface ManualPayoutModalProps {
  onClose: () => void;
}

export function ManualPayoutModal({ onClose }: ManualPayoutModalProps) {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccount, setSelectedAccount] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('usd');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadAccounts();
  }, []);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('stripe_connect_accounts')
      .select('*')
      .eq('status', 'active')
      .eq('payouts_enabled', true);
    
    setAccounts(data || []);
  };

  const handleTriggerPayout = async () => {
    if (!selectedAccount || !amount) {
      toast.error('Please select account and enter amount');
      return;
    }

    const amountInCents = Math.round(parseFloat(amount) * 100);
    if (amountInCents < 100) {
      toast.error('Minimum payout amount is $1.00');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'trigger_payout',
          data: {
            accountId: selectedAccount,
            amount: amountInCents,
            currency
          },
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });

      if (error) throw error;
      toast.success('Payout triggered successfully');
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Manual Payout</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Account</label>
            <Select value={selectedAccount} onValueChange={setSelectedAccount}>
              <SelectTrigger>
                <SelectValue placeholder="Choose account..." />
              </SelectTrigger>
              <SelectContent>
                {accounts.map((account) => (
                  <SelectItem key={account.id} value={account.id}>
                    {account.email} - {account.business_type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Amount</label>
            <Input
              type="number"
              step="0.01"
              min="1"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Currency</label>
            <Select value={currency} onValueChange={setCurrency}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="usd">USD</SelectItem>
                <SelectItem value="eur">EUR</SelectItem>
                <SelectItem value="gbp">GBP</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleTriggerPayout}
            disabled={loading}
            className="w-full bg-green-600"
          >
            <DollarSign className="w-4 h-4 mr-2" />
            Trigger Payout
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}