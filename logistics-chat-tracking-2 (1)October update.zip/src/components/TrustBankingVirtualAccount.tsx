import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield, Building2, ArrowRightLeft, Copy, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface VirtualTrustAccount {
  id: string;
  name: string;
  type: 'trust_main' | 'escrow' | 'fiduciary';
  virtualNumber: string;
  routingNumber: string;
  balance: number;
  status: 'active' | 'pending' | 'restricted';
  complianceLevel: 'standard' | 'enhanced' | 'regulatory';
  createdAt: string;
}

const TrustBankingVirtualAccount: React.FC = () => {
  const [virtualAccounts, setVirtualAccounts] = useState<VirtualTrustAccount[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<string>('');
  const [transferAmount, setTransferAmount] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadVirtualAccounts();
  }, []);

  const loadVirtualAccounts = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'getTrustVirtualAccounts' }
      });

      if (error) throw error;

      if (data?.success) {
        setVirtualAccounts(data.data);
      } else {
        setVirtualAccounts([
          {
            id: 'trust-main-2024',
            name: 'Alaziel Trust Banking - Main Account',
            type: 'trust_main',
            virtualNumber: '4472-8901-3456-7890',
            routingNumber: '021000021',
            balance: 8750000.00,
            status: 'active',
            complianceLevel: 'regulatory',
            createdAt: new Date().toISOString()
          },
          {
            id: 'escrow-main-2024',
            name: 'Alaziel Escrow Services - Main Account',
            type: 'escrow',
            virtualNumber: '5573-9012-4567-8901',
            routingNumber: '031176110',
            balance: 2450000.00,
            status: 'active',
            complianceLevel: 'enhanced',
            createdAt: new Date().toISOString()
          }
        ]);
      }
    } catch (error) {
      console.error('Error loading virtual accounts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const executeTransfer = async () => {
    if (!selectedAccount || !transferAmount) {
      toast({ title: 'Error', description: 'Please fill all transfer details', variant: 'destructive' });
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'executeTrustTransfer',
          accountId: selectedAccount,
          amount: parseFloat(transferAmount)
        }
      });

      if (error) throw error;

      toast({ 
        title: 'Transfer Initiated', 
        description: `Transfer of $${parseFloat(transferAmount).toLocaleString()} initiated successfully`,
        variant: 'default' 
      });

      setTransferAmount('');
      await loadVirtualAccounts();
    } catch (error) {
      console.error('Transfer error:', error);
      toast({ title: 'Transfer Failed', description: 'Failed to execute transfer', variant: 'destructive' });
    }
  };

  const copyAccountInfo = (account: VirtualTrustAccount) => {
    const info = `${account.name}\nAccount: ${account.virtualNumber}\nRouting: ${account.routingNumber}`;
    navigator.clipboard.writeText(info);
    toast({ title: 'Copied', description: 'Account information copied to clipboard' });
  };

  const getAccountTypeColor = (type: string) => {
    switch (type) {
      case 'trust_main': return 'bg-blue-600';
      case 'escrow': return 'bg-emerald-600';
      case 'fiduciary': return 'bg-purple-600';
      default: return 'bg-gray-600';
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-gray-800 border-blue-500/30">
        <CardContent className="p-6">
          <div className="text-center text-blue-400">Loading trust banking accounts...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Trust Banking Virtual Accounts
            <Lock className="h-4 w-4 text-red-400" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {virtualAccounts.map((account) => (
              <Card key={account.id} className="bg-gray-700 border-blue-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-blue-300 text-sm flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4" />
                      {account.name}
                    </div>
                    <Lock className="h-3 w-3 text-red-400" />
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Account:</span>
                      <span className="text-blue-400 font-mono">{account.virtualNumber}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Routing:</span>
                      <span className="text-blue-400 font-mono">{account.routingNumber}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Balance:</span>
                      <span className="text-emerald-400 font-bold">
                        ${account.balance.toLocaleString()}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    <Badge className={getAccountTypeColor(account.type)}>
                      {account.type.replace('_', ' ').toUpperCase()}
                    </Badge>
                    <Badge className={account.status === 'active' ? 'bg-green-600' : 'bg-red-600'}>
                      {account.status.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <Button
                    onClick={() => copyAccountInfo(account)}
                    variant="outline"
                    size="sm"
                    className="w-full border-blue-500/30 text-blue-400 hover:bg-blue-900/20"
                  >
                    <Copy className="h-3 w-3 mr-1" />
                    Copy Account Info
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5" />
            Legal Transfer Options
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-emerald-300">Source Account</Label>
              <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                <SelectTrigger className="bg-gray-700 border-emerald-500/30 text-white">
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {virtualAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name} - ${account.balance.toLocaleString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-emerald-300">Transfer Amount ($)</Label>
              <Input
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-gray-700 border-emerald-500/30 text-white"
              />
            </div>
          </div>
          
          <Button
            onClick={executeTransfer}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
          >
            Execute Legal Transfer
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrustBankingVirtualAccount;