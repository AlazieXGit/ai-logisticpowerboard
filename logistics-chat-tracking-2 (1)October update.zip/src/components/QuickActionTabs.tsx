import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Play, Pause, Square, Zap, Activity, Bot, 
  Truck, Heart, DollarSign, TrendingUp 
} from 'lucide-react';

const QuickActionTabs: React.FC = () => {
  const [aiStates, setAiStates] = useState({
    loadMatching: 'stopped',
    forecasting: 'stopped',
    medical: 'stopped',
    transportation: 'stopped'
  });

  const [performanceBoost, setPerformanceBoost] = useState(false);

  const toggleAI = (system: string) => {
    setAiStates(prev => ({
      ...prev,
      [system]: prev[system as keyof typeof prev] === 'running' ? 'paused' : 'running'
    }));
  };

  const stopAI = (system: string) => {
    setAiStates(prev => ({
      ...prev,
      [system]: 'stopped'
    }));
  };

  const activate200xBoost = () => {
    setPerformanceBoost(true);
    setTimeout(() => setPerformanceBoost(false), 5000);
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'running': return 'bg-green-600';
      case 'paused': return 'bg-yellow-600';
      default: return 'bg-red-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/30 border-blue-500">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Bot className="h-5 w-5" />
            AI ALAZIE XPRESS - Quick Action Control Center
          </CardTitle>

        </CardHeader>
        <CardContent>
          <Tabs defaultValue="ai-systems" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-700">
              <TabsTrigger value="ai-systems">AI Systems</TabsTrigger>
              <TabsTrigger value="load-matching">Load Matching</TabsTrigger>
              <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
              <TabsTrigger value="medical-transport">Medical/Transport</TabsTrigger>
            </TabsList>

            <TabsContent value="ai-systems" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(aiStates).map(([system, status]) => (
                  <Card key={system} className="bg-gray-700/50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-white capitalize">{system.replace(/([A-Z])/g, ' $1')}</h4>
                        <Badge className={getStatusColor(status)}>
                          {status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => toggleAI(system)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          {status === 'running' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => stopAI(system)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Square className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="load-matching" className="space-y-4">
              <Card className="bg-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-cyan-400 flex items-center gap-2">
                    <Truck className="h-5 w-5" />
                    AI Load Matching System
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">System Status:</span>
                    <Badge className={getStatusColor(aiStates.loadMatching)}>
                      {aiStates.loadMatching.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      onClick={() => toggleAI('loadMatching')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Start
                    </Button>
                    <Button
                      onClick={() => toggleAI('loadMatching')}
                      className="bg-yellow-600 hover:bg-yellow-700"
                    >
                      <Pause className="h-4 w-4 mr-2" />
                      Pause
                    </Button>
                    <Button
                      onClick={() => stopAI('loadMatching')}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      <Square className="h-4 w-4 mr-2" />
                      Stop
                    </Button>
                  </div>
                  <Button
                    onClick={activate200xBoost}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    disabled={performanceBoost}
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    200x Performance Boost
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="forecasting" className="space-y-4">
              <Card className="bg-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Futuristic Load Forecasting
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Forecasting Status:</span>
                    <Badge className={getStatusColor(aiStates.forecasting)}>
                      {aiStates.forecasting.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      onClick={() => toggleAI('forecasting')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Start
                    </Button>
                    <Button
                      onClick={() => toggleAI('forecasting')}
                      className="bg-yellow-600 hover:bg-yellow-700"
                    >
                      <Pause className="h-4 w-4 mr-2" />
                      Pause
                    </Button>
                    <Button
                      onClick={() => stopAI('forecasting')}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      <Square className="h-4 w-4 mr-2" />
                      Stop
                    </Button>
                  </div>
                  <Button
                    onClick={activate200xBoost}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    disabled={performanceBoost}
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    200x Revenue Boost
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="medical-transport" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-gray-700/50">
                  <CardHeader>
                    <CardTitle className="text-red-400 flex items-center gap-2">
                      <Heart className="h-5 w-5" />
                      AI Medical System
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Medical AI:</span>
                      <Badge className={getStatusColor(aiStates.medical)}>
                        {aiStates.medical.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <Button
                        size="sm"
                        onClick={() => toggleAI('medical')}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Play className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => toggleAI('medical')}
                        className="bg-yellow-600 hover:bg-yellow-700"
                      >
                        <Pause className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => stopAI('medical')}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        <Square className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-700/50">
                  <CardHeader>
                    <CardTitle className="text-blue-400 flex items-center gap-2">
                      <Truck className="h-5 w-5" />
                      Transport Control
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Transport AI:</span>
                      <Badge className={getStatusColor(aiStates.transportation)}>
                        {aiStates.transportation.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <Button
                        size="sm"
                        onClick={() => toggleAI('transportation')}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Play className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => toggleAI('transportation')}
                        className="bg-yellow-600 hover:bg-yellow-700"
                      >
                        <Pause className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => stopAI('transportation')}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        <Square className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Button
                onClick={activate200xBoost}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                disabled={performanceBoost}
              >
                <Zap className="h-4 w-4 mr-2" />
                200x Medical Transport Revenue Boost
              </Button>
            </TabsContent>
          </Tabs>

          {performanceBoost && (
            <div className="mt-4 p-4 bg-gradient-to-r from-purple-900 to-pink-900 rounded-lg border border-purple-500">
              <div className="flex items-center gap-2 text-purple-300">
                <Activity className="h-5 w-5 animate-pulse" />
                <span className="font-bold">200x PERFORMANCE BOOST ACTIVE!</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default QuickActionTabs;