import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { CreditCard, ArrowRight, DollarSign, Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import CardManagementSection from './CardManagementSection';

const ManualCardTransferForum = () => {
  const [selectedInternalCard, setSelectedInternalCard] = useState('primary-account-1');
  const [selectedCardId, setSelectedCardId] = useState('card-1');
  
  // Primary Account and Escrow Operations Debit Cards for Stripe Connection
  const [internalCards, setInternalCards] = useState([
    {
      id: 'primary-account-1',
      cardNumber: '4031631245486508',
      expiryDate: '06/30',
      cvv: '379',
      cardholderName: 'Alucius Alford - Primary Account',
      bankName: 'Wells Fargo Primary Banking',
      routingNumber: '021000021',
      accountNumber: '1234567890',
      processor: 'Stripe',
      balance: 125000.00,
      cardType: 'Debit',
      isEditable: true,
      accountType: 'Primary'
    },
    {
      id: 'primary-account-2',
      cardNumber: '4532015112830366',
      expiryDate: '12/28',
      cvv: '842',
      cardholderName: 'Alazie Xpress - Primary Business',
      bankName: 'PNC Bank Primary',
      routingNumber: '043000096',
      accountNumber: '9876543210',
      processor: 'Stripe',
      balance: 89500.00,
      cardType: 'Debit',
      isEditable: true,
      accountType: 'Primary'
    },
    {
      id: 'escrow-ops-1',
      cardNumber: '5555555555554444',
      expiryDate: '09/27',
      cvv: '123',
      cardholderName: 'Escrow Operations - Trust Account',
      bankName: 'Chase Escrow Banking',
      routingNumber: '021000021',
      accountNumber: '5555444433',
      processor: 'Stripe',
      balance: 234500.00,
      cardType: 'Debit',
      isEditable: true,
      accountType: 'Escrow'
    },
    {
      id: 'escrow-ops-2',
      cardNumber: '4111111111111111',
      expiryDate: '03/29',
      cvv: '456',
      cardholderName: 'Escrow Operations - Secondary',
      bankName: 'Bank of America Escrow',
      routingNumber: '026009593',
      accountNumber: '1111222233',
      processor: 'Stripe',
      balance: 156700.00,
      cardType: 'Debit',
      isEditable: true,
      accountType: 'Escrow'
    },
    {
      id: 'stripe-connect-1',
      cardNumber: '4242424242424242',
      expiryDate: '12/25',
      cvv: '123',
      cardholderName: 'Stripe Connect - External Bridge',
      bankName: 'Stripe Banking Services',
      routingNumber: '110000000',
      accountNumber: '4242424242',
      processor: 'Stripe',
      balance: 75000.00,
      cardType: 'Debit',
      isEditable: true,
      accountType: 'External Bridge'
    },
    {
      id: 'stripe-direct-1',
      cardNumber: '4000000000000002',
      expiryDate: '08/26',
      cvv: '789',
      cardholderName: 'Stripe Direct - External Debit Connection',
      bankName: 'Stripe Direct Banking',
      routingNumber: '110000001',
      accountNumber: '4000000002',
      processor: 'Stripe',
      balance: 45000.00,
      cardType: 'Debit',
      isEditable: true,
      accountType: 'External Connection'
    }
  ]);

  const [cards, setCards] = useState([
    {
      id: 'card-1',
      cardNumber: '4031631245486508',
      expiryDate: '06/30',
      cvv: '379',
      cardholderName: 'Alucius Alford',
      cardType: 'Credit' as 'Credit' | 'Debit',
      isActive: true
    }
  ]);

  const [senderInfo, setSenderInfo] = useState({
    cardNumber: '4031631245486508',
    expiry: '06/30',
    cvv: '379',
    name: 'Alucius Alford',
    billingAddress: '123 Primary Banking St, Wells Fargo Plaza, Charlotte, NC 28202',
    ssn: '123-45-6789',
    pin: '1234',
    bankRouting: '021000021',
    bankAccount: '1234567890',
    motherMaiden: 'Johnson',
    dateOfBirth: '01/15/1985'
  });

  const [receiverInfo, setReceiverInfo] = useState({
    cardNumber: '4031631245486508',
    expiry: '06/30',
    cvv: '379',
    name: 'Alucius Alford',
    billingAddress: '123 Primary Banking St, Wells Fargo Plaza, Charlotte, NC 28202',
    bankRouting: '021000021',
    bankAccount: '1234567890'
  });

  const [transferData, setTransferData] = useState({
    sourceAccount: '',
    amount: '7777',
    memo: ''
  });

  const [transferHistory, setTransferHistory] = useState([
    {
      id: 'TXN-001',
      date: '2024-01-15',
      sourceAccount: 'Trust Banking Fee Collection',
      targetCard: '**** **** **** 6508',
      targetName: 'Alucius Alford',
      amount: 2500.00,
      status: 'Completed',
      processor: 'Stripe'
    }
  ]);

  const internalAccounts = [
    { id: 'trust-fee', name: 'Trust Banking Fee Collection', balance: 125000.00, processor: 'Stripe' },
    { id: 'escrow-op', name: 'Escrow Account - Operating', balance: 89500.00, processor: 'Dwolla ACH' },
    { id: 'revenue-primary', name: 'Primary Revenue Account', balance: 234500.00, processor: 'Dwolla ACH' }
  ];

  const updateInternalCard = (cardId: string, field: string, value: string) => {
    setInternalCards(prev => prev.map(card => 
      card.id === cardId ? { ...card, [field]: value } : card
    ));
  };

  const handleTransfer = () => {
    const newTransfer = {
      id: `TXN-${String(transferHistory.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      sourceAccount: internalAccounts.find(acc => acc.id === transferData.sourceAccount)?.name || '',
      targetCard: `**** **** **** ${receiverInfo.cardNumber.slice(-4)}`,
      targetName: receiverInfo.name,
      amount: parseFloat(transferData.amount),
      status: 'Processing',
      processor: internalAccounts.find(acc => acc.id === transferData.sourceAccount)?.processor || 'Stripe'
    };

    setTransferHistory([newTransfer, ...transferHistory]);
  };

  return (
    <div className="space-y-6">
      <CardManagementSection
        cards={cards}
        onCardsUpdate={setCards}
        selectedCardId={selectedCardId}
        onCardSelect={(cardId) => setSelectedCardId(cardId)}
      />

      <Card className="border-2 border-red-200">
        <CardHeader className="bg-gradient-to-r from-red-50 to-orange-50">
          <CardTitle className="flex items-center gap-2 text-red-800">
            <AlertTriangle className="w-5 h-5" />
            Manual Card Transfer Forum - Complete Sensitive Data Collection
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            
            {/* Internal Source Account with Card Information */}
            <div className="space-y-4">
              <h3 className="font-semibold text-green-800 flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-600" />
                Internal Source of Funds - Account & Card Details
              </h3>
              
              <Select value={transferData.sourceAccount} onValueChange={(value) => 
                setTransferData({...transferData, sourceAccount: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select internal account" />
                </SelectTrigger>
                <SelectContent>
                  {internalAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      <div className="flex flex-col">
                        <span>{account.name}</span>
                        <span className="text-sm text-green-600">${account.balance.toLocaleString()}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {/* Multiple Internal Banking System Cards Selection */}
              <div className="space-y-3">
                <Label className="text-green-800 font-semibold">Select Internal Banking Card</Label>
                <Select value={selectedInternalCard} onValueChange={setSelectedInternalCard}>
                  <SelectTrigger className="border-green-300">
                    <SelectValue placeholder="Choose internal banking card" />
                  </SelectTrigger>
                  <SelectContent>
                    {internalCards.map((card) => (
                      <SelectItem key={card.id} value={card.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">{card.cardholderName}</span>
                          <span className="text-sm text-green-600">**** **** **** {card.cardNumber.slice(-4)} • {card.processor}</span>
                          <span className="text-xs text-gray-500">${card.balance.toLocaleString()} • {card.cardType}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Editable Internal Card Information */}
              {selectedInternalCard && (
                <div className="bg-green-50 border-2 border-green-300 p-4 rounded-lg space-y-3">
                  <h4 className="font-medium text-green-800 flex items-center gap-2">
                    <CreditCard className="w-4 h-4" />
                    Editable Internal Card Details - {internalCards.find(c => c.id === selectedInternalCard)?.processor}
                  </h4>
                  
                  <div className="space-y-3">
                    <Input
                      placeholder="Internal Card Number"
                      value={internalCards.find(c => c.id === selectedInternalCard)?.cardNumber || ''}
                      onChange={(e) => updateInternalCard(selectedInternalCard, 'cardNumber', e.target.value)}
                      className="border-green-300 bg-white font-mono"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="MM/YY"
                        value={internalCards.find(c => c.id === selectedInternalCard)?.expiryDate || ''}
                        onChange={(e) => updateInternalCard(selectedInternalCard, 'expiryDate', e.target.value)}
                        className="border-green-300 bg-white"
                      />
                      <Input
                        placeholder="CVV"
                        value={internalCards.find(c => c.id === selectedInternalCard)?.cvv || ''}
                        onChange={(e) => updateInternalCard(selectedInternalCard, 'cvv', e.target.value)}
                        className="border-green-300 bg-white"
                      />
                    </div>
                    <Input
                      placeholder="Cardholder Name"
                      value={internalCards.find(c => c.id === selectedInternalCard)?.cardholderName || ''}
                      onChange={(e) => updateInternalCard(selectedInternalCard, 'cardholderName', e.target.value)}
                      className="border-green-300 bg-white"
                    />
                    <Input
                      placeholder="Bank Name"
                      value={internalCards.find(c => c.id === selectedInternalCard)?.bankName || ''}
                      onChange={(e) => updateInternalCard(selectedInternalCard, 'bankName', e.target.value)}
                      className="border-green-300 bg-white"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="Routing Number"
                        value={internalCards.find(c => c.id === selectedInternalCard)?.routingNumber || ''}
                        onChange={(e) => updateInternalCard(selectedInternalCard, 'routingNumber', e.target.value)}
                        className="border-green-300 bg-white font-mono"
                      />
                      <Input
                        placeholder="Account Number"
                        value={internalCards.find(c => c.id === selectedInternalCard)?.accountNumber || ''}
                        onChange={(e) => updateInternalCard(selectedInternalCard, 'accountNumber', e.target.value)}
                        className="border-green-300 bg-white font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Select 
                        value={internalCards.find(c => c.id === selectedInternalCard)?.processor || ''} 
                        onValueChange={(value) => updateInternalCard(selectedInternalCard, 'processor', value)}
                      >
                        <SelectTrigger className="border-green-300 bg-white">
                          <SelectValue placeholder="Payment Processor" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Stripe">Stripe</SelectItem>
                          <SelectItem value="Plaid">Plaid</SelectItem>
                          <SelectItem value="Dwolla ACH">Dwolla ACH</SelectItem>
                          <SelectItem value="Stripe Connect">Stripe Connect</SelectItem>
                          <SelectItem value="Square">Square</SelectItem>
                          <SelectItem value="PayPal">PayPal</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select 
                        value={internalCards.find(c => c.id === selectedInternalCard)?.cardType || ''} 
                        onValueChange={(value) => updateInternalCard(selectedInternalCard, 'cardType', value)}
                      >
                        <SelectTrigger className="border-green-300 bg-white">
                          <SelectValue placeholder="Card Type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Debit">Debit Card</SelectItem>
                          <SelectItem value="Credit">Credit Card</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Input
                      placeholder="Available Balance"
                      type="number"
                      value={internalCards.find(c => c.id === selectedInternalCard)?.balance || 0}
                      onChange={(e) => updateInternalCard(selectedInternalCard, 'balance', e.target.value)}
                      className="border-green-300 bg-white"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>Transfer Amount</Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={transferData.amount}
                  onChange={(e) => setTransferData({...transferData, amount: e.target.value})}
                />
              </div>
            </div>

            {/* Sender's Complete Information */}
            <div className="space-y-4">
              <h3 className="font-semibold text-red-800">Complete Sender Information</h3>
              <div className="bg-red-50 border-2 border-red-300 p-4 rounded-lg space-y-3">
                <Input
                  placeholder="Full Card Number"
                  value={senderInfo.cardNumber}
                  onChange={(e) => setSenderInfo({...senderInfo, cardNumber: e.target.value})}
                  className="border-red-300"
                />
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="MM/YY"
                    value={senderInfo.expiry}
                    onChange={(e) => setSenderInfo({...senderInfo, expiry: e.target.value})}
                    className="border-red-300"
                  />
                  <Input
                    placeholder="CVV"
                    value={senderInfo.cvv}
                    onChange={(e) => setSenderInfo({...senderInfo, cvv: e.target.value})}
                    className="border-red-300"
                  />
                </div>
                <Input
                  placeholder="Cardholder Name"
                  value={senderInfo.name}
                  onChange={(e) => setSenderInfo({...senderInfo, name: e.target.value})}
                  className="border-red-300"
                />
                <Textarea
                  placeholder="Complete Billing Address"
                  value={senderInfo.billingAddress}
                  onChange={(e) => setSenderInfo({...senderInfo, billingAddress: e.target.value})}
                  className="border-red-300"
                />
                <Input
                  placeholder="SSN (XXX-XX-XXXX)"
                  value={senderInfo.ssn}
                  onChange={(e) => setSenderInfo({...senderInfo, ssn: e.target.value})}
                  className="border-red-300"
                />
                <Input
                  type="password"
                  placeholder="Card PIN"
                  value={senderInfo.pin}
                  onChange={(e) => setSenderInfo({...senderInfo, pin: e.target.value})}
                  className="border-red-300"
                />
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Bank Routing #"
                    value={senderInfo.bankRouting}
                    onChange={(e) => setSenderInfo({...senderInfo, bankRouting: e.target.value})}
                    className="border-red-300"
                  />
                  <Input
                    placeholder="Bank Account #"
                    value={senderInfo.bankAccount}
                    onChange={(e) => setSenderInfo({...senderInfo, bankAccount: e.target.value})}
                    className="border-red-300"
                  />
                </div>
              </div>
            </div>

            {/* Receiver's External Account Information */}
            <div className="space-y-4">
              <h3 className="font-semibold text-blue-800">External Receiver Information</h3>
              <div className="bg-blue-50 border-2 border-blue-300 p-4 rounded-lg space-y-3">
                <Input
                  placeholder="Receiver Card Number"
                  value={receiverInfo.cardNumber}
                  onChange={(e) => setReceiverInfo({...receiverInfo, cardNumber: e.target.value})}
                  className="border-blue-300"
                />
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="MM/YY"
                    value={receiverInfo.expiry}
                    onChange={(e) => setReceiverInfo({...receiverInfo, expiry: e.target.value})}
                    className="border-blue-300"
                  />
                  <Input
                    placeholder="CVV"
                    value={receiverInfo.cvv}
                    onChange={(e) => setReceiverInfo({...receiverInfo, cvv: e.target.value})}
                    className="border-blue-300"
                  />
                </div>
                <Input
                  placeholder="Receiver Name"
                  value={receiverInfo.name}
                  onChange={(e) => setReceiverInfo({...receiverInfo, name: e.target.value})}
                  className="border-blue-300"
                />
                <Textarea
                  placeholder="Receiver Billing Address"
                  value={receiverInfo.billingAddress}
                  onChange={(e) => setReceiverInfo({...receiverInfo, billingAddress: e.target.value})}
                  className="border-blue-300"
                />
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Bank Routing #"
                    value={receiverInfo.bankRouting}
                    onChange={(e) => setReceiverInfo({...receiverInfo, bankRouting: e.target.value})}
                    className="border-blue-300"
                  />
                  <Input
                    placeholder="Bank Account #"
                    value={receiverInfo.bankAccount}
                    onChange={(e) => setReceiverInfo({...receiverInfo, bankAccount: e.target.value})}
                    className="border-blue-300"
                  />
                </div>
              </div>

              <div className="flex items-center justify-center py-2">
                <div className="flex items-center gap-2 text-purple-600">
                  <span className="text-sm font-medium">Internal</span>
                  <ArrowRight className="w-4 h-4" />
                  <span className="text-sm font-medium">External</span>
                </div>
              </div>

              <Button 
                onClick={handleTransfer}
                className="w-full bg-red-600 hover:bg-red-700"
                disabled={!transferData.sourceAccount || !transferData.amount}
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Process Sensitive Transfer
              </Button>
            </div>
          </div>

          <div className="mt-6 bg-red-100 border-2 border-red-300 p-4 rounded-lg">
            <p className="text-red-800 font-bold text-center">
              ⚠️ CRITICAL: All sensitive financial data, personal information, and security codes are being collected for external transfer processing
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Transfer History */}
      <Card>
        <CardHeader>
          <CardTitle>Transfer History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {transferHistory.map((transfer) => (
              <div key={transfer.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-1">
                  <div className="font-medium">{transfer.sourceAccount} → {transfer.targetCard}</div>
                  <div className="text-sm text-gray-600">{transfer.targetName} • {transfer.date}</div>
                  <Badge variant="outline">{transfer.processor}</Badge>
                </div>
                <div className="text-right space-y-1">
                  <div className="font-bold text-green-600">${transfer.amount.toLocaleString()}</div>
                  <Badge variant={transfer.status === 'Completed' ? 'default' : 'secondary'}>
                    {transfer.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ManualCardTransferForum;