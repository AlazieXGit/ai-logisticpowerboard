import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bot, 
  Zap, 
  Settings, 
  Play, 
  Pause, 
  RotateCcw,
  CheckCircle,
  AlertCircle,
  Clock,
  TrendingUp
} from 'lucide-react';

interface WorkflowTask {
  id: string;
  name: string;
  status: 'running' | 'paused' | 'completed' | 'error';
  progress: number;
  aiDuty: string;
  revenue: number;
  efficiency: number;
}

export const IntelligentAutomationHub: React.FC = () => {
  const [workflows, setWorkflows] = useState<WorkflowTask[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [totalRevenue, setTotalRevenue] = useState(0);

  useEffect(() => {
    loadWorkflows();
    const interval = setInterval(loadWorkflows, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadWorkflows = () => {
    const mockWorkflows: WorkflowTask[] = [
      {
        id: '1',
        name: 'Credit Score Analysis',
        status: 'running',
        progress: 78,
        aiDuty: 'Analyze credit reports and generate improvement strategies',
        revenue: 2500,
        efficiency: 94
      },
      {
        id: '2',
        name: 'Transaction Monitoring',
        status: 'running',
        progress: 92,
        aiDuty: 'Monitor real-time transactions for fraud detection',
        revenue: 1800,
        efficiency: 98
      },
      {
        id: '3',
        name: 'Revenue Optimization',
        status: 'completed',
        progress: 100,
        aiDuty: 'Optimize fee structures and revenue routing',
        revenue: 3200,
        efficiency: 96
      },
      {
        id: '4',
        name: 'Client Onboarding',
        status: 'running',
        progress: 45,
        aiDuty: 'Automate client verification and account setup',
        revenue: 1200,
        efficiency: 89
      },
      {
        id: '5',
        name: 'Dispute Letter Generation',
        status: 'paused',
        progress: 23,
        aiDuty: 'Generate personalized credit dispute letters',
        revenue: 950,
        efficiency: 87
      }
    ];
    
    setWorkflows(mockWorkflows);
    setTotalRevenue(mockWorkflows.reduce((sum, w) => sum + w.revenue, 0));
  };

  const toggleWorkflow = (id: string) => {
    setWorkflows(prev => prev.map(w => 
      w.id === id 
        ? { ...w, status: w.status === 'running' ? 'paused' : 'running' }
        : w
    ));
  };

  const restartWorkflow = (id: string) => {
    setWorkflows(prev => prev.map(w => 
      w.id === id 
        ? { ...w, status: 'running', progress: 0 }
        : w
    ));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running': return <Play className="h-4 w-4 text-green-400" />;
      case 'paused': return <Pause className="h-4 w-4 text-yellow-400" />;
      case 'completed': return <CheckCircle className="h-4 w-4 text-blue-400" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-400" />;
      default: return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-600';
      case 'paused': return 'bg-yellow-600';
      case 'completed': return 'bg-blue-600';
      case 'error': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Intelligent Automation Hub</h2>
          <p className="text-gray-400">AI-Powered Workflow Management & Revenue Generation</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="bg-green-600">
            ${totalRevenue.toLocaleString()} Daily Revenue
          </Badge>
          <Button onClick={loadWorkflows} disabled={isLoading} className="bg-blue-600 hover:bg-blue-700">
            <RotateCcw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Active Workflows</CardTitle>
            <Bot className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{workflows.filter(w => w.status === 'running').length}</div>
            <p className="text-xs text-blue-400">AI processes running</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Efficiency Rate</CardTitle>
            <Zap className="h-4 w-4 text-yellow-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {Math.round(workflows.reduce((sum, w) => sum + w.efficiency, 0) / workflows.length)}%
            </div>
            <p className="text-xs text-yellow-400">Average performance</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Revenue Generated</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-green-400">Today's automation revenue</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Completed Tasks</CardTitle>
            <CheckCircle className="h-4 w-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{workflows.filter(w => w.status === 'completed').length}</div>
            <p className="text-xs text-purple-400">Successfully finished</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="workflows" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="workflows">Active Workflows</TabsTrigger>
          <TabsTrigger value="ai-duties">AI Duties</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="workflows" className="space-y-4">
          <div className="grid gap-4">
            {workflows.map((workflow) => (
              <Card key={workflow.id} className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(workflow.status)}
                      <CardTitle className="text-white">{workflow.name}</CardTitle>
                      <Badge className={getStatusColor(workflow.status)}>
                        {workflow.status.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        ${workflow.revenue}
                      </Badge>
                      <Badge variant="outline" className="text-blue-400 border-blue-400">
                        {workflow.efficiency}% Efficiency
                      </Badge>
                    </div>
                  </div>
                  <CardDescription className="text-gray-400">
                    {workflow.aiDuty}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-300">Progress</span>
                        <span className="text-white">{workflow.progress}%</span>
                      </div>
                      <Progress value={workflow.progress} className="h-2" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        onClick={() => toggleWorkflow(workflow.id)}
                        className={workflow.status === 'running' ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-green-600 hover:bg-green-700'}
                      >
                        {workflow.status === 'running' ? <Pause className="h-4 w-4 mr-1" /> : <Play className="h-4 w-4 mr-1" />}
                        {workflow.status === 'running' ? 'Pause' : 'Start'}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => restartWorkflow(workflow.id)}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Restart
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Settings className="h-4 w-4 mr-1" />
                        Configure
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ai-duties" className="space-y-4">
          <div className="grid gap-4">
            {workflows.map((workflow) => (
              <Card key={workflow.id} className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Bot className="h-5 w-5 mr-2 text-blue-400" />
                    {workflow.name} - AI Responsibilities
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-gray-300">{workflow.aiDuty}</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">Performance: {workflow.efficiency}%</Badge>
                      <Badge variant="secondary">Revenue Impact: ${workflow.revenue}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Automation Revenue Breakdown</CardTitle>
              <CardDescription className="text-gray-400">Revenue generated by each AI workflow</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {workflows.map((workflow) => (
                  <div key={workflow.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(workflow.status)}
                      <span className="text-white font-medium">{workflow.name}</span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        ${workflow.revenue}
                      </Badge>
                      <div className="w-24">
                        <Progress value={(workflow.revenue / Math.max(...workflows.map(w => w.revenue))) * 100} className="h-2" />
                      </div>
                    </div>
                  </div>
                ))}
                <div className="border-t border-gray-600 pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-white">Total Daily Revenue</span>
                    <Badge className="bg-green-600 text-lg px-3 py-1">
                      ${totalRevenue.toLocaleString()}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};