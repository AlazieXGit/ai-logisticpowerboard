import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, Zap, Bot, Code, Database, Shield, CreditCard, Users, BarChart3, Sparkles } from 'lucide-react';

const SynergyAIPlatform: React.FC = () => {
  const [activeService, setActiveService] = useState<string>('overview');

  const services = [
    {
      id: 'ai-assistant',
      name: 'AI Assistant Pro',
      icon: <Bot className="h-6 w-6" />,
      price: '$49/month',
      category: 'AI Services',
      description: 'Advanced AI assistant with natural language processing',
      revenue: 2450,
      features: ['24/7 AI Support', 'Multi-language', 'Custom Training', 'API Access']
    },
    {
      id: 'code-generator',
      name: 'Code Generator',
      icon: <Code className="h-6 w-6" />,
      category: 'Development',
      price: '$99/month',
      description: 'AI-powered code generation and optimization',
      revenue: 4950,
      features: ['Multi-language Support', 'Code Review', 'Auto-completion', 'Debugging']
    },
    {
      id: 'data-analytics',
      name: 'Data Analytics Suite',
      icon: <BarChart3 className="h-6 w-6" />,
      category: 'Analytics',
      price: '$149/month',
      description: 'Comprehensive data analysis and visualization',
      revenue: 7450,
      features: ['Real-time Analytics', 'Custom Dashboards', 'Predictive Models', 'Export Tools']
    },
    {
      id: 'security-shield',
      name: 'Security Shield',
      icon: <Shield className="h-6 w-6" />,
      category: 'Security',
      price: '$199/month',
      description: 'Advanced AI-powered security monitoring',
      revenue: 9950,
      features: ['Threat Detection', 'Real-time Monitoring', 'Incident Response', 'Compliance']
    }
  ];

  const totalRevenue = services.reduce((sum, service) => sum + service.revenue, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-purple-400 to-pink-400 p-3 rounded-full mr-4">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              SYNERGY AI
            </h1>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Next-generation AI platform powering intelligent automation, advanced analytics, and seamless integration
          </p>
        </div>

        <Tabs value={activeService} onValueChange={setActiveService} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="bg-gradient-to-br from-purple-800/50 to-pink-800/50 border-purple-500/20">
                <CardHeader className="text-center">
                  <Users className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                  <CardTitle className="text-white">Active Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-purple-400 text-center">12,847</div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-800/50 to-cyan-800/50 border-blue-500/20">
                <CardHeader className="text-center">
                  <CreditCard className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                  <CardTitle className="text-white">Monthly Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-400 text-center">${totalRevenue.toLocaleString()}</div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-800/50 to-emerald-800/50 border-green-500/20">
                <CardHeader className="text-center">
                  <Zap className="h-8 w-8 text-green-400 mx-auto mb-2" />
                  <CardTitle className="text-white">API Calls</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-400 text-center">2.4M</div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-800/50 to-red-800/50 border-orange-500/20">
                <CardHeader className="text-center">
                  <Brain className="h-8 w-8 text-orange-400 mx-auto mb-2" />
                  <CardTitle className="text-white">AI Models</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-orange-400 text-center">47</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="services">
            <div className="grid md:grid-cols-2 gap-6">
              {services.map((service) => (
                <Card key={service.id} className="bg-slate-800/50 border-purple-500/20">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="text-purple-400 mr-3">{service.icon}</div>
                        <div>
                          <CardTitle className="text-white">{service.name}</CardTitle>
                          <Badge className="bg-purple-600/20 text-purple-300 mt-1">
                            {service.category}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-purple-400">{service.price}</div>
                        <div className="text-sm text-gray-400">Revenue: ${service.revenue}</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-300 mb-4">
                      {service.description}
                    </CardDescription>
                    <div className="space-y-2">
                      {service.features.map((feature, index) => (
                        <div key={index} className="flex items-center text-sm text-gray-300">
                          <div className="w-2 h-2 bg-purple-400 rounded-full mr-2"></div>
                          {feature}
                        </div>
                      ))}
                    </div>
                    <Button className="w-full mt-4 bg-gradient-to-r from-purple-600 to-pink-600">
                      Manage Service
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white">Revenue Analytics</CardTitle>
                <CardDescription className="text-gray-300">
                  Comprehensive revenue tracking across all Synergy AI services
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-400">${totalRevenue.toLocaleString()}</div>
                    <div className="text-gray-400">Total Monthly Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-400">+23.5%</div>
                    <div className="text-gray-400">Growth Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400">94.2%</div>
                    <div className="text-gray-400">Customer Retention</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white">Billing & Payments</CardTitle>
                <CardDescription className="text-gray-300">
                  Integrated payment processing for all Synergy AI services
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-purple-900/20 rounded-lg">
                    <span className="text-white">Primary Payment Account</span>
                    <Badge className="bg-green-600/20 text-green-300">Active</Badge>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-blue-900/20 rounded-lg">
                    <span className="text-white">Stripe Integration</span>
                    <Badge className="bg-blue-600/20 text-blue-300">Connected</Badge>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-orange-900/20 rounded-lg">
                    <span className="text-white">Revenue Collection</span>
                    <Badge className="bg-orange-600/20 text-orange-300">Automated</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white">Platform Settings</CardTitle>
                <CardDescription className="text-gray-300">
                  Configure Synergy AI platform preferences and integrations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
                    Configure API Access
                  </Button>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-600">
                    Manage Integrations
                  </Button>
                  <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600">
                    Security Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SynergyAIPlatform;