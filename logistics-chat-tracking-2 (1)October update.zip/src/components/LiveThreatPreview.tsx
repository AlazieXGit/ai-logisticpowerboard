import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertTriangle, Users, Activity } from 'lucide-react';
import SessionThreatMonitor from './SessionThreatMonitor';

interface ThreatData {
  id: string;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
  source: string;
  status: 'active' | 'resolved' | 'investigating';
}

const LiveThreatPreview: React.FC = () => {
  const [threats, setThreats] = useState<ThreatData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Mock data for demonstration
    const mockThreats: ThreatData[] = [
      {
        id: '1',
        type: 'Suspicious Login',
        severity: 'high',
        timestamp: new Date().toISOString(),
        source: '192.168.1.100',
        status: 'active'
      },
      {
        id: '2',
        type: 'Multiple Failed Attempts',
        severity: 'medium',
        timestamp: new Date(Date.now() - 300000).toISOString(),
        source: '10.0.0.50',
        status: 'investigating'
      }
    ];
    
    setTimeout(() => {
      setThreats(mockThreats);
      setIsLoading(false);
    }, 1000);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-emerald-400 mb-2">Live Threat Preview</h1>
          <p className="text-gray-400">Real-time security monitoring and threat detection</p>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800">
            <TabsTrigger value="overview" className="text-white data-[state=active]:bg-emerald-600">
              <Shield className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="threats" className="text-white data-[state=active]:bg-emerald-600">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Active Threats
            </TabsTrigger>
            <TabsTrigger value="sessions" className="text-white data-[state=active]:bg-emerald-600">
              <Users className="w-4 h-4 mr-2" />
              Session Monitor
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-white data-[state=active]:bg-emerald-600">
              <Activity className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-emerald-400 text-lg">System Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Security Level</span>
                      <Badge className="bg-emerald-600 text-white">SECURE</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Response Time</span>
                      <span className="text-emerald-400">&lt; 100ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Active Monitors</span>
                      <span className="text-emerald-400">24/7</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-emerald-400 text-lg">Threat Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Active Threats</span>
                      <span className="text-red-400">{threats.filter(t => t.status === 'active').length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Resolved Today</span>
                      <span className="text-emerald-400">12</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Under Investigation</span>
                      <span className="text-yellow-400">{threats.filter(t => t.status === 'investigating').length}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-emerald-400 text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                      Run Security Scan
                    </Button>
                    <Button className="w-full bg-gray-700 hover:bg-gray-600 text-white">
                      View Full Report
                    </Button>
                    <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                      Emergency Lockdown
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="threats" className="mt-6">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-emerald-400">Active Threat Detection</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-400 mx-auto"></div>
                    <p className="text-gray-400 mt-2">Loading threat data...</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {threats.map((threat) => (
                      <Alert key={threat.id} className="bg-gray-800 border-gray-600">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-semibold text-white">{threat.type}</h4>
                              <p className="text-gray-400 text-sm">Source: {threat.source}</p>
                              <p className="text-gray-400 text-sm">{new Date(threat.timestamp).toLocaleString()}</p>
                            </div>
                            <div className="flex gap-2">
                              <Badge className={getSeverityColor(threat.severity)}>
                                {threat.severity.toUpperCase()}
                              </Badge>
                              <Badge variant="outline" className="text-white border-gray-500">
                                {threat.status.toUpperCase()}
                              </Badge>
                            </div>
                          </div>
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sessions" className="mt-6">
            <SessionThreatMonitor />
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-emerald-400">Security Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Activity className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                  <p className="text-gray-400">Analytics dashboard coming soon</p>
                  <p className="text-sm text-gray-500 mt-2">Comprehensive security metrics and reporting</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default LiveThreatPreview;