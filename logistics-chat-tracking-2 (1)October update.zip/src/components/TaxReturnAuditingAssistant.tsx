import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FileText, Download, Upload, Bot, Calculator, CheckCircle, AlertTriangle } from 'lucide-react';

export const TaxReturnAuditingAssistant = () => {
  const [clientInfo, setClientInfo] = useState({
    name: '',
    ssn: '',
    income: '',
    deductions: '',
    filingStatus: ''
  });
  const [progress, setProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [subscriptionPlan, setSubscriptionPlan] = useState('premium');

  const handleAutoFile = async () => {
    setIsProcessing(true);
    setProgress(0);
    
    // Simulate AI processing with progress updates
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsProcessing(false);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const getBoostMultiplier = () => {
    switch(subscriptionPlan) {
      case 'basic': return '100x';
      case 'premium': return '250x';
      case 'enterprise': return '400x';
      default: return '100x';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-black/20 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calculator className="h-6 w-6" />
            Tax Return Auditing Assistant
            <Badge className="bg-green-500">Synthetic AI Powered</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Subscription Plan Selector */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {['basic', 'premium', 'enterprise'].map((plan) => (
              <Card 
                key={plan}
                className={`cursor-pointer transition-all ${
                  subscriptionPlan === plan 
                    ? 'bg-blue-600/30 border-blue-400' 
                    : 'bg-gray-800/30 border-gray-600'
                }`}
                onClick={() => setSubscriptionPlan(plan)}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-white font-bold capitalize">{plan}</div>
                  <div className="text-sm text-gray-300">
                    {plan === 'basic' && '100x Boost'}
                    {plan === 'premium' && '250x Boost'}
                    {plan === 'enterprise' && '400x Boost'}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Client Information Form */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-4">
              <div>
                <label className="text-white text-sm font-medium">Client Name</label>
                <Input
                  value={clientInfo.name}
                  onChange={(e) => setClientInfo({...clientInfo, name: e.target.value})}
                  placeholder="Enter client full name"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="text-white text-sm font-medium">SSN/Tax ID</label>
                <Input
                  value={clientInfo.ssn}
                  onChange={(e) => setClientInfo({...clientInfo, ssn: e.target.value})}
                  placeholder="XXX-XX-XXXX"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="text-white text-sm font-medium">Filing Status</label>
                <Select value={clientInfo.filingStatus} onValueChange={(value) => setClientInfo({...clientInfo, filingStatus: value})}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="Select filing status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single">Single</SelectItem>
                    <SelectItem value="married-joint">Married Filing Jointly</SelectItem>
                    <SelectItem value="married-separate">Married Filing Separately</SelectItem>
                    <SelectItem value="head">Head of Household</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-white text-sm font-medium">Annual Income</label>
                <Input
                  value={clientInfo.income}
                  onChange={(e) => setClientInfo({...clientInfo, income: e.target.value})}
                  placeholder="$0.00"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="text-white text-sm font-medium">Deductions</label>
                <Textarea
                  value={clientInfo.deductions}
                  onChange={(e) => setClientInfo({...clientInfo, deductions: e.target.value})}
                  placeholder="List all deductions..."
                  className="bg-gray-800 border-gray-600 text-white"
                  rows={4}
                />
              </div>
            </div>
          </div>

          {/* Processing Progress */}
          {isProcessing && (
            <div className="space-y-2">
              <div className="flex justify-between text-white text-sm">
                <span>AI Processing Tax Return ({getBoostMultiplier()} Performance)</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          {/* Action Buttons */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Upload className="h-4 w-4 mr-2" />
              Upload Documents
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              <Download className="h-4 w-4 mr-2" />
              Download Filing
            </Button>
            <Button 
              onClick={handleAutoFile}
              disabled={isProcessing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isProcessing ? (
                <>
                  <Bot className="h-4 w-4 mr-2 animate-spin" />
                  Auto Filing...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4 mr-2" />
                  AI Auto File
                </>
              )}
            </Button>
          </div>

          {/* Real-time Status */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-green-900/20 border-green-500/30">
              <CardContent className="p-4 text-center">
                <CheckCircle className="h-6 w-6 mx-auto mb-2 text-green-400" />
                <div className="text-white font-medium">Federal Ready</div>
                <div className="text-sm text-green-400">Compliance: 100%</div>
              </CardContent>
            </Card>
            <Card className="bg-blue-900/20 border-blue-500/30">
              <CardContent className="p-4 text-center">
                <AlertTriangle className="h-6 w-6 mx-auto mb-2 text-blue-400" />
                <div className="text-white font-medium">State Processing</div>
                <div className="text-sm text-blue-400">Optimization: {getBoostMultiplier()}</div>
              </CardContent>
            </Card>
            <Card className="bg-purple-900/20 border-purple-500/30">
              <CardContent className="p-4 text-center">
                <Bot className="h-6 w-6 mx-auto mb-2 text-purple-400" />
                <div className="text-white font-medium">AI Analysis</div>
                <div className="text-sm text-purple-400">Real-time</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};