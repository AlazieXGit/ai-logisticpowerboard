import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Truck, Search, DollarSign, Clock, TrendingUp, MapPin } from 'lucide-react';

interface Load {
  id: string;
  origin: string;
  destination: string;
  weight: number;
  rate: number;
  status: 'searching' | 'negotiating' | 'booked' | 'dispatched';
  fees: {
    aiAutoBooking: number;
    admin: number;
    process: number;
    aiGen: number;
    platform: number;
  };
}

const TMSSystem = () => {
  const [loads, setLoads] = useState<Load[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [liveBookings, setLiveBookings] = useState(0);

  useEffect(() => {
    // Simulate real-time load generation
    const interval = setInterval(() => {
      const newLoad: Load = {
        id: `LOAD-${Date.now()}`,
        origin: `City ${Math.floor(Math.random() * 100)}`,
        destination: `City ${Math.floor(Math.random() * 100)}`,
        weight: Math.floor(Math.random() * 40000) + 10000,
        rate: Math.floor(Math.random() * 3000) + 1000,
        status: 'searching',
        fees: {
          aiAutoBooking: 0,
          admin: 0,
          process: 0,
          aiGen: 0,
          platform: 0
        }
      };
      
      // Calculate fees (5% each)
      const baseRate = newLoad.rate;
      newLoad.fees = {
        aiAutoBooking: baseRate * 0.05,
        admin: baseRate * 0.05,
        process: baseRate * 0.05,
        aiGen: baseRate * 0.05,
        platform: baseRate * 0.05
      };
      
      setLoads(prev => [newLoad, ...prev.slice(0, 9)]);
      setLiveBookings(prev => prev + 1);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const autoBook = (loadId: string) => {
    setLoads(prev => prev.map(load => {
      if (load.id === loadId) {
        const totalFees = Object.values(load.fees).reduce((sum, fee) => sum + fee, 0);
        setTotalRevenue(prev => prev + totalFees);
        return { ...load, status: 'booked' };
      }
      return load;
    }));
  };

  const totalFeeRevenue = loads.reduce((sum, load) => {
    return sum + Object.values(load.fees).reduce((feeSum, fee) => feeSum + fee, 0);
  }, 0);

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Truck className="h-4 w-4 mr-2" />
              Live Bookings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{liveBookings}</div>
            <p className="text-xs text-gray-400">Real-time count</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <DollarSign className="h-4 w-4 mr-2" />
              Total Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-gray-400">Platform fees</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <TrendingUp className="h-4 w-4 mr-2" />
              Fee Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${totalFeeRevenue.toFixed(2)}</div>
            <p className="text-xs text-gray-400">25% total fees</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Live Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{new Date().toLocaleTimeString()}</div>
            <p className="text-xs text-gray-400">Real-time clock</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Auto-booking */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center">
            <Search className="h-5 w-5 mr-2" />
            AI Auto Search & Booking
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <Input
              placeholder="Search loads by origin, destination, or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-gray-700 border-emerald-500/30 text-white"
            />
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
          
          <div className="space-y-2">
            {loads.slice(0, 5).map((load) => (
              <div key={load.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                <div className="flex items-center gap-4">
                  <MapPin className="h-4 w-4 text-emerald-400" />
                  <div>
                    <div className="text-white font-medium">{load.id}</div>
                    <div className="text-gray-400 text-sm">{load.origin} → {load.destination}</div>
                  </div>
                  <Badge className={`${
                    load.status === 'searching' ? 'bg-yellow-600' :
                    load.status === 'negotiating' ? 'bg-blue-600' :
                    load.status === 'booked' ? 'bg-green-600' :
                    'bg-purple-600'
                  }`}>
                    {load.status}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-white font-bold">${load.rate}</div>
                    <div className="text-gray-400 text-sm">+${Object.values(load.fees).reduce((sum, fee) => sum + fee, 0).toFixed(2)} fees</div>
                  </div>
                  
                  {load.status === 'searching' && (
                    <Button 
                      size="sm" 
                      onClick={() => autoBook(load.id)}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      Auto Book
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TMSSystem;