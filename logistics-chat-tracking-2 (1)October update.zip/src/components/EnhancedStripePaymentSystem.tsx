import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, DollarSign, Zap, ArrowRight, Building2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

export const EnhancedStripePaymentSystem = () => {
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('stripe');
  const [accountDetails, setAccountDetails] = useState('');
  const [processing, setProcessing] = useState(false);

  const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/fZudR93xS0jf1kq4PTcQU02';
  
  const paymentMethods = [
    { value: 'stripe', label: 'Stripe Credit/Debit', icon: CreditCard, color: 'bg-purple-600' },
    { value: 'ach', label: 'ACH Transfer', icon: Building2, color: 'bg-blue-600' },
    { value: 'wire', label: 'Wire Transfer', icon: Zap, color: 'bg-green-600' },
    { value: 'cashapp', label: 'Cash App', icon: DollarSign, color: 'bg-green-500' },
    { value: 'chime', label: 'Chime', icon: DollarSign, color: 'bg-teal-600' },
    { value: 'venmo', label: 'Venmo', icon: DollarSign, color: 'bg-blue-500' },
    { value: 'paypal', label: 'PayPal', icon: DollarSign, color: 'bg-indigo-600' },
    { value: 'zelle', label: 'Zelle', icon: DollarSign, color: 'bg-yellow-600' }
  ];

  const processPayment = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid payment amount",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: { 
          amount: parseFloat(amount) * 100,
          currency: 'usd',
          payment_method: paymentMethod,
          description: `XPRESS AI Payment - ${paymentMethods.find(m => m.value === paymentMethod)?.label}`,
          account_details: accountDetails
        }
      });

      if (error) throw error;

      toast({
        title: "Payment Processed",
        description: `Successfully processed $${amount} via ${paymentMethods.find(m => m.value === paymentMethod)?.label}`,
      });
      
      setAmount('');
      setAccountDetails('');
    } catch (error) {
      console.error('Payment error:', error);
      toast({
        title: "Payment Failed",
        description: "Unable to process payment. Please try again.",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  const selectedMethod = paymentMethods.find(m => m.value === paymentMethod);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900 to-blue-900 border-purple-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="h-6 w-6" />
            ENHANCED STRIPE PAYMENT SYSTEM
            <Badge className="bg-green-600">MULTI-PLATFORM</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Payment Processor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Payment Method</label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  {paymentMethods.map((method) => (
                    <SelectItem key={method.value} value={method.value} className="text-white">
                      <div className="flex items-center gap-2">
                        <method.icon className="h-4 w-4" />
                        {method.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Amount ($)</label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            {paymentMethod !== 'stripe' && (
              <div className="space-y-2">
                <label className="text-gray-300 text-sm">Account Details</label>
                <Input
                  value={accountDetails}
                  onChange={(e) => setAccountDetails(e.target.value)}
                  placeholder={`Enter ${selectedMethod?.label} account info`}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            )}

            <Button
              onClick={() => {
                if (paymentMethod === 'stripe') {
                  window.open(STRIPE_PAYMENT_LINK, '_blank');
                } else {
                  processPayment();
                }
              }}
              disabled={processing}
              className={`w-full ${selectedMethod?.color} hover:opacity-90`}
            >
              {processing ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Processing...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  {selectedMethod && <selectedMethod.icon className="h-4 w-4" />}
                  {paymentMethod === 'stripe' ? 'Open Stripe Payment' : 'Process Payment'}
                  <ArrowRight className="h-4 w-4" />
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Payment Methods</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {paymentMethods.map((method) => (
                <div 
                  key={method.value}
                  className={`p-3 rounded border-2 cursor-pointer transition-all ${
                    paymentMethod === method.value 
                      ? `${method.color} border-white` 
                      : 'bg-gray-700 border-gray-600 hover:border-gray-500'
                  }`}
                  onClick={() => setPaymentMethod(method.value)}
                >
                  <div className="flex items-center gap-2">
                    <method.icon className="h-5 w-5 text-white" />
                    <span className="text-white text-sm font-medium">{method.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-purple-900 border-purple-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Direct Stripe Payment Link
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-purple-100 text-sm">
            Direct access to live Stripe payment processing
          </p>
          <div className="space-y-2">
            <code className="block bg-gray-700 p-2 rounded text-xs text-purple-400 break-all">
              {STRIPE_PAYMENT_LINK}
            </code>
          </div>
          <Button 
            onClick={() => window.open(STRIPE_PAYMENT_LINK, '_blank')}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            <CreditCard className="h-4 w-4 mr-2" />
            Open Live Payment Link
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedStripePaymentSystem;