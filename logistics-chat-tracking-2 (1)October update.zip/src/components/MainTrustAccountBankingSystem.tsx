import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, DollarSign, TrendingUp, Calculator, ArrowRight, CheckCircle, Zap } from 'lucide-react';

export const MainTrustAccountBankingSystem: React.FC = () => {
  const [totalFunds, setTotalFunds] = useState(9535092.45);
  const [isCalculating, setIsCalculating] = useState(false);
  const [fundSources, setFundSources] = useState([
    { source: 'JP Morgan Checking (Alacias J. Bethea)', amount: 3247592.45, status: 'ROUTED' },
    { source: 'US Bank Checking (Alacias J. Bethea)', amount: 2163847.23, status: 'ROUTED' },
    { source: 'TD Bank Checking (Alacias J. Bethea)', amount: 1894756.89, status: 'ROUTED' },
    { source: 'Credit/Debit Card Fees', amount: 125000.00, status: 'ROUTED' },
    { source: 'Platform Fees', amount: 87500.00, status: 'ROUTED' },
    { source: 'Associated Charges', amount: 45000.00, status: 'ROUTED' },
    { source: 'Revenue Collections', amount: 1250000.00, status: 'ROUTED' },
    { source: 'Profit Margins', amount: 721395.88, status: 'ROUTED' }
  ]);

  // Alucius Alford Virtual Account Details
  const virtualAccounts = {
    main: { number: '35563935267', name: 'Main Virtual Account' },
    reserve: { number: '5563935275', name: 'Reserve and Growth' },
    combined: { number: '5563935283', name: 'Combined Account' },
    routing: '054000030'
  };

  useEffect(() => {
    calculateTotalFunds();
  }, []);

  const calculateTotalFunds = () => {
    setIsCalculating(true);
    setTimeout(() => {
      const total = fundSources.reduce((sum, source) => sum + source.amount, 0);
      setTotalFunds(total);
      setIsCalculating(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-emerald-900 to-teal-900 border-emerald-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            Main Trust Account Banking System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-emerald-500 bg-emerald-900/20">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription className="text-emerald-300">
              CENTRALIZED FUND ROUTING: All sources directed to Main Trust Account
            </AlertDescription>
          </Alert>

          <Card className="bg-black/40 border-emerald-400">
            <CardContent className="p-6">
              <div className="text-center space-y-3">
                <h2 className="text-white text-2xl font-bold">Total Trust Account Balance</h2>
                <div className="text-emerald-400 text-4xl font-bold">
                  ${isCalculating ? '...' : totalFunds.toLocaleString()}
                </div>
                <Button 
                  onClick={calculateTotalFunds}
                  className="bg-emerald-600 hover:bg-emerald-700"
                  disabled={isCalculating}
                >
                  <Calculator className="h-4 w-4 mr-2" />
                  {isCalculating ? 'Calculating...' : 'Recalculate Total'}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="sources" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="sources" className="text-white">Fund Sources</TabsTrigger>
              <TabsTrigger value="accounts" className="text-white">Virtual Accounts</TabsTrigger>
              <TabsTrigger value="operations" className="text-white">Payment Operations</TabsTrigger>
              <TabsTrigger value="routing" className="text-white">Routing Status</TabsTrigger>
            </TabsList>

            <TabsContent value="sources" className="space-y-4">
              {fundSources.map((source, index) => (
                <Card key={index} className="bg-black/40 border-emerald-500">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <ArrowRight className="h-5 w-5 text-emerald-400" />
                        <div>
                          <p className="text-white font-semibold">{source.source}</p>
                          <p className="text-gray-400 text-sm">Routed to Main Trust</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-emerald-400 text-xl font-bold">
                          ${source.amount.toLocaleString()}
                        </span>
                        <Badge className="bg-emerald-600 ml-2">{source.status}</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="accounts" className="space-y-4">
              <Card className="bg-black/40 border-purple-500">
                <CardHeader>
                  <CardTitle className="text-white">Alucius Alford Virtual Accounts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-purple-500 bg-purple-900/20">
                    <Building2 className="h-4 w-4" />
                    <AlertDescription className="text-purple-300">
                      Routing Number: {virtualAccounts.routing} - Ready for immediate fund transfers
                    </AlertDescription>
                  </Alert>
                  
                  <div className="space-y-3">
                    <Card className="bg-gray-800 border-purple-400">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-white font-semibold">{virtualAccounts.main.name}</p>
                            <p className="text-purple-400 font-mono">ACC: {virtualAccounts.main.number}</p>
                          </div>
                          <Badge className="bg-purple-600">ACTIVE</Badge>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-gray-800 border-blue-400">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-white font-semibold">{virtualAccounts.reserve.name}</p>
                            <p className="text-blue-400 font-mono">ACC: {virtualAccounts.reserve.number}</p>
                          </div>
                          <Badge className="bg-blue-600">ACTIVE</Badge>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-gray-800 border-green-400">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-white font-semibold">{virtualAccounts.combined.name}</p>
                            <p className="text-green-400 font-mono">ACC: {virtualAccounts.combined.number}</p>
                          </div>
                          <Badge className="bg-green-600">ACTIVE</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    <Button className="bg-purple-600 hover:bg-purple-700 text-xs">
                      Transfer to Main
                    </Button>
                    <Button className="bg-blue-600 hover:bg-blue-700 text-xs">
                      Transfer to Reserve
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700 text-xs">
                      Transfer to Combined
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="operations" className="space-y-4">
              <Card className="bg-black/40 border-blue-500">
                <CardHeader>
                  <CardTitle className="text-white">Unified Payment Operations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-blue-500 bg-blue-900/20">
                    <Zap className="h-4 w-4" />
                    <AlertDescription className="text-blue-300">
                      All payments processed from Main Trust Account after fund calculation
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Process Vendor Payments
                    </Button>
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      Execute Platform Payouts
                    </Button>
                    <Button className="bg-orange-600 hover:bg-orange-700">
                      Transfer to Operations
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700">
                      Distribute Revenue
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="routing" className="space-y-4">
              <Card className="bg-black/40 border-yellow-500">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Fund Routing Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">Bank Account Funds</span>
                        <span className="text-green-400">✓ ROUTED</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">Fee Collections</span>
                        <span className="text-green-400">✓ ROUTED</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">Platform Charges</span>
                        <span className="text-green-400">✓ ROUTED</span>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded">
                      <div className="flex justify-between">
                        <span className="text-white">Revenue & Profit</span>
                        <span className="text-green-400">✓ ROUTED</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default MainTrustAccountBankingSystem;