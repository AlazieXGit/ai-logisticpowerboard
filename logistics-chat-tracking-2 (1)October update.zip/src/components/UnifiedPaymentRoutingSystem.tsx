import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  CreditCard, DollarSign, Zap, CheckCircle, 
  AlertTriangle, Activity, Server, Shield, BarChart3
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import EnhancedPaymentRoutingAnalytics from './EnhancedPaymentRoutingAnalytics';

interface PaymentRoute {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'error';
  processed: number;
  revenue: number;
}

const UnifiedPaymentRoutingSystem: React.FC = () => {
  const [routes, setRoutes] = useState<PaymentRoute[]>([
    { id: '1', name: 'Stripe Connect → Wells Fargo Business', status: 'active', processed: 1247, revenue: 125000 },
    { id: '2', name: 'Square Payments → Plaid Connected', status: 'active', processed: 892, revenue: 75000 },
    { id: '3', name: 'ACH Network → Trust Main Account', status: 'active', processed: 654, revenue: 250000 },
    { id: '4', name: 'Synergy Payment Router → Unified System', status: 'active', processed: 423, revenue: 500000 }
  ]);

  const [totalRevenue, setTotalRevenue] = useState(0);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    const total = routes.reduce((sum, route) => sum + route.revenue, 0);
    setTotalRevenue(total);
  }, [routes]);

  const handleRouteToggle = async (routeId: string) => {
    setProcessing(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: { 
          action: 'toggle_route',
          routeId,
          timestamp: new Date().toISOString()
        }
      });

      if (!error) {
        setRoutes(prev => prev.map(route => 
          route.id === routeId 
            ? { ...route, status: route.status === 'active' ? 'inactive' : 'active' }
            : route
        ));
      }
    } catch (error) {
      console.error('Route toggle failed:', error);
    } finally {
      setProcessing(false);
    }
  };

  const processPayment = async (amount: number, gateway: string) => {
    setProcessing(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: { 
          action: 'process_payment',
          amount,
          gateway,
          timestamp: new Date().toISOString()
        }
      });

      if (!error) {
        // Update route statistics
        setRoutes(prev => prev.map(route => 
          route.name.toLowerCase().includes(gateway.toLowerCase())
            ? { ...route, processed: route.processed + 1, revenue: route.revenue + amount }
            : route
        ));
      }
    } catch (error) {
      console.error('Payment processing failed:', error);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Alert className="border-green-500 bg-green-900/20">
        <Zap className="h-4 w-4" />
        <AlertDescription className="text-green-300">
          Unified Payment Routing System - All gateways integrated and operational
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Server className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="controls" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Controls
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gray-800/30 border-green-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400">Total Revenue</p>
                    <p className="text-2xl font-bold text-green-400">
                      ${totalRevenue.toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-blue-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400">Active Routes</p>
                    <p className="text-2xl font-bold text-blue-400">
                      {routes.filter(r => r.status === 'active').length}
                    </p>
                  </div>
                  <Server className="h-8 w-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-purple-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400">Processed Today</p>
                    <p className="text-2xl font-bold text-purple-400">
                      {routes.reduce((sum, r) => sum + r.processed, 0)}
                    </p>
                  </div>
                  <Activity className="h-8 w-8 text-purple-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-orange-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400">System Status</p>
                    <p className="text-lg font-bold text-orange-400">OPTIMAL</p>
                  </div>
                  <Shield className="h-8 w-8 text-orange-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800/30 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Routes
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {routes.map((route) => (
                  <div key={route.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${
                        route.status === 'active' ? 'bg-green-400' : 
                        route.status === 'error' ? 'bg-red-400' : 'bg-gray-400'
                      }`} />
                      <div>
                        <p className="text-white font-medium">{route.name}</p>
                        <p className="text-gray-400 text-sm">
                          {route.processed} transactions • ${route.revenue.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant={route.status === 'active' ? 'destructive' : 'default'}
                      onClick={() => handleRouteToggle(route.id)}
                      disabled={processing}
                    >
                      {route.status === 'active' ? 'Disable' : 'Enable'}
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => processPayment(100, 'stripe')}
                  disabled={processing}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Test Stripe Payment ($100)
                </Button>
                
                <Button 
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  onClick={() => processPayment(250, 'synergy')}
                  disabled={processing}
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Test Synergy Router ($250)
                </Button>
                
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => processPayment(500, 'banking')}
                  disabled={processing}
                >
                  <DollarSign className="h-4 w-4 mr-2" />
                  Test Banking Direct ($500)
                </Button>

                <div className="pt-4 border-t border-gray-600">
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <AlertTriangle className="h-4 w-4" />
                    All payments are processed through secure, encrypted channels
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <EnhancedPaymentRoutingAnalytics />
        </TabsContent>

        <TabsContent value="controls" className="space-y-6">
          <Card className="bg-gray-800/30 border-red-500">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="h-5 w-5" />
                System Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button className="w-full bg-red-600 hover:bg-red-700">
                Emergency Stop All Routes
              </Button>
              <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                Maintenance Mode
              </Button>
              <Button className="w-full bg-green-600 hover:bg-green-700">
                Restart All Services
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UnifiedPaymentRoutingSystem;