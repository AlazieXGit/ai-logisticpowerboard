import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Building2, DollarSign, CheckCircle, Ban, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface VendorPayoutSystemProps {
  onPayoutComplete?: (payout: any) => void;
}

const VendorPayoutSystem: React.FC<VendorPayoutSystemProps> = ({ onPayoutComplete }) => {
  const [processing, setProcessing] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  const vendors = [
    { id: 'v001', name: 'Alazie LLC Square', account: '3236618840224', routing: '041215663', amount: 50000.00, type: 'Infrastructure', status: 'active' },
    { id: 'v002', name: 'Tech Solutions Inc', account: '1234567890', routing: '021000021', amount: 25000.00, type: 'Software', status: 'active' },
    { id: 'v003', name: 'ABC Vendor Corp', account: '9876543210', routing: '031176110', amount: 15000.00, type: 'Technology', status: 'active' },
    { id: 'v004', name: 'XYZ Logistics', account: '5555444433', routing: '026009593', amount: 20000.00, type: 'Transportation', status: 'active' }
  ];

  useEffect(() => {
    const checkAdminStatus = () => {
      const adminStatus = localStorage.getItem('superAdminAuth');
      setIsSuperAdmin(adminStatus === 'authenticated');
    };
    checkAdminStatus();
  }, []);

  const processVendorPayout = async (vendor: any) => {
    if (!isSuperAdmin) {
      alert('🚫 Super Admin access required for vendor payouts');
      return;
    }

    setProcessing(true);
    try {
      const { data } = await supabase.functions.invoke('payout', {
        body: {
          amount: vendor.amount,
          userId: vendor.id,
          vendorName: vendor.name,
          accountNumber: vendor.account,
          routingNumber: vendor.routing,
          paymentType: 'ACH',
          description: `Vendor payout - ${vendor.type}`,
          adminOverride: true
        }
      });
      
      if (data?.status === 'success') {
        onPayoutComplete?.(data);
        alert(`✅ Vendor payout processed: $${vendor.amount.toLocaleString()} to ${vendor.name}`);
      } else {
        throw new Error('Payout processing failed');
      }
    } catch (error: any) {
      console.error('Payout error:', error);
      alert(`❌ Vendor payout failed: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  if (!isSuperAdmin) {
    return (
      <Alert className="border-emerald-500 bg-emerald-900/20">
        <CheckCircle className="h-4 w-4" />
        <AlertDescription className="text-emerald-400 font-semibold">
          ✅ Vendor payout system reactivated. Super Admin access required for processing.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Alert className="border-emerald-500 bg-emerald-900/20">
        <Shield className="h-4 w-4" />
        <AlertDescription className="text-emerald-400 font-semibold">
          🔐 Vendor Payout System - Reactivated (Super Admin Mode)
        </AlertDescription>
      </Alert>

      <Card className="bg-emerald-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Active Vendor Payouts
            <Badge className="bg-emerald-600">REACTIVATED</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-600">
                <TableHead className="text-gray-300">Vendor</TableHead>
                <TableHead className="text-gray-300">Account</TableHead>
                <TableHead className="text-gray-300">Amount</TableHead>
                <TableHead className="text-gray-300">Type</TableHead>
                <TableHead className="text-gray-300">Status</TableHead>
                <TableHead className="text-gray-300">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vendors.map((vendor) => (
                <TableRow key={vendor.id} className="border-gray-600">
                  <TableCell className="text-white font-medium">{vendor.name}</TableCell>
                  <TableCell className="text-gray-300 font-mono">
                    ****{vendor.account.slice(-4)} / {vendor.routing}
                  </TableCell>
                  <TableCell className="text-emerald-400 font-bold">
                    ${vendor.amount.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Badge className={vendor.id === 'v001' ? 'bg-emerald-600' : 'bg-blue-600'}>
                      {vendor.type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className="bg-emerald-600">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      ACTIVE
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      onClick={() => processVendorPayout(vendor)}
                      disabled={processing}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      <DollarSign className="h-3 w-3 mr-1" />
                      {processing ? 'Processing...' : 'Pay Vendor'}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="bg-gray-900/50 border-gray-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="h-5 w-5" />
            System Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center justify-between p-3 bg-emerald-950/30 rounded border border-emerald-500/30">
              <span className="text-gray-300">Vendor Payments</span>
              <Badge className="bg-emerald-600">ACTIVE</Badge>
            </div>
            <div className="flex items-center justify-between p-3 bg-emerald-950/30 rounded border border-emerald-500/30">
              <span className="text-gray-300">Total Vendors</span>
              <Badge className="bg-blue-600">{vendors.length}</Badge>
            </div>
            <div className="flex items-center justify-between p-3 bg-emerald-950/30 rounded border border-emerald-500/30">
              <span className="text-gray-300">Admin Override</span>
              <Badge className="bg-purple-600">ENABLED</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VendorPayoutSystem;