import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertTriangle, UserX, Settings, LogOut } from 'lucide-react';
import AccountSuspensionDisplay from './AccountSuspensionDisplay';
import ThreatAccountLockdown from './ThreatAccountLockdown';

const SuperAdminControlCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState('security');

  const handleLogout = () => {
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-red-900/20 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Shield className="h-8 w-8 text-red-400" />
            <div>
              <h1 className="text-3xl font-bold text-white">Super Admin Control Center</h1>
              <p className="text-gray-400">alaziellc.innovation@gmail.com - Master Administrator</p>
              <p className="text-xs text-red-300">Alucius Alford - PIN #19762020</p>
            </div>
          </div>
          <Button onClick={handleLogout} variant="outline" className="border-red-500 text-red-400 hover:bg-red-900/20">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Security Status Alert */}
        <Alert className="border-red-500 bg-red-900/30">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          <AlertDescription className="text-red-300">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-bold">SYSTEM LOCKDOWN ACTIVE</h3>
                <p className="text-sm">admin_user account suspended - Single login route enforced</p>
                <p className="text-xs mt-1">Only alaziellc.innovation@gmail.com authorized</p>
              </div>
              <div className="text-right">
                <div className="text-red-400 font-bold">Threat Level: HIGH</div>
                <div className="text-sm">Active Incidents: 2</div>
              </div>
            </div>
          </AlertDescription>
        </Alert>

        {/* Main Control Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800">
            <TabsTrigger value="security" className="data-[state=active]:bg-red-600">
              <AlertTriangle className="h-4 w-4 mr-2" />
              THREAT LOCKDOWN
            </TabsTrigger>
            <TabsTrigger value="suspended" className="data-[state=active]:bg-red-600">
              <UserX className="h-4 w-4 mr-2" />
              Suspended Accounts
            </TabsTrigger>
            <TabsTrigger value="system" className="data-[state=active]:bg-red-600">
              <Settings className="h-4 w-4 mr-2" />
              System Control
            </TabsTrigger>
            <TabsTrigger value="logs" className="data-[state=active]:bg-red-600">
              <Shield className="h-4 w-4 mr-2" />
              Security Logs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="security" className="space-y-6">
            <Alert className="border-red-500 bg-red-900/40 border-2">
              <AlertTriangle className="h-6 w-6 text-red-400 animate-pulse" />
              <AlertDescription className="text-red-300">
                <h2 className="text-xl font-bold text-red-400 mb-2">🚨 SECURITY THREAT DETECTED</h2>
                <p className="font-bold">ALL USER ACCESS RESTRICTED - SUPER ADMIN ONLY</p>
              </AlertDescription>
            </Alert>
            <ThreatAccountLockdown />
          </TabsContent>

          <TabsContent value="suspended" className="space-y-6">
            <Card className="bg-black/80 border-red-500">
              <CardHeader>
                <CardTitle className="text-red-400">Account Suspension Management</CardTitle>
              </CardHeader>
              <CardContent>
                <AccountSuspensionDisplay />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system" className="space-y-6">
            <Card className="bg-black/80 border-red-500">
              <CardHeader>
                <CardTitle className="text-red-400">System Control Panel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Alert className="border-green-500 bg-green-900/20">
                    <Shield className="h-5 w-5 text-green-400" />
                    <AlertDescription className="text-green-300">
                      <h4 className="font-semibold mb-2">Current Security Configuration:</h4>
                      <ul className="text-sm space-y-1">
                        <li>✓ Single login route active (alaziellc.innovation@gmail.com only)</li>
                        <li>✓ admin_user account suspended</li>
                        <li>✓ PIN authentication required (#19762020)</li>
                        <li>✓ All user access restricted</li>
                        <li>✓ Threat monitoring active</li>
                        <li>✓ Alucius Alford control established</li>
                      </ul>
                    </AlertDescription>
                  </Alert>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button className="bg-red-600 hover:bg-red-700" disabled>
                      System Lockdown: ACTIVE
                    </Button>
                    <Button className="bg-gray-600 hover:bg-gray-700" disabled>
                      Emergency Override: READY
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6">
            <Card className="bg-black/80 border-red-500">
              <CardHeader>
                <CardTitle className="text-red-400">Security Event Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  <div className="p-3 bg-green-900/30 rounded border border-green-500/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-green-300">New Super Admin Credentials Active</p>
                        <p className="text-sm text-gray-300">alaziellc.innovation@gmail.com with PIN #19762020</p>
                      </div>
                      <span className="text-xs text-gray-400">Now</span>
                    </div>
                  </div>
                  <div className="p-3 bg-red-900/30 rounded border border-red-500/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-red-300">Account Suspension</p>
                        <p className="text-sm text-gray-300">admin_user account suspended due to security threat</p>
                      </div>
                      <span className="text-xs text-gray-400">7/25/2025, 3:45:21 PM</span>
                    </div>
                  </div>
                  <div className="p-3 bg-red-900/30 rounded border border-red-500/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-red-300">Suspicious Login Detected</p>
                        <p className="text-sm text-gray-300">IP: 192.168.1.100 - Credentials: admin_user/admin123</p>
                      </div>
                      <span className="text-xs text-gray-400">7/25/2025, 3:45:21 PM</span>
                    </div>
                  </div>
                  <div className="p-3 bg-red-900/30 rounded border border-red-500/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-red-300">Multiple Failed Attempts</p>
                        <p className="text-sm text-gray-300">IP: 10.0.0.50 - Credentials: admin_user/admin123</p>
                      </div>
                      <span className="text-xs text-gray-400">7/25/2025, 3:40:21 PM</span>
                    </div>
                  </div>
                  <div className="p-3 bg-green-900/30 rounded border border-green-500/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-green-300">Super Admin Access</p>
                        <p className="text-sm text-gray-300">alaziellc.innovation@gmail.com authenticated successfully</p>
                      </div>
                      <span className="text-xs text-gray-400">Now</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SuperAdminControlCenter;