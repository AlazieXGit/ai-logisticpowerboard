import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield, Key, DollarSign, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface TransactionCode {
  id: string;
  code: string;
  type: 'ESC' | 'TRU' | 'ALZ';
  sequence: number;
  route: string;
  fees: number;
  status: 'active' | 'used' | 'expired';
  generatedBy: 'system' | 'super_admin';
  createdAt: string;
}

const TransactionCodeGenerator: React.FC = () => {
  const [codes, setCodes] = useState<TransactionCode[]>([]);
  const [selectedType, setSelectedType] = useState<'ESC' | 'TRU' | 'ALZ'>('ESC');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadTransactionCodes();
    checkSuperAdminStatus();
  }, []);

  const checkSuperAdminStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'verify_super_admin' }
      });
      if (!error && data?.isSuperAdmin) {
        setIsSuperAdmin(true);
      }
    } catch (error) {
      console.log('Super admin check failed');
    }
  };

  const loadTransactionCodes = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_transaction_codes' }
      });
      if (!error && data?.codes) {
        setCodes(data.codes);
      }
    } catch (error) {
      console.log('Failed to load codes');
    }
  };

  const generateTransactionCode = async () => {
    if (!isSuperAdmin) {
      toast({
        title: 'Access Denied',
        description: 'Only Super Admin can manually generate codes',
        variant: 'destructive'
      });
      return;
    }

    setIsGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'generate_transaction_code',
          type: selectedType,
          generatedBy: 'super_admin'
        }
      });

      if (error) throw error;

      toast({
        title: 'Code Generated',
        description: `New ${selectedType} code: ${data.code}`,
        variant: 'default'
      });

      loadTransactionCodes();
    } catch (error) {
      toast({
        title: 'Generation Failed',
        description: 'Could not generate transaction code',
        variant: 'destructive'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'ESC': return 'bg-blue-600';
      case 'TRU': return 'bg-purple-600';
      case 'ALZ': return 'bg-emerald-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-600';
      case 'used': return 'bg-gray-600';
      case 'expired': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Key className="h-5 w-5" />
            Transaction Code Generator
            {!isSuperAdmin && (
              <Badge className="bg-red-600 ml-2">
                <AlertTriangle className="h-3 w-3 mr-1" />
                Super Admin Only
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-emerald-300">Transaction Type</Label>
              <Select value={selectedType} onValueChange={(value: 'ESC' | 'TRU' | 'ALZ') => setSelectedType(value)}>
                <SelectTrigger className="bg-gray-700 border-emerald-500/30 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ESC">ESC - Escrow</SelectItem>
                  <SelectItem value="TRU">TRU - Trust</SelectItem>
                  <SelectItem value="ALZ">ALZ - Alaziel Banking</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                onClick={generateTransactionCode}
                disabled={isGenerating || !isSuperAdmin}
                className="bg-emerald-600 hover:bg-emerald-700 w-full"
              >
                {isGenerating ? 'Generating...' : 'Generate Code'}
              </Button>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="text-emerald-300 font-semibold mb-4">Recent Transaction Codes</h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {codes.map((code) => (
                <div key={code.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge className={getTypeColor(code.type)}>
                      {code.type}
                    </Badge>
                    <span className="font-mono text-emerald-400">{code.code}</span>
                    <Badge className={getStatusColor(code.status)}>
                      {code.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-300">
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />
                      ${code.fees.toFixed(2)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Shield className="h-3 w-3" />
                      {code.generatedBy === 'system' ? 'Auto' : 'Manual'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TransactionCodeGenerator;