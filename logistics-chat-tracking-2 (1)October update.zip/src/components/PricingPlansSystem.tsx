import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Star, Zap, Crown } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface PricingPlan {
  id: string;
  name: string;
  price: number;
  period: string;
  features: string[];
  popular?: boolean;
  icon: React.ReactNode;
  color: string;
}

const PricingPlansSystem: React.FC = () => {
  const [plans] = useState<PricingPlan[]>([
    {
      id: 'basic',
      name: 'Basic Plan',
      price: 29,
      period: 'month',
      features: [
        'Load Board Access',
        'Basic AI Matching',
        'Email Support',
        'Standard Dashboard',
        'Up to 10 Loads/Month'
      ],
      popular: false,
      icon: <Star className="w-6 h-6" />,
      color: 'bg-blue-600'
    },
    {
      id: 'professional',
      name: 'Professional Plan',
      price: 99,
      period: 'month',
      features: [
        'Everything in Basic',
        'AI Auto Booking',
        'Advanced Analytics',
        'Priority Support',
        'Unlimited Loads',
        'TMS Integration',
        'Performance Boost 50x'
      ],
      popular: true,
      icon: <Zap className="w-6 h-6" />,
      color: 'bg-green-600'
    },
    {
      id: 'enterprise',
      name: 'Enterprise Plan',
      price: 299,
      period: 'month',
      features: [
        'Everything in Professional',
        'Custom AI Solutions',
        'Dedicated Account Manager',
        '24/7 Phone Support',
        'White Label Options',
        'API Access',
        'Performance Boost 100x',
        'Legal Document Management',
        'Revenue Optimization'
      ],
      popular: false,
      icon: <Crown className="w-6 h-6" />,
      color: 'bg-purple-600'
    }
  ]);

  const [selectedPlan, setSelectedPlan] = useState<string>('');
  const MAIN_STRIPE_LINK = 'https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00';
  
  const handleSubscribe = async (planId: string) => {
    setSelectedPlan(planId);
    
    // AI automation for immediate payment processing
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: {
          planId,
          stripeLink: MAIN_STRIPE_LINK,
          aiAutomation: true
        }
      });
      
      if (error) throw error;
      
      // Open Stripe payment link
      window.open(MAIN_STRIPE_LINK, '_blank');
    } catch (error) {
      console.error('Payment error:', error);
      // Fallback to direct link
      window.open(MAIN_STRIPE_LINK, '_blank');
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Choose Your Plan</h2>
        <p className="text-gray-300">Select the perfect plan for your logistics needs</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative bg-gray-800/30 border-gray-600 ${plan.popular ? 'ring-2 ring-green-500' : ''}`}>
            {plan.popular && (
              <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-green-500">
                Most Popular
              </Badge>
            )}
            
            <CardHeader className="text-center">
              <div className={`w-12 h-12 ${plan.color} rounded-full flex items-center justify-center text-white mx-auto mb-2`}>
                {plan.icon}
              </div>
              <CardTitle className="text-xl text-white">{plan.name}</CardTitle>
              <div className="text-3xl font-bold text-white">
                ${plan.price}
                <span className="text-sm text-gray-400">/{plan.period}</span>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                className="w-full" 
                onClick={() => handleSubscribe(plan.id)}
                variant={plan.popular ? 'default' : 'outline'}
              >
                Subscribe Now
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default PricingPlansSystem;