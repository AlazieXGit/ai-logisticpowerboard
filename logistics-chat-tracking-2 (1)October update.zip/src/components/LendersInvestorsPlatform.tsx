import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { DollarSign, TrendingUp, Users, PieChart, Copy, Check } from 'lucide-react';

export const LendersInvestorsPlatform: React.FC = () => {
  const [copied, setCopied] = useState<string | null>(null);
  
  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  const bankingAccounts = [
    {
      type: 'Investment Wire Account',
      accountNumber: '4567890123456789',
      routingNumber: '021000021',
      bankName: 'Chase Private Banking',
      purpose: 'Large Investment Transfers'
    },
    {
      type: 'Lending Operations Account',
      accountNumber: '7890123456789012',
      routingNumber: '026009593',
      bankName: 'Bank of America Business',
      purpose: 'Loan Disbursements'
    },
    {
      type: 'Escrow Settlement Account',
      accountNumber: '3456789012345678',
      routingNumber: '121000248',
      bankName: 'Wells Fargo Commercial',
      purpose: 'Secure Transaction Holding'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="bg-white rounded-lg shadow-lg p-6 border-t-4 border-green-500">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Lenders & Investors Platform</h1>
              <p className="text-gray-600">Capital management and investment tracking system</p>
            </div>
            <Badge className="bg-green-100 text-green-800 border-green-200">
              <DollarSign className="h-3 w-3 mr-1" />
              CAPITAL PLATFORM
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-4">
          <TabsList className="grid w-full grid-cols-6 bg-white">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="investments">Investments</TabsTrigger>
            <TabsTrigger value="lending">Lending</TabsTrigger>
            <TabsTrigger value="banking">Banking Info</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4">
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="border-green-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Investments</CardTitle>
                  <DollarSign className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-700">$2.4M</div>
                  <p className="text-xs text-green-600">+12% this quarter</p>
                </CardContent>
              </Card>
              
              <Card className="border-blue-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
                  <TrendingUp className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-700">47</div>
                  <p className="text-xs text-blue-600">$890K outstanding</p>
                </CardContent>
              </Card>
              
              <Card className="border-purple-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Portfolio ROI</CardTitle>
                  <PieChart className="h-4 w-4 text-purple-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-700">18.5%</div>
                  <p className="text-xs text-green-600">Above target</p>
                </CardContent>
              </Card>
              
              <Card className="border-orange-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Investors</CardTitle>
                  <Users className="h-4 w-4 text-orange-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-700">156</div>
                  <p className="text-xs text-green-600">+8 new this month</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="investments">
            <Card>
              <CardHeader>
                <CardTitle>Investment Portfolio Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 bg-green-50 rounded-lg">
                      <h4 className="font-medium text-green-800">Logistics Ventures</h4>
                      <p className="text-2xl font-bold text-green-700">$1.2M</p>
                      <p className="text-sm text-green-600">ROI: 22.3%</p>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-medium text-blue-800">Tech Startups</h4>
                      <p className="text-2xl font-bold text-blue-700">$800K</p>
                      <p className="text-sm text-blue-600">ROI: 15.7%</p>
                    </div>
                    <div className="p-4 bg-purple-50 rounded-lg">
                      <h4 className="font-medium text-purple-800">Real Estate</h4>
                      <p className="text-2xl font-bold text-purple-700">$400K</p>
                      <p className="text-sm text-purple-600">ROI: 12.1%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="lending">
            <Card>
              <CardHeader>
                <CardTitle>Lending Operations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium">Equipment Financing</h4>
                      <p className="text-lg font-bold">$450K</p>
                      <p className="text-sm text-gray-600">15 active loans</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium">Working Capital</h4>
                      <p className="text-lg font-bold">$340K</p>
                      <p className="text-sm text-gray-600">22 active loans</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="banking">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Banking Integration - Account Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {bankingAccounts.map((account, index) => (
                      <div key={index} className="p-4 border rounded-lg bg-gray-50">
                        <div className="flex justify-between items-start mb-3">
                          <h4 className="font-medium text-lg">{account.type}</h4>
                          <Badge variant="outline">{account.bankName}</Badge>
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium text-gray-600">Account Number</label>
                            <div className="flex items-center gap-2 mt-1">
                              <Input value={account.accountNumber} readOnly className="font-mono" />
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => copyToClipboard(account.accountNumber, `account-${index}`)}
                              >
                                {copied === `account-${index}` ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                              </Button>
                            </div>
                          </div>
                          
                          <div>
                            <label className="text-sm font-medium text-gray-600">Routing Number</label>
                            <div className="flex items-center gap-2 mt-1">
                              <Input value={account.routingNumber} readOnly className="font-mono" />
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => copyToClipboard(account.routingNumber, `routing-${index}`)}
                              >
                                {copied === `routing-${index}` ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                              </Button>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-3">
                          <label className="text-sm font-medium text-gray-600">Purpose</label>
                          <p className="text-sm text-gray-800 mt-1">{account.purpose}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Wire Transfer Instructions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <h5 className="font-medium text-blue-800">Domestic Wire Transfers</h5>
                      <p className="text-sm text-blue-600">Use Investment Wire Account for amounts over $100,000</p>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg">
                      <h5 className="font-medium text-green-800">ACH Transfers</h5>
                      <p className="text-sm text-green-600">Standard processing 1-3 business days</p>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <h5 className="font-medium text-purple-800">International Transfers</h5>
                      <p className="text-sm text-purple-600">Contact support for SWIFT codes and additional requirements</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle>Investment Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-medium text-green-800">Performance Metrics</h4>
                    <p className="text-sm text-green-600">Portfolio performance tracking and analysis</p>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-800">Risk Assessment</h4>
                    <p className="text-sm text-blue-600">Real-time risk monitoring and alerts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Financial Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button className="w-full justify-start">Generate Monthly Investment Report</Button>
                  <Button className="w-full justify-start">Generate Lending Portfolio Report</Button>
                  <Button className="w-full justify-start">Generate Tax Documentation</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};