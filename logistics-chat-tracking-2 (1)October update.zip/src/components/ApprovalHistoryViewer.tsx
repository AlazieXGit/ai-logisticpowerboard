import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import { History, Search, Filter } from 'lucide-react';

export function ApprovalHistoryViewer() {
  const [history, setHistory] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAction, setFilterAction] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 60000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [historyRes, auditRes] = await Promise.all([
        supabase
          .from('approval_history')
          .select('*, stripe_connect_accounts(email)')
          .order('created_at', { ascending: false })
          .limit(50),
        supabase
          .from('admin_audit_logs')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(100)
      ]);

      setHistory(historyRes.data || []);
      setAuditLogs(auditRes.data || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredHistory = history.filter(item => {
    const matchesSearch = item.admin_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.stripe_connect_accounts?.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterAction === 'all' || item.action === filterAction;
    return matchesSearch && matchesFilter;
  });

  const getActionColor = (action: string) => {
    const colors: Record<string, string> = {
      approved: 'bg-green-500',
      rejected: 'bg-red-500',
      info_requested: 'bg-yellow-500',
      modified: 'bg-blue-500',
      created: 'bg-gray-500'
    };
    return colors[action] || 'bg-gray-500';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5" />
            Approval History & Audit Logs
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by email..."
                className="pl-10"
              />
            </div>
            <Select value={filterAction} onValueChange={setFilterAction}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="info_requested">Info Requested</SelectItem>
                <SelectItem value="modified">Modified</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {filteredHistory.map((item) => (
              <div key={item.id} className="p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <Badge className={getActionColor(item.action)}>
                      {item.action}
                    </Badge>
                    <span className="font-semibold">{item.admin_email}</span>
                  </div>
                  <span className="text-sm text-gray-500">
                    {new Date(item.created_at).toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-gray-600">
                  Account: {item.stripe_connect_accounts?.email || 'N/A'}
                </p>
                {item.reason && (
                  <p className="text-sm text-gray-700 mt-2 p-2 bg-gray-100 rounded">
                    {item.reason}
                  </p>
                )}
                {item.previous_status && (
                  <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                    <span>Status: {item.previous_status}</span>
                    <span>→</span>
                    <span>{item.new_status}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Audit Logs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {auditLogs.slice(0, 20).map((log) => (
              <div key={log.id} className="p-3 bg-gray-50 rounded text-sm">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold">{log.action_type}</span>
                  <span className="text-xs text-gray-500">
                    {new Date(log.created_at).toLocaleString()}
                  </span>
                </div>
                <p className="text-gray-600">
                  {log.admin_email} - {log.resource_type}
                </p>
                {log.error_message && (
                  <p className="text-red-600 text-xs mt-1">{log.error_message}</p>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}