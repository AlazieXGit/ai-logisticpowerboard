import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, UserX, Shield } from 'lucide-react';

const AccountSuspensionDisplay: React.FC = () => {
  const suspendedAccount = {
    username: 'admin_user',
    password: 'admin123',
    email: 'admin@company.com',
    suspensionReason: 'Invalid login credentials detected - Security threat identified',
    suspendedBy: 'Alucius Alford - Super Admin',
    suspendedAt: '7/25/2025, 3:45:21 PM',
    threatLevel: 'HIGH'
  };

  return (
    <div className="space-y-4">
      <Alert className="border-red-500 bg-red-900/30">
        <UserX className="h-5 w-5 text-red-400" />
        <AlertDescription className="text-red-300">
          <div className="space-y-2">
            <h3 className="font-bold text-lg">ACCOUNT SUSPENDED</h3>
            <p>The following admin account has been permanently suspended:</p>
          </div>
        </AlertDescription>
      </Alert>

      <Card className="bg-gray-900/50 border-red-500">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Suspended Account Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div>
                <label className="text-gray-400 text-sm">Username:</label>
                <div className="bg-gray-800 p-2 rounded font-mono text-red-300">
                  {suspendedAccount.username}
                </div>
              </div>
              <div>
                <label className="text-gray-400 text-sm">Password:</label>
                <div className="bg-gray-800 p-2 rounded font-mono text-red-300">
                  {suspendedAccount.password}
                </div>
              </div>
              <div>
                <label className="text-gray-400 text-sm">Email:</label>
                <div className="bg-gray-800 p-2 rounded font-mono text-red-300">
                  {suspendedAccount.email}
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-gray-400 text-sm">Suspended By:</label>
                <div className="bg-gray-800 p-2 rounded text-white">
                  {suspendedAccount.suspendedBy}
                </div>
              </div>
              <div>
                <label className="text-gray-400 text-sm">Suspension Date:</label>
                <div className="bg-gray-800 p-2 rounded text-white">
                  {suspendedAccount.suspendedAt}
                </div>
              </div>
              <div>
                <label className="text-gray-400 text-sm">Threat Level:</label>
                <div className="bg-red-800 p-2 rounded text-red-200 font-bold">
                  {suspendedAccount.threatLevel}
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4 p-3 bg-red-900/30 rounded border border-red-500/50">
            <h4 className="text-red-300 font-semibold mb-2">Suspension Reason:</h4>
            <p className="text-gray-300 text-sm">{suspendedAccount.suspensionReason}</p>
          </div>
        </CardContent>
      </Card>

      <Alert className="border-yellow-500 bg-yellow-900/20">
        <Shield className="h-5 w-5 text-yellow-400" />
        <AlertDescription className="text-yellow-300">
          <div className="space-y-2">
            <h4 className="font-semibold">Security Measures Active:</h4>
            <ul className="text-sm space-y-1">
              <li>• Single login route implemented</li>
              <li>• Only Alucius Alford authorized for system access</li>
              <li>• PIN 20201976 required for authentication</li>
              <li>• All standard user accounts suspended</li>
            </ul>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default AccountSuspensionDisplay;