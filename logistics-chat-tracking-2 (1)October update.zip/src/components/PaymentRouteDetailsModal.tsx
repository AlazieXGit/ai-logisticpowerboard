import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Key, CreditCard, Globe, Shield, Clock, 
  Database, AlertTriangle, Copy, Eye, EyeOff 
} from 'lucide-react';

interface RouteDetails {
  id: string;
  name: string;
  apiKey: string;
  secretKey: string;
  webhookUrl: string;
  accountId: string;
  merchantId: string;
  routingNumber: string;
  accountNumber: string;
  environment: 'live' | 'sandbox';
  lastSync: string;
  ipWhitelist: string[];
  rateLimit: string;
  retryAttempts: number;
  timeoutMs: number;
}

interface PaymentRouteDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  routeName: string;
}

const PaymentRouteDetailsModal: React.FC<PaymentRouteDetailsModalProps> = ({
  isOpen,
  onClose,
  routeName
}) => {
  const [showSensitive, setShowSensitive] = React.useState(false);

  const routeDetails: Record<string, RouteDetails> = {
    'Stripe Gateway': {
      id: 'stripe_001',
      name: 'Stripe Gateway',
      apiKey: 'pk_live_51H7zQrKj8...',
      secretKey: 'sk_live_51H7zQrKj8...',
      webhookUrl: 'https://api.alaziexpress.com/webhooks/stripe',
      accountId: 'acct_1H7zQrKj8YvKzQr',
      merchantId: 'STRIPE_MERCHANT_001',
      routingNumber: '021000021',
      accountNumber: '****7890',
      environment: 'live',
      lastSync: '2024-01-15 14:32:18',
      ipWhitelist: ['54.187.174.169', '54.187.205.235'],
      rateLimit: '100 req/min',
      retryAttempts: 3,
      timeoutMs: 30000
    },
    'Synergy Router': {
      id: 'synergy_001',
      name: 'Synergy Router',
      apiKey: 'syn_pk_live_7Hj9K...',
      secretKey: 'syn_sk_live_9Kj7H...',
      webhookUrl: 'https://api.alaziexpress.com/webhooks/synergy',
      accountId: 'syn_acct_001',
      merchantId: 'SYNERGY_MERCHANT_001',
      routingNumber: '026009593',
      accountNumber: '****4567',
      environment: 'live',
      lastSync: '2024-01-15 14:28:45',
      ipWhitelist: ['192.168.1.100', '10.0.0.50'],
      rateLimit: '150 req/min',
      retryAttempts: 5,
      timeoutMs: 25000
    },
    'Banking Direct': {
      id: 'banking_001',
      name: 'Banking Direct',
      apiKey: 'bd_api_live_Kj8H...',
      secretKey: 'bd_secret_live_H8jK...',
      webhookUrl: 'https://api.alaziexpress.com/webhooks/banking',
      accountId: 'bd_acct_001',
      merchantId: 'BANKING_MERCHANT_001',
      routingNumber: '121000248',
      accountNumber: '****1234',
      environment: 'live',
      lastSync: '2024-01-15 14:35:12',
      ipWhitelist: ['172.16.0.1', '203.0.113.5'],
      rateLimit: '80 req/min',
      retryAttempts: 4,
      timeoutMs: 35000
    },
    'Hosting Payment': {
      id: 'hosting_001',
      name: 'Hosting Payment',
      apiKey: 'hp_live_9Kj7H8...',
      secretKey: 'hp_secret_H8jK9...',
      webhookUrl: 'https://api.alaziexpress.com/webhooks/hosting',
      accountId: 'hp_acct_001',
      merchantId: 'HOSTING_MERCHANT_001',
      routingNumber: '111000025',
      accountNumber: '****9876',
      environment: 'live',
      lastSync: '2024-01-15 14:25:33',
      ipWhitelist: ['198.51.100.1', '203.0.113.10'],
      rateLimit: '60 req/min',
      retryAttempts: 2,
      timeoutMs: 20000
    }
  };

  const details = routeDetails[routeName];
  if (!details) return null;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const maskSensitive = (text: string) => {
    if (showSensitive) return text;
    return text.substring(0, 8) + '...';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-gray-900 border-gray-700 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Shield className="h-5 w-5 text-blue-400" />
            {details.name} - Sensitive Configuration
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Security Toggle */}
          <div className="flex items-center justify-between p-4 bg-red-900/20 border border-red-500 rounded">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              <span className="text-red-300">Sensitive Data Protection</span>
            </div>
            <Button
              onClick={() => setShowSensitive(!showSensitive)}
              variant="outline"
              size="sm"
              className="border-red-500 text-red-400 hover:bg-red-900/30"
            >
              {showSensitive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {showSensitive ? 'Hide' : 'Show'} Sensitive Data
            </Button>
          </div>

          {/* API Configuration */}
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-400">
                <Key className="h-5 w-5" />
                API Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">API Key</label>
                  <div className="flex items-center gap-2">
                    <code className="bg-gray-700 px-3 py-2 rounded text-green-400 flex-1">
                      {maskSensitive(details.apiKey)}
                    </code>
                    <Button size="sm" variant="ghost" onClick={() => copyToClipboard(details.apiKey)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Secret Key</label>
                  <div className="flex items-center gap-2">
                    <code className="bg-gray-700 px-3 py-2 rounded text-red-400 flex-1">
                      {maskSensitive(details.secretKey)}
                    </code>
                    <Button size="sm" variant="ghost" onClick={() => copyToClipboard(details.secretKey)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-gray-300 text-sm">Webhook URL</label>
                <div className="flex items-center gap-2">
                  <code className="bg-gray-700 px-3 py-2 rounded text-blue-400 flex-1">
                    {details.webhookUrl}
                  </code>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(details.webhookUrl)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Information */}
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-400">
                <CreditCard className="h-5 w-5" />
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Account ID</label>
                  <code className="bg-gray-700 px-3 py-2 rounded text-yellow-400 block">
                    {details.accountId}
                  </code>
                </div>
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Merchant ID</label>
                  <code className="bg-gray-700 px-3 py-2 rounded text-purple-400 block">
                    {details.merchantId}
                  </code>
                </div>
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Routing Number</label>
                  <code className="bg-gray-700 px-3 py-2 rounded text-orange-400 block">
                    {maskSensitive(details.routingNumber)}
                  </code>
                </div>
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Account Number</label>
                  <code className="bg-gray-700 px-3 py-2 rounded text-red-400 block">
                    {details.accountNumber}
                  </code>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System Configuration */}
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Database className="h-5 w-5" />
                System Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Environment</label>
                  <Badge variant={details.environment === 'live' ? 'default' : 'secondary'}>
                    {details.environment.toUpperCase()}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Last Sync</label>
                  <div className="flex items-center gap-2 text-gray-300">
                    <Clock className="h-4 w-4" />
                    {details.lastSync}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Rate Limit</label>
                  <span className="text-green-400">{details.rateLimit}</span>
                </div>
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Timeout</label>
                  <span className="text-blue-400">{details.timeoutMs}ms</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-gray-300 text-sm">IP Whitelist</label>
                <div className="flex flex-wrap gap-2">
                  {details.ipWhitelist.map((ip, index) => (
                    <Badge key={index} variant="outline" className="text-cyan-400 border-cyan-400">
                      {ip}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentRouteDetailsModal;