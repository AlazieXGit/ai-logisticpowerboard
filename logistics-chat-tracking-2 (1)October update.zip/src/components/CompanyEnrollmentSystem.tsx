import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Building2, Truck, Package, Users, Warehouse, 
  MapPin, Globe, CheckCircle, Clock 
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface CompanyType {
  type: string;
  icon: React.ReactNode;
  enrolled: number;
  target: number;
  contracts: number;
  status: 'active' | 'enrolling' | 'complete';
}

const CompanyEnrollmentSystem: React.FC = () => {
  const [companies, setCompanies] = useState<CompanyType[]>([
    { type: 'Shippers', icon: <Package className="h-5 w-5" />, enrolled: 28847, target: 29000, contracts: 28234, status: 'enrolling' },
    { type: 'Carriers', icon: <Truck className="h-5 w-5" />, enrolled: 28923, target: 29000, contracts: 28456, status: 'enrolling' },
    { type: 'Manufacturers', icon: <Building2 className="h-5 w-5" />, enrolled: 28756, target: 29000, contracts: 28123, status: 'enrolling' },
    { type: 'Brokers', icon: <Users className="h-5 w-5" />, enrolled: 28934, target: 29000, contracts: 28567, status: 'enrolling' },
    { type: 'Independent Drivers', icon: <MapPin className="h-5 w-5" />, enrolled: 28678, target: 29000, contracts: 27989, status: 'enrolling' },
    { type: 'Owner Operators', icon: <Truck className="h-5 w-5" />, enrolled: 28812, target: 29000, contracts: 28234, status: 'enrolling' },
    { type: 'Warehouses', icon: <Warehouse className="h-5 w-5" />, enrolled: 28789, target: 29000, contracts: 28156, status: 'enrolling' },
    { type: 'Distribution Centers', icon: <Building2 className="h-5 w-5" />, enrolled: 28901, target: 29000, contracts: 28345, status: 'enrolling' },
    { type: 'Domestic Businesses', icon: <Globe className="h-5 w-5" />, enrolled: 28823, target: 29000, contracts: 28267, status: 'enrolling' },
    { type: 'Alazie LLC Clients', icon: <Building2 className="h-5 w-5 text-lime-400" />, enrolled: 28945, target: 29000, contracts: 28678, status: 'enrolling' }
  ]);

  const [totalEnrolled, setTotalEnrolled] = useState(0);
  const [totalContracts, setTotalContracts] = useState(0);

  useEffect(() => {
    const total = companies.reduce((sum, company) => sum + company.enrolled, 0);
    const contracts = companies.reduce((sum, company) => sum + company.contracts, 0);
    setTotalEnrolled(total);
    setTotalContracts(contracts);
  }, [companies]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCompanies(prev => prev.map(company => {
        if (company.enrolled < company.target) {
          const increment = Math.floor(Math.random() * 5) + 1;
          const newEnrolled = Math.min(company.target, company.enrolled + increment);
          const newContracts = Math.floor(newEnrolled * 0.92);
          
          return {
            ...company,
            enrolled: newEnrolled,
            contracts: newContracts,
            status: newEnrolled >= company.target ? 'complete' : 'enrolling'
          };
        }
        return company;
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const generateContract = async (companyType: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('contract-generator', {
        body: {
          company_type: companyType,
          company_name: `${companyType} Company ${Date.now()}`,
          services: 'AI Load Board Auto Booking'
        }
      });

      if (error) throw error;
      
      console.log('Contract generated:', data);
    } catch (error) {
      console.error('Contract generation failed:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'complete': return 'bg-green-600';
      case 'enrolling': return 'bg-blue-600';
      case 'active': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/30 border-green-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Building2 className="h-6 w-6 text-green-400" />
              <CardTitle className="text-green-400">Company Enrollment System</CardTitle>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-white">{totalEnrolled.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Total Enrolled</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
              <div className="text-lg font-semibold text-blue-300 mb-2">Enrollment Progress</div>
              <div className="text-3xl font-bold text-white mb-1">{((totalEnrolled / 290000) * 100).toFixed(1)}%</div>
              <Progress value={(totalEnrolled / 290000) * 100} className="h-3" />
              <div className="text-sm text-gray-400 mt-2">Target: 290,000 companies</div>
            </div>
            
            <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30">
              <div className="text-lg font-semibold text-green-300 mb-2">Contracts Generated</div>
              <div className="text-3xl font-bold text-white mb-1">{totalContracts.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Auto-generated with AI</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {companies.map((company, index) => (
              <Card key={index} className="bg-gray-700/30 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {company.icon}
                      <span className="font-medium text-white">{company.type}</span>
                    </div>
                    <Badge className={getStatusColor(company.status)}>
                      {company.status === 'complete' ? <CheckCircle className="h-3 w-3 mr-1" /> : <Clock className="h-3 w-3 mr-1" />}
                      {company.status}
                    </Badge>
                  </div>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-300">Enrolled</span>
                        <span className="text-blue-400">{company.enrolled.toLocaleString()} / {company.target.toLocaleString()}</span>
                      </div>
                      <Progress value={(company.enrolled / company.target) * 100} className="h-2" />
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Contracts</span>
                      <span className="text-green-400">{company.contracts.toLocaleString()}</span>
                    </div>
                    
                    <Button 
                      size="sm" 
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => generateContract(company.type)}
                    >
                      Generate Contract
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CompanyEnrollmentSystem;