import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Users, CheckCircle, Ban, Shield, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const DirectDepositManager: React.FC = () => {
  const [processing, setProcessing] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [systemStatus, setSystemStatus] = useState('active');

  const employees = [
    { id: 'emp001', name: 'Jane Doe', department: 'Engineering', salary: 75000, account: '****1234', status: 'active' },
    { id: 'emp002', name: 'Mike Johnson', department: 'Sales', salary: 65000, account: '****5678', status: 'active' },
    { id: 'emp003', name: 'Sarah Wilson', department: 'Marketing', salary: 60000, account: '****9012', status: 'active' },
    { id: 'emp004', name: 'John Smith', department: 'Security', salary: 70000, account: '****3456', status: 'suspended' }
  ];

  useEffect(() => {
    const checkAdminStatus = () => {
      const adminStatus = localStorage.getItem('superAdminAuth');
      setIsSuperAdmin(adminStatus === 'authenticated');
    };
    checkAdminStatus();
  }, []);

  const processPayroll = async (employee: any) => {
    if (!isSuperAdmin) {
      alert('🚫 Super Admin access required for payroll processing');
      return;
    }

    if (employee.status === 'suspended') {
      alert(`❌ Payroll blocked for ${employee.name} - Account under targeted suspension`);
      return;
    }

    setProcessing(true);
    try {
      const { data } = await supabase.functions.invoke('payroll-processor', {
        body: {
          action: 'process_payroll',
          employeeId: employee.id,
          amount: employee.salary / 12, // Monthly salary
          adminOverride: true
        }
      });

      if (data?.success) {
        alert(`✅ Payroll processed for ${employee.name}: $${(employee.salary / 12).toLocaleString()}`);
      } else {
        throw new Error(data?.error || 'Payroll processing failed');
      }
    } catch (error: any) {
      console.error('Payroll error:', error);
      alert(`❌ Payroll failed for ${employee.name}: ${error.message}`);
    }
    setProcessing(false);
  };

  const processBulkPayroll = async () => {
    if (!isSuperAdmin) {
      alert('🚫 Super Admin access required for bulk payroll');
      return;
    }

    const activeEmployees = employees.filter(emp => emp.status === 'active');
    setProcessing(true);
    
    try {
      for (const employee of activeEmployees) {
        await processPayroll(employee);
      }
      alert(`✅ Bulk payroll completed for ${activeEmployees.length} employees`);
    } catch (error) {
      alert('❌ Bulk payroll processing encountered errors');
    }
    setProcessing(false);
  };

  if (!isSuperAdmin) {
    return (
      <Alert className="border-emerald-500 bg-emerald-900/20">
        <CheckCircle className="h-4 w-4" />
        <AlertDescription className="text-emerald-400 font-semibold">
          ✅ Employee payroll system reactivated (except targeted suspensions). Super Admin access required for processing.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Alert className="border-emerald-500 bg-emerald-900/20">
        <Shield className="h-4 w-4" />
        <AlertDescription className="text-emerald-400 font-semibold">
          🔐 Employee Direct Deposit System - Reactivated with Targeted Exceptions
        </AlertDescription>
      </Alert>

      <Card className="bg-emerald-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Users className="h-5 w-5" />
            Employee Payroll Management
            <Badge className="bg-emerald-600">ACTIVE</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Button
              onClick={processBulkPayroll}
              disabled={processing}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Shield className="h-4 w-4 mr-2" />
              {processing ? 'Processing...' : '🔐 Process All Active Payroll'}
            </Button>
          </div>

          <Table>
            <TableHeader>
              <TableRow className="border-gray-600">
                <TableHead className="text-gray-300">Employee</TableHead>
                <TableHead className="text-gray-300">Department</TableHead>
                <TableHead className="text-gray-300">Monthly Pay</TableHead>
                <TableHead className="text-gray-300">Account</TableHead>
                <TableHead className="text-gray-300">Status</TableHead>
                <TableHead className="text-gray-300">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees.map((employee) => (
                <TableRow key={employee.id} className="border-gray-600">
                  <TableCell className="text-white font-medium">{employee.name}</TableCell>
                  <TableCell className="text-gray-300">{employee.department}</TableCell>
                  <TableCell className="text-emerald-400 font-bold">
                    ${(employee.salary / 12).toLocaleString()}
                  </TableCell>
                  <TableCell className="text-gray-300 font-mono">{employee.account}</TableCell>
                  <TableCell>
                    <Badge className={employee.status === 'active' ? 'bg-emerald-600' : 'bg-red-600'}>
                      {employee.status === 'active' ? (
                        <><CheckCircle className="h-3 w-3 mr-1" />ACTIVE</>
                      ) : (
                        <><Ban className="h-3 w-3 mr-1" />SUSPENDED</>
                      )}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {employee.status === 'active' ? (
                      <Button
                        size="sm"
                        onClick={() => processPayroll(employee)}
                        disabled={processing}
                        className="bg-emerald-600 hover:bg-emerald-700"
                      >
                        <DollarSign className="h-3 w-3 mr-1" />
                        Pay
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        disabled
                        className="bg-red-600 cursor-not-allowed"
                      >
                        <Ban className="h-3 w-3 mr-1" />
                        Blocked
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="bg-red-900/20 border-red-500/50">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Ban className="h-5 w-5" />
            Targeted Suspensions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-gray-400 mb-2">
              Employee: <span className="text-red-400 font-bold">John Smith</span>
            </p>
            <p className="text-gray-400">
              Status: <Badge className="bg-red-600">TARGETED SUSPENSION</Badge>
            </p>
            <p className="text-sm text-gray-500 mt-2">Payroll processing blocked for security review</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DirectDepositManager;