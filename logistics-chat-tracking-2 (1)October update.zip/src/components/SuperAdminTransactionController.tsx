import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DollarSign, CreditCard, Zap, Shield, Infinity, User, Building, Star, ArrowUpDown, Minus } from 'lucide-react';

export const SuperAdminTransactionController: React.FC = () => {
  const [unlimitedMode, setUnlimitedMode] = useState(true);
  const [transactionAmount, setTransactionAmount] = useState('');
  const [processingPayment, setProcessingPayment] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState('');

  // Preset Alucius Alford Account Data
  const aluciosAccounts = {
    debitCards: [
      { id: 'dc001', number: '****-****-****-4521', bank: 'PNC Bank', balance: 2847592.45, status: 'Active', priority: 'HIGH' },
      { id: 'dc002', number: '****-****-****-8934', bank: 'Wells Fargo', balance: 1563847.23, status: 'Active', priority: 'HIGH' },
      { id: 'dc003', number: '****-****-****-2176', bank: 'Chase Bank', balance: 3294756.89, status: 'Active', priority: 'HIGH' }
    ],
    creditCards: [
      { id: 'cc001', number: '****-****-****-7845', bank: 'American Express', limit: 5000000, available: 4876543.21, priority: 'HIGH' },
      { id: 'cc002', number: '****-****-****-3629', bank: 'Visa Signature', limit: 2500000, available: 2398765.43, priority: 'HIGH' },
      { id: 'cc003', number: '****-****-****-9517', bank: 'Mastercard Black', limit: 10000000, available: 9847362.15, priority: 'HIGH' }
    ],
    checkingAccounts: [
      { id: 'ca001', routing: '043000096', account: '****5847', bank: 'PNC Bank', balance: 8947563.28, priority: 'HIGH' },
      { id: 'ca002', routing: '121000248', account: '****7392', bank: 'Wells Fargo', balance: 6543298.76, priority: 'HIGH' },
      { id: 'ca003', routing: '021000021', account: '****9485', bank: 'Chase Bank', balance: 12847596.34, priority: 'HIGH' }
    ]
  };

  const handleInstantTransfer = async (accountId: string, type: string) => {
    setProcessingPayment(true);
    setSelectedAccount(`${type}-${accountId}`);
    setTimeout(() => {
      setProcessingPayment(false);
      setSelectedAccount('');
    }, 2000);
  };

  const handleWithdrawal = async (accountId: string, type: string) => {
    setProcessingPayment(true);
    setSelectedAccount(`${type}-${accountId}`);
    setTimeout(() => {
      setProcessingPayment(false);
      setSelectedAccount('');
    }, 2500);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900 to-blue-900 border-purple-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Super Admin Transaction Controller - Alucius Alford Accounts
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-green-500 bg-green-900/20">
            <Infinity className="h-4 w-4" />
            <AlertDescription className="text-green-300">
              HIGH PRIORITY ACCOUNTS - UNLIMITED WITHDRAWAL & TRANSFER LIMITS ACTIVATED
            </AlertDescription>
          </Alert>

          <Tabs defaultValue="debit" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800">
              <TabsTrigger value="debit" className="text-white">Debit Cards</TabsTrigger>
              <TabsTrigger value="credit" className="text-white">Credit Cards</TabsTrigger>
              <TabsTrigger value="checking" className="text-white">Checking Accounts</TabsTrigger>
            </TabsList>

            <TabsContent value="debit" className="space-y-4">
              <div className="grid gap-4">
                {aluciosAccounts.debitCards.map((card) => (
                  <Card key={card.id} className="bg-black/40 border-green-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-2">
                          <CreditCard className="h-5 w-5 text-green-400" />
                          <span className="text-white font-semibold">{card.bank}</span>
                          <Badge className="bg-red-600 text-white">
                            <Star className="h-3 w-3 mr-1" />
                            {card.priority}
                          </Badge>
                        </div>
                        <span className="text-gray-300">{card.number}</span>
                      </div>
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-green-400 text-xl font-bold">
                          ${card.balance.toLocaleString()}
                        </span>
                        <Badge className="bg-green-600">{card.status}</Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleInstantTransfer(card.id, 'debit')}
                          disabled={processingPayment && selectedAccount === `debit-${card.id}`}
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                        >
                          <ArrowUpDown className="h-4 w-4 mr-1" />
                          {processingPayment && selectedAccount === `debit-${card.id}` ? 'Processing...' : 'Instant Transfer'}
                        </Button>
                        <Button
                          onClick={() => handleWithdrawal(card.id, 'debit')}
                          disabled={processingPayment && selectedAccount === `debit-${card.id}`}
                          className="flex-1 bg-red-600 hover:bg-red-700"
                        >
                          <Minus className="h-4 w-4 mr-1" />
                          {processingPayment && selectedAccount === `debit-${card.id}` ? 'Processing...' : 'Withdraw Funds'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="credit" className="space-y-4">
              <div className="grid gap-4">
                {aluciosAccounts.creditCards.map((card) => (
                  <Card key={card.id} className="bg-black/40 border-purple-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-2">
                          <CreditCard className="h-5 w-5 text-purple-400" />
                          <span className="text-white font-semibold">{card.bank}</span>
                          <Badge className="bg-red-600 text-white">
                            <Star className="h-3 w-3 mr-1" />
                            {card.priority}
                          </Badge>
                        </div>
                        <span className="text-gray-300">{card.number}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-3">
                        <div>
                          <span className="text-gray-400 text-sm">Available Credit</span>
                          <div className="text-purple-400 text-lg font-bold">
                            ${card.available.toLocaleString()}
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-400 text-sm">Credit Limit</span>
                          <div className="text-white text-lg font-bold">
                            ${card.limit.toLocaleString()}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleInstantTransfer(card.id, 'credit')}
                          disabled={processingPayment && selectedAccount === `credit-${card.id}`}
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                        >
                          <ArrowUpDown className="h-4 w-4 mr-1" />
                          {processingPayment && selectedAccount === `credit-${card.id}` ? 'Processing...' : 'Instant Transfer'}
                        </Button>
                        <Button
                          onClick={() => handleWithdrawal(card.id, 'credit')}
                          disabled={processingPayment && selectedAccount === `credit-${card.id}`}
                          className="flex-1 bg-red-600 hover:bg-red-700"
                        >
                          <Minus className="h-4 w-4 mr-1" />
                          {processingPayment && selectedAccount === `credit-${card.id}` ? 'Processing...' : 'Cash Advance'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="checking" className="space-y-4">
              <div className="grid gap-4">
                {aluciosAccounts.checkingAccounts.map((account) => (
                  <Card key={account.id} className="bg-black/40 border-blue-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-2">
                          <Building className="h-5 w-5 text-blue-400" />
                          <span className="text-white font-semibold">{account.bank}</span>
                          <Badge className="bg-red-600 text-white">
                            <Star className="h-3 w-3 mr-1" />
                            {account.priority}
                          </Badge>
                        </div>
                        <div className="text-gray-300 text-sm">
                          Routing: {account.routing} | Account: {account.account}
                        </div>
                      </div>
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-blue-400 text-xl font-bold">
                          ${account.balance.toLocaleString()}
                        </span>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleInstantTransfer(account.id, 'checking')}
                          disabled={processingPayment && selectedAccount === `checking-${account.id}`}
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                        >
                          <ArrowUpDown className="h-4 w-4 mr-1" />
                          {processingPayment && selectedAccount === `checking-${account.id}` ? 'Processing...' : 'Instant Transfer'}
                        </Button>
                        <Button
                          onClick={() => handleWithdrawal(account.id, 'checking')}
                          disabled={processingPayment && selectedAccount === `checking-${account.id}`}
                          className="flex-1 bg-red-600 hover:bg-red-700"
                        >
                          <Minus className="h-4 w-4 mr-1" />
                          {processingPayment && selectedAccount === `checking-${account.id}` ? 'Processing...' : 'Withdraw Funds'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="space-y-4 mt-6">
            <div>
              <label className="text-white text-sm mb-2 block">Manual Transaction Amount</label>
              <Input
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
                placeholder="Enter any amount (no limits for HIGH priority accounts)"
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>

            <div className="flex justify-center">
              <Badge className="bg-red-600 text-white px-4 py-2">
                <User className="h-4 w-4 mr-2" />
                ALUCIUS ALFORD - HIGH PRIORITY ACCOUNT HOLDER
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminTransactionController;