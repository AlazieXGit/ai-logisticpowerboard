import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { TestTube, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const DepositTestPanel: React.FC = () => {
  const [testResults, setTestResults] = useState<any[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const testCases = [
    {
      name: 'Valid Deposit Request',
      input: {
        action: 'process_deposit',
        user_id: 'user_123',
        amount: 150.00,
        currency: 'USD'
      },
      expectedStatus: 200
    },
    {
      name: 'Missing Required Fields',
      input: {
        action: 'process_deposit',
        amount: 150.00
      },
      expectedStatus: 400
    },
    {
      name: 'Invalid Amount (Zero)',
      input: {
        action: 'process_deposit',
        user_id: 'user_123',
        amount: 0,
        currency: 'USD'
      },
      expectedStatus: 400
    },
    {
      name: 'Unsupported Currency',
      input: {
        action: 'process_deposit',
        user_id: 'user_123',
        amount: 100.00,
        currency: 'BTC'
      },
      expectedStatus: 422
    },
    {
      name: 'Unknown Action',
      input: {
        action: 'withdraw_funds',
        user_id: 'user_123',
        amount: 50
      },
      expectedStatus: 400
    }
  ];

  const runTests = async () => {
    setIsRunning(true);
    const results = [];

    for (const testCase of testCases) {
      try {
        const { data, error } = await supabase.functions.invoke('banking-operations', {
          body: testCase.input
        });

        const passed = error ? 
          (error.message.includes('non-2xx') && testCase.expectedStatus !== 200) :
          (testCase.expectedStatus === 200);

        results.push({
          ...testCase,
          passed,
          response: data || error,
          actualStatus: error ? 'error' : 'success'
        });
      } catch (err) {
        results.push({
          ...testCase,
          passed: testCase.expectedStatus !== 200,
          response: err,
          actualStatus: 'error'
        });
      }
    }

    setTestResults(results);
    setIsRunning(false);
  };

  return (
    <Card className="bg-gray-800 border-blue-500/30">
      <CardHeader>
        <CardTitle className="text-blue-400 flex items-center gap-2">
          <TestTube className="h-5 w-5" />
          Deposit API Test Panel
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button 
          onClick={runTests}
          disabled={isRunning}
          className="w-full bg-blue-600 hover:bg-blue-700"
        >
          {isRunning ? 'Running Tests...' : 'Run All Tests'}
        </Button>

        {testResults.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-white font-semibold">Test Results:</h3>
            {testResults.map((result, index) => (
              <div key={index} className="bg-gray-700 p-3 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium">{result.name}</span>
                  <Badge className={result.passed ? 'bg-green-600' : 'bg-red-600'}>
                    {result.passed ? (
                      <><CheckCircle className="h-3 w-3 mr-1" />PASS</>
                    ) : (
                      <><XCircle className="h-3 w-3 mr-1" />FAIL</>
                    )}
                  </Badge>
                </div>
                <Textarea
                  value={JSON.stringify({
                    input: result.input,
                    expected: result.expectedStatus,
                    response: result.response
                  }, null, 2)}
                  readOnly
                  className="bg-gray-800 text-xs font-mono h-24"
                />
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DepositTestPanel;