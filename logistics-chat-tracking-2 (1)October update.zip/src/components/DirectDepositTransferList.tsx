import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Users, Building, UserCheck, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface TransferRecipient {
  id: string;
  name: string;
  type: 'employee' | 'contractor' | 'vendor';
  accountNumber: string;
  routingNumber: string;
  email: string;
  status: 'active' | 'inactive';
  createdAt: string;
}

const DirectDepositTransferList: React.FC = () => {
  const [recipients, setRecipients] = useState<TransferRecipient[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [newRecipient, setNewRecipient] = useState({
    name: '',
    type: 'employee' as const,
    accountNumber: '',
    routingNumber: '',
    email: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    loadRecipients();
  }, []);

  const loadRecipients = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_transfer_recipients' }
      });
      
      if (error) throw error;
      setRecipients(data?.recipients || []);
    } catch (error) {
      console.warn('Failed to load recipients, using mock data:', error);
      setRecipients([
        {
          id: '1',
          name: 'John Smith',
          type: 'employee',
          accountNumber: '****1234',
          routingNumber: '021000021',
          email: 'john@company.com',
          status: 'active',
          createdAt: new Date().toISOString()
        }
      ]);
    }
  };

  const addRecipient = async () => {
    if (!newRecipient.name || !newRecipient.accountNumber || !newRecipient.routingNumber) {
      toast({ title: 'Error', description: 'Please fill all required fields', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'add_transfer_recipient',
          ...newRecipient
        }
      });
      
      if (error) throw error;
      
      const recipient: TransferRecipient = {
        id: data?.id || Date.now().toString(),
        ...newRecipient,
        status: 'active',
        createdAt: new Date().toISOString()
      };
      
      setRecipients(prev => [...prev, recipient]);
      setNewRecipient({ name: '', type: 'employee', accountNumber: '', routingNumber: '', email: '' });
      setIsAddModalOpen(false);
      toast({ title: 'Success', description: 'Recipient added successfully' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to add recipient', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const deleteRecipient = async (id: string) => {
    try {
      await supabase.functions.invoke('banking-operations', {
        body: { action: 'delete_transfer_recipient', recipientId: id }
      });
      
      setRecipients(prev => prev.filter(r => r.id !== id));
      toast({ title: 'Success', description: 'Recipient deleted successfully' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to delete recipient', variant: 'destructive' });
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'employee': return <Users className="h-4 w-4" />;
      case 'contractor': return <UserCheck className="h-4 w-4" />;
      case 'vendor': return <Building className="h-4 w-4" />;
      default: return <Users className="h-4 w-4" />;
    }
  };

  return (
    <Card className="bg-gray-800 border-emerald-500/30">
      <CardHeader>
        <CardTitle className="text-emerald-400 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Direct Deposit Transfer Recipients
          </span>
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Recipient
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-800 border-emerald-500/30">
              <DialogHeader>
                <DialogTitle className="text-emerald-400">Add New Transfer Recipient</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label className="text-emerald-300">Full Name</Label>
                  <Input
                    value={newRecipient.name}
                    onChange={(e) => setNewRecipient(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-gray-700 border-emerald-500/30 text-white"
                    placeholder="Enter full name"
                  />
                </div>
                <div>
                  <Label className="text-emerald-300">Type</Label>
                  <Select value={newRecipient.type} onValueChange={(value: any) => setNewRecipient(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger className="bg-gray-700 border-emerald-500/30 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="employee">Employee</SelectItem>
                      <SelectItem value="contractor">Contractor</SelectItem>
                      <SelectItem value="vendor">Vendor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-emerald-300">Account Number</Label>
                  <Input
                    value={newRecipient.accountNumber}
                    onChange={(e) => setNewRecipient(prev => ({ ...prev, accountNumber: e.target.value }))}
                    className="bg-gray-700 border-emerald-500/30 text-white"
                    placeholder="Enter account number"
                  />
                </div>
                <div>
                  <Label className="text-emerald-300">Routing Number</Label>
                  <Input
                    value={newRecipient.routingNumber}
                    onChange={(e) => setNewRecipient(prev => ({ ...prev, routingNumber: e.target.value }))}
                    className="bg-gray-700 border-emerald-500/30 text-white"
                    placeholder="Enter routing number"
                  />
                </div>
                <div>
                  <Label className="text-emerald-300">Email</Label>
                  <Input
                    type="email"
                    value={newRecipient.email}
                    onChange={(e) => setNewRecipient(prev => ({ ...prev, email: e.target.value }))}
                    className="bg-gray-700 border-emerald-500/30 text-white"
                    placeholder="Enter email address"
                  />
                </div>
                <Button 
                  onClick={addRecipient} 
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  {loading ? 'Adding...' : 'Add Recipient'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border border-emerald-500/30">
          <Table>
            <TableHeader>
              <TableRow className="border-emerald-500/30">
                <TableHead className="text-emerald-300">Name</TableHead>
                <TableHead className="text-emerald-300">Type</TableHead>
                <TableHead className="text-emerald-300">Account</TableHead>
                <TableHead className="text-emerald-300">Email</TableHead>
                <TableHead className="text-emerald-300">Status</TableHead>
                <TableHead className="text-emerald-300">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recipients.map((recipient) => (
                <TableRow key={recipient.id} className="border-emerald-500/30">
                  <TableCell className="text-white font-medium">{recipient.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getTypeIcon(recipient.type)}
                      <span className="text-emerald-300 capitalize">{recipient.type}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-gray-300">
                    {recipient.accountNumber} • {recipient.routingNumber}
                  </TableCell>
                  <TableCell className="text-gray-300">{recipient.email}</TableCell>
                  <TableCell>
                    <Badge variant={recipient.status === 'active' ? 'default' : 'secondary'}>
                      {recipient.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteRecipient(recipient.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {recipients.length === 0 && (
            <div className="text-center py-8 text-gray-400">
              No transfer recipients found. Add one to get started.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default DirectDepositTransferList;