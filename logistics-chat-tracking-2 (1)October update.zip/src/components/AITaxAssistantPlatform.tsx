import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { FileText, Calculator, TrendingUp, AlertCircle, CheckCircle, Upload, Shield } from 'lucide-react';
import TaxCorrectionInstructionsPanel from './TaxCorrectionInstructionsPanel';

interface TaxFormData {
  personalInfo: PersonalInfo;
  income: IncomeData;
  deductions: DeductionData;
  documents: DocumentData[];
}

interface PersonalInfo {
  firstName: string;
  lastName: string;
  ssn: string;
  filingStatus: string;
  dependents: number;
  address: string;
  phone: string;
  email: string;
}

interface IncomeData {
  w2Income: number;
  selfEmployment: number;
  investments: number;
  rental: number;
  unemployment: number;
  other: number;
}

interface DeductionData {
  standardDeduction: boolean;
  itemizedDeductions: ItemizedDeduction[];
  businessExpenses: number;
  charitableContributions: number;
  medicalExpenses: number;
}

interface ItemizedDeduction {
  type: string;
  amount: number;
  description: string;
}

interface DocumentData {
  type: string;
  name: string;
  uploaded: boolean;
  required: boolean;
}

export const AITaxAssistantPlatform: React.FC = () => {
  const [formData, setFormData] = useState<TaxFormData>({
    personalInfo: {
      firstName: '', lastName: '', ssn: '', filingStatus: '', 
      dependents: 0, address: '', phone: '', email: ''
    },
    income: {
      w2Income: 0, selfEmployment: 0, investments: 0, 
      rental: 0, unemployment: 0, other: 0
    },
    deductions: {
      standardDeduction: true, itemizedDeductions: [], 
      businessExpenses: 0, charitableContributions: 0, medicalExpenses: 0
    },
    documents: []
  });

  const [completionProgress, setCompletionProgress] = useState(15);
  const [aiAnalysis, setAiAnalysis] = useState({
    estimatedRefund: 2450,
    taxOwed: 0,
    effectiveRate: 12.5,
    suggestions: [
      'Consider maximizing retirement contributions',
      'Review charitable deduction opportunities',
      'Optimize business expense deductions'
    ]
  });

  return (
    <div className="p-6 space-y-6">
      {/* Real-Time Actual Revenue Display */}
      <Card className="bg-gradient-to-r from-red-900/30 to-red-800/20 border-red-500 border-2">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <TrendingUp className="h-6 w-6 animate-pulse" />
            Real-Time Actual Revenue Display - AI Tax Platform
            <Badge className="bg-red-600 text-white animate-pulse ml-2">REAL DATA</Badge>
          </CardTitle>
          <p className="text-gray-300 text-sm">
            Last Updated: {new Date().toLocaleString('en-US', { 
              weekday: 'short', 
              year: 'numeric', 
              month: 'short', 
              day: 'numeric', 
              hour: '2-digit', 
              minute: '2-digit', 
              second: '2-digit',
              timeZoneName: 'short'
            })}
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">$1,847,300</div>
              <div className="text-sm text-gray-300">Today's Revenue (71% of projected)</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">1,247</div>
              <div className="text-sm text-gray-300">Active Tax Returns</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">$1.5K/hr</div>
              <div className="text-sm text-gray-300">Revenue Rate</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-6 w-6" />
            AI Tax Assistant Platform
          </CardTitle>
          <div className="flex items-center gap-4">
            <Progress value={completionProgress} className="flex-1" />
            <Badge variant="outline">{completionProgress}% Complete</Badge>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="personal" className="space-y-4">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="personal">Personal Info</TabsTrigger>
          <TabsTrigger value="income">Income</TabsTrigger>
          <TabsTrigger value="deductions">Deductions</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
          <TabsTrigger value="corrections">Corrections</TabsTrigger>
          <TabsTrigger value="review">Review & File</TabsTrigger>
        </TabsList>

        <TabsContent value="personal">
          <PersonalInfoForm formData={formData} setFormData={setFormData} />
        </TabsContent>

        <TabsContent value="income">
          <IncomeForm formData={formData} setFormData={setFormData} />
        </TabsContent>

        <TabsContent value="deductions">
          <DeductionsForm formData={formData} setFormData={setFormData} />
        </TabsContent>

        <TabsContent value="documents">
          <DocumentsUpload formData={formData} setFormData={setFormData} />
        </TabsContent>

        <TabsContent value="analysis">
          <AIAnalysisPanel analysis={aiAnalysis} />
        </TabsContent>

        <TabsContent value="corrections">
          <TaxCorrectionInstructionsPanel />
        </TabsContent>

        <TabsContent value="review">
          <ReviewAndFile formData={formData} analysis={aiAnalysis} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

const PersonalInfoForm: React.FC<{formData: TaxFormData, setFormData: any}> = ({ formData, setFormData }) => (
  <Card>
    <CardHeader>
      <CardTitle>Personal Information</CardTitle>
    </CardHeader>
    <CardContent className="grid grid-cols-2 gap-4">
      <div>
        <Label>First Name</Label>
        <Input placeholder="Enter first name" />
      </div>
      <div>
        <Label>Last Name</Label>
        <Input placeholder="Enter last name" />
      </div>
      <div>
        <Label>Social Security Number</Label>
        <Input placeholder="XXX-XX-XXXX" type="password" />
      </div>
      <div>
        <Label>Filing Status</Label>
        <Select>
          <SelectTrigger>
            <SelectValue placeholder="Select status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="single">Single</SelectItem>
            <SelectItem value="married-joint">Married Filing Jointly</SelectItem>
            <SelectItem value="married-separate">Married Filing Separately</SelectItem>
            <SelectItem value="head">Head of Household</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="col-span-2">
        <Label>Address</Label>
        <Textarea placeholder="Full address" />
      </div>
    </CardContent>
  </Card>
);

const IncomeForm: React.FC<{formData: TaxFormData, setFormData: any}> = ({ formData, setFormData }) => (
  <Card>
    <CardHeader>
      <CardTitle>Income Sources</CardTitle>
    </CardHeader>
    <CardContent className="grid grid-cols-2 gap-4">
      <div>
        <Label>W-2 Wages</Label>
        <Input type="number" placeholder="0.00" />
      </div>
      <div>
        <Label>Self-Employment Income</Label>
        <Input type="number" placeholder="0.00" />
      </div>
      <div>
        <Label>Investment Income</Label>
        <Input type="number" placeholder="0.00" />
      </div>
      <div>
        <Label>Rental Income</Label>
        <Input type="number" placeholder="0.00" />
      </div>
      <div>
        <Label>Unemployment Benefits</Label>
        <Input type="number" placeholder="0.00" />
      </div>
      <div>
        <Label>Other Income</Label>
        <Input type="number" placeholder="0.00" />
      </div>
    </CardContent>
  </Card>
);

const DeductionsForm: React.FC<{formData: TaxFormData, setFormData: any}> = ({ formData, setFormData }) => (
  <Card>
    <CardHeader>
      <CardTitle>Deductions & Credits</CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="flex items-center space-x-2">
        <input type="radio" name="deduction" id="standard" />
        <Label htmlFor="standard">Standard Deduction ($13,850)</Label>
      </div>
      <div className="flex items-center space-x-2">
        <input type="radio" name="deduction" id="itemized" />
        <Label htmlFor="itemized">Itemized Deductions</Label>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Business Expenses</Label>
          <Input type="number" placeholder="0.00" />
        </div>
        <div>
          <Label>Charitable Contributions</Label>
          <Input type="number" placeholder="0.00" />
        </div>
        <div>
          <Label>Medical Expenses</Label>
          <Input type="number" placeholder="0.00" />
        </div>
        <div>
          <Label>State & Local Taxes</Label>
          <Input type="number" placeholder="0.00" />
        </div>
      </div>
    </CardContent>
  </Card>
);

const DocumentsUpload: React.FC<{formData: TaxFormData, setFormData: any}> = ({ formData, setFormData }) => (
  <Card>
    <CardHeader>
      <CardTitle>Required Documents</CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      {['W-2 Forms', '1099 Forms', 'Receipts', 'Bank Statements'].map((doc) => (
        <div key={doc} className="flex items-center justify-between p-4 border rounded">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span>{doc}</span>
          </div>
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Upload
          </Button>
        </div>
      ))}
    </CardContent>
  </Card>
);

const AIAnalysisPanel: React.FC<{analysis: any}> = ({ analysis }) => (
  <div className="space-y-4">
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          AI Tax Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              ${analysis.estimatedRefund.toLocaleString()}
            </div>
            <div className="text-sm text-gray-500">Estimated Refund</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{analysis.effectiveRate}%</div>
            <div className="text-sm text-gray-500">Effective Tax Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">
              ${analysis.taxOwed.toLocaleString()}
            </div>
            <div className="text-sm text-gray-500">Tax Owed</div>
          </div>
        </div>
      </CardContent>
    </Card>

    <Card>
      <CardHeader>
        <CardTitle>AI Recommendations</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {analysis.suggestions.map((suggestion: string, index: number) => (
            <div key={index} className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>{suggestion}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  </div>
);

const ReviewAndFile: React.FC<{formData: TaxFormData, analysis: any}> = ({ formData, analysis }) => (
  <Card>
    <CardHeader>
      <CardTitle>Review & File Tax Return</CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
        <div className="flex items-center gap-2">
          <AlertCircle className="h-5 w-5 text-yellow-600" />
          <span className="font-medium">Review Required</span>
        </div>
        <p className="text-sm text-yellow-700 mt-1">
          Please review all information before filing your tax return.
        </p>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <Button className="w-full" size="lg">
          Save as Draft
        </Button>
        <Button className="w-full" variant="default" size="lg">
          File Tax Return
        </Button>
      </div>
    </CardContent>
  </Card>
);

export default AITaxAssistantPlatform;