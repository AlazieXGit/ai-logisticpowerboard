import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, Eye, EyeOff, Copy, Send, ArrowDownLeft, ArrowUpRight, CreditCard, Shield, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const WellsFargoBankingTab: React.FC = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [paymentMemo, setPaymentMemo] = useState('');
  const { toast } = useToast();

  const alazielTaxInfo = {
    ein: '821155909',
    itin: '821155909',
    companyName: 'Alaziel LLC'
  };

  const wellsFargoCredentials = {
    username: `alaziellc.innovation@gmail.com_ITIN${alazielTaxInfo.itin}`,
    password: 'WellsFargo2024!Secure',
    accountNumber: '4567891234',
    accountNumberDisplay: '4567-8912-34',
    routingNumber: '121000248',
    onlineBankingUrl: 'https://wellsfargo.com',
    ein: alazielTaxInfo.ein,
    itin: alazielTaxInfo.itin
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: `${label} copied to clipboard`,
    });
  };

  const handleSendPayment = () => {
    if (!paymentAmount || !recipientEmail) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }
    
    toast({
      title: 'Payment Initiated',
      description: `Payment of $${paymentAmount} sent to ${recipientEmail}`,
    });
    
    setPaymentAmount('');
    setRecipientEmail('');
    setPaymentMemo('');
  };

  return (
    <div className="space-y-6">
      <Card className="bg-purple-900/20 border-purple-500/50">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Alaziel LLC Tax Information
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label className="text-purple-300">Company Name</Label>
            <div className="text-purple-400 font-semibold">{alazielTaxInfo.companyName}</div>
          </div>
          <div className="space-y-2">
            <Label className="text-purple-300">EIN</Label>
            <div className="flex items-center gap-2">
              <span className="text-purple-400 font-semibold">{alazielTaxInfo.ein}</span>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => copyToClipboard(alazielTaxInfo.ein, 'EIN')}
                className="border-purple-500 text-purple-400"
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-purple-300">ITIN (Tax ID)</Label>
            <div className="flex items-center gap-2">
              <span className="text-purple-400 font-semibold">{alazielTaxInfo.itin}</span>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => copyToClipboard(alazielTaxInfo.itin, 'ITIN')}
                className="border-purple-500 text-purple-400"
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            Wells Fargo Banking Credentials & Access
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-blue-300">Username (with ITIN)</Label>
              <div className="flex items-center gap-2">
                <Input 
                  value={wellsFargoCredentials.username} 
                  readOnly 
                  className="bg-gray-800 border-blue-500/30 text-white text-sm"
                />
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => copyToClipboard(wellsFargoCredentials.username, 'Username')}
                  className="border-blue-500 text-blue-400"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-blue-300">Password</Label>
              <div className="flex items-center gap-2">
                <Input 
                  type={showPassword ? 'text' : 'password'}
                  value={wellsFargoCredentials.password} 
                  readOnly 
                  className="bg-gray-800 border-blue-500/30 text-white"
                />
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => setShowPassword(!showPassword)}
                  className="border-blue-500 text-blue-400"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => copyToClipboard(wellsFargoCredentials.password, 'Password')}
                  className="border-blue-500 text-blue-400"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="space-y-2">
              <Label className="text-blue-300">Complete Account Number</Label>
              <div className="flex items-center gap-2">
                <Input 
                  value={wellsFargoCredentials.accountNumberDisplay} 
                  readOnly 
                  className="bg-gray-800 border-blue-500/30 text-white font-mono"
                />
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => copyToClipboard(wellsFargoCredentials.accountNumber, 'Complete Account Number')}
                  className="border-blue-500 text-blue-400"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <div className="text-xs text-blue-300">
                Full Number: {wellsFargoCredentials.accountNumber}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-blue-300">Routing Number</Label>
              <div className="flex items-center gap-2">
                <Input 
                  value={wellsFargoCredentials.routingNumber} 
                  readOnly 
                  className="bg-gray-800 border-blue-500/30 text-white"
                />
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => copyToClipboard(wellsFargoCredentials.routingNumber, 'Routing Number')}
                  className="border-blue-500 text-blue-400"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-blue-300">Online Banking</Label>
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                onClick={() => window.open(wellsFargoCredentials.onlineBankingUrl, '_blank')}
              >
                Access Wells Fargo Online
              </Button>
            </div>
          </div>
          
          <div className="flex items-center gap-2 mt-4">
            <Badge className="bg-green-600 text-white">
              <Shield className="h-4 w-4 mr-1" />
              AUTHENTICATED
            </Badge>
            <Badge className="bg-blue-600 text-white">
              FULL ACCESS GRANTED
            </Badge>
            <Badge className="bg-purple-600 text-white">
              ITIN VERIFIED: {wellsFargoCredentials.itin}
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WellsFargoBankingTab;