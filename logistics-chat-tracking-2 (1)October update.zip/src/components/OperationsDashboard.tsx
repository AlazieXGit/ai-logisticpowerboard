import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Download, Users, DollarSign, TrendingUp, Activity, Clock, Volume2 } from 'lucide-react';

const OperationsDashboard = () => {
  const handleDownload = (docName: string) => {
    // Simulate document download
    const link = document.createElement('a');
    link.href = '#';
    link.download = `${docName}.pdf`;
    link.click();
  };

  const divisions = [
    {
      title: "Payment Processing Operations",
      department: "Finance",
      status: "Active",
      statusColor: "bg-green-500",
      description: "Managing all payment processing systems and integrations",
      manager: "John Smith",
      budget: "$250,000",
      employees: 12,
      kpis: [
        { label: "99.9% Uptime", icon: Activity, value: "99.9%", metric: "Uptime" },
        { label: "2.5s Avg Response Time", icon: Clock, value: "2.5s", metric: "Response Time" },
        { label: "$2.3M Monthly Volume", icon: DollarSign, value: "$2.3M", metric: "Monthly Volume" }
      ],
      documents: [
        "SOP Manual",
        "Compliance Guide", 
        "Training Materials"
      ]
    },
    {
      title: "TMS Platform Management",
      department: "Technology", 
      status: "Active",
      statusColor: "bg-blue-500",
      description: "Transportation Management System operations and support",
      manager: "Sarah Johnson",
      budget: "$180,000",
      employees: 8,
      kpis: [
        { label: "500+ Active Users", icon: Users, value: "500+", metric: "Active Users" },
        { label: "95% Customer Satisfaction", icon: TrendingUp, value: "95%", metric: "Satisfaction" },
        { label: "24/7 Support", icon: Activity, value: "24/7", metric: "Support" }
      ],
      documents: [
        "User Manual",
        "API Documentation",
        "Support Procedures"
      ]
    },
    {
      title: "Asset Management Division",
      department: "Operations",
      status: "Expanding", 
      statusColor: "bg-orange-500",
      description: "Managing vehicle acquisitions and asset portfolio",
      manager: "Mike Davis",
      budget: "$320,000",
      employees: 15,
      kpis: [
        { label: "$8.5M Assets Under Management", icon: DollarSign, value: "$8.5M", metric: "AUM" },
        { label: "15.2% Annual Growth", icon: TrendingUp, value: "15.2%", metric: "Growth" },
        { label: "147 Vehicles", icon: Volume2, value: "147", metric: "Vehicles" }
      ],
      documents: [
        "Asset Registry",
        "Acquisition Procedures", 
        "Valuation Reports"
      ]
    }
  ];

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-slate-800 mb-2">Operations Dashboard</h1>
        <p className="text-slate-600">Comprehensive overview of all operational divisions</p>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-1">
        {divisions.map((division, index) => (
          <Card key={index} className="shadow-lg hover:shadow-xl transition-shadow border-0">
            <CardHeader className="pb-4">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl font-bold text-slate-800">{division.title}</CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline" className="text-slate-600">{division.department}</Badge>
                    <Badge className={`${division.statusColor} text-white`}>{division.status}</Badge>
                  </div>
                </div>
              </div>
              <p className="text-slate-600 mt-3">{division.description}</p>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Management Info */}
              <div className="grid grid-cols-3 gap-4 p-4 bg-slate-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-slate-500">Manager</p>
                  <p className="text-lg font-semibold text-slate-800">{division.manager}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-500">Budget</p>
                  <p className="text-lg font-semibold text-green-600">{division.budget}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-500">Employees</p>
                  <p className="text-lg font-semibold text-blue-600">{division.employees}</p>
                </div>
              </div>

              {/* KPIs */}
              <div>
                <h4 className="text-lg font-semibold text-slate-800 mb-3">Key Performance Indicators</h4>
                <div className="grid grid-cols-3 gap-4">
                  {division.kpis.map((kpi, kpiIndex) => (
                    <div key={kpiIndex} className="bg-white p-4 rounded-lg border shadow-sm">
                      <div className="flex items-center gap-2 mb-2">
                        <kpi.icon className="h-5 w-5 text-blue-600" />
                        <span className="text-sm font-medium text-slate-500">{kpi.metric}</span>
                      </div>
                      <p className="text-2xl font-bold text-slate-800">{kpi.value}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Documents */}
              <div>
                <h4 className="text-lg font-semibold text-slate-800 mb-3">Documents</h4>
                <div className="grid grid-cols-3 gap-3">
                  {division.documents.map((doc, docIndex) => (
                    <Button
                      key={docIndex}
                      variant="outline"
                      onClick={() => handleDownload(doc)}
                      className="flex items-center gap-2 justify-start p-3 h-auto"
                    >
                      <Download className="h-4 w-4" />
                      <span className="text-sm">{doc}</span>
                    </Button>
                  ))}
                </div>
                <p className="text-xs text-slate-500 mt-2">All documents are available for download</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default OperationsDashboard;