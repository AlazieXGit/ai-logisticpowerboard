import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Building, DollarSign, ArrowRight, Plus, Trash2 } from 'lucide-react';

const ManualTransferForum = () => {
  const [transferType, setTransferType] = useState('card');
  const [amount, setAmount] = useState('7777');
  const [memo, setMemo] = useState('');
  const [selectedCard, setSelectedCard] = useState('4031631245486508');
  const [selectedAccount, setSelectedAccount] = useState('');

  const [cards, setCards] = useState([
    {
      id: '1',
      number: '4031631245486508',
      fullNumber: '4031631245486508',
      expiry: '06/30',
      cvv: '379',
      name: 'Alucius Alford',
      type: 'Credit',
      bank: 'Chase Sapphire'
    }
  ]);

  const [newCard, setNewCard] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: '',
    type: 'Credit',
    bank: ''
  });

  const checkingAccounts = [
    { id: 'ch001', name: 'Primary Checking', routing: '021000021', account: '****1234', balance: 2847592.45 },
    { id: 'ch002', name: 'Business Checking', routing: '091000019', account: '****5678', balance: 1963847.23 },
    { id: 'ch003', name: 'Trust Account', routing: '031201360', account: '****9012', balance: 3594756.89 }
  ];

  const addCard = () => {
    if (newCard.number && newCard.expiry && newCard.cvv && newCard.name) {
      const card = {
        id: Date.now().toString(),
        fullNumber: newCard.number,
        number: newCard.number,
        expiry: newCard.expiry,
        cvv: newCard.cvv,
        name: newCard.name,
        type: newCard.type,
        bank: newCard.bank || 'Unknown Bank'
      };
      setCards([...cards, card]);
      setNewCard({ number: '', expiry: '', cvv: '', name: '', type: 'Credit', bank: '' });
    }
  };

  const deleteCard = (cardId: string) => {
    setCards(cards.filter(card => card.id !== cardId));
    if (selectedCard === cards.find(c => c.id === cardId)?.number) {
      setSelectedCard(cards[0]?.number || '');
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-300 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Manual Card & Account Transfer Forum
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Transfer Type Selection */}
          <div className="grid grid-cols-2 gap-4">
            <Button
              onClick={() => setTransferType('card')}
              className={`${transferType === 'card' ? 'bg-blue-600' : 'bg-gray-700'} text-white`}
            >
              <CreditCard className="h-4 w-4 mr-2" />
              Card Transfer
            </Button>
            <Button
              onClick={() => setTransferType('checking')}
              className={`${transferType === 'checking' ? 'bg-purple-600' : 'bg-gray-700'} text-white`}
            >
              <Building className="h-4 w-4 mr-2" />
              Checking Transfer
            </Button>
          </div>

          {/* Source Account */}
          <div className="space-y-2">
            <label className="text-white font-semibold">Internal Source Account</label>
            <div className="bg-gray-800 p-4 rounded-lg">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-blue-300 font-semibold">Platform Fee Collection</p>
                  <p className="text-gray-400 text-sm">Stripe</p>
                </div>
                <p className="text-green-400 font-bold text-xl">$45,600</p>
              </div>
            </div>
          </div>

          {/* Transfer Amount */}
          <div className="space-y-2">
            <label className="text-white font-semibold">Transfer Amount</label>
            <Input
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-gray-800 border-gray-600 text-white"
              placeholder="Enter amount"
            />
          </div>

          {/* Memo */}
          <div className="space-y-2">
            <label className="text-white font-semibold">Memo (Optional)</label>
            <Textarea
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              className="bg-gray-800 border-gray-600 text-white"
              placeholder="Transfer description or notes..."
              rows={3}
            />
          </div>

          {transferType === 'card' && (
            <>
              {/* Card Management Section */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-white font-semibold">Target Card Account (Credit To)</h3>
                  <Badge className="bg-blue-600">Card Transfer Mode</Badge>
                </div>

                {/* Existing Cards */}
                <div className="space-y-3">
                  {cards.map((card) => (
                    <div key={card.id} className="bg-gray-800 p-4 rounded-lg border border-gray-600">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          <input
                            type="radio"
                            name="selectedCard"
                            value={card.number}
                            checked={selectedCard === card.number}
                            onChange={(e) => setSelectedCard(e.target.value)}
                            className="text-blue-600"
                          />
                          <div>
                            <p className="text-blue-300 font-semibold">{card.name}</p>
                            <p className="text-gray-300 font-mono">**** **** **** {card.number.slice(-4)}</p>
                            <p className="text-gray-400 text-sm">{card.expiry} | CVV: {card.cvv}</p>
                            <Badge className={card.type === 'Credit' ? 'bg-purple-600' : 'bg-green-600'}>
                              {card.type}
                            </Badge>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => deleteCard(card.id)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add New Card */}
                <Card className="bg-gray-900 border-green-500/30">
                  <CardHeader>
                    <CardTitle className="text-green-300 text-sm flex items-center gap-2">
                      <Plus className="h-4 w-4" />
                      Add New Card
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-gray-300 text-sm">Card Number</label>
                        <Input
                          value={newCard.number}
                          onChange={(e) => setNewCard({...newCard, number: e.target.value})}
                          className="bg-gray-800 border-gray-600 text-white"
                          placeholder="1234567890123456"
                        />
                      </div>
                      <div>
                        <label className="text-gray-300 text-sm">Cardholder Name</label>
                        <Input
                          value={newCard.name}
                          onChange={(e) => setNewCard({...newCard, name: e.target.value})}
                          className="bg-gray-800 border-gray-600 text-white"
                          placeholder="Full Name"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="text-gray-300 text-sm">Expiry Date</label>
                        <Input
                          value={newCard.expiry}
                          onChange={(e) => setNewCard({...newCard, expiry: e.target.value})}
                          className="bg-gray-800 border-gray-600 text-white"
                          placeholder="MM/YY"
                        />
                      </div>
                      <div>
                        <label className="text-gray-300 text-sm">CVV</label>
                        <Input
                          value={newCard.cvv}
                          onChange={(e) => setNewCard({...newCard, cvv: e.target.value})}
                          className="bg-gray-800 border-gray-600 text-white"
                          placeholder="123"
                        />
                      </div>
                      <div>
                        <label className="text-gray-300 text-sm">Type</label>
                        <Select value={newCard.type} onValueChange={(value) => setNewCard({...newCard, type: value})}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Credit">Credit Card</SelectItem>
                            <SelectItem value="Debit">Debit Card</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <label className="text-gray-300 text-sm">Bank Name</label>
                      <Input
                        value={newCard.bank}
                        onChange={(e) => setNewCard({...newCard, bank: e.target.value})}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="Bank Name"
                      />
                    </div>
                    <Button onClick={addCard} className="w-full bg-green-600 hover:bg-green-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Card
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {transferType === 'checking' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-white font-semibold">Target Checking Account</h3>
                <Badge className="bg-purple-600">Checking Transfer Mode</Badge>
              </div>

              <div className="space-y-3">
                {checkingAccounts.map((account) => (
                  <div key={account.id} className="bg-gray-800 p-4 rounded-lg border border-gray-600">
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="selectedAccount"
                        value={account.id}
                        checked={selectedAccount === account.id}
                        onChange={(e) => setSelectedAccount(e.target.value)}
                        className="text-purple-600"
                      />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-purple-300 font-semibold">{account.name}</p>
                            <p className="text-gray-300 font-mono">Routing: {account.routing}</p>
                            <p className="text-gray-300 font-mono">Account: {account.account}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-green-400 font-bold text-lg">${account.balance.toLocaleString()}</p>
                            <p className="text-gray-400 text-sm">Available Balance</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Process Transfer Button */}
          <div className="pt-4 border-t border-gray-600">
            <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3">
              <DollarSign className="h-4 w-4 mr-2" />
              Process Transfer
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ManualTransferForum;