import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { 
  TrendingUp, DollarSign, PieChart, BarChart3, 
  Download, Activity, Target, Zap 
} from 'lucide-react';

interface PlatformRevenue {
  platform: string;
  totalRevenue: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  fees: number;
  netRevenue: number;
  transactionCount: number;
  growthRate: number;
}

const EnhancedRevenueTrackingDashboard: React.FC = () => {
  const [platformData, setPlatformData] = useState<PlatformRevenue[]>([]);
  const [totalCombinedRevenue, setTotalCombinedRevenue] = useState(0);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchRevenueData();
    const interval = setInterval(fetchRevenueData, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchRevenueData = async () => {
    try {
      const mockPlatforms: PlatformRevenue[] = [
        {
          platform: 'Trust Banking System',
          totalRevenue: 15800000,
          monthlyRevenue: 1316667,
          yearlyRevenue: 15800000,
          fees: 158000,
          netRevenue: 15642000,
          transactionCount: 18420,
          growthRate: 28.7
        },
        {
          platform: 'AI Loadboard Platform',
          totalRevenue: 9200000,
          monthlyRevenue: 766667,
          yearlyRevenue: 9200000,
          fees: 92000,
          netRevenue: 9108000,
          transactionCount: 12850,
          growthRate: 31.4
        },
        {
          platform: 'Payment Processing Hub',
          totalRevenue: 7500000,
          monthlyRevenue: 625000,
          yearlyRevenue: 7500000,
          fees: 75000,
          netRevenue: 7425000,
          transactionCount: 8950,
          growthRate: 25.8
        },
        {
          platform: 'Credit Repair AI',
          totalRevenue: 6200000,
          monthlyRevenue: 516667,
          yearlyRevenue: 6200000,
          fees: 62000,
          netRevenue: 6138000,
          transactionCount: 4200,
          growthRate: 35.2
        },
        {
          platform: 'Automotive AI Services',
          totalRevenue: 5600000,
          monthlyRevenue: 466667,
          yearlyRevenue: 5600000,
          fees: 56000,
          netRevenue: 5544000,
          transactionCount: 2850,
          growthRate: 29.6
        }
      ];

      setPlatformData(mockPlatforms);
      const combined = mockPlatforms.reduce((sum, p) => sum + p.totalRevenue, 0);
      setTotalCombinedRevenue(combined);
    } catch (error) {
      console.error('Error fetching revenue data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const downloadReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      totalCombinedRevenue,
      platforms: platformData,
      summary: {
        totalFees: platformData.reduce((sum, p) => sum + p.fees, 0),
        totalNetRevenue: platformData.reduce((sum, p) => sum + p.netRevenue, 0),
        totalTransactions: platformData.reduce((sum, p) => sum + p.transactionCount, 0),
        averageGrowthRate: platformData.reduce((sum, p) => sum + p.growthRate, 0) / platformData.length
      }
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `revenue-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  if (loading) {
    return <div className="animate-pulse bg-gray-200 h-96 rounded-lg"></div>;
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-emerald-600 to-green-700 text-white">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-3xl font-bold flex items-center gap-2">
                <TrendingUp className="h-8 w-8" />
                Enhanced Revenue Tracking Dashboard
              </CardTitle>
              <p className="text-emerald-100 mt-2">Real-time platform revenue analysis with advanced metrics</p>
            </div>
            <Button 
              onClick={downloadReport}
              className="bg-white text-emerald-600 hover:bg-emerald-50"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <p className="text-emerald-200 text-sm">Total Combined Revenue</p>
              <p className="text-4xl font-bold">{formatCurrency(totalCombinedRevenue)}</p>
            </div>
            <div>
              <p className="text-emerald-200 text-sm">Active Platforms</p>
              <p className="text-3xl font-bold">{platformData.length}</p>
            </div>
            <div>
              <p className="text-emerald-200 text-sm">Total Transactions</p>
              <p className="text-3xl font-bold">
                {platformData.reduce((sum, p) => sum + p.transactionCount, 0).toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-emerald-200 text-sm">Avg Growth Rate</p>
              <p className="text-3xl font-bold">
                {(platformData.reduce((sum, p) => sum + p.growthRate, 0) / platformData.length).toFixed(1)}%
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Platform Overview</TabsTrigger>
          <TabsTrigger value="monthly">Monthly Analysis</TabsTrigger>
          <TabsTrigger value="yearly">Yearly Projections</TabsTrigger>
          <TabsTrigger value="fees">Fee Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {platformData.map((platform) => (
              <Card key={platform.platform} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{platform.platform}</span>
                    <Badge className={`${
                      platform.growthRate > 25 ? 'bg-green-500' :
                      platform.growthRate > 15 ? 'bg-yellow-500' : 'bg-blue-500'
                    } text-white`}>
                      +{platform.growthRate}% Growth
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Total Revenue</span>
                      <span className="text-2xl font-bold text-green-600">
                        {formatCurrency(platform.totalRevenue)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Net Revenue</span>
                      <span className="text-lg font-semibold text-emerald-600">
                        {formatCurrency(platform.netRevenue)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Transactions</span>
                      <span className="font-medium">{platform.transactionCount.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full"
                        style={{ 
                          width: `${(platform.totalRevenue / Math.max(...platformData.map(p => p.totalRevenue))) * 100}%` 
                        }}
                      ></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="monthly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Monthly Revenue Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {platformData.map((platform) => (
                  <div key={platform.platform} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{platform.platform}</span>
                      <span className="text-xl font-bold text-green-600">
                        {formatCurrency(platform.monthlyRevenue)}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600">
                      Monthly average based on current performance
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="yearly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Yearly Revenue Projections
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {platformData.map((platform) => (
                  <div key={platform.platform} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{platform.platform}</span>
                      <span className="text-xl font-bold text-blue-600">
                        {formatCurrency(platform.yearlyRevenue)}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600">
                      Projected annual revenue with {platform.growthRate}% growth rate
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fees" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Fee Structure & Net Revenue Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {platformData.map((platform) => (
                  <div key={platform.platform} className="p-4 border rounded-lg">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <span className="text-sm text-gray-600">Platform Fees</span>
                        <div className="text-lg font-semibold text-red-600">
                          {formatCurrency(platform.fees)}
                        </div>
                      </div>
                      <div>
                        <span className="text-sm text-gray-600">Net Revenue</span>
                        <div className="text-lg font-semibold text-green-600">
                          {formatCurrency(platform.netRevenue)}
                        </div>
                      </div>
                      <div>
                        <span className="text-sm text-gray-600">Profit Margin</span>
                        <div className="text-lg font-semibold text-blue-600">
                          {((platform.netRevenue / platform.totalRevenue) * 100).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedRevenueTrackingDashboard;