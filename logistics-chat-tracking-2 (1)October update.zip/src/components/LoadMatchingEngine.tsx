import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Target, Zap, TrendingUp, MapPin, Clock, 
  CheckCircle, AlertTriangle, Truck 
} from 'lucide-react';

interface LoadMatch {
  id: string;
  loadId: string;
  carrierId: string;
  matchScore: number;
  distance: number;
  estimatedProfit: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  autoBookable: boolean;
}

const LoadMatchingEngine: React.FC = () => {
  const [matches, setMatches] = useState<LoadMatch[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [autoMatchEnabled, setAutoMatchEnabled] = useState(true);

  useEffect(() => {
    generateMatches();
    const interval = setInterval(generateMatches, 15000);
    return () => clearInterval(interval);
  }, []);

  const generateMatches = async () => {
    setIsProcessing(true);
    
    // Simulate AI matching algorithm
    const mockMatches: LoadMatch[] = [
      {
        id: 'M001',
        loadId: 'LD001',
        carrierId: 'CR001',
        matchScore: 95,
        distance: 12,
        estimatedProfit: 2100,
        riskLevel: 'LOW',
        autoBookable: true
      },
      {
        id: 'M002',
        loadId: 'LD002',
        carrierId: 'CR002',
        matchScore: 87,
        distance: 25,
        estimatedProfit: 1650,
        riskLevel: 'MEDIUM',
        autoBookable: false
      },
      {
        id: 'M003',
        loadId: 'LD003',
        carrierId: 'CR003',
        matchScore: 92,
        distance: 8,
        estimatedProfit: 1890,
        riskLevel: 'LOW',
        autoBookable: true
      }
    ];
    
    setTimeout(() => {
      setMatches(mockMatches);
      setIsProcessing(false);
    }, 2000);
  };

  const autoBookMatch = async (match: LoadMatch) => {
    if (match.autoBookable && match.matchScore > 90) {
      // Auto-book high-confidence matches
      console.log(`Auto-booking match ${match.id}`);
      // Remove from matches after booking
      setMatches(prev => prev.filter(m => m.id !== match.id));
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/30 border-blue-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Target className="h-6 w-6 text-blue-400" />
              <CardTitle className="text-blue-400">AI Load Matching Engine</CardTitle>
            </div>
            <div className="flex items-center gap-3">
              <Badge className={autoMatchEnabled ? 'bg-green-600' : 'bg-gray-600'}>
                Auto-Match: {autoMatchEnabled ? 'ON' : 'OFF'}
              </Badge>
              <Button
                size="sm"
                onClick={() => setAutoMatchEnabled(!autoMatchEnabled)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Toggle Auto-Match
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isProcessing && (
            <Alert className="border-blue-500 bg-blue-900/20 mb-4">
              <Zap className="h-4 w-4 animate-pulse" />
              <AlertDescription className="text-blue-300">
                AI Engine processing load matches...
              </AlertDescription>
            </Alert>
          )}
          
          <div className="space-y-4">
            {matches.map((match) => (
              <Card key={match.id} className="bg-gray-700/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Badge className="bg-purple-600">Match {match.id}</Badge>
                      <span className="text-white">Load {match.loadId} → Carrier {match.carrierId}</span>
                    </div>
                    <Badge className={
                      match.riskLevel === 'LOW' ? 'bg-green-600' : 
                      match.riskLevel === 'MEDIUM' ? 'bg-yellow-600' : 'bg-red-600'
                    }>
                      {match.riskLevel} RISK
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-4 mb-3">
                    <div>
                      <p className="text-gray-400 text-xs">Match Score</p>
                      <div className="flex items-center gap-2">
                        <Progress value={match.matchScore} className="flex-1 h-2" />
                        <span className="text-green-400 font-bold">{match.matchScore}%</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Distance</p>
                      <p className="text-blue-400 font-semibold">{match.distance} mi</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Est. Profit</p>
                      <p className="text-green-400 font-semibold">${match.estimatedProfit}</p>
                    </div>
                    <div className="text-right">
                      {match.autoBookable && match.matchScore > 90 ? (
                        <Button
                          size="sm"
                          onClick={() => autoBookMatch(match)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Auto-Book
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-gray-500 text-gray-300"
                        >
                          Manual Review
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoadMatchingEngine;