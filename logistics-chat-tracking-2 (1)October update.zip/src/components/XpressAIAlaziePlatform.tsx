import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Sparkles, DollarSign, Server, Shield, Activity, 
  CreditCard, Truck, Building2, BarChart3, Zap
} from 'lucide-react';

const XpressAIAlaziePlatform: React.FC = () => {
  const [isActive, setIsActive] = useState(true);
  const [revenue, setRevenue] = useState(0);
  const [transactions, setTransactions] = useState(0);
  const [users, setUsers] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setRevenue(prev => prev + Math.random() * 1000);
      setTransactions(prev => prev + Math.floor(Math.random() * 10));
      setUsers(prev => prev + Math.floor(Math.random() * 5));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-black p-6">
      <Card className="bg-black/90 border-purple-500 mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sparkles className="h-8 w-8 text-purple-400" />
              <div>
                <CardTitle className="text-3xl text-purple-400">
                  XPRESS AI ALAZIE PLATFORM
                </CardTitle>
                <p className="text-gray-300">Unified Payment Routing & AI Services</p>
              </div>
            </div>
            <Badge className={`px-4 py-2 ${isActive ? 'bg-green-600' : 'bg-red-600'}`}>
              {isActive ? 'ACTIVE' : 'INACTIVE'}
            </Badge>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="bg-gray-800/50 border-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400">Live Revenue</p>
                <p className="text-2xl font-bold text-green-400">
                  ${revenue.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400">Transactions</p>
                <p className="text-2xl font-bold text-blue-400">{transactions}</p>
              </div>
              <Activity className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400">Active Users</p>
                <p className="text-2xl font-bold text-purple-400">{users}</p>
              </div>
              <Server className="h-8 w-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="payment-routing" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800 border border-purple-500/30 mb-6">
          <TabsTrigger value="payment-routing" className="text-green-300 data-[state=active]:bg-green-600">
            <CreditCard className="h-4 w-4 mr-2" />
            Payment Routing
          </TabsTrigger>
          <TabsTrigger value="ai-services" className="text-purple-300 data-[state=active]:bg-purple-600">
            <Sparkles className="h-4 w-4 mr-2" />
            AI Services
          </TabsTrigger>
          <TabsTrigger value="user-portals" className="text-blue-300 data-[state=active]:bg-blue-600">
            <Building2 className="h-4 w-4 mr-2" />
            User Portals
          </TabsTrigger>
          <TabsTrigger value="analytics" className="text-orange-300 data-[state=active]:bg-orange-600">
            <BarChart3 className="h-4 w-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="payment-routing">
          <div className="space-y-6">
            <Alert className="border-green-500 bg-green-900/20">
              <AlertDescription className="text-green-300">
                🚀 Seamless Payment Routing System Active - Processing all transactions through unified gateway
              </AlertDescription>
            </Alert>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-400" />
                    Payment Processors
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Stripe Integration</span>
                    <Badge className="bg-green-600">ACTIVE</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Synergy Payment Router</span>
                    <Badge className="bg-green-600">ACTIVE</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Banking Integration</span>
                    <Badge className="bg-green-600">ACTIVE</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Hosting Payment Gateway</span>
                    <Badge className="bg-green-600">ACTIVE</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Revenue Distribution</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Primary Account</span>
                    <span className="text-green-400">65%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Trust Account</span>
                    <span className="text-blue-400">25%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Operational Fund</span>
                    <span className="text-purple-400">10%</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="ai-services">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-gray-800/30 border-purple-500">
              <CardHeader>
                <CardTitle className="text-purple-400">AI Loadboard</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Intelligent load matching and dispatch automation</p>
                <Button className="mt-3 bg-purple-600 hover:bg-purple-700">
                  Access Service
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-blue-500">
              <CardHeader>
                <CardTitle className="text-blue-400">Banking Assistant</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">AI-powered financial management and analysis</p>
                <Button className="mt-3 bg-blue-600 hover:bg-blue-700">
                  Access Service
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-green-500">
              <CardHeader>
                <CardTitle className="text-green-400">Revenue Optimizer</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Automated revenue enhancement and routing</p>
                <Button className="mt-3 bg-green-600 hover:bg-green-700">
                  Access Service
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="user-portals">
          <Alert className="border-blue-500 bg-blue-900/20 mb-6">
            <AlertDescription className="text-blue-300">
              🔒 All user portals are accessible to registered members. Sensitive information is restricted to Super Admin controls only.
            </AlertDescription>
          </Alert>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800/30 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">Member Services</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start" variant="outline">
                  <Truck className="h-4 w-4 mr-2" />
                  Load Board Access
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <DollarSign className="h-4 w-4 mr-2" />
                  Payment Portal
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Analytics Dashboard
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <Shield className="h-4 w-4 mr-2" />
                  Account Management
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/30 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">Service Access</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Public Access</span>
                  <Badge className="bg-green-600">ENABLED</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Member Portal</span>
                  <Badge className="bg-green-600">ENABLED</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Sensitive Data</span>
                  <Badge className="bg-red-600">ADMIN ONLY</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-gray-800/30 border-green-500">
                <CardContent className="p-4 text-center">
                  <p className="text-green-400 text-2xl font-bold">98.7%</p>
                  <p className="text-gray-400">System Uptime</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-800/30 border-blue-500">
                <CardContent className="p-4 text-center">
                  <p className="text-blue-400 text-2xl font-bold">1,247</p>
                  <p className="text-gray-400">Active Sessions</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-800/30 border-purple-500">
                <CardContent className="p-4 text-center">
                  <p className="text-purple-400 text-2xl font-bold">$2.4M</p>
                  <p className="text-gray-400">Monthly Revenue</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-800/30 border-orange-500">
                <CardContent className="p-4 text-center">
                  <p className="text-orange-400 text-2xl font-bold">15,892</p>
                  <p className="text-gray-400">Total Transactions</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default XpressAIAlaziePlatform;