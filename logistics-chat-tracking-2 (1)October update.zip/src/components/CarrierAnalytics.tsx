import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  BarChart3, TrendingUp, Users, Star, 
  Clock, DollarSign, Truck, Award,
  AlertTriangle, CheckCircle
} from 'lucide-react';

interface CarrierMetrics {
  carrierId: string;
  name: string;
  rating: number;
  totalLoads: number;
  onTimeDelivery: number;
  averageRate: number;
  totalRevenue: number;
  riskScore: number;
  preferredStatus: boolean;
  lastActive: string;
}

const CarrierAnalytics: React.FC = () => {
  const [carriers, setCarriers] = useState<CarrierMetrics[]>([]);
  const [sortBy, setSortBy] = useState<'rating' | 'revenue' | 'loads'>('rating');
  const [filterStatus, setFilterStatus] = useState<'all' | 'preferred' | 'standard'>('all');

  useEffect(() => {
    loadCarrierData();
  }, []);

  const loadCarrierData = () => {
    const mockCarriers: CarrierMetrics[] = [
      {
        carrierId: 'CR001',
        name: 'Swift Transport Solutions',
        rating: 4.8,
        totalLoads: 156,
        onTimeDelivery: 96,
        averageRate: 2250,
        totalRevenue: 351000,
        riskScore: 15,
        preferredStatus: true,
        lastActive: '2025-01-07 15:30'
      },
      {
        carrierId: 'CR002',
        name: 'Elite Freight Services',
        rating: 4.6,
        totalLoads: 89,
        onTimeDelivery: 92,
        averageRate: 2100,
        totalRevenue: 186900,
        riskScore: 22,
        preferredStatus: true,
        lastActive: '2025-01-07 12:15'
      },
      {
        carrierId: 'CR003',
        name: 'Reliable Logistics Co',
        rating: 4.2,
        totalLoads: 203,
        onTimeDelivery: 88,
        averageRate: 1950,
        totalRevenue: 395850,
        riskScore: 35,
        preferredStatus: false,
        lastActive: '2025-01-06 18:45'
      },
      {
        carrierId: 'CR004',
        name: 'Express Cargo Lines',
        rating: 4.9,
        totalLoads: 67,
        onTimeDelivery: 98,
        averageRate: 2400,
        totalRevenue: 160800,
        riskScore: 8,
        preferredStatus: true,
        lastActive: '2025-01-07 16:20'
      }
    ];
    
    setCarriers(mockCarriers);
  };

  const sortedCarriers = [...carriers].sort((a, b) => {
    switch (sortBy) {
      case 'rating': return b.rating - a.rating;
      case 'revenue': return b.totalRevenue - a.totalRevenue;
      case 'loads': return b.totalLoads - a.totalLoads;
      default: return 0;
    }
  });

  const filteredCarriers = sortedCarriers.filter(carrier => {
    if (filterStatus === 'preferred') return carrier.preferredStatus;
    if (filterStatus === 'standard') return !carrier.preferredStatus;
    return true;
  });

  const getRiskColor = (score: number) => {
    if (score <= 20) return 'text-green-400';
    if (score <= 40) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getRatingStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i} 
        className={`h-4 w-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-400'}`} 
      />
    ));
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/30 border-orange-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BarChart3 className="h-6 w-6 text-orange-400" />
              <CardTitle className="text-orange-400">Advanced Carrier Analytics</CardTitle>
            </div>
            <div className="flex items-center gap-3">
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-gray-700 border border-gray-600 rounded px-3 py-1 text-white text-sm"
              >
                <option value="rating">Sort by Rating</option>
                <option value="revenue">Sort by Revenue</option>
                <option value="loads">Sort by Loads</option>
              </select>
              <select 
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="bg-gray-700 border border-gray-600 rounded px-3 py-1 text-white text-sm"
              >
                <option value="all">All Carriers</option>
                <option value="preferred">Preferred Only</option>
                <option value="standard">Standard Only</option>
              </select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Alert className="border-orange-500 bg-orange-900/20 mb-4">
            <TrendingUp className="h-4 w-4" />
            <AlertDescription className="text-orange-300">
              AI-powered carrier performance analysis with predictive risk scoring
            </AlertDescription>
          </Alert>
          
          <div className="space-y-4">
            {filteredCarriers.map((carrier) => (
              <Card key={carrier.carrierId} className="bg-gray-700/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Badge className={carrier.preferredStatus ? 'bg-gold-600' : 'bg-gray-600'}>
                        {carrier.preferredStatus ? (
                          <><Award className="h-3 w-3 mr-1" />PREFERRED</>
                        ) : 'STANDARD'}
                      </Badge>
                      <div>
                        <h3 className="text-white font-semibold">{carrier.name}</h3>
                        <p className="text-gray-400 text-sm">ID: {carrier.carrierId}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 mb-1">
                        {getRatingStars(carrier.rating)}
                        <span className="text-white ml-2">{carrier.rating}</span>
                      </div>
                      <p className="text-gray-400 text-xs">Last Active: {carrier.lastActive}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-5 gap-4 mb-4">
                    <div>
                      <p className="text-gray-400 text-xs">Total Loads</p>
                      <p className="text-blue-400 font-bold text-lg">{carrier.totalLoads}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">On-Time %</p>
                      <div className="flex items-center gap-2">
                        <Progress value={carrier.onTimeDelivery} className="flex-1 h-2" />
                        <span className="text-green-400 font-semibold text-sm">{carrier.onTimeDelivery}%</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Avg Rate</p>
                      <p className="text-green-400 font-semibold">${carrier.averageRate}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Total Revenue</p>
                      <p className="text-purple-400 font-semibold">${carrier.totalRevenue.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Risk Score</p>
                      <p className={`font-semibold ${getRiskColor(carrier.riskScore)}`}>
                        {carrier.riskScore}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {carrier.onTimeDelivery >= 95 && (
                        <Badge className="bg-green-600">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Excellent Performance
                        </Badge>
                      )}
                      {carrier.riskScore > 40 && (
                        <Badge className="bg-red-600">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          High Risk
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        View Details
                      </Button>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        Assign Load
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CarrierAnalytics;