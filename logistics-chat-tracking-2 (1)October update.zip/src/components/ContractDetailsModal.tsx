import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Download, Mail, FileText, DollarSign } from 'lucide-react';

interface ContractDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  contract: any;
}

export default function ContractDetailsModal({ isOpen, onClose, contract }: ContractDetailsModalProps) {
  if (!contract) return null;

  const handleDownload = () => {
    // Create contract PDF content
    const contractContent = `
VEHICLE PURCHASE CONTRACT

Contract ID: ${contract.id}
Date: ${contract.date}

VEHICLE DETAILS:
- Vehicle: ${contract.vehicle}
- Price: ${contract.price}
- Dealership: ${contract.dealership}

BUYER INFORMATION:
- Name: Alucius Alford
- Company: Alazie LLC
- Email: alaziellc.innovation@gmail.com
- Address: 2408 Yanceyville St. Greensboro N.C. 27405

DELIVERY DETAILS:
- Delivery Address: 2408 Yanceyville St. Greensboro N.C. 27405
- Contact: alaziellc.innovation@gmail.com

ACCOUNT DEBITED:
- Account: PNC Business Account
- Account Number: ****-****-****-1234
- Transaction ID: ${contract.transactionId}
- Amount: ${contract.price}

This contract is legally binding and has been electronically signed.
    `;

    const blob = new Blob([contractContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${contract.vehicle}_Contract.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Contract Details - {contract.vehicle}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Vehicle Information</h4>
                  <div className="space-y-1 text-sm">
                    <div>Vehicle: {contract.vehicle}</div>
                    <div>Price: {contract.price}</div>
                    <div>Dealership: {contract.dealership}</div>
                    <div>Status: <Badge variant="outline">{contract.status}</Badge></div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Contract Details</h4>
                  <div className="space-y-1 text-sm">
                    <div>Contract ID: {contract.id}</div>
                    <div>Date: {contract.date}</div>
                    <div>Owner: Alucius Alford</div>
                    <div>Company: Alazie LLC</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <h4 className="font-semibold mb-2">Account Debited</h4>
              <div className="space-y-1 text-sm">
                <div>Account: PNC Business Account</div>
                <div>Account Number: ****-****-****-1234</div>
                <div>Transaction ID: {contract.transactionId}</div>
                <div className="flex items-center gap-1">
                  <DollarSign className="h-4 w-4" />
                  Amount Debited: {contract.price}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <h4 className="font-semibold mb-2">Delivery Information</h4>
              <div className="space-y-1 text-sm">
                <div>Delivery Address: 2408 Yanceyville St. Greensboro N.C. 27405</div>
                <div>Contact Email: alaziellc.innovation@gmail.com</div>
                <div>Delivery Service: {contract.deliveryService}</div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button onClick={handleDownload} className="flex-1">
              <Download className="h-4 w-4 mr-2" />
              Download Contract
            </Button>
            <Button variant="outline" className="flex-1">
              <Mail className="h-4 w-4 mr-2" />
              Email Copy
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}