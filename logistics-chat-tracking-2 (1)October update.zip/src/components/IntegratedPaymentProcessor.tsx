import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CreditCard, DollarSign, Zap, Bell } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface FeeNotification {
  id: string;
  type: 'fee_applied' | 'payment_processed' | 'revenue_distributed';
  amount: number;
  fees: Record<string, number>;
  timestamp: Date;
}

interface PaymentData {
  amount: number;
  description: string;
  userId: string;
  serviceType: 'automated' | 'manual';
}

const IntegratedPaymentProcessor: React.FC = () => {
  const [notifications, setNotifications] = useState<FeeNotification[]>([]);
  const [processing, setProcessing] = useState(false);
  const [totalRevenue, setTotalRevenue] = useState(0);

  const feeStructure = {
    admin: 0.05,
    aiGen: 0.05,
    autoBooking: 0.05,
    service: 0.05,
    platform: 0.07
  };

  const calculateFees = (amount: number) => {
    const fees = {
      admin: amount * feeStructure.admin,
      aiGen: amount * feeStructure.aiGen,
      autoBooking: amount * feeStructure.autoBooking,
      service: amount * feeStructure.service,
      platform: amount * feeStructure.platform
    };
    const totalFees = Object.values(fees).reduce((sum, fee) => sum + fee, 0);
    return { fees, totalFees, netAmount: amount - totalFees };
  };

  const processPayment = async (paymentData: PaymentData) => {
    setProcessing(true);
    try {
      const { fees, totalFees, netAmount } = calculateFees(paymentData.amount);
      
      // Process payment with integrated fees
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'process_payment_with_fees',
          amount: paymentData.amount,
          fees,
          description: paymentData.description,
          userId: paymentData.userId,
          serviceType: paymentData.serviceType
        }
      });

      if (error) throw error;

      // Create real-time notification
      const notification: FeeNotification = {
        id: Date.now().toString(),
        type: 'fee_applied',
        amount: paymentData.amount,
        fees,
        timestamp: new Date()
      };

      setNotifications(prev => [notification, ...prev.slice(0, 9)]);
      setTotalRevenue(prev => prev + totalFees);

      // Route revenue to appropriate accounts
      await routeRevenue(fees);

    } catch (error) {
      console.error('Payment processing error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const routeRevenue = async (fees: Record<string, number>) => {
    try {
      await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'distribute_revenue',
          fees,
          timestamp: new Date().toISOString()
        }
      });

      const notification: FeeNotification = {
        id: Date.now().toString() + '_revenue',
        type: 'revenue_distributed',
        amount: Object.values(fees).reduce((sum, fee) => sum + fee, 0),
        fees,
        timestamp: new Date()
      };

      setNotifications(prev => [notification, ...prev.slice(0, 9)]);
    } catch (error) {
      console.error('Revenue routing error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-green-900/20 border-green-500/50">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Integrated Payment Processor with Automated Fees
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {Object.entries(feeStructure).map(([key, rate]) => (
              <Card key={key} className="bg-gray-800/30">
                <CardContent className="p-3 text-center">
                  <div className="text-sm text-gray-300 capitalize">{key} Fee</div>
                  <div className="text-lg font-bold text-green-400">{(rate * 100)}%</div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Alert className="border-yellow-500 bg-yellow-900/20">
            <AlertDescription className="text-yellow-300">
              <Zap className="h-4 w-4 inline mr-2" />
              Total Fee Rate: 27% | All automated services subject to mandatory fees
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Real-Time Fee Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {notifications.map((notification) => (
              <div key={notification.id} className="p-3 bg-gray-800/50 rounded-lg border border-gray-600">
                <div className="flex justify-between items-start">
                  <div>
                    <Badge className={
                      notification.type === 'fee_applied' ? 'bg-green-600' :
                      notification.type === 'revenue_distributed' ? 'bg-blue-600' : 'bg-purple-600'
                    }>
                      {notification.type.replace('_', ' ').toUpperCase()}
                    </Badge>
                    <div className="text-sm text-gray-300 mt-1">
                      Amount: ${notification.amount.toFixed(2)}
                    </div>
                  </div>
                  <div className="text-xs text-gray-400">
                    {notification.timestamp.toLocaleTimeString()}
                  </div>
                </div>
                <div className="grid grid-cols-5 gap-2 mt-2 text-xs">
                  {Object.entries(notification.fees).map(([key, amount]) => (
                    <div key={key} className="text-center">
                      <div className="text-gray-400 capitalize">{key}</div>
                      <div className="text-green-400">${amount.toFixed(2)}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default IntegratedPaymentProcessor;