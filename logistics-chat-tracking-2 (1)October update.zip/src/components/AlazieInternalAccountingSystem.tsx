import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Building2, DollarSign, FileText, Calculator, TrendingUp, Copy, CheckCircle } from 'lucide-react';

const AlazieInternalAccountingSystem: React.FC = () => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const alazieCompanyInfo = {
    name: 'Alazie LLC',
    owner: 'Alucius Alford',
    ein: '82-1155909',
    address: 'C/O: Alucius Alford',
    type: 'Limited Liability Company',
    status: 'Active'
  };

  const internalAccounts = [
    {
      name: 'Operating Revenue',
      account: 'ALAZIE-OP-001',
      balance: 2847592.33,
      type: 'Revenue Collection'
    },
    {
      name: 'Processing Fees',
      account: 'ALAZIE-FEE-002', 
      balance: 892456.78,
      type: 'Fee Collection'
    },
    {
      name: 'Platform Services',
      account: 'ALAZIE-SVC-003',
      balance: 1456789.12,
      type: 'Service Revenue'
    }
  ];

  return (
    <div className="space-y-6">
      <Alert className="border-blue-500 bg-blue-900/20">
        <Building2 className="h-4 w-4" />
        <AlertDescription className="text-blue-300">
          🏢 ALAZIE LLC INTERNAL ACCOUNTING & PAYMENT PROCESSING SYSTEM - EIN: {alazieCompanyInfo.ein}
        </AlertDescription>
      </Alert>

      <Card className="bg-gray-800/30 border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-cyan-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Company Registration Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Company Name:</span>
                <div className="flex items-center gap-2">
                  <code className="text-cyan-400 font-bold">{alazieCompanyInfo.name}</code>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(alazieCompanyInfo.name, 'name')}>
                    {copiedField === 'name' ? <CheckCircle className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3" />}
                  </Button>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Owner:</span>
                <div className="flex items-center gap-2">
                  <code className="text-green-400">{alazieCompanyInfo.owner}</code>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(alazieCompanyInfo.owner, 'owner')}>
                    {copiedField === 'owner' ? <CheckCircle className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3" />}
                  </Button>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">EIN:</span>
                <div className="flex items-center gap-2">
                  <code className="text-yellow-400 font-bold">{alazieCompanyInfo.ein}</code>
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(alazieCompanyInfo.ein, 'ein')}>
                    {copiedField === 'ein' ? <CheckCircle className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3" />}
                  </Button>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Type:</span>
                <Badge className="bg-purple-600">{alazieCompanyInfo.type}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Status:</span>
                <Badge className="bg-green-600">{alazieCompanyInfo.status}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Address:</span>
                <code className="text-blue-400">{alazieCompanyInfo.address}</code>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="accounts" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800 border border-cyan-500/30">
          <TabsTrigger value="accounts" className="text-cyan-300 data-[state=active]:bg-cyan-600">
            <DollarSign className="h-4 w-4 mr-2" />
            Internal Accounts
          </TabsTrigger>
          <TabsTrigger value="processing" className="text-green-300 data-[state=active]:bg-green-600">
            <Calculator className="h-4 w-4 mr-2" />
            Payment Processing
          </TabsTrigger>
          <TabsTrigger value="revenue" className="text-yellow-300 data-[state=active]:bg-yellow-600">
            <TrendingUp className="h-4 w-4 mr-2" />
            Revenue Tracking
          </TabsTrigger>
          <TabsTrigger value="documents" className="text-purple-300 data-[state=active]:bg-purple-600">
            <FileText className="h-4 w-4 mr-2" />
            Legal Documents
          </TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {internalAccounts.map((account, index) => (
              <Card key={index} className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-sm">{account.name}</CardTitle>
                  <Badge className="bg-blue-600 w-fit">{account.type}</Badge>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-sm">Account:</span>
                      <code className="text-cyan-400 text-sm">{account.account}</code>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-sm">Balance:</span>
                      <span className="text-green-400 font-bold">${account.balance.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="processing" className="space-y-4">
          <Card className="bg-gray-800/30 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400">Fee Collection & Processing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="text-white font-semibold">Platform Fees Collected</h4>
                  <div className="text-2xl font-bold text-green-400">$892,456.78</div>
                  <p className="text-gray-400 text-sm">All-inclusive processing fees</p>
                </div>
                <div className="space-y-2">
                  <h4 className="text-white font-semibold">Service Revenue</h4>
                  <div className="text-2xl font-bold text-blue-400">$1,456,789.12</div>
                  <p className="text-gray-400 text-sm">Internal services ROI</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card className="bg-gray-800/30 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-yellow-400">Total Revenue Outlook</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-4">
                <div className="text-4xl font-bold text-green-400">
                  ${internalAccounts.reduce((sum, acc) => sum + acc.balance, 0).toLocaleString()}
                </div>
                <p className="text-gray-300">Total Alazie LLC Internal Capital</p>
                <Badge className="bg-green-600 text-lg px-4 py-2">
                  PROFIT FOR ALUCIUS ALFORD
                </Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          <Card className="bg-gray-800/30 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-400">Legal Registration Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">LLC Registration:</span>
                <Badge className="bg-green-600">ACTIVE</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">EIN Status:</span>
                <Badge className="bg-green-600">VERIFIED</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Business License:</span>
                <Badge className="bg-green-600">CURRENT</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Tax Status:</span>
                <Badge className="bg-blue-600">COMPLIANT</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AlazieInternalAccountingSystem;