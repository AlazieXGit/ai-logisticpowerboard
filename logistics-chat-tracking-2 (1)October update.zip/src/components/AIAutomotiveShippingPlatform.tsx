import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Truck, Package, MapPin, User, Calendar, DollarSign, CheckCircle } from 'lucide-react';

const AIAutomotiveShippingPlatform = () => {
  const [activeOrders, setActiveOrders] = useState([
    {
      id: 'ORD-2025-001',
      product: 'Tesla Model S AI Autopilot System',
      vendor: 'Tesla International Robotics',
      status: 'In Transit',
      trackingNumber: 'TRK-789456123',
      estimatedDelivery: '2025-01-18',
      value: '$45,000.00',
      weight: '125 lbs'
    },
    {
      id: 'ORD-2025-002',
      product: 'BMW iX AI Navigation Robotics',
      vendor: 'BMW Robotics Division',
      status: 'Processing',
      trackingNumber: 'TRK-456789012',
      estimatedDelivery: '2025-01-20',
      value: '$38,500.00',
      weight: '89 lbs'
    }
  ]);

  const deliveryAddress = {
    recipient: 'Super Admin Alucius Alford',
    street: '2408 Yanceyville St',
    city: 'Greensboro',
    state: 'N.C.',
    zipCode: '27405',
    phone: '+1 (336) 555-0123',
    email: 'alucius.alford@alaziexpress.com'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">AI Automotive Robotics Shipping Platform</h1>
          <p className="text-blue-200">International Vendor & Dealer Delivery Management</p>
        </div>

        <Tabs defaultValue="active-orders" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="active-orders">Active Orders</TabsTrigger>
            <TabsTrigger value="new-order">New Order</TabsTrigger>
            <TabsTrigger value="tracking">Live Tracking</TabsTrigger>
            <TabsTrigger value="vendors">Vendors</TabsTrigger>
            <TabsTrigger value="delivery-info">Delivery Info</TabsTrigger>
          </TabsList>

          <TabsContent value="active-orders" className="space-y-4">
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Package className="h-5 w-5 text-blue-400" />
                  Active Shipments
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {activeOrders.map((order) => (
                  <div key={order.id} className="bg-slate-700/50 p-4 rounded-lg border border-blue-500/20">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="text-white font-semibold">{order.product}</h3>
                        <p className="text-blue-300 text-sm">{order.vendor}</p>
                      </div>
                      <Badge variant={order.status === 'In Transit' ? 'default' : 'secondary'}>
                        {order.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-400">Order ID</p>
                        <p className="text-white">{order.id}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Tracking</p>
                        <p className="text-blue-300">{order.trackingNumber}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Delivery</p>
                        <p className="text-white">{order.estimatedDelivery}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Value</p>
                        <p className="text-green-400">{order.value}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="delivery-info" className="space-y-4">
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-blue-400" />
                  Standard Delivery Address
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-slate-700/50 p-6 rounded-lg border border-blue-500/20">
                  <div className="flex items-center gap-3 mb-4">
                    <User className="h-6 w-6 text-blue-400" />
                    <h3 className="text-xl font-semibold text-white">{deliveryAddress.recipient}</h3>
                  </div>
                  <div className="space-y-2 text-white">
                    <p>{deliveryAddress.street}</p>
                    <p>{deliveryAddress.city}, {deliveryAddress.state} {deliveryAddress.zipCode}</p>
                    <p className="text-blue-300">{deliveryAddress.phone}</p>
                    <p className="text-blue-300">{deliveryAddress.email}</p>
                  </div>
                  <div className="mt-4 p-3 bg-green-900/30 border border-green-500/30 rounded">
                    <p className="text-green-300 text-sm flex items-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      Verified Delivery Address - All AI Automotive Robotics Orders
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AIAutomotiveShippingPlatform;