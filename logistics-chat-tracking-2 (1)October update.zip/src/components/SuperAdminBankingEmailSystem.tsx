import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Mail, Plus, Edit, Trash2, Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface BankingEmailAccount {
  id: string;
  email: string;
  password: string;
  bank_name: string;
  account_type: string;
  routing_number: string;
  account_number: string;
  status: 'active' | 'inactive' | 'deleted';
  created_at: string;
  updated_at: string;
}

const SuperAdminBankingEmailSystem: React.FC = () => {
  const [accounts, setAccounts] = useState<BankingEmailAccount[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingAccount, setEditingAccount] = useState<BankingEmailAccount | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    bank_name: '',
    account_type: '',
    routing_number: '',
    account_number: ''
  });

  useEffect(() => {
    loadBankingAccounts();
  }, []);

  const loadBankingAccounts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-email-processor', {
        body: { action: 'get_all_accounts' }
      });
      if (data?.accounts) {
        setAccounts(data.accounts);
      }
    } catch (error) {
      console.error('Error loading accounts:', error);
    }
    setLoading(false);
  };

  const handleAddAccount = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-email-processor', {
        body: { 
          action: 'add_account',
          ...formData
        }
      });
      if (data?.success) {
        await loadBankingAccounts();
        setShowAddForm(false);
        resetForm();
      }
    } catch (error) {
      console.error('Error adding account:', error);
    }
    setLoading(false);
  };

  const handleUpdateAccount = async () => {
    if (!editingAccount) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-email-processor', {
        body: { 
          action: 'update_account',
          id: editingAccount.id,
          ...formData
        }
      });
      if (data?.success) {
        await loadBankingAccounts();
        setEditingAccount(null);
        resetForm();
      }
    } catch (error) {
      console.error('Error updating account:', error);
    }
    setLoading(false);
  };

  const handleDeleteAccount = async (id: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-email-processor', {
        body: { 
          action: 'delete_account',
          id
        }
      });
      if (data?.success) {
        await loadBankingAccounts();
      }
    } catch (error) {
      console.error('Error deleting account:', error);
    }
    setLoading(false);
  };

  const resetForm = () => {
    setFormData({
      email: '',
      password: '',
      bank_name: '',
      account_type: '',
      routing_number: '',
      account_number: ''
    });
  };

  const startEdit = (account: BankingEmailAccount) => {
    setEditingAccount(account);
    setFormData({
      email: account.email,
      password: account.password,
      bank_name: account.bank_name,
      account_type: account.account_type,
      routing_number: account.routing_number,
      account_number: account.account_number
    });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Super Admin Banking Email System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-4">
            <Badge className="bg-green-600">Full Admin Access</Badge>
            <Button 
              onClick={() => setShowAddForm(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Account
            </Button>
          </div>

          {loading && (
            <div className="text-center py-4 text-gray-400">Loading...</div>
          )}

          <div className="grid gap-4">
            {accounts.map((account) => (
              <Card key={account.id} className="bg-gray-800/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-blue-400" />
                        <span className="text-white font-semibold">{account.email}</span>
                        <Badge className={account.status === 'active' ? 'bg-green-600' : 'bg-red-600'}>
                          {account.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-300">
                        <div>Bank: {account.bank_name}</div>
                        <div>Type: {account.account_type}</div>
                        <div>Routing: {account.routing_number}</div>
                        <div>Account: {account.account_number}</div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => startEdit(account)}
                        className="border-blue-500 text-blue-400"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-red-500 text-red-400"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Account</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete {account.email}? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteAccount(account.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Form Modal */}
      {(showAddForm || editingAccount) && (
        <Card className="bg-gray-800/50 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">
              {editingAccount ? 'Edit Account' : 'Add New Account'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email" className="text-gray-300">Email</Label>
                <Input
                  id="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="password" className="text-gray-300">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="bank_name" className="text-gray-300">Bank Name</Label>
                <Input
                  id="bank_name"
                  value={formData.bank_name}
                  onChange={(e) => setFormData({...formData, bank_name: e.target.value})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="account_type" className="text-gray-300">Account Type</Label>
                <Input
                  id="account_type"
                  value={formData.account_type}
                  onChange={(e) => setFormData({...formData, account_type: e.target.value})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="routing_number" className="text-gray-300">Routing Number</Label>
                <Input
                  id="routing_number"
                  value={formData.routing_number}
                  onChange={(e) => setFormData({...formData, routing_number: e.target.value})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="account_number" className="text-gray-300">Account Number</Label>
                <Input
                  id="account_number"
                  value={formData.account_number}
                  onChange={(e) => setFormData({...formData, account_number: e.target.value})}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddForm(false);
                  setEditingAccount(null);
                  resetForm();
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={editingAccount ? handleUpdateAccount : handleAddAccount}
                className="bg-blue-600 hover:bg-blue-700"
                disabled={loading}
              >
                {editingAccount ? 'Update' : 'Add'} Account
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SuperAdminBankingEmailSystem;