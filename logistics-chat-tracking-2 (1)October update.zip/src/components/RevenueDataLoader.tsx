import { supabase } from '@/lib/supabase';

export interface RevenueData {
  success: boolean;
  timeRange: string;
  revenue: {
    total: number;
    monthly: number;
    daily: number;
    growth: number;
  };
  transactions: Array<{
    id: string;
    amount: number;
    date: string;
    source: string;
  }>;
}

export async function loadRevenueData(timeRange: string = 'monthly'): Promise<RevenueData> {
  try {
    const { data, error } = await supabase.functions.invoke('revenue', {
      body: { timeRange },
    });

    if (error) {
      console.error('❌ Error loading revenue data:', error);
      throw error;
    }

    return data;
  } catch (error) {
    console.error('❌ Failed to load revenue data:', error);
    // Return fallback data
    return {
      success: false,
      timeRange,
      revenue: {
        total: 0,
        monthly: 0,
        daily: 0,
        growth: 0
      },
      transactions: []
    };
  }
}

export async function loadBankingBalances() {
  try {
    const { data, error } = await supabase.functions.invoke('revenue', {
      body: { action: 'getBalances' },
    });

    if (error) {
      console.error('❌ Error loading balances:', error);
      throw error;
    }

    return data;
  } catch (error) {
    console.error('❌ Failed to load balances:', error);
    return {
      success: false,
      data: { main: 0, business: 0 }
    };
  }
}

export async function loadBankingTransactions() {
  try {
    const { data, error } = await supabase.functions.invoke('revenue', {
      body: { action: 'getTransactions' },
    });

    if (error) {
      console.error('❌ Error loading transactions:', error);
      throw error;
    }

    return data;
  } catch (error) {
    console.error('❌ Failed to load transactions:', error);
    return {
      success: false,
      data: []
    };
  }
}