import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Building2, Users, Zap, ShoppingCart, HeadphonesIcon, Code, TrendingUp } from 'lucide-react';

const DepartmentMetricsTab = () => {
  const departments = [
    {
      name: 'Sales',
      icon: ShoppingCart,
      metrics: {
        revenue: '$1.2M',
        conversion: '12.4%',
        leads: '2,341',
        performance: 94
      },
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      name: 'Marketing',
      icon: TrendingUp,
      metrics: {
        cac: '$45',
        roas: '4.2x',
        campaigns: '28',
        performance: 87
      },
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      name: 'Engineering',
      icon: Code,
      metrics: {
        velocity: '42 pts',
        uptime: '99.9%',
        bugs: '12',
        performance: 91
      },
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      name: 'Support',
      icon: HeadphonesIcon,
      metrics: {
        satisfaction: '4.8/5',
        response: '2.3h',
        tickets: '156',
        performance: 89
      },
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      name: 'Operations',
      icon: Building2,
      metrics: {
        efficiency: '96%',
        cost: '$234K',
        automation: '78%',
        performance: 92
      },
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50'
    },
    {
      name: 'HR',
      icon: Users,
      metrics: {
        retention: '94%',
        satisfaction: '4.6/5',
        hiring: '12',
        performance: 88
      },
      color: 'text-pink-600',
      bgColor: 'bg-pink-50'
    }
  ];

  const crossFunctionalKPIs = [
    { name: 'Customer Lifetime Value', value: '$2,340', target: '$2,500', progress: 94 },
    { name: 'Net Promoter Score', value: '67', target: '70', progress: 96 },
    { name: 'Employee Engagement', value: '8.2/10', target: '8.5/10', progress: 96 },
    { name: 'Operational Efficiency', value: '87%', target: '90%', progress: 97 }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Cross-Functional KPIs
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {crossFunctionalKPIs.map((kpi, index) => (
              <div key={index} className="p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium text-sm text-gray-600 mb-2">{kpi.name}</h4>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xl font-bold">{kpi.value}</span>
                  <span className="text-sm text-gray-500">Target: {kpi.target}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full" 
                    style={{width: `${kpi.progress}%`}}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map((dept, index) => (
          <Card key={index} className={`${dept.bgColor} border-l-4 border-l-current ${dept.color}`}>
            <CardHeader className="pb-3">
              <CardTitle className={`flex items-center gap-2 ${dept.color}`}>
                <dept.icon className="h-5 w-5" />
                {dept.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(dept.metrics).map(([key, value], idx) => (
                  key !== 'performance' && (
                    <div key={idx} className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 capitalize">{key}:</span>
                      <span className="font-semibold">{value}</span>
                    </div>
                  )
                ))}
                <div className="pt-2 border-t">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-600">Performance</span>
                    <span className="font-semibold">{dept.metrics.performance}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${dept.color.replace('text-', 'bg-')}`}
                      style={{width: `${dept.metrics.performance}%`}}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default DepartmentMetricsTab;