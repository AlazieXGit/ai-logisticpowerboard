import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DollarSign, TrendingUp, BarChart3, PieChart, RefreshCw, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import BankingRevenueTab from './BankingRevenueTab';
import VirtualAccountManager from './VirtualAccountManager';

interface RevenueData {
  totalRevenue: number;
  monthlyRevenue: number;
  dailyRevenue: number;
  virtualAccountRevenue: number;
  mainAccountRevenue: number;
  growthRate: number;
  transactionCount: number;
}

interface RevenueStream {
  id: string;
  name: string;
  amount: number;
  percentage: number;
  trend: 'up' | 'down' | 'stable';
  color: string;
}

const EnhancedRevenueTab: React.FC = () => {
  const [revenueData, setRevenueData] = useState<RevenueData>({
    totalRevenue: 4371140.37,
    monthlyRevenue: 892345.50,
    dailyRevenue: 29411.52,
    virtualAccountRevenue: 200000.00,
    mainAccountRevenue: 4171140.37,
    growthRate: 15.7,
    transactionCount: 1247
  });
  
  const [revenueStreams, setRevenueStreams] = useState<RevenueStream[]>([
    { id: '1', name: 'Main Banking Operations', amount: 2500000, percentage: 57.2, trend: 'up', color: 'bg-emerald-500' },
    { id: '2', name: 'Virtual Account Processing', amount: 800000, percentage: 18.3, trend: 'up', color: 'bg-blue-500' },
    { id: '3', name: 'Escrow Services', amount: 650000, percentage: 14.9, trend: 'stable', color: 'bg-purple-500' },
    { id: '4', name: 'Trust Management', amount: 421140, percentage: 9.6, trend: 'up', color: 'bg-orange-500' }
  ]);
  
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadRevenueData();
    const interval = setInterval(loadRevenueData, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const loadRevenueData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'getRevenueData' }
      });

      if (error) throw error;

      if (data?.success) {
        setRevenueData(data.data.revenue);
        setRevenueStreams(data.data.streams);
      }
    } catch (error) {
      console.error('Error loading revenue data:', error);
    }
  };

  const refreshData = async () => {
    setIsLoading(true);
    await loadRevenueData();
    setIsLoading(false);
    toast({ title: 'Success', description: 'Revenue data refreshed' });
  };

  const exportData = () => {
    const csvData = revenueStreams.map(stream => 
      `${stream.name},${stream.amount},${stream.percentage}%,${stream.trend}`
    ).join('\n');
    
    const blob = new Blob([`Revenue Stream,Amount,Percentage,Trend\n${csvData}`], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'revenue-data.csv';
    a.click();
    
    toast({ title: 'Success', description: 'Revenue data exported' });
  };

  return (
    <div className="space-y-6">
      {/* Revenue Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-emerald-800 to-emerald-900 border-emerald-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-300 text-sm">Total Revenue</p>
                <p className="text-2xl font-bold text-white">
                  ${revenueData.totalRevenue.toLocaleString()}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-emerald-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-800 to-blue-900 border-blue-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-300 text-sm">Monthly Revenue</p>
                <p className="text-2xl font-bold text-white">
                  ${revenueData.monthlyRevenue.toLocaleString()}
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-800 to-purple-900 border-purple-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm">Virtual Account Revenue</p>
                <p className="text-2xl font-bold text-white">
                  ${revenueData.virtualAccountRevenue.toLocaleString()}
                </p>
              </div>
              <PieChart className="h-8 w-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-800 to-orange-900 border-orange-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-300 text-sm">Growth Rate</p>
                <p className="text-2xl font-bold text-white">
                  +{revenueData.growthRate}%
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4">
        <Button onClick={refreshData} disabled={isLoading} className="bg-emerald-600 hover:bg-emerald-700">
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh Data
        </Button>
        <Button onClick={exportData} variant="outline" className="border-emerald-500/30 text-emerald-400">
          <Download className="h-4 w-4 mr-2" />
          Export Data
        </Button>
      </div>

      {/* Revenue Streams */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400">Revenue Streams Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {revenueStreams.map((stream) => (
              <div key={stream.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className={`w-4 h-4 rounded-full ${stream.color}`} />
                  <div>
                    <p className="text-white font-medium">{stream.name}</p>
                    <p className="text-gray-400 text-sm">{stream.percentage}% of total revenue</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-emerald-400 font-bold">
                    ${stream.amount.toLocaleString()}
                  </p>
                  <Badge className={`text-xs ${
                    stream.trend === 'up' ? 'bg-green-600' :
                    stream.trend === 'down' ? 'bg-red-600' : 'bg-gray-600'
                  }`}>
                    {stream.trend === 'up' ? '↗' : stream.trend === 'down' ? '↘' : '→'} {stream.trend}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tabbed Content */}
      <Tabs defaultValue="banking" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="banking" className="data-[state=active]:bg-emerald-600">
            Banking Revenue
          </TabsTrigger>
          <TabsTrigger value="virtual" className="data-[state=active]:bg-emerald-600">
            Virtual Accounts
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-emerald-600">
            Advanced Analytics
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="banking" className="space-y-4">
          <BankingRevenueTab />
        </TabsContent>
        
        <TabsContent value="virtual" className="space-y-4">
          <VirtualAccountManager />
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-4">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400">Advanced Revenue Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-white font-semibold">Performance Metrics</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Transaction Volume:</span>
                      <span className="text-emerald-400">{revenueData.transactionCount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Average Transaction:</span>
                      <span className="text-emerald-400">
                        ${(revenueData.totalRevenue / revenueData.transactionCount).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Daily Average:</span>
                      <span className="text-emerald-400">${revenueData.dailyRevenue.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-white font-semibold">Account Distribution</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Main Accounts:</span>
                      <span className="text-blue-400">
                        ${revenueData.mainAccountRevenue.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Virtual Accounts:</span>
                      <span className="text-purple-400">
                        ${revenueData.virtualAccountRevenue.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Virtual Account %:</span>
                      <span className="text-orange-400">
                        {((revenueData.virtualAccountRevenue / revenueData.totalRevenue) * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedRevenueTab;