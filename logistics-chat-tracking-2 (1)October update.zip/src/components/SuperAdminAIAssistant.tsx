import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bot, Send, Brain, Code, BarChart3, Shield, MessageSquare, Cpu } from 'lucide-react';

interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface SystemMetric {
  name: string;
  value: string;
  status: 'good' | 'warning' | 'critical';
  icon: React.ReactNode;
}

const SuperAdminAIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Hello! I\'m your AI ALAZIE XPRESS Super Admin Assistant. I have complete knowledge of all platform components, banking systems, TMS operations, and can help with development tasks. How can I assist you today?',
      timestamp: new Date()
    }
  ]);
  
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const systemMetrics: SystemMetric[] = [
    { name: 'Components', value: '247', status: 'good', icon: <Code className="h-4 w-4" /> },
    { name: 'Active Services', value: '18', status: 'good', icon: <Cpu className="h-4 w-4" /> },
    { name: 'API Endpoints', value: '156', status: 'good', icon: <BarChart3 className="h-4 w-4" /> },
    { name: 'Security Status', value: 'Secure', status: 'good', icon: <Shield className="h-4 w-4" /> },
    { name: 'System Uptime', value: '99.9%', status: 'good', icon: <Brain className="h-4 w-4" /> }
  ];

  const componentCategories = [
    { name: 'Banking Systems', count: 45, components: ['UnifiedBankingSystem', 'WellsFargoBankingTab', 'AlazielBankingConfig'] },
    { name: 'TMS Operations', count: 28, components: ['EnhancedTMSSystem', 'TMSDispatch', 'LoadMatchingSystem'] },
    { name: 'Payment Processing', count: 32, components: ['StripePaymentSystem', 'PaymentProcessor', 'VendorPayoutSystem'] },
    { name: 'AI Systems', count: 15, components: ['AIAgentSystem', 'AIBankingAssistant', 'AIProjectManager'] },
    { name: 'Security & Auth', count: 22, components: ['SuperAdminAuth', 'SessionThreatMonitor', 'MasterCredentialsAuth'] },
    { name: 'Analytics & Reports', count: 18, components: ['PerformanceAnalytics', 'RevenueAnalytics', 'TMSAnalytics'] }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: generateAIResponse(inputMessage),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('component') || lowerInput.includes('system')) {
      return 'I can help you with any of our 247 components across 6 major categories. Our platform includes banking systems, TMS operations, payment processing, AI systems, security modules, and analytics. Which specific component would you like to know about?';
    }
    
    if (lowerInput.includes('banking') || lowerInput.includes('payment')) {
      return 'Our banking infrastructure includes UnifiedBankingSystem, Wells Fargo integration, Alaziel Banking Config, Stripe payments, and ACH network registration. All systems are NACHA compliant with 99.8% uptime. Need help with a specific banking operation?';
    }
    
    if (lowerInput.includes('tms') || lowerInput.includes('load')) {
      return 'The TMS system handles load matching, dispatch operations, and revenue tracking. We have 28 TMS components including EnhancedTMSSystem, LoadMatchingSystem, and TMSDispatch. Current load board shows 1,247 active loads. What TMS function do you need assistance with?';
    }
    
    if (lowerInput.includes('security') || lowerInput.includes('auth')) {
      return 'Security systems are fully operational with threat monitoring, session management, and master credentials control. All 22 security components are active with AES-256 encryption. Current threat level: LOW. Any specific security concerns?';
    }
    
    return 'I\'m here to help with all aspects of AI ALAZIE XPRESS platform. I can assist with component development, system troubleshooting, banking operations, TMS management, security protocols, and performance optimization. What specific task can I help you with?';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'bg-green-600';
      case 'warning': return 'bg-yellow-600';
      case 'critical': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-indigo-900/20 border-indigo-500/50">
        <CardHeader>
          <CardTitle className="text-indigo-400 flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Super Admin AI Assistant
          </CardTitle>
          <Badge className="bg-indigo-600 w-fit">AI ALAZIE XPRESS • Platform Intelligence • Development Assistant</Badge>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="chat" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="chat">AI Chat</TabsTrigger>
              <TabsTrigger value="components">Component Overview</TabsTrigger>
              <TabsTrigger value="metrics">System Metrics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="chat" className="space-y-4">
              <div className="h-96 bg-gray-800/30 rounded-lg border border-gray-600 p-4 overflow-y-auto">
                {messages.map((message) => (
                  <div key={message.id} className={`mb-4 ${message.type === 'user' ? 'text-right' : 'text-left'}`}>
                    <div className={`inline-block max-w-[80%] p-3 rounded-lg ${
                      message.type === 'user' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-700 text-gray-100'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="text-left mb-4">
                    <div className="inline-block bg-gray-700 text-gray-100 p-3 rounded-lg">
                      <p className="text-sm">AI Assistant is typing...</p>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
              
              <div className="flex gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask about components, systems, development, or any platform question..."
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1"
                />
                <Button onClick={handleSendMessage} className="bg-indigo-600 hover:bg-indigo-700">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="components" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {componentCategories.map((category, index) => (
                  <Card key={index} className="bg-gray-800/30 border-gray-600">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white text-lg flex items-center justify-between">
                        {category.name}
                        <Badge className="bg-blue-600">{category.count}</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-1">
                        {category.components.map((component, idx) => (
                          <p key={idx} className="text-sm text-gray-400 font-mono">{component}</p>
                        ))}
                        {category.count > 3 && (
                          <p className="text-sm text-blue-400">+ {category.count - 3} more components</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="metrics" className="space-y-4">
              <div className="grid grid-cols-5 gap-4">
                {systemMetrics.map((metric, index) => (
                  <Card key={index} className="bg-gray-800/30 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        {metric.icon}
                        <Badge className={getStatusColor(metric.status)}>
                          {metric.status.toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-2xl font-bold text-white">{metric.value}</p>
                      <p className="text-sm text-gray-400">{metric.name}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    Platform Intelligence Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <h4 className="text-white font-medium mb-2">System Health</h4>
                      <ul className="space-y-1 text-gray-400">
                        <li>• All 247 components operational</li>
                        <li>• 18 active services running</li>
                        <li>• 156 API endpoints responding</li>
                        <li>• Security systems fully active</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="text-white font-medium mb-2">AI Capabilities</h4>
                      <ul className="space-y-1 text-gray-400">
                        <li>• Complete platform knowledge</li>
                        <li>• Development assistance</li>
                        <li>• System troubleshooting</li>
                        <li>• Performance optimization</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminAIAssistant;