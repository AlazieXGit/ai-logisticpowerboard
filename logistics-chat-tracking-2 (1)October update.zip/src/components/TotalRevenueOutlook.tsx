import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, DollarSign, PieChart, BarChart3 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface RevenueData {
  totalRevenue: number;
  monthlyGrowth: number;
  bankingRevenue: number;
  tmsRevenue: number;
  vendorPayouts: number;
  netProfit: number;
}

const TotalRevenueOutlook: React.FC = () => {
  const [revenueData, setRevenueData] = useState<RevenueData>({
    totalRevenue: 0,
    monthlyGrowth: 0,
    bankingRevenue: 0,
    tmsRevenue: 0,
    vendorPayouts: 0,
    netProfit: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRevenueData();
  }, []);

  const fetchRevenueData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('revenue', {
        body: { action: 'get_total_outlook' }
      });
      
      if (data && !error) {
        setRevenueData(data);
      }
    } catch (error) {
      console.error('Revenue fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  if (loading) {
    return (
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardContent className="p-6">
          <div className="text-center text-blue-300">Loading revenue data...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Total Revenue Outlook - Alaziel LLC
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">
                {formatCurrency(revenueData.totalRevenue)}
              </div>
              <div className="text-gray-300 text-sm">Total Revenue</div>
              <Badge className="bg-green-600 mt-2">
                +{revenueData.monthlyGrowth}% Growth
              </Badge>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">
                {formatCurrency(revenueData.netProfit)}
              </div>
              <div className="text-gray-300 text-sm">Net Profit</div>
              <Badge className="bg-blue-600 mt-2">Current Month</Badge>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">
                {formatCurrency(revenueData.vendorPayouts)}
              </div>
              <div className="text-gray-300 text-sm">Vendor Payouts</div>
              <Badge className="bg-purple-600 mt-2">Total Paid</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-6">
        <Card className="bg-emerald-900/20 border-emerald-500/50">
          <CardHeader>
            <CardTitle className="text-emerald-400 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Banking Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-400">
              {formatCurrency(revenueData.bankingRevenue)}
            </div>
            <div className="text-gray-300 text-sm mt-2">
              Transaction fees, account management, transfers
            </div>
          </CardContent>
        </Card>

        <Card className="bg-orange-900/20 border-orange-500/50">
          <CardHeader>
            <CardTitle className="text-orange-400 flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              TMS Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-400">
              {formatCurrency(revenueData.tmsRevenue)}
            </div>
            <div className="text-gray-300 text-sm mt-2">
              Load bookings, dispatch fees, analytics
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-900/20 border-gray-500/50">
        <CardHeader>
          <CardTitle className="text-gray-400 flex items-center gap-2">
            <PieChart className="h-4 w-4" />
            Revenue Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Banking Services</span>
              <span className="text-emerald-400 font-semibold">
                {((revenueData.bankingRevenue / revenueData.totalRevenue) * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">TMS Operations</span>
              <span className="text-orange-400 font-semibold">
                {((revenueData.tmsRevenue / revenueData.totalRevenue) * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Net Profit Margin</span>
              <span className="text-green-400 font-semibold">
                {((revenueData.netProfit / revenueData.totalRevenue) * 100).toFixed(1)}%
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TotalRevenueOutlook;