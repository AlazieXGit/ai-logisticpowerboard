import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Mail, Lock, CreditCard, User, Crown, Zap } from 'lucide-react';

interface SynergyAILoginProps {
  onLogin: (userType: 'free' | 'pro' | 'enterprise') => void;
  onClose: () => void;
}

const SynergyAILogin: React.FC<SynergyAILoginProps> = ({ onLogin, onClose }) => {
  const [activeTab, setActiveTab] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<'free' | 'pro' | 'enterprise'>('free');

  const subscriptionPlans = [
    {
      id: 'free' as const,
      name: 'Synergy Free',
      price: '$0/month',
      icon: <User className="h-6 w-6" />,
      features: ['Basic AI Assistant', '100 API calls/month', 'Community Support', 'Basic Analytics'],
      color: 'from-gray-600 to-gray-700',
      revenue: 0
    },
    {
      id: 'pro' as const,
      name: 'Synergy Pro',
      price: '$49/month',
      icon: <Zap className="h-6 w-6" />,
      features: ['Advanced AI Models', '10K API calls/month', 'Priority Support', 'Advanced Analytics', 'Custom Integrations'],
      color: 'from-purple-600 to-pink-600',
      revenue: 49
    },
    {
      id: 'enterprise' as const,
      name: 'Synergy Enterprise',
      price: '$199/month',
      icon: <Crown className="h-6 w-6" />,
      features: ['All AI Models', 'Unlimited API calls', '24/7 Support', 'Custom Solutions', 'White-label Options', 'Dedicated Account Manager'],
      color: 'from-yellow-600 to-orange-600',
      revenue: 199
    }
  ];

  const handleLogin = () => {
    if (email && password) {
      onLogin(selectedPlan);
    }
  };

  const handleSubscribe = (planType: 'free' | 'pro' | 'enterprise') => {
    setSelectedPlan(planType);
    onLogin(planType);
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl bg-gradient-to-br from-slate-900 to-purple-900 border-purple-500/20">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-purple-400 to-pink-400 p-3 rounded-full mr-4">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              SYNERGY AI
            </CardTitle>
          </div>
          <CardDescription className="text-gray-300 text-lg">
            Access the most advanced AI platform for business automation
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="signup">Sign Up</TabsTrigger>
              <TabsTrigger value="plans">Subscription Plans</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="email" className="text-white">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 bg-slate-800 border-purple-500/20"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="password" className="text-white">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 bg-slate-800 border-purple-500/20"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Select Plan</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {subscriptionPlans.map((plan) => (
                      <Button
                        key={plan.id}
                        variant={selectedPlan === plan.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedPlan(plan.id)}
                        className={selectedPlan === plan.id ? `bg-gradient-to-r ${plan.color}` : ''}
                      >
                        {plan.icon}
                        <span className="ml-2">{plan.name}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button onClick={handleLogin} className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600">
                    Login to Synergy AI
                  </Button>
                  <Button variant="outline" onClick={onClose}>
                    Cancel
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="signup" className="space-y-4">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-white mb-4">Join Synergy AI</h3>
                <p className="text-gray-300 mb-6">Create your account and start with our Free plan</p>
                
                <Button 
                  onClick={() => handleSubscribe('free')} 
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 mb-4"
                >
                  Start Free Account
                </Button>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <Button 
                    onClick={() => handleSubscribe('pro')} 
                    className="bg-gradient-to-r from-purple-600 to-pink-600"
                  >
                    Start Pro Trial - $49/month
                  </Button>
                  <Button 
                    onClick={() => handleSubscribe('enterprise')} 
                    className="bg-gradient-to-r from-yellow-600 to-orange-600"
                  >
                    Enterprise Demo - $199/month
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="plans">
              <div className="grid md:grid-cols-3 gap-6">
                {subscriptionPlans.map((plan) => (
                  <Card key={plan.id} className="bg-slate-800/50 border-purple-500/20 relative">
                    {plan.id === 'pro' && (
                      <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-purple-600">
                        Most Popular
                      </Badge>
                    )}
                    <CardHeader className="text-center">
                      <div className={`mx-auto p-3 rounded-full bg-gradient-to-r ${plan.color} w-fit mb-4`}>
                        {plan.icon}
                      </div>
                      <CardTitle className="text-white">{plan.name}</CardTitle>
                      <div className="text-3xl font-bold text-purple-400">{plan.price}</div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {plan.features.map((feature, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-300">
                            <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                            {feature}
                          </div>
                        ))}
                      </div>
                      <Button 
                        onClick={() => handleSubscribe(plan.id)} 
                        className={`w-full mt-6 bg-gradient-to-r ${plan.color}`}
                      >
                        {plan.id === 'free' ? 'Start Free' : 'Subscribe Now'}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SynergyAILogin;