import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Car, Image, Download, Edit, Save, Plus } from 'lucide-react';

const AssetManagementTab = () => {
  const [assets, setAssets] = useState([
    {
      id: 1,
      name: 'BMW X7 M50i',
      type: 'Luxury SUV',
      purchasePrice: 85000,
      currentValue: 78000,
      purchaseDate: '2024-01-15',
      dealer: 'BMW Munich Premium',
      purpose: 'Executive Transportation',
      image: '/placeholder.svg',
      description: 'High-end luxury SUV for executive transport and client meetings',
      buyerInfo: 'Alazie LLC - Corporate Fleet',
      sellerInfo: 'BMW Munich Premium - Germany',
      documents: ['Purchase Agreement', 'Title', 'Insurance', 'Registration']
    },
    {
      id: 2,
      name: 'Ferrari 488 GTB',
      type: 'Sports Car',
      purchasePrice: 320000,
      currentValue: 315000,
      purchaseDate: '2024-02-10',
      dealer: 'Ferrari Maranello',
      purpose: 'Investment Vehicle',
      image: '/placeholder.svg',
      description: 'High-performance sports car for investment and special occasions',
      buyerInfo: 'Alazie LLC - Investment Portfolio',
      sellerInfo: 'Ferrari Maranello - Italy',
      documents: ['Purchase Agreement', 'Certificate of Origin', 'Insurance', 'Export Docs']
    }
  ]);

  const [editingId, setEditingId] = useState(null);
  const [newAsset, setNewAsset] = useState({
    name: '',
    type: '',
    purchasePrice: '',
    currentValue: '',
    purpose: '',
    description: '',
    dealer: '',
    buyerInfo: '',
    sellerInfo: ''
  });

  const downloadDocument = (assetName, docType) => {
    // Simulate document download
    const element = document.createElement('a');
    element.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(`${docType} for ${assetName}`);
    element.download = `${assetName}_${docType}.pdf`;
    element.click();
  };

  const addAsset = () => {
    if (newAsset.name && newAsset.type) {
      const asset = {
        id: Date.now(),
        ...newAsset,
        purchasePrice: parseFloat(newAsset.purchasePrice) || 0,
        currentValue: parseFloat(newAsset.currentValue) || 0,
        purchaseDate: new Date().toISOString().split('T')[0],
        image: '/placeholder.svg',
        documents: ['Purchase Agreement', 'Title', 'Insurance']
      };
      setAssets([...assets, asset]);
      setNewAsset({
        name: '', type: '', purchasePrice: '', currentValue: '',
        purpose: '', description: '', dealer: '', buyerInfo: '', sellerInfo: ''
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-300 flex items-center gap-2">
            <Car className="h-5 w-5" />
            Asset & Vehicle Management Platform
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-800/30 p-4 rounded-lg">
              <p className="text-blue-300 font-semibold">Total Assets</p>
              <p className="text-2xl font-bold text-white">{assets.length}</p>
            </div>
            <div className="bg-green-800/30 p-4 rounded-lg">
              <p className="text-green-300 font-semibold">Total Value</p>
              <p className="text-2xl font-bold text-green-400">
                ${assets.reduce((sum, asset) => sum + asset.currentValue, 0).toLocaleString()}
              </p>
            </div>
            <div className="bg-purple-800/30 p-4 rounded-lg">
              <p className="text-purple-300 font-semibold">Investment</p>
              <p className="text-2xl font-bold text-purple-400">
                ${assets.reduce((sum, asset) => sum + asset.purchasePrice, 0).toLocaleString()}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-green-300 flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Add New Asset
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              placeholder="Asset Name"
              value={newAsset.name}
              onChange={(e) => setNewAsset({...newAsset, name: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Asset Type"
              value={newAsset.type}
              onChange={(e) => setNewAsset({...newAsset, type: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Purchase Price"
              type="number"
              value={newAsset.purchasePrice}
              onChange={(e) => setNewAsset({...newAsset, purchasePrice: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Current Value"
              type="number"
              value={newAsset.currentValue}
              onChange={(e) => setNewAsset({...newAsset, currentValue: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Purpose"
              value={newAsset.purpose}
              onChange={(e) => setNewAsset({...newAsset, purpose: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Dealer/Source"
              value={newAsset.dealer}
              onChange={(e) => setNewAsset({...newAsset, dealer: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
          </div>
          <div className="mt-4 space-y-4">
            <Textarea
              placeholder="Asset Description"
              value={newAsset.description}
              onChange={(e) => setNewAsset({...newAsset, description: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                placeholder="Buyer Information"
                value={newAsset.buyerInfo}
                onChange={(e) => setNewAsset({...newAsset, buyerInfo: e.target.value})}
                className="bg-gray-700 border-gray-600"
              />
              <Input
                placeholder="Seller Information"
                value={newAsset.sellerInfo}
                onChange={(e) => setNewAsset({...newAsset, sellerInfo: e.target.value})}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            <Button onClick={addAsset} className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              Add Asset
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {assets.map((asset) => (
          <Card key={asset.id} className="bg-gray-800 border-blue-500/30">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-blue-300">{asset.name}</CardTitle>
                  <Badge className="mt-2">{asset.type}</Badge>
                </div>
                <Button
                  size="sm"
                  onClick={() => setEditingId(editingId === asset.id ? null : asset.id)}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-24 h-24 bg-gray-700 rounded-lg flex items-center justify-center">
                  <Image className="h-8 w-8 text-gray-400" />
                </div>
                <div className="flex-1">
                  <p className="text-gray-300">{asset.description}</p>
                  <p className="text-sm text-gray-400 mt-2">Purpose: {asset.purpose}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-sm">Purchase Price</p>
                  <p className="text-green-400 font-bold">${asset.purchasePrice.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Current Value</p>
                  <p className="text-blue-400 font-bold">${asset.currentValue.toLocaleString()}</p>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-gray-400 text-sm">Buyer: {asset.buyerInfo}</p>
                <p className="text-gray-400 text-sm">Seller: {asset.sellerInfo}</p>
                <p className="text-gray-400 text-sm">Acquired: {asset.purchaseDate}</p>
              </div>

              <div className="space-y-2">
                <p className="text-gray-300 font-semibold">Documents:</p>
                <div className="flex flex-wrap gap-2">
                  {asset.documents.map((doc, index) => (
                    <Button
                      key={index}
                      size="sm"
                      onClick={() => downloadDocument(asset.name, doc)}
                      className="bg-gray-700 hover:bg-gray-600 text-xs"
                    >
                      <Download className="h-3 w-3 mr-1" />
                      {doc}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AssetManagementTab;