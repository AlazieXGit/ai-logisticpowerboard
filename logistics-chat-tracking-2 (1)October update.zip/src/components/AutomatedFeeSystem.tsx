import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DollarSign, Calculator, CreditCard } from 'lucide-react';

interface FeeBreakdown {
  adminFee: number;
  aiGenFee: number;
  autoBookingFee: number;
  serviceFee: number;
  platformFee: number;
  totalFees: number;
  netAmount: number;
}

interface AutomatedFeeSystemProps {
  amount: number;
  onPaymentConfirm: (feeBreakdown: FeeBreakdown) => void;
  serviceType: string;
}

export const AutomatedFeeSystem: React.FC<AutomatedFeeSystemProps> = ({
  amount,
  onPaymentConfirm,
  serviceType
}) => {
  const calculateFees = (baseAmount: number): FeeBreakdown => {
    const adminFee = baseAmount * 0.05;
    const aiGenFee = baseAmount * 0.05;
    const autoBookingFee = baseAmount * 0.05;
    const serviceFee = baseAmount * 0.05;
    const platformFee = baseAmount * 0.07;
    const totalFees = adminFee + aiGenFee + autoBookingFee + serviceFee + platformFee;
    const netAmount = baseAmount - totalFees;

    return {
      adminFee,
      aiGenFee,
      autoBookingFee,
      serviceFee,
      platformFee,
      totalFees,
      netAmount
    };
  };

  const fees = calculateFees(amount);

  const handlePaymentConfirm = () => {
    onPaymentConfirm(fees);
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-gradient-to-br from-blue-900 to-purple-900 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Automated Service Fees - {serviceType}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span>Base Amount:</span>
            <span className="font-bold">${amount.toFixed(2)}</span>
          </div>
          
          <div className="border-t border-gray-600 pt-2 space-y-1">
            <div className="flex justify-between text-sm">
              <span>Admin Fee (5%):</span>
              <span>${fees.adminFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>AI Gen Fee (5%):</span>
              <span>${fees.aiGenFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Auto Booking Fee (5%):</span>
              <span>${fees.autoBookingFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Service Fee (5%):</span>
              <span>${fees.serviceFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Platform Fee (7%):</span>
              <span>${fees.platformFee.toFixed(2)}</span>
            </div>
          </div>
          
          <div className="border-t border-gray-400 pt-2">
            <div className="flex justify-between font-bold">
              <span>Total Fees (27%):</span>
              <Badge variant="destructive">${fees.totalFees.toFixed(2)}</Badge>
            </div>
            <div className="flex justify-between font-bold text-green-400">
              <span>Net Amount:</span>
              <span>${fees.netAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <Button 
          onClick={handlePaymentConfirm}
          className="w-full bg-green-600 hover:bg-green-700"
        >
          <CreditCard className="h-4 w-4 mr-2" />
          Confirm Payment & Fees
        </Button>
      </CardContent>
    </Card>
  );
};