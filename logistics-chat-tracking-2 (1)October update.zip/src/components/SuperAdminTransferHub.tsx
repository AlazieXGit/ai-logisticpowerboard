import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, CreditCard, Building2, Eye, Users, History } from 'lucide-react';
import CardTransactionSystem from './CardTransactionSystem';
import VendorPayoutSystem from './VendorPayoutSystem';
import UnifiedCheckingTab from './UnifiedCheckingTab';
import DirectDepositTransferList from './DirectDepositTransferList';
import RecipientTransactionHistory from './RecipientTransactionHistory';

interface SuperAdminTransferHubProps {
  onTransactionComplete?: (transaction: any) => void;
}

const SuperAdminTransferHub: React.FC<SuperAdminTransferHubProps> = ({ onTransactionComplete }) => {
  const [activeTab, setActiveTab] = useState('transfers');
  const [recentActivity, setRecentActivity] = useState([]);

  const handleTransactionComplete = (transaction: any) => {
    setRecentActivity(prev => [transaction, ...prev.slice(0, 9)]);
    onTransactionComplete?.(transaction);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Super Admin Transfer Hub - Secure Banking Operations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5 bg-gray-700">
              <TabsTrigger value="transfers" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                <CreditCard className="h-4 w-4 mr-2" />
                Card Transfers
              </TabsTrigger>
              <TabsTrigger value="vendors" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                <Building2 className="h-4 w-4 mr-2" />
                Vendor Payouts
              </TabsTrigger>
              <TabsTrigger value="accounts" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                <Eye className="h-4 w-4 mr-2" />
                Unified Checking
              </TabsTrigger>
              <TabsTrigger value="recipients" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                <Users className="h-4 w-4 mr-2" />
                Direct Deposit
              </TabsTrigger>
              <TabsTrigger value="history" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                <History className="h-4 w-4 mr-2" />
                Transaction History
              </TabsTrigger>
            </TabsList>

            <TabsContent value="transfers" className="mt-6">
              <CardTransactionSystem onTransactionComplete={handleTransactionComplete} />
            </TabsContent>

            <TabsContent value="vendors" className="mt-6">
              <VendorPayoutSystem onPayoutComplete={handleTransactionComplete} />
            </TabsContent>

            <TabsContent value="accounts" className="mt-6">
              <UnifiedCheckingTab />
            </TabsContent>

            <TabsContent value="recipients" className="mt-6">
              <DirectDepositTransferList />
            </TabsContent>

            <TabsContent value="history" className="mt-6">
              <RecipientTransactionHistory />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminTransferHub;