import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FolderOpen, Code, Globe, Trash2, Eye, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Project {
  id: string;
  project_name: string;
  project_type: 'app' | 'website';
  command_prompt: string;
  generated_code: string;
  enhancement_level: number;
  status: string;
  created_at: string;
}

const AIProjectManager: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      const { data, error } = await supabase
        .from('ai_dev_projects')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error('Load projects error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteProject = async (id: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return;
    
    try {
      const { error } = await supabase
        .from('ai_dev_projects')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setProjects(projects.filter(p => p.id !== id));
      if (selectedProject?.id === id) setSelectedProject(null);
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const downloadProject = (project: Project) => {
    const fileExtension = project.project_type === 'website' ? '.html' : '.tsx';
    const fileName = `${project.project_name}${fileExtension}`;
    const blob = new Blob([project.generated_code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <Card className="bg-gray-900/50 border-gray-500/50">
        <CardContent className="p-6">
          <div className="text-center text-gray-400">Loading projects...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500/50">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <FolderOpen className="h-6 w-6" />
            AI Project Manager - Revolutionary Infrastructure
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">{projects.length}</div>
              <div className="text-sm text-gray-400">Total Projects</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">{projects.filter(p => p.project_type === 'app').length}</div>
              <div className="text-sm text-gray-400">Apps Generated</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">{projects.filter(p => p.project_type === 'website').length}</div>
              <div className="text-sm text-gray-400">Websites Generated</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-900/50 border-gray-500/50">
          <CardHeader>
            <CardTitle className="text-gray-300">Project Library</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-96 overflow-y-auto">
            {projects.length === 0 ? (
              <div className="text-center text-gray-400 py-8">
                No projects yet. Generate your first AI project!
              </div>
            ) : (
              projects.map((project) => (
                <div key={project.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                  <div className="flex items-center gap-3">
                    {project.project_type === 'app' ? (
                      <Code className="h-5 w-5 text-blue-400" />
                    ) : (
                      <Globe className="h-5 w-5 text-emerald-400" />
                    )}
                    <div>
                      <div className="font-medium text-white">{project.project_name}</div>
                      <div className="text-xs text-gray-400">
                        {new Date(project.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={project.project_type === 'app' ? 'bg-blue-600' : 'bg-emerald-600'}>
                      {project.project_type.toUpperCase()}
                    </Badge>
                    <Button size="sm" variant="outline" onClick={() => setSelectedProject(project)}>
                      <Eye className="h-3 w-3" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => downloadProject(project)}>
                      <Download className="h-3 w-3" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => deleteProject(project.id)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {selectedProject && (
          <Card className="bg-gray-900/50 border-gray-500/50">
            <CardHeader>
              <CardTitle className="text-gray-300 flex items-center gap-2">
                {selectedProject.project_type === 'app' ? (
                  <Code className="h-5 w-5 text-blue-400" />
                ) : (
                  <Globe className="h-5 w-5 text-emerald-400" />
                )}
                {selectedProject.project_name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-400 mb-1">Command Prompt:</div>
                  <div className="text-sm text-gray-300 bg-gray-800 p-2 rounded">
                    {selectedProject.command_prompt}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-400 mb-1">Generated Code Preview:</div>
                  <pre className="bg-black p-3 rounded-lg overflow-auto max-h-48 text-green-400 text-xs">
                    <code>{selectedProject.generated_code.substring(0, 500)}...</code>
                  </pre>
                </div>
                <div className="flex justify-between items-center">
                  <Badge className="bg-purple-600">Enhanced {selectedProject.enhancement_level}x</Badge>
                  <Badge className={selectedProject.status === 'generated' ? 'bg-yellow-600' : 'bg-green-600'}>
                    {selectedProject.status.toUpperCase()}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AIProjectManager;