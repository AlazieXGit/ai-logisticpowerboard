import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowUpRight, ArrowDownLeft, Search, Eye, Download, CreditCard, Receipt, Route, FileText } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TransferDetail {
  id: string;
  transaction_id: string;
  amount: number;
  type: 'incoming' | 'outgoing';
  status: 'completed' | 'pending' | 'failed';
  from_account: string;
  to_account: string;
  description: string;
  payment_method: string;
  invoice_number?: string;
  payment_route: string;
  request_details: {
    requester: string;
    purpose: string;
    approval_status: string;
    requested_date: string;
  };
  processing_details: {
    processor: string;
    processing_fee: number;
    routing_number: string;
  };
  created_at: string;
}

const EnhancedRecentTransfers: React.FC = () => {
  const [transfers, setTransfers] = useState<TransferDetail[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedTransfer, setSelectedTransfer] = useState<TransferDetail | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    loadTransfers();
  }, []);

  const loadTransfers = async () => {
    try {
      const { data } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'get_recent_transfers_detailed',
          admin_id: 'super_admin'
        }
      });
      if (data?.transfers) {
        setTransfers(data.transfers);
      }
    } catch (error) {
      console.error('Error loading transfers:', error);
    }
  };

  const viewTransferDetails = (transfer: TransferDetail) => {
    setSelectedTransfer(transfer);
    setShowDetails(true);
  };

  const filteredTransfers = transfers.filter(transfer => {
    const matchesSearch = transfer.transaction_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transfer.from_account.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transfer.to_account.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || transfer.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <Card className="bg-green-900/20 border-green-500/50">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <ArrowUpRight className="h-5 w-5" />
            Recent Transfers - Complete Transaction Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
              <Input
                placeholder="Search transfers, accounts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-800 border-gray-600"
              />
            </div>
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white"
            >
              <option value="all">All Status</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
          </div>

          <div className="space-y-4">
            {filteredTransfers.map((transfer) => (
              <Card key={transfer.id} className="bg-gray-800/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        {transfer.type === 'incoming' ? 
                          <ArrowDownLeft className="h-5 w-5 text-green-400" /> : 
                          <ArrowUpRight className="h-5 w-5 text-red-400" />
                        }
                        <span className="font-mono text-sm text-blue-400">{transfer.transaction_id}</span>
                        <Badge className={
                          transfer.status === 'completed' ? 'bg-green-600' :
                          transfer.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                        }>
                          {transfer.status.toUpperCase()}
                        </Badge>
                        <Badge className={transfer.type === 'incoming' ? 'bg-blue-600' : 'bg-purple-600'}>
                          {transfer.type.toUpperCase()}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-400">Amount</p>
                          <p className="font-semibold text-white">${transfer.amount.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">From Account</p>
                          <p className="text-white">{transfer.from_account}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">To Account</p>
                          <p className="text-white">{transfer.to_account}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Payment Method</p>
                          <p className="text-white flex items-center gap-1">
                            <CreditCard className="h-4 w-4" />
                            {transfer.payment_method}
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4 text-sm">
                        <div>
                          <p className="text-gray-400 flex items-center gap-1">
                            <Receipt className="h-4 w-4" />
                            Invoice Details
                          </p>
                          <p className="text-white">{transfer.invoice_number || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-gray-400 flex items-center gap-1">
                            <Route className="h-4 w-4" />
                            Payment Route
                          </p>
                          <p className="text-white">{transfer.payment_route}</p>
                        </div>
                        <div>
                          <p className="text-gray-400 flex items-center gap-1">
                            <FileText className="h-4 w-4" />
                            Request Purpose
                          </p>
                          <p className="text-white">{transfer.request_details.purpose}</p>
                        </div>
                      </div>
                      
                      <div className="mt-3 p-3 bg-gray-700/50 rounded">
                        <p className="text-gray-300 text-sm">
                          <strong>Description:</strong> {transfer.description}
                        </p>
                        <div className="flex justify-between items-center mt-2 text-xs text-gray-400">
                          <span>Requester: {transfer.request_details.requester}</span>
                          <span>Processor: {transfer.processing_details.processor}</span>
                          <span>Created: {new Date(transfer.created_at).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => viewTransferDetails(transfer)}
                        className="border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {showDetails && selectedTransfer && (
        <Card className="bg-blue-900/20 border-blue-500/50">
          <CardHeader>
            <CardTitle className="text-blue-400 flex items-center justify-between">
              <span>Complete Transaction Details - {selectedTransfer.transaction_id}</span>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowDetails(false)}
                className="border-gray-500 text-gray-400"
              >
                Close
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-white">Transaction Information</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Transaction ID:</span>
                    <span className="text-white font-mono">{selectedTransfer.transaction_id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Amount:</span>
                    <span className="text-white font-semibold">${selectedTransfer.amount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Processing Fee:</span>
                    <span className="text-white">${selectedTransfer.processing_details.processing_fee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Routing Number:</span>
                    <span className="text-white font-mono">{selectedTransfer.processing_details.routing_number}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-semibold text-white">Request Details</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Requester:</span>
                    <span className="text-white">{selectedTransfer.request_details.requester}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Purpose:</span>
                    <span className="text-white">{selectedTransfer.request_details.purpose}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Approval Status:</span>
                    <Badge className="bg-green-600">{selectedTransfer.request_details.approval_status}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Requested Date:</span>
                    <span className="text-white">{new Date(selectedTransfer.request_details.requested_date).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-gray-700/50 rounded">
              <h4 className="font-semibold text-white mb-2">Payment Route & Invoice Details</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-400">Payment Route:</p>
                  <p className="text-white">{selectedTransfer.payment_route}</p>
                </div>
                <div>
                  <p className="text-gray-400">Invoice Number:</p>
                  <p className="text-white">{selectedTransfer.invoice_number || 'N/A'}</p>
                </div>
              </div>
              <div className="mt-3">
                <p className="text-gray-400">Full Description:</p>
                <p className="text-white">{selectedTransfer.description}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default EnhancedRecentTransfers;