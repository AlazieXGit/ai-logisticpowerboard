import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import PaymentProcessorIntegration from './PaymentProcessorIntegration';
import ManualCardTransferForum from './ManualCardTransferForum';
import { 
  Building2, DollarSign, Users, Database, Shield, 
  CreditCard, TrendingUp 
} from 'lucide-react';
const EnhancedCompletePlatformOverview: React.FC = () => {
  const totalRevenue = 14795747.63;
  const activeAccounts = 7;
  const connectedProcessors = 4;

  const accounts = [
    {
      name: 'Trust Banking Account',
      type: 'Trust Banking',
      number: '****1234',
      routing: '021000021',
      balance: 28500000.00,
      status: 'Active',
      revenueSource: 'Xpress AI Platform + Loadboard AI + Trust Account Revenue'
    },
    {
      name: 'Operating Account',
      type: 'Operating',
      number: '****5678',
      routing: '121000248',
      balance: 12750000.00,
      status: 'Active',
      revenueSource: 'Synergy AI Platform + Lenders/Investors Platform'
    },
    {
      name: 'Escrow Account',
      type: 'Escrow',
      number: '****9012',
      routing: '031000021',
      balance: 8500000.00,
      status: 'Active',
      revenueSource: 'Master Savings Fund + Overflow Protection'
    },
    {
      name: 'Fee Collection Account',
      type: 'Fee Collection',
      number: '5186776357552',
      routing: '041215663',
      balance: 1818861.48,
      status: 'Active',
      revenueSource: 'Transaction Fees + Processing Fees + Service Charges'
    },
    {
      name: 'Cash App - Super Admin Payroll',
      type: 'Payroll',
      number: '****3456',
      routing: '051000021',
      balance: 15000.00,
      status: 'Active - Payroll Due',
      revenueSource: 'Administrative Payroll + Executive Compensation'
    },
    {
      name: 'Growth Account - x5283',
      type: 'Growth',
      number: '5563935283',
      routing: '054000030',
      balance: 2500000.00,
      status: 'Active',
      revenueSource: 'Investment Growth + Capital Appreciation + Profit Reinvestment'
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-blue-500">
        <CardHeader>
          <CardTitle className="text-2xl text-blue-400 flex items-center gap-3">
            <Building2 className="h-8 w-8" />
            Complete Platform Overview & Payment System
          </CardTitle>
          <p className="text-gray-300">Comprehensive account management and internal transfer system</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30">
              <div className="flex items-center gap-3">
                <DollarSign className="h-8 w-8 text-green-400" />
                <div>
                  <p className="text-green-300 text-sm">Total Platform Revenue</p>
                  <p className="text-2xl font-bold text-green-400">
                    ${totalRevenue.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
              <div className="flex items-center gap-3">
                <Users className="h-8 w-8 text-blue-400" />
                <div>
                  <p className="text-blue-300 text-sm">Active Accounts</p>
                  <p className="text-2xl font-bold text-blue-400">{activeAccounts}</p>
                </div>
              </div>
            </div>
            <div className="bg-purple-900/20 p-4 rounded-lg border border-purple-500/30">
              <div className="flex items-center gap-3">
                <Database className="h-8 w-8 text-purple-400" />
                <div>
                  <p className="text-purple-300 text-sm">Connected Processors</p>
                  <p className="text-2xl font-bold text-purple-400">{connectedProcessors}</p>
                </div>
              </div>
            </div>
          </div>

          <Tabs defaultValue="accounts" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="accounts">Account Management</TabsTrigger>
              <TabsTrigger value="transfers">Internal Transfers</TabsTrigger>
              <TabsTrigger value="processors">Payment Processors</TabsTrigger>
              <TabsTrigger value="instructions">Platform Instructions</TabsTrigger>
            </TabsList>

            <TabsContent value="accounts" className="space-y-4">
              {accounts.map((account, index) => (
                <Card key={index} className="bg-gray-800/30 border-gray-600">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="text-white font-semibold">{account.name}</h3>
                        <Badge className={`mt-1 ${
                          account.status.includes('Due') ? 'bg-yellow-600' : 'bg-green-600'
                        }`}>
                          {account.status}
                        </Badge>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-green-400">
                          ${account.balance.toLocaleString()}
                        </p>
                        <p className="text-gray-400 text-sm">{account.type}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                      <div>
                        <p className="text-gray-400 text-sm">Account Number:</p>
                        <p className="text-blue-400 font-mono">{account.number}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Routing Number:</p>
                        <p className="text-green-400 font-mono">{account.routing}</p>
                      </div>
                    </div>
                    
                    <div className="bg-gray-700/30 p-3 rounded-lg">
                      <p className="text-gray-400 text-sm mb-1">Revenue Source:</p>
                      <p className="text-yellow-300 text-sm">{account.revenueSource}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="transfers">
              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Internal Transfer System</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-blue-900/20 p-4 rounded-lg">
                      <h3 className="text-blue-300 font-semibold mb-2">Automated Revenue Routing</h3>
                      <p className="text-gray-300 text-sm">AI-powered distribution of platform revenue across trust, operating, and growth accounts</p>
                    </div>
                    <div className="bg-green-900/20 p-4 rounded-lg">
                      <h3 className="text-green-300 font-semibold mb-2">Escrow Overflow Protection</h3>
                      <p className="text-gray-300 text-sm">Automatic overflow routing to master savings fund when escrow limits are reached</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="processors">
              <div className="space-y-4">
                <PaymentProcessorIntegration />
                <ManualCardTransferForum />
              </div>
            </TabsContent>
            <TabsContent value="instructions">
              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Platform Instructions & Documents</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button className="w-full justify-start" variant="outline">
                      <Shield className="h-4 w-4 mr-2" />
                      Trust Banking Setup Guide
                    </Button>
                    <Button className="w-full justify-start" variant="outline">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Payment Processing Manual
                    </Button>
                    <Button className="w-full justify-start" variant="outline">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Revenue Optimization Strategies
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedCompletePlatformOverview;