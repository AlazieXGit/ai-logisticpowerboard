import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileText, Download, Shield, Calendar, 
  CheckCircle, AlertTriangle, Search
} from 'lucide-react';

const LegalDocumentManager: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('tax');

  const legalDocuments = {
    tax: [
      { name: '2024 Tax Return', status: 'ready', date: '2024-12-31', type: 'PDF' },
      { name: '1099 Forms', status: 'ready', date: '2024-12-31', type: 'PDF' },
      { name: 'Business Expenses', status: 'ready', date: '2024-12-31', type: 'Excel' },
      { name: 'Quarterly Reports', status: 'ready', date: '2024-12-31', type: 'PDF' }
    ],
    contracts: [
      { name: 'Vendor Agreements', status: 'ready', date: '2024-01-15', type: 'PDF' },
      { name: 'Service Contracts', status: 'ready', date: '2024-02-20', type: 'PDF' },
      { name: 'Employment Contracts', status: 'ready', date: '2024-03-10', type: 'PDF' }
    ],
    compliance: [
      { name: 'DOT Compliance', status: 'ready', date: '2024-06-15', type: 'PDF' },
      { name: 'Insurance Certificates', status: 'ready', date: '2024-07-01', type: 'PDF' },
      { name: 'Safety Records', status: 'ready', date: '2024-08-30', type: 'PDF' }
    ],
    audit: [
      { name: 'Financial Audit 2024', status: 'ready', date: '2024-12-31', type: 'PDF' },
      { name: 'Internal Controls', status: 'ready', date: '2024-11-15', type: 'PDF' },
      { name: 'Compliance Audit', status: 'ready', date: '2024-10-20', type: 'PDF' }
    ]
  };

  const downloadDocument = (docName: string) => {
    // Simulate document download
    console.log(`Downloading ${docName}`);
    alert(`Downloading ${docName} - Ready for tax audit or inquiry`);
  };

  return (
    <div className="space-y-6">
      <Alert className="border-green-500 bg-green-900/20">
        <Shield className="h-4 w-4 text-green-400" />
        <AlertDescription className="text-green-300">
          📋 Legal Document Management - Ready for Tax Audits & Inquiries
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-4 gap-4 mb-6">
        {Object.keys(legalDocuments).map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            onClick={() => setSelectedCategory(category)}
            className={selectedCategory === category ? "bg-green-600" : ""}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </Button>
        ))}
      </div>

      <Card className="bg-gray-800/30 border-green-500">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <FileText className="h-5 w-5" />
            {selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Documents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {legalDocuments[selectedCategory as keyof typeof legalDocuments].map((doc, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg border border-gray-600">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-blue-400" />
                  <div>
                    <h4 className="text-white font-medium">{doc.name}</h4>
                    <p className="text-gray-400 text-sm flex items-center gap-2">
                      <Calendar className="h-3 w-3" />
                      {doc.date} • {doc.type}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-green-600 text-white">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    {doc.status.toUpperCase()}
                  </Badge>
                  <Button
                    size="sm"
                    onClick={() => downloadDocument(doc.name)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Download
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800/30 border-yellow-500">
          <CardHeader>
            <CardTitle className="text-yellow-400">Audit Readiness</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Tax Documents:</span>
                <Badge className="bg-green-600">READY</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Financial Records:</span>
                <Badge className="bg-green-600">READY</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Compliance Files:</span>
                <Badge className="bg-green-600">READY</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-purple-500">
          <CardHeader>
            <CardTitle className="text-purple-400">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Button className="w-full bg-purple-600 hover:bg-purple-700">
                <Search className="h-4 w-4 mr-2" />
                Search All Documents
              </Button>
              <Button className="w-full bg-green-600 hover:bg-green-700">
                <Download className="h-4 w-4 mr-2" />
                Download All Tax Files
              </Button>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                <FileText className="h-4 w-4 mr-2" />
                Generate Audit Package
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LegalDocumentManager;