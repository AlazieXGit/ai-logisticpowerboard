import React, { useState, useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

interface NukieChatPanelProps {
  context: any;
  aiMode: string;
}

const NukieChatPanel: React.FC<NukieChatPanelProps> = ({ context, aiMode }) => {
  const [messages, setMessages] = useState<Message[]>([{
    id: '1',
    role: 'assistant',
    text: 'Hello! I\'m Alaziel AI, your intelligent banking and logistics assistant. Ask me about transactions, loads, routing, or get insights!',
    timestamp: new Date()
  }]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const wsUrl = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsHost = window.location.host.includes('localhost') ? 'localhost:8000' : window.location.host;
    
    try {
      wsRef.current = new WebSocket(`${wsUrl}//${wsHost}/ws/chat`);
      
      wsRef.current.onmessage = (event) => {
        const aiMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          text: event.data,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiMessage]);
        setIsTyping(false);
      };

      wsRef.current.onerror = () => {
        console.log('WebSocket failed, using Supabase fallback');
      };
    } catch (error) {
      console.log('WebSocket not available, using Supabase');
    }

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const sendMessage = async () => {
    if (input.trim() === '') return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);
    
    const payload = {
      message: input,
      mode: aiMode,
      context: context
    };
    
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(payload));
    } else {
      try {
        const { data, error } = await supabase.functions.invoke('generate-insights', {
          body: payload,
        });

        const aiMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          text: error ? 'Sorry, I encountered an error. Please try again.' : (data?.response || 'I received your message but couldn\'t generate a response.'),
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiMessage]);
      } catch (err) {
        const errorMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          text: 'I\'m having trouble connecting right now. Please try again later.',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
      setIsTyping(false);
    }
    
    setInput('');
  };

  return (
    <Card className="h-full flex flex-col bg-gradient-to-br from-emerald-50 to-teal-100 border-2 border-emerald-200 shadow-xl">
      <div className="p-4 border-b bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-t-lg">
        <h2 className="text-xl font-bold flex items-center gap-2">
          🧠 Alaziel AI Assistant
          <Badge variant="secondary" className="bg-white/20 text-white">
            {aiMode.toUpperCase()}
          </Badge>
        </h2>
      </div>
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-3 rounded-lg shadow-md ${
                msg.role === 'user' 
                  ? 'bg-gradient-to-r from-emerald-500 to-emerald-600 text-white' 
                  : 'bg-white border-2 border-gray-200'
              }`}>
                <div className="text-sm font-semibold mb-1">
                  {msg.role === 'user' ? 'You' : '🧠 Alaziel AI'}
                </div>
                <div className="text-sm whitespace-pre-wrap">{msg.text}</div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white border-2 border-gray-200 p-3 rounded-lg shadow-md">
                <div className="text-sm font-semibold mb-1">🧠 Alaziel AI</div>
                <div className="text-sm text-gray-500">Analyzing...</div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
      <div className="p-4 border-t bg-white">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Ask about banking, loads, routing, or automation..."
            className="flex-1 border-2 border-emerald-200 focus:border-emerald-400"
          />
          <Button 
            onClick={sendMessage}
            className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white px-6"
          >
            Send
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default NukieChatPanel;