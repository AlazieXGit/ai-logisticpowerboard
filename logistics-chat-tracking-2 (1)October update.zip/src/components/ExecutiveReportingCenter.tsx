import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileText, Users, TrendingUp, MessageCircle,
  BarChart3, PieChart, Calendar, Send
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface ExecutiveData {
  monthlyRevenue: number;
  activeClients: number;
  completedProjects: number;
  stakeholderCount: number;
}

const ExecutiveReportingCenter: React.FC = () => {
  const [executiveData, setExecutiveData] = useState<ExecutiveData>({
    monthlyRevenue: 4250000,
    activeClients: 1247,
    completedProjects: 892,
    stakeholderCount: 156
  });
  const [messages, setMessages] = useState<string[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const generateBoardReport = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('automated-report-generator', {
        body: {
          reportType: 'executive_summary',
          data: executiveData,
          period: 'monthly'
        }
      });
      
      if (error) throw error;
      
      // Simulate report generation
      alert('Executive Board Report Generated Successfully');
    } catch (error) {
      console.error('Report generation error:', error);
    } finally {
      setLoading(false);
    }
  };

  const sendStakeholderUpdate = async () => {
    if (!newMessage.trim()) return;
    
    try {
      const { data, error } = await supabase.functions.invoke('automated-report-generator', {
        body: {
          type: 'stakeholder_communication',
          message: newMessage,
          recipients: 'all_stakeholders'
        }
      });
      
      if (error) throw error;
      
      setMessages(prev => [...prev, newMessage]);
      setNewMessage('');
      alert('Stakeholder update sent successfully');
    } catch (error) {
      console.error('Communication error:', error);
    }
  };

  const boardMetrics = [
    { label: 'Monthly Revenue', value: executiveData.monthlyRevenue, icon: <TrendingUp className="h-4 w-4" />, color: 'green' },
    { label: 'Active Clients', value: executiveData.activeClients, icon: <Users className="h-4 w-4" />, color: 'blue' },
    { label: 'Completed Projects', value: executiveData.completedProjects, icon: <FileText className="h-4 w-4" />, color: 'purple' },
    { label: 'Stakeholders', value: executiveData.stakeholderCount, icon: <MessageCircle className="h-4 w-4" />, color: 'orange' }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-purple-900/20 border-purple-500/50">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Executive Reporting Center - Board Communications
          </CardTitle>
          <Badge className="bg-purple-600 w-fit">EXECUTIVE ACCESS</Badge>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="board-reports" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="board-reports">Board Reports</TabsTrigger>
              <TabsTrigger value="stakeholder-updates">Stakeholder Updates</TabsTrigger>
              <TabsTrigger value="communications">Communications Hub</TabsTrigger>
            </TabsList>

            <TabsContent value="board-reports" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {boardMetrics.map((metric, index) => (
                  <Card key={index} className="bg-gray-800/30 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        {metric.icon}
                        <span className="text-white text-sm">{metric.label}</span>
                      </div>
                      <div className="text-2xl font-bold text-white">
                        {typeof metric.value === 'number' && metric.label.includes('Revenue') 
                          ? `$${metric.value.toLocaleString()}`
                          : metric.value.toLocaleString()
                        }
                      </div>
                      <Badge className={`bg-${metric.color}-600 mt-2`}>CURRENT</Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Executive Summary Generation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <Button 
                        onClick={generateBoardReport}
                        disabled={loading}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        {loading ? 'Generating...' : 'Generate Board Report'}
                      </Button>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Financial Summary
                      </Button>
                      <Button className="bg-green-600 hover:bg-green-700">
                        <PieChart className="h-4 w-4 mr-2" />
                        Performance Metrics
                      </Button>
                    </div>
                    
                    <Alert className="border-blue-500 bg-blue-900/20">
                      <AlertDescription className="text-blue-300">
                        📊 Next board meeting: December 15, 2024 - All reports will be auto-generated 24 hours prior
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Key Performance Indicators</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Revenue Growth (YoY)</span>
                        <Badge className="bg-green-600">+23.5%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Client Retention</span>
                        <Badge className="bg-blue-600">94.2%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Project Success Rate</span>
                        <Badge className="bg-purple-600">97.8%</Badge>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Market Share</span>
                        <Badge className="bg-orange-600">12.8%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Employee Satisfaction</span>
                        <Badge className="bg-green-600">4.7/5</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Innovation Index</span>
                        <Badge className="bg-blue-600">8.9/10</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stakeholder-updates" className="space-y-4">
              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Investor Communications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <h4 className="text-white font-semibold">Active Investors</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-300">Institutional</span>
                            <span className="text-white">23</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-300">Private Equity</span>
                            <span className="text-white">8</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-300">Angel Investors</span>
                            <span className="text-white">45</span>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <h4 className="text-white font-semibold">Communication Schedule</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-300">Monthly Updates</span>
                            <Badge className="bg-green-600">ACTIVE</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-300">Quarterly Reports</span>
                            <Badge className="bg-blue-600">SCHEDULED</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-300">Annual Meeting</span>
                            <Badge className="bg-purple-600">Q1 2025</Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Send Stakeholder Update</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Compose stakeholder update message..."
                      className="w-full h-32 p-3 bg-gray-700 border border-gray-600 rounded-lg text-white resize-none"
                    />
                    <div className="flex gap-3">
                      <Button 
                        onClick={sendStakeholderUpdate}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Send to All Stakeholders
                      </Button>
                      <Button className="bg-gray-600 hover:bg-gray-700">
                        <Calendar className="h-4 w-4 mr-2" />
                        Schedule for Later
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="communications" className="space-y-4">
              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Community Super Admin Communications
                  </CardTitle>
                  <Badge className="bg-red-600 w-fit">SUPER ADMIN ONLY</Badge>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Alert className="border-yellow-500 bg-yellow-900/20">
                      <AlertDescription className="text-yellow-300">
                        🔒 Restricted Access: Alucius Alford - 2408 Yanceyville St. Greensboro N.C. 27405
                      </AlertDescription>
                    </Alert>
                    
                    <div className="bg-gray-700/50 p-4 rounded-lg max-h-64 overflow-y-auto">
                      <h4 className="text-white font-semibold mb-3">Recent Communications</h4>
                      {messages.length === 0 ? (
                        <p className="text-gray-400">No recent messages</p>
                      ) : (
                        messages.map((msg, index) => (
                          <div key={index} className="mb-2 p-2 bg-gray-600/50 rounded">
                            <p className="text-gray-300 text-sm">{msg}</p>
                          </div>
                        ))
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <Button className="bg-green-600 hover:bg-green-700">
                        <Users className="h-4 w-4 mr-2" />
                        View All Stakeholders
                      </Button>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <FileText className="h-4 w-4 mr-2" />
                        Communication Log
                      </Button>
                      <Button className="bg-purple-600 hover:bg-purple-700">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Engagement Analytics
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ExecutiveReportingCenter;