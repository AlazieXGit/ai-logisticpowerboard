import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Camera, Scan, CreditCard, CheckCircle, Upload, Download, Smartphone } from 'lucide-react';

export const VirtualCheckingSystem = () => {
  const [checkAmount, setCheckAmount] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scannedCheck, setScannedCheck] = useState(null);
  const [depositStatus, setDepositStatus] = useState('');

  const handleBarcodeScanning = () => {
    setIsScanning(true);
    // Simulate barcode scanning
    setTimeout(() => {
      setScannedCheck({
        amount: '$1,250.00',
        checkNumber: '1001',
        routingNumber: '043000096',
        accountNumber: '****5678',
        date: new Date().toLocaleDateString()
      });
      setIsScanning(false);
      setDepositStatus('processed');
    }, 3000);
  };

  const handleManualDeposit = () => {
    if (checkAmount) {
      setDepositStatus('manual-processed');
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-black/20 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="h-6 w-6" />
            Virtual eChecking & Barcode Processing System
            <Badge className="bg-green-500">AI Automated</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="barcode" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="barcode">Barcode Scanning</TabsTrigger>
              <TabsTrigger value="manual">Manual Processing</TabsTrigger>
              <TabsTrigger value="virtual">Virtual Checking</TabsTrigger>
            </TabsList>

            <TabsContent value="barcode" className="space-y-4">
              <div className="text-center space-y-4">
                <div className="bg-gray-800/50 border-2 border-dashed border-gray-600 rounded-lg p-8">
                  {isScanning ? (
                    <div className="space-y-4">
                      <Scan className="h-16 w-16 mx-auto text-blue-400 animate-pulse" />
                      <p className="text-white">Scanning barcode...</p>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{width: '60%'}}></div>
                      </div>
                    </div>
                  ) : scannedCheck ? (
                    <div className="space-y-4">
                      <CheckCircle className="h-16 w-16 mx-auto text-green-400" />
                      <div className="text-white space-y-2">
                        <h3 className="text-xl font-bold">Check Scanned Successfully</h3>
                        <div className="grid grid-cols-2 gap-4 text-left bg-gray-900/50 p-4 rounded">
                          <div>Amount: <span className="text-green-400 font-bold">{scannedCheck.amount}</span></div>
                          <div>Check #: <span className="text-blue-400">{scannedCheck.checkNumber}</span></div>
                          <div>Routing: <span className="text-purple-400">{scannedCheck.routingNumber}</span></div>
                          <div>Account: <span className="text-orange-400">{scannedCheck.accountNumber}</span></div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Camera className="h-16 w-16 mx-auto text-gray-400" />
                      <p className="text-gray-300">Position check within camera view</p>
                    </div>
                  )}
                </div>
                
                <Button 
                  onClick={handleBarcodeScanning}
                  disabled={isScanning}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {isScanning ? 'Scanning...' : 'Start Barcode Scan'}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="manual" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div>
                    <label className="text-white text-sm font-medium">Check Amount</label>
                    <Input
                      value={checkAmount}
                      onChange={(e) => setCheckAmount(e.target.value)}
                      placeholder="$0.00"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-white text-sm font-medium">Check Number</label>
                    <Input
                      placeholder="Enter check number"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-white text-sm font-medium">Routing Number</label>
                    <Input
                      placeholder="9-digit routing number"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-white text-sm font-medium">Account Number</label>
                    <Input
                      placeholder="Account number"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-white text-sm font-medium">Memo</label>
                    <Input
                      placeholder="Optional memo"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <Button 
                    onClick={handleManualDeposit}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Process Manual Deposit
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="virtual" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { title: 'Virtual Account Balance', amount: '$45,892.33', status: 'Active' },
                  { title: 'Pending Deposits', amount: '$2,150.00', status: 'Processing' },
                  { title: 'Available Balance', amount: '$43,742.33', status: 'Available' }
                ].map((account, index) => (
                  <Card key={index} className="bg-gray-900/50 border-gray-600">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-white">{account.amount}</div>
                      <div className="text-sm text-gray-300">{account.title}</div>
                      <Badge className={`mt-2 ${
                        account.status === 'Active' ? 'bg-green-500' :
                        account.status === 'Processing' ? 'bg-yellow-500' : 'bg-blue-500'
                      }`}>
                        {account.status}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="bg-purple-600 hover:bg-purple-700">
                  <Smartphone className="h-4 w-4 mr-2" />
                  Mobile Check Capture
                </Button>
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <Download className="h-4 w-4 mr-2" />
                  Export Statements
                </Button>
              </div>
            </TabsContent>
          </Tabs>

          {/* Status Display */}
          {depositStatus && (
            <Card className="mt-4 bg-green-900/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-green-400">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-medium">
                    {depositStatus === 'processed' ? 'Barcode deposit processed successfully' : 'Manual deposit processed successfully'}
                  </span>
                </div>
                <p className="text-sm text-gray-300 mt-1">
                  Funds will be available within 1-2 business days
                </p>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
};