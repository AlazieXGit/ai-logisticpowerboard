import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, DollarSign, Users, Target, BarChart3 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Metric {
  name: string;
  value: number;
  trend: 'up' | 'down' | 'stable';
  target: number;
  unit?: string;
}

const EnhancedExecutiveOverview = () => {
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchAnalytics = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enterprise-analytics-processor', {
        body: { action: 'get_analytics' }
      });
      
      if (!error && data?.metrics) {
        setMetrics(data.metrics);
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTrendIcon = (trend: string) => {
    return trend === 'up' ? <TrendingUp className="w-4 h-4 text-green-500" /> : 
           trend === 'down' ? <TrendingDown className="w-4 h-4 text-red-500" /> : 
           <BarChart3 className="w-4 h-4 text-yellow-500" />;
  };

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  if (loading) {
    return <div className="p-6">Loading analytics...</div>;
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-blue-900">Executive Overview</h2>
        <Badge variant="outline" className="bg-blue-50">
          Real-time Data • Last Updated: {new Date().toLocaleTimeString()}
        </Badge>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric, index) => (
          <Card key={index} className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                {metric.name}
                {getTrendIcon(metric.trend)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-900">
                {metric.value}{metric.unit || '%'}
              </div>
              <div className="mt-2">
                <div className="flex justify-between text-xs text-gray-600 mb-1">
                  <span>Progress to Target</span>
                  <span>{getProgressPercentage(metric.value, metric.target).toFixed(1)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${getProgressPercentage(metric.value, metric.target)}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Target: {metric.target}{metric.unit || '%'}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Executive Summary Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Financial Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Quarterly Revenue</span>
                <span className="font-bold text-green-600">$7.5M (+15.5%)</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Operating Margin</span>
                <span className="font-bold">28.3%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>EBITDA</span>
                <span className="font-bold text-green-600">$2.1M (+12.8%)</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Organizational Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">92.3%</div>
                <div className="text-sm text-gray-600">Employee Retention</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">4.2/5</div>
                <div className="text-sm text-gray-600">Employee Satisfaction</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EnhancedExecutiveOverview;