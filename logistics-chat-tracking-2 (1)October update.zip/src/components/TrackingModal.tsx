import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { MapPin, Truck, CheckCircle, Download } from 'lucide-react';

interface TrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: {
    vehicle: string;
    trackingNumber: string;
    currentLocation: string;
    route: string;
    status: string;
  };
}

export default function TrackingModal({ isOpen, onClose, order }: TrackingModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Vehicle Tracking: {order.vehicle}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="font-semibold">Tracking Number</h4>
                  <p className="text-lg font-mono">{order.trackingNumber}</p>
                </div>
                <Badge className="bg-green-600">{order.status}</Badge>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-blue-500" />
                  <span className="font-medium">Current Location:</span>
                  <span>{order.currentLocation}</span>
                </div>
                
                <div>
                  <h5 className="font-medium mb-2">Delivery Route:</h5>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm">{order.route}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 text-green-600">
                  <CheckCircle className="h-4 w-4" />
                  <span className="font-medium">Delivery Complete</span>
                </div>
              </div>
              
              <div className="flex gap-2 mt-4">
                <Button size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Download Receipt
                </Button>
                <Button size="sm" variant="outline" onClick={onClose}>
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}