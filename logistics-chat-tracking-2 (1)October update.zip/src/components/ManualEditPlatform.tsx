import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { 
  Code, Save, Play, Settings, Database, Globe, 
  Smartphone, Monitor, GitBranch, Zap
} from 'lucide-react';

const ManualEditPlatform = () => {
  const [activeEditor, setActiveEditor] = useState('internal');
  const [code, setCode] = useState('// Enter your code here...');
  const [projectName, setProjectName] = useState('');
  const [deploymentTarget, setDeploymentTarget] = useState('internal');

  const editorTabs = [
    { id: 'internal', label: 'Internal System', icon: Database },
    { id: 'web', label: 'Web Platform', icon: Globe },
    { id: 'mobile', label: 'Mobile App', icon: Smartphone },
    { id: 'desktop', label: 'Desktop App', icon: Monitor }
  ];

  const deploymentOptions = [
    { id: 'internal', label: 'Internal System', color: 'bg-blue-600' },
    { id: 'staging', label: 'Staging Environment', color: 'bg-yellow-600' },
    { id: 'production', label: 'Production', color: 'bg-green-600' },
    { id: 'external', label: 'External Platform', color: 'bg-purple-600' }
  ];

  const handleDeploy = () => {
    console.log('Deploying to:', deploymentTarget);
    console.log('Code:', code);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Manual Edit Platform</h2>
        <Badge className="bg-red-600">Super Admin Only</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Editor Tabs */}
        <div className="lg:col-span-2">
          <Card className="bg-gray-800/30 border-cyan-500">
            <CardHeader>
              <CardTitle className="text-cyan-400 flex items-center gap-2">
                <Code className="h-5 w-5" />
                Code Editor
              </CardTitle>
              <div className="flex gap-2 mt-4">
                {editorTabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <Button
                      key={tab.id}
                      variant={activeEditor === tab.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setActiveEditor(tab.id)}
                      className={activeEditor === tab.id ? "bg-cyan-600" : ""}
                    >
                      <Icon className="h-4 w-4 mr-2" />
                      {tab.label}
                    </Button>
                  );
                })}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Input
                  placeholder="Project Name"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="bg-gray-700 border-gray-600"
                />
                <Textarea
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="min-h-96 bg-gray-900 border-gray-600 font-mono text-sm"
                  placeholder="Enter your code here..."
                />
                <div className="flex gap-2">
                  <Button className="bg-green-600 hover:bg-green-700">
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Play className="h-4 w-4 mr-2" />
                    Test Run
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Deployment Panel */}
        <div>
          <Card className="bg-gray-800/30 border-purple-500">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                <GitBranch className="h-5 w-5" />
                Deployment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Target Environment</label>
                  <div className="space-y-2">
                    {deploymentOptions.map((option) => (
                      <Button
                        key={option.id}
                        variant={deploymentTarget === option.id ? "default" : "outline"}
                        size="sm"
                        className={`w-full justify-start ${
                          deploymentTarget === option.id ? option.color : ""
                        }`}
                        onClick={() => setDeploymentTarget(option.id)}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>
                <Button 
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={handleDeploy}
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Deploy Now
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/30 border-yellow-500 mt-4">
            <CardHeader>
              <CardTitle className="text-yellow-400 flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Advanced Settings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Auto-Deploy</span>
                  <Badge className="bg-green-600">Enabled</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Version Control</span>
                  <Badge className="bg-blue-600">Git</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Build Status</span>
                  <Badge className="bg-green-600">Success</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ManualEditPlatform;