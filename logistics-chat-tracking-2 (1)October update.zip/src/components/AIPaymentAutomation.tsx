import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Zap, CreditCard, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface PaymentTransaction {
  id: string;
  amount: number;
  tier: string;
  status: 'processing' | 'completed' | 'failed';
  timestamp: string;
  stripeLink: string;
}

export const AIPaymentAutomation: React.FC = () => {
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const MAIN_STRIPE_LINK = 'https://buy.stripe.com/fZudR93xS0jf1kq4PTcQU02';
  const LIVE_STRIPE_KEY = 'pk_live_51Nel9QESMiZyND6V5ixJK2PkqjlaMSG58kfYMAjcAs3X7AIEKbWQyIevTZq4KIuTJ96uvdjxVWzkuw3gFUfdfsgA00fQaqC5Gu';

  const processImmediatePayment = async (tier: string, amount: number) => {
    setIsProcessing(true);
    
    const newTransaction: PaymentTransaction = {
      id: `txn_${Date.now()}`,
      amount,
      tier,
      status: 'processing',
      timestamp: new Date().toISOString(),
      stripeLink: MAIN_STRIPE_LINK
    };

    setTransactions(prev => [newTransaction, ...prev]);

    try {
      // AI-powered payment processing
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: {
          transactionId: newTransaction.id,
          amount,
          tier,
          stripeLink: MAIN_STRIPE_LINK,
          aiAutomation: true,
          immediateProcessing: true
        }
      });

      if (error) throw error;

      // Simulate AI processing delay
      setTimeout(() => {
        setTransactions(prev => 
          prev.map(txn => 
            txn.id === newTransaction.id 
              ? { ...txn, status: 'completed' as const }
              : txn
          )
        );
        setIsProcessing(false);
      }, 2000);

      // Open Stripe payment link
      window.open(MAIN_STRIPE_LINK, '_blank');

    } catch (error) {
      console.error('Payment processing error:', error);
      setTransactions(prev => 
        prev.map(txn => 
          txn.id === newTransaction.id 
            ? { ...txn, status: 'failed' as const }
            : txn
        )
      );
      setIsProcessing(false);
    }
  };

  // Real-time payment monitoring
  useEffect(() => {
    const subscription = supabase
      .channel('payment_automation')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'payment_transactions' },
        (payload) => {
          console.log('Payment update:', payload);
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processing':
        return <Zap className="w-4 h-4 text-yellow-500 animate-spin" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return <CreditCard className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-gray-900 to-black min-h-screen">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">AI Payment Automation</h2>
        <p className="text-gray-300">Immediate processing with intelligent routing</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-6">
        <Card className="bg-gray-800/30 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Zap className="w-5 h-5 mr-2 text-yellow-500" />
              Basic Tier - $29
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={() => processImmediatePayment('Basic', 29)}
              disabled={isProcessing}
            >
              Pay Now - AI Boost 50x
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Zap className="w-5 h-5 mr-2 text-green-500" />
              Professional - $99
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={() => processImmediatePayment('Professional', 99)}
              disabled={isProcessing}
            >
              Pay Now - AI Boost 100x
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Zap className="w-5 h-5 mr-2 text-purple-500" />
              Enterprise - $299
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              className="w-full bg-purple-600 hover:bg-purple-700"
              onClick={() => processImmediatePayment('Enterprise', 299)}
              disabled={isProcessing}
            >
              Pay Now - AI Boost 250x
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800/30 border-gray-600">
        <CardHeader>
          <CardTitle className="text-white">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {transactions.length === 0 ? (
              <p className="text-gray-400 text-center py-4">No transactions yet</p>
            ) : (
              transactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(transaction.status)}
                    <div>
                      <div className="text-white font-medium">{transaction.tier} Tier</div>
                      <div className="text-sm text-gray-400">{transaction.id}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-white font-medium">${transaction.amount}</div>
                    <Badge variant={
                      transaction.status === 'completed' ? 'default' : 
                      transaction.status === 'processing' ? 'secondary' : 'destructive'
                    }>
                      {transaction.status}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800/30 border-gray-600">
        <CardHeader>
          <CardTitle className="text-white">Direct Stripe Access</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-blue-900/20 border border-blue-500 rounded-lg">
            <p className="text-blue-300 mb-3">Main Payment Link (All Tiers):</p>
            <div className="flex items-center space-x-2">
              <code className="flex-1 p-2 bg-gray-900 rounded text-gray-300 text-sm">
                {MAIN_STRIPE_LINK}
              </code>
              <Button 
                size="sm"
                onClick={() => window.open(MAIN_STRIPE_LINK, '_blank')}
              >
                Open Link
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};