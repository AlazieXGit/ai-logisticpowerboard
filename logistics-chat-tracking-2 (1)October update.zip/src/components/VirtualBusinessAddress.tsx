import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Building2, MapPin, Mail, Phone, Shield, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const VirtualBusinessAddress: React.FC = () => {
  const [isActivating, setIsActivating] = useState(false);
  const [isActive, setIsActive] = useState(false);

  const virtualAddress = {
    company: 'Alazie LLC',
    street: '1234 Commerce Plaza Drive',
    suite: 'Suite 500',
    city: 'Charlotte',
    state: 'NC',
    zip: '28202',
    phone: '(704) 555-0100',
    email: 'business@alazie.com',
    mailForwarding: true,
    packageReceiving: true,
    businessLicense: true
  };

  const personalAddress = {
    street: '2408 Yanceyville',
    note: 'Personal Information Address (Separate & Protected)'
  };

  const handleActivateAddress = async () => {
    setIsActivating(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'activate_virtual_address',
          address: virtualAddress,
          company: 'Alazie LLC'
        }
      });
      
      if (!error) {
        setIsActive(true);
      }
    } catch (error) {
      console.error('Error activating virtual address:', error);
    } finally {
      setIsActivating(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-emerald-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Virtual Commercial Business Address - Alazie LLC
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-emerald-800/20 p-4 rounded-lg border border-emerald-500/30">
                <h3 className="text-emerald-300 font-bold mb-3 flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Commercial Virtual Address
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="text-white font-bold">{virtualAddress.company}</div>
                  <div className="text-gray-300">{virtualAddress.street}</div>
                  <div className="text-gray-300">{virtualAddress.suite}</div>
                  <div className="text-gray-300">{virtualAddress.city}, {virtualAddress.state} {virtualAddress.zip}</div>
                  <div className="text-gray-300 flex items-center gap-2">
                    <Phone className="h-3 w-3" />
                    {virtualAddress.phone}
                  </div>
                  <div className="text-gray-300 flex items-center gap-2">
                    <Mail className="h-3 w-3" />
                    {virtualAddress.email}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Badge className={`${isActive ? 'bg-emerald-600' : 'bg-gray-600'} p-3 justify-center`}>
                  <div className="text-center">
                    <div className="text-xs font-bold">Mail Forwarding</div>
                    <div className="text-xs">{isActive ? 'Active' : 'Pending'}</div>
                  </div>
                </Badge>
                <Badge className={`${isActive ? 'bg-emerald-600' : 'bg-gray-600'} p-3 justify-center`}>
                  <div className="text-center">
                    <div className="text-xs font-bold">Package Receiving</div>
                    <div className="text-xs">{isActive ? 'Active' : 'Pending'}</div>
                  </div>
                </Badge>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                <h3 className="text-red-400 font-bold mb-3 flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Personal Address Protection
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="text-gray-300">{personalAddress.street}</div>
                  <div className="text-red-300 text-xs italic">{personalAddress.note}</div>
                  <Badge className="bg-red-600 text-xs">
                    Protected & Separate from Business
                  </Badge>
                </div>
              </div>
              
              <div className="bg-gray-800/50 p-4 rounded-lg">
                <h4 className="text-white font-bold mb-2">Address Separation Benefits</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li className="flex items-center gap-2">
                    <Check className="h-3 w-3 text-emerald-400" />
                    Privacy Protection
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3 w-3 text-emerald-400" />
                    Professional Business Image
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3 w-3 text-emerald-400" />
                    Legal Compliance
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3 w-3 text-emerald-400" />
                    Mail Management
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mt-6 flex gap-4">
            <Button 
              onClick={handleActivateAddress}
              disabled={isActivating || isActive}
              className={`${isActive ? 'bg-emerald-600' : 'bg-emerald-700 hover:bg-emerald-600'}`}
            >
              {isActivating ? 'Activating...' : isActive ? 'Address Active' : 'Activate Virtual Address'}
              {isActive && <Check className="h-4 w-4 ml-2" />}
            </Button>
            
            {isActive && (
              <Badge className="bg-emerald-600 p-2">
                <Building2 className="h-3 w-3 mr-1" />
                Commercial Address Live
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VirtualBusinessAddress;