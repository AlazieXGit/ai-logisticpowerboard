import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Shield, ArrowRight, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface RedirectionRule {
  id: string;
  source: string;
  enabled: boolean;
  lastRedirect: string;
  amount: number;
}

const TrustRedirectionSystem: React.FC = () => {
  const [rules, setRules] = useState<RedirectionRule[]>([]);
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadRedirectionRules();
  }, []);

  const loadRedirectionRules = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_redirection_rules' }
      });
      
      if (error) throw error;
      setRules(data.rules || []);
    } catch (error) {
      console.error('Error loading rules:', error);
    }
  };

  const updateRedirectionRule = async (ruleId: string, enabled: boolean) => {
    setIsUpdating(true);
    try {
      const { error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'update_redirection_rule',
          ruleId,
          enabled
        }
      });

      if (error) throw error;
      
      toast({ 
        title: 'Success', 
        description: `Redirection ${enabled ? 'enabled' : 'disabled'}` 
      });
      
      loadRedirectionRules();
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to update rule', variant: 'destructive' });
    } finally {
      setIsUpdating(false);
    }
  };

  const enableAllRedirections = async () => {
    setIsUpdating(true);
    try {
      const { error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'enable_all_trust_redirections' }
      });

      if (error) throw error;
      
      toast({ 
        title: 'Success', 
        description: 'All funds now redirect to Revocable Trust for Alucius Alford' 
      });
      
      loadRedirectionRules();
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to enable redirections', variant: 'destructive' });
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Trust Fund Redirection - Alucius Alford Revocable Trust
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-emerald-900/20 p-4 rounded-lg border border-emerald-500/30">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-5 w-5 text-emerald-400" />
              <span className="text-emerald-300 font-semibold">Primary Trust Account</span>
            </div>
            <p className="text-gray-300 text-sm mb-3">
              Revocable Trust for Alucius Alford - All redirected funds destination
            </p>
            <Button 
              onClick={enableAllRedirections}
              disabled={isUpdating}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isUpdating ? 'Updating...' : 'Enable All Fund Redirections to Trust'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400">Revenue Source Redirections</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div className="flex items-center gap-3">
                  <ArrowRight className="h-4 w-4 text-emerald-400" />
                  <div>
                    <p className="text-white font-medium">{rule.source}</p>
                    <p className="text-gray-400 text-sm">
                      Last redirect: {rule.lastRedirect} - ${rule.amount.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className={rule.enabled ? 'bg-green-600' : 'bg-gray-600'}>
                    {rule.enabled ? 'Active' : 'Inactive'}
                  </Badge>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={rule.enabled}
                      onCheckedChange={(enabled) => updateRedirectionRule(rule.id, enabled)}
                      disabled={isUpdating}
                    />
                    <Label className="text-gray-300">Redirect</Label>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrustRedirectionSystem;