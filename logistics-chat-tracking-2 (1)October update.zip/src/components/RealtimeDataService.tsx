import { supabase } from '@/lib/supabase';

export interface TransactionData {
  id: string;
  timestamp: string;
  amount: number;
  type: 'credit' | 'debit';
  platform: string;
  status: 'completed' | 'pending' | 'failed';
  account: string;
}

export interface RevenueAnalytics {
  totalRevenue: number;
  revenueSources: Array<{
    name: string;
    amount: number;
    percentage: number;
    growth: number;
  }>;
  platformFees: Array<{
    platform: string;
    processingFee: number;
    serviceFee: number;
    totalFee: number;
  }>;
}

export class RealtimeDataService {
  static async getLiveTransactions(): Promise<{
    transactions: TransactionData[];
    currentBalance: number;
    previousDayBalance: number;
  }> {
    try {
      const { data, error } = await supabase.functions.invoke('realtime-transaction-processor', {
        body: { action: 'getLiveTransactions' }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching live transactions:', error);
      return {
        transactions: [],
        currentBalance: 0,
        previousDayBalance: 0
      };
    }
  }

  static async getRevenueAnalytics(): Promise<RevenueAnalytics> {
    try {
      const { data, error } = await supabase.functions.invoke('realtime-transaction-processor', {
        body: { action: 'getRevenueAnalytics' }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching revenue analytics:', error);
      return {
        totalRevenue: 0,
        revenueSources: [],
        platformFees: []
      };
    }
  }

  static async processPayment(amount: number, routingEndpoint: string): Promise<{
    success: boolean;
    transactionId: string;
    status: string;
  }> {
    try {
      const { data, error } = await supabase.functions.invoke('realtime-transaction-processor', {
        body: { 
          action: 'processPayment',
          data: { amount, routingEndpoint }
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error processing payment:', error);
      return {
        success: false,
        transactionId: '',
        status: 'failed'
      };
    }
  }
}