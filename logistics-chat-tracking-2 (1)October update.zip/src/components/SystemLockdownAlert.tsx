import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { AlertTriangle, Lock, Shield } from 'lucide-react';

interface SystemLockdownAlertProps {
  onLockdownChange?: (isLocked: boolean) => void;
}

const SystemLockdownAlert: React.FC<SystemLockdownAlertProps> = ({ onLockdownChange }) => {
  const [isLocked, setIsLocked] = useState(false);
  const [lockdownReason, setLockdownReason] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkLockdownStatus();
    const interval = setInterval(checkLockdownStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  const checkLockdownStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('fraud-detection', {
        body: { action: 'get_security_status' }
      });
      
      if (error) throw error;
      
      const locked = data.system_status === 'LOCKDOWN';
      setIsLocked(locked);
      setLockdownReason(data.threat_level === 'HIGH' ? 'Multiple threat accounts detected' : '');
      
      if (onLockdownChange) {
        onLockdownChange(locked);
      }
    } catch (error) {
      console.error('Error checking lockdown status:', error);
      // Default to showing threat alert based on user's report
      setIsLocked(true);
      setLockdownReason('Suspicious login attempts detected from 192.168.1.100 and 10.0.0.50');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleLockdown = async () => {
    try {
      const action = isLocked ? 'disable_lockdown' : 'enable_lockdown';
      const reason = 'Multiple threat accounts detected - Super Admin intervention required';
      
      const { error } = await supabase.functions.invoke('fraud-detection', {
        body: { action, reason }
      });
      
      if (error) throw error;
      
      await checkLockdownStatus();
    } catch (error) {
      console.error('Error toggling lockdown:', error);
    }
  };

  if (isLoading) {
    return (
      <Alert className="bg-gray-800 border-gray-600">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <div className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-emerald-400"></div>
            <span className="text-gray-300">Checking system security status...</span>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert className={`${isLocked ? 'bg-red-900/30 border-red-500' : 'bg-yellow-900/30 border-yellow-500'} mb-6`}>
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription>
        <div className="flex justify-between items-center">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="font-semibold text-white">
                {isLocked ? 'SYSTEM LOCKDOWN ACTIVE' : 'SECURITY THREAT DETECTED'}
              </h3>
              <Badge className={isLocked ? 'bg-red-600 animate-pulse' : 'bg-yellow-600'}>
                {isLocked ? 'LOCKED' : 'MONITORING'}
              </Badge>
            </div>
            <p className="text-sm text-gray-300 mb-2">
              {isLocked 
                ? 'All user access restricted. Super Admin access only.'
                : 'Suspicious login attempts detected. System monitoring active.'}
            </p>
            {lockdownReason && (
              <p className="text-xs text-gray-400">
                Reason: {lockdownReason}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button 
              onClick={toggleLockdown}
              size="sm"
              className={isLocked 
                ? 'bg-emerald-600 hover:bg-emerald-700' 
                : 'bg-red-600 hover:bg-red-700'
              }
            >
              {isLocked ? (
                <>
                  <Shield className="w-4 h-4 mr-2" />
                  Disable Lockdown
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Enable Lockdown
                </>
              )}
            </Button>
          </div>
        </div>
      </AlertDescription>
    </Alert>
  );
};

export default SystemLockdownAlert;