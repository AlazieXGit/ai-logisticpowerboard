import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Key, 
  Shield, 
  Activity, 
  Database, 
  Lock,
  Eye,
  Copy,
  RefreshCw
} from 'lucide-react';

const APIManagementSystem: React.FC = () => {
  const [apiKeys, setApiKeys] = useState([
    {
      id: 'ak_live_1234567890',
      name: 'Production API Key',
      type: 'Full Access',
      status: 'Active',
      created: '2025-01-15',
      lastUsed: '2025-01-15 14:30:22'
    },
    {
      id: 'ak_test_0987654321',
      name: 'Test Environment',
      type: 'Read Only',
      status: 'Active',
      created: '2025-01-14',
      lastUsed: '2025-01-15 12:15:45'
    }
  ]);

  const [rateLimits] = useState({
    requests_per_minute: 1000,
    requests_per_hour: 50000,
    requests_per_day: 1000000
  });

  const generateApiKey = () => {
    const newKey = {
      id: `ak_${Date.now()}`,
      name: 'New API Key',
      type: 'Read Only',
      status: 'Active',
      created: new Date().toISOString().split('T')[0],
      lastUsed: 'Never'
    };
    setApiKeys([...apiKeys, newKey]);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">API Management</h2>
        <Button onClick={generateApiKey} className="bg-blue-600 hover:bg-blue-700">
          <Key className="w-4 h-4 mr-2" />
          Generate New Key
        </Button>
      </div>

      <Tabs defaultValue="keys" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="keys">API Keys</TabsTrigger>
          <TabsTrigger value="limits">Rate Limits</TabsTrigger>
          <TabsTrigger value="logs">Access Logs</TabsTrigger>
          <TabsTrigger value="docs">Documentation</TabsTrigger>
        </TabsList>

        <TabsContent value="keys" className="space-y-4">
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Key className="w-5 h-5 mr-2" />
                API Keys Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {apiKeys.map((key) => (
                <div key={key.id} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-medium">{key.name}</span>
                      <Badge variant={key.status === 'Active' ? 'default' : 'secondary'}>
                        {key.status}
                      </Badge>
                      <Badge variant="outline">{key.type}</Badge>
                    </div>
                    <div className="text-sm text-gray-400">
                      ID: {key.id} • Created: {key.created} • Last Used: {key.lastUsed}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="limits" className="space-y-4">
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Rate Limiting Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-gray-800 rounded-lg">
                  <div className="text-2xl font-bold text-blue-400">{rateLimits.requests_per_minute.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Requests per Minute</div>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg">
                  <div className="text-2xl font-bold text-green-400">{rateLimits.requests_per_hour.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Requests per Hour</div>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg">
                  <div className="text-2xl font-bold text-purple-400">{rateLimits.requests_per_day.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Requests per Day</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Activity className="w-5 h-5 mr-2" />
                API Access Logs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[
                  { timestamp: '2025-01-15 14:30:22', endpoint: '/api/v1/transactions', method: 'GET', status: 200, key: 'ak_live_***7890' },
                  { timestamp: '2025-01-15 14:29:15', endpoint: '/api/v1/accounts', method: 'POST', status: 201, key: 'ak_live_***7890' },
                  { timestamp: '2025-01-15 14:28:08', endpoint: '/api/v1/transfers', method: 'GET', status: 200, key: 'ak_test_***4321' }
                ].map((log, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded text-sm">
                    <span className="text-gray-300">{log.timestamp}</span>
                    <span className="text-blue-400">{log.method}</span>
                    <span className="text-white">{log.endpoint}</span>
                    <Badge variant={log.status === 200 || log.status === 201 ? 'default' : 'destructive'}>
                      {log.status}
                    </Badge>
                    <span className="text-gray-400">{log.key}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="docs" className="space-y-4">
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Database className="w-5 h-5 mr-2" />
                API Documentation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-2">Authentication</h3>
                <p className="text-gray-300 mb-2">Include your API key in the Authorization header:</p>
                <code className="block p-2 bg-gray-700 rounded text-green-400 text-sm">
                  Authorization: Bearer YOUR_API_KEY
                </code>
              </div>
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-2">Base URL</h3>
                <code className="block p-2 bg-gray-700 rounded text-blue-400 text-sm">
                  https://api.alaziexpress.com/v1/
                </code>
              </div>
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-2">Webhook Example</h3>
                <pre className="text-xs text-gray-300 bg-gray-700 p-3 rounded overflow-x-auto">
{`POST /webhook HTTP/1.1
Content-Type: application/json
Stripe-Signature: t=1234567890,v1=...

{
  "id": "evt_1234567890",
  "object": "event",
  "type": "payment_intent.succeeded",
  "data": {
    "object": {
      "id": "pi_1234567890",
      "amount": 2000,
      "currency": "usd"
    }
  }
}`}
                </pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default APIManagementSystem;