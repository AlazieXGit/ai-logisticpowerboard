import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { CheckCircle, XCircle, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

interface DocumentReviewModalProps {
  document: any;
  onClose: () => void;
}

export function DocumentReviewModal({ document, onClose }: DocumentReviewModalProps) {
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const handleApprove = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'approve_document',
          data: {
            documentId: document.id,
            accountId: document.account_id
          },
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });

      if (error) throw error;
      toast.success('Document approved');
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    if (!reason.trim()) {
      toast.error('Please provide a reason for rejection');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('admin-approval-operations', {
        body: {
          action: 'reject_document',
          data: {
            documentId: document.id,
            accountId: document.account_id,
            reason
          },
          adminId: 'admin-user-id',
          adminEmail: 'admin@aiexpress.com'
        }
      });

      if (error) throw error;
      toast.success('Document rejected');
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Review Document</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">File Name</p>
              <p className="font-semibold">{document.file_name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Document Type</p>
              <Badge>{document.document_type}</Badge>
            </div>
            <div>
              <p className="text-sm text-gray-500">Account</p>
              <p className="font-semibold">{document.stripe_connect_accounts?.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Uploaded</p>
              <p className="text-sm">{new Date(document.uploaded_at).toLocaleString()}</p>
            </div>
          </div>

          <div className="p-4 bg-gray-50 rounded-lg">
            <Button
              variant="outline"
              className="w-full"
              onClick={() => window.open(document.file_url, '_blank')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              View Document
            </Button>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Rejection Reason (if applicable)</label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Provide reason if rejecting..."
              rows={3}
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleApprove}
              disabled={loading}
              className="flex-1 bg-green-600"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Approve Document
            </Button>
            <Button
              onClick={handleReject}
              disabled={loading}
              variant="destructive"
              className="flex-1"
            >
              <XCircle className="w-4 h-4 mr-2" />
              Reject Document
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}