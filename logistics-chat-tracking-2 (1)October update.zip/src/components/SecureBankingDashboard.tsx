import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Building2, CreditCard, Shield, TrendingUp, Lock, Copy } from 'lucide-react';
import BankingEmailProfile from './BankingEmailProfile';
import AIBankingAssistant from './AIBankingAssistant';
import EnhancedUnifiedBankingSystem from './EnhancedUnifiedBankingSystem';
import { useToast } from '@/hooks/use-toast';

interface SecureBankingDashboardProps {
  onLogout: () => void;
  hideHeader?: boolean;
}

const SecureBankingDashboard: React.FC<SecureBankingDashboardProps> = ({ onLogout, hideHeader = false }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const { toast } = useToast();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Hard Copy Secured', description: 'Banking information copied and secured' });
  };

  return (
    <div className={`${!hideHeader ? 'min-h-screen' : ''} bg-gradient-to-br from-emerald-900 via-gray-900 to-black`}>
      {!hideHeader && (
        <div className="bg-emerald-800/20 border-b border-emerald-500/30 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 text-emerald-400" />
              <div>
                <h1 className="text-2xl font-bold text-emerald-400">ALAZIEL BANKING SYSTEM</h1>
                <p className="text-gray-300 text-sm">Secure Financial Operations Platform - Hard Copy Secured</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-emerald-600 text-white animate-pulse">
                <Building2 className="h-3 w-3 mr-1" />
                ALAZIEL BANKING ACTIVE
              </Badge>
              <Badge className="bg-red-600 text-white animate-pulse">
                <Lock className="h-3 w-3 mr-1" />
                HARD COPY SECURED
              </Badge>
            </div>
          </div>
        </div>
      )}

      <div className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800 border border-emerald-500/30">
            <TabsTrigger value="overview" className="text-emerald-300 data-[state=active]:bg-emerald-600">
              <TrendingUp className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="unified" className="text-emerald-300 data-[state=active]:bg-emerald-600">
              <Building2 className="h-4 w-4 mr-2" />
              Alaziel Unified
            </TabsTrigger>
            <TabsTrigger value="profiles" className="text-emerald-300 data-[state=active]:bg-emerald-600">
              <CreditCard className="h-4 w-4 mr-2" />
              Profiles
            </TabsTrigger>
            <TabsTrigger value="ai" className="text-emerald-300 data-[state=active]:bg-emerald-600">
              🧠 Alaziel AI
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Daily Volume</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">$2.8M</div>
                  <p className="text-emerald-400">+18% via Alaziel Banking</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">1,389</div>
                  <p className="text-emerald-400">+12% Alaziel processed</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Total Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-emerald-400">$9.99M</div>
                  <p className="text-emerald-400">Alaziel Banking Total</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400">AI Efficiency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-emerald-400">99.9%</div>
                  <p className="text-emerald-400">Alaziel AI Performance</p>
                </CardContent>
              </Card>
            </div>
            <Card className="bg-gray-800 border-emerald-500/30 mt-6">
              <CardHeader>
                <CardTitle className="text-emerald-400 flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Banking Provider Update Status - Hard Copy Secured
                  <Lock className="h-4 w-4 text-red-400" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Badge className="bg-red-600 text-white p-3 text-lg">
                    🔒 HARD COPY SECURED - Successfully Updated to ALAZIEL BANKING
                  </Badge>
                  <div className="grid grid-cols-3 gap-4 mt-4">
                    <Button 
                      variant="ghost" 
                      className="bg-emerald-600 p-2 text-white hover:bg-emerald-700"
                      onClick={() => copyToClipboard('5573-9012-4567-8901')}
                    >
                      Main: 5573-9012-4567-8901 <Copy className="h-3 w-3 ml-1" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      className="bg-blue-600 p-2 text-white hover:bg-blue-700"
                      onClick={() => copyToClipboard('5573-9012-4567-8902')}
                    >
                      Escrow: 5573-9012-4567-8902 <Copy className="h-3 w-3 ml-1" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      className="bg-purple-600 p-2 text-white hover:bg-purple-700"
                      onClick={() => copyToClipboard('5573-9012-4567-8903')}
                    >
                      Trust: 5573-9012-4567-8903 <Copy className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                  <div className="flex justify-center mt-4">
                    <Button 
                      variant="ghost" 
                      className="bg-red-600 p-3 text-white hover:bg-red-700"
                      onClick={() => copyToClipboard('031176110')}
                    >
                      Routing Number: 031176110 <Copy className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                  <p className="text-gray-300 text-sm mt-3">
                    🔒 HARD COPY SECURED: All platform components updated to Alaziel Banking accounts. 
                    Routing: 031176110 | SWIFT Codes: ALAZUS33 series | All account information secured with hard copy backup.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="unified" className="mt-6">
            <EnhancedUnifiedBankingSystem />
          </TabsContent>

          <TabsContent value="profiles" className="mt-6">
            <BankingEmailProfile />
          </TabsContent>

          <TabsContent value="ai" className="mt-6">
            <AIBankingAssistant />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SecureBankingDashboard;