import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, Car, Truck, Download, Mail, Play, Pause, Square, Bot, CreditCard } from 'lucide-react';

const AIAutomotiveRoboticsSystem: React.FC = () => {
  const [purchaseStatus, setPurchaseStatus] = useState('pending');
  const [vendorRegistered, setVendorRegistered] = useState(false);
  const [paymentCompleted, setPaymentCompleted] = useState(false);
  const [creditRepairStatus, setCreditRepairStatus] = useState({
    client1: 'stopped',
    client2: 'stopped',
    client3: 'stopped'
  });

  const vehicleConfig = {
    model: "2025 Toyota Land Cruiser",
    basePrice: "$61,470",
    totalPrice: "$76,653",
    exterior: "Ice Cap",
    interior: "Black Leather",
    engine: "2.4L 4-Cyl. i-FORCE MAX Hybrid Engine",
    drivetrain: "Full-time 4-Wheel Drive",
    transmission: "8-Speed ECT-i",
    deliveryFee: "$1,450",
    configUrl: "https://www.toyota.com/configurator/build/step/summary/year/2025/series/landcruiser/model/6167/exteriorcolor/0040/interiorcolor/LB20/packages/FE-AA-BG-PP-TL/accessories/CB1000-CN1000-CY2000-DC2000-DS1000-EK1000-LS1000-MT2000-SK1000-TB5000-TB5800-XY9000/?bap_guid=0a14c753-1e3b-4431-974f-6a0c95fc36ef"
  };

  const handleVendorRegistration = () => {
    setVendorRegistered(true);
  };

  const handleVehiclePurchase = () => {
    setPurchaseStatus('processing');
    setPaymentCompleted(true);
    setTimeout(() => {
      setPurchaseStatus('completed');
    }, 3000);
  };

  const handleCreditRepairControl = (client: string, action: string) => {
    setCreditRepairStatus(prev => ({ ...prev, [client]: action }));
  };

  return (
    <div className="space-y-6">
      <Alert className="border-red-500 bg-red-900/20">
        <AlertDescription className="text-red-300">
          🔒 RESTRICTED ACCESS: Super Admin Alucius Alford Only
          <br />📍 Delivery Address: 2408 Yanceyville St. Greensboro N.C. 27405
          <br />📱 Dealership Updates: Text 336-458-8449
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Vehicle Purchase Section */}
        <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Car className="h-5 w-5" />
              AI Automotive Acquisition System
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!vendorRegistered ? (
              <div className="space-y-3">
                <h3 className="text-white font-semibold">Vendor Registration Required</h3>
                <p className="text-sm text-gray-300">
                  Register Alazie LLC Platform as vendor account with Toyota of Greensboro
                </p>
                <Button onClick={handleVendorRegistration} className="w-full bg-green-600 hover:bg-green-700">
                  Register Alazie LLC as Toyota Vendor
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <Badge className="bg-green-600 text-white">
                  ✓ Alazie LLC Registered as Toyota Vendor
                </Badge>
                
                <div className="bg-black/30 p-4 rounded-lg">
                  <h3 className="text-white font-semibold mb-2">{vehicleConfig.model}</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-gray-300">Exterior: <span className="text-white">{vehicleConfig.exterior}</span></div>
                    <div className="text-gray-300">Interior: <span className="text-white">{vehicleConfig.interior}</span></div>
                    <div className="text-gray-300">Engine: <span className="text-white">{vehicleConfig.engine}</span></div>
                    <div className="text-gray-300">Drivetrain: <span className="text-white">{vehicleConfig.drivetrain}</span></div>
                  </div>
                  <div className="mt-3 text-xl font-bold text-green-400">
                    Total: {vehicleConfig.totalPrice}
                  </div>
                </div>

                <div className="space-y-2">
                  <Button 
                    onClick={handleVehiclePurchase}
                    disabled={purchaseStatus === 'processing' || purchaseStatus === 'completed'}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    {purchaseStatus === 'processing' ? 'Processing Payment...' : 
                     purchaseStatus === 'completed' ? 'Purchase Completed' : 
                     'Pay $76,653 & Schedule Delivery'}
                  </Button>
                  
                  <Button variant="outline" className="w-full text-white border-white hover:bg-white hover:text-black">
                    <Truck className="h-4 w-4 mr-2" />
                    Select On-Site Model for Pickup
                  </Button>
                </div>

                {paymentCompleted && (
                  <Alert className="bg-green-900/50 border-green-500">
                    <CheckCircle className="h-4 w-4 text-green-400" />
                    <AlertDescription className="text-green-300">
                      <strong>Payment Completed: $76,653</strong>
                      <br />Documents emailed to: alaziellc.innovation@gmail.com
                      <br />Dealership Contact: 336-458-8449 for delivery updates
                      <div className="flex gap-2 mt-2">
                        <Button size="sm" variant="outline" className="text-green-300 border-green-300">
                          <Download className="h-4 w-4 mr-1" />
                          Download Docs
                        </Button>
                        <Button size="sm" variant="outline" className="text-green-300 border-green-300">
                          <Mail className="h-4 w-4 mr-1" />
                          View Email
                        </Button>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* AI Robotics Dealers */}
        <Card className="bg-gradient-to-r from-orange-900 to-red-900 border-orange-500">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Bot className="h-5 w-5" />
              AI Robotics Dealers Collection
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Tabs defaultValue="toyota" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-black/30">
                <TabsTrigger value="toyota" className="text-white data-[state=active]:bg-blue-600">Toyota</TabsTrigger>
                <TabsTrigger value="robotics" className="text-white data-[state=active]:bg-blue-600">Robotics</TabsTrigger>
              </TabsList>
              
              <TabsContent value="toyota" className="space-y-3">
                <div className="bg-black/30 p-3 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-white font-medium">2025 Land Cruiser</span>
                      <div className="text-sm text-gray-300">Configured & Ready</div>
                    </div>
                    <Badge className="bg-green-600">{vehicleConfig.totalPrice}</Badge>
                  </div>
                  <Button 
                    className="mt-2 w-full bg-blue-600 hover:bg-blue-700" 
                    size="sm"
                    disabled={purchaseStatus === 'completed'}
                    onClick={() => window.open(vehicleConfig.configUrl, '_blank')}
                  >
                    {purchaseStatus === 'completed' ? 'Purchased' : 'View Configuration'}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="robotics" className="space-y-3">
                <div className="bg-black/30 p-3 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-white font-medium">Tesla Bot</span>
                      <div className="text-sm text-gray-300">Humanoid Robot</div>
                    </div>
                    <Badge className="bg-green-600">$125K</Badge>
                  </div>
                </div>
                <div className="bg-black/30 p-3 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-white font-medium">Boston Dynamics</span>
                      <div className="text-sm text-gray-300">Spot Robot</div>
                    </div>
                    <Badge className="bg-green-600">$95K</Badge>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Credit Repair Controls */}
      <Card className="bg-gray-800/30 border-gray-600">
        <CardHeader>
          <CardTitle className="text-white">Credit Repair Control Center - 800x Optimization & 200x Assurance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {['client1', 'client2', 'client3'].map((client, index) => (
              <div key={client} className="p-4 bg-black/30 rounded-lg">
                <div className="flex justify-between items-center mb-3">
                  <div>
                    <h4 className="text-white font-semibold">Client {index + 1}</h4>
                    <div className="text-sm text-gray-300">
                      {index === 0 ? '800x Completion' : '200x Assurance'}
                    </div>
                  </div>
                  <Badge className={
                    creditRepairStatus[client] === 'running' ? 'bg-green-600' :
                    creditRepairStatus[client] === 'paused' ? 'bg-yellow-600' : 'bg-red-600'
                  }>
                    {creditRepairStatus[client].toUpperCase()}
                  </Badge>
                </div>
                <div className="flex gap-1">
                  <Button 
                    size="sm" 
                    onClick={() => handleCreditRepairControl(client, 'running')}
                    className="bg-green-600 hover:bg-green-700 flex-1"
                  >
                    <Play className="h-3 w-3" />
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => handleCreditRepairControl(client, 'paused')}
                    className="bg-yellow-600 hover:bg-yellow-700 flex-1"
                  >
                    <Pause className="h-3 w-3" />
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => handleCreditRepairControl(client, 'stopped')}
                    className="bg-red-600 hover:bg-red-700 flex-1"
                  >
                    <Square className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AIAutomotiveRoboticsSystem;