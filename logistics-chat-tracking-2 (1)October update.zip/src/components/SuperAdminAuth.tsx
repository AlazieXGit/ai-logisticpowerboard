import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, Eye, EyeOff, Mail } from 'lucide-react';

interface SuperAdminAuthProps {
  onAuthenticated: (isAdmin: boolean) => void;
}

const SuperAdminAuth: React.FC<SuperAdminAuthProps> = ({ onAuthenticated }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);

  // MASTER Super Admin credentials - ONLY LOGIN SOURCE
  const SUPER_ADMIN_EMAIL = 'alaziellc.innovation@gmail.com';
  const SUPER_ADMIN_PASSWORD = 'gotchupin1976';
  const SUPER_ADMIN_PIN = '1976';
  const handleLogin = async () => {
    setLoading(true);
    setError('');
    
    // Check for suspended admin_user account
    if (email === 'admin_user' || email === 'admin@company.com') {
      setError('⚠️ ACCOUNT SUSPENDED - admin_user access denied');
      setLoading(false);
      return;
    }
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (email === SUPER_ADMIN_EMAIL && password === SUPER_ADMIN_PASSWORD && pin === SUPER_ADMIN_PIN) {
      onAuthenticated(true);
    } else {
      setError('Access Denied - Only alaziellc.innovation@gmail.com authorized');
      onAuthenticated(false);
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-gray-900 to-black flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-black/80 border-red-500 shadow-2xl">
        <CardHeader className="text-center">
          <div className="flex justify-center items-center gap-2 mb-4">
            <Shield className="h-16 w-16 text-red-500" />
          </div>
          <CardTitle className="text-2xl font-bold text-red-400">
            🔒 SUPER ADMIN ONLY
          </CardTitle>
          <p className="text-gray-400">Controlled by Alucius Alford</p>
          <div className="text-xs text-red-300 mt-2">
            ⚠️ admin_user account SUSPENDED
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-red-300">
              Super Admin Email
            </Label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-4 w-4 text-red-400" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 bg-gray-900 border-red-500 text-white"
                placeholder="alaziellc.innovation@gmail.com"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password" className="text-red-300">
              Password
            </Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-red-400" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-10 bg-gray-900 border-red-500 text-white"
                placeholder="Enter password"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-2 top-2 h-6 w-6 p-0 text-red-400"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="pin" className="text-red-300">
              Security PIN #1976
            </Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-red-400" />
              <Input
                id="pin"
                type={showPin ? "text" : "password"}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                className="pl-10 pr-10 bg-gray-900 border-red-500 text-white"
                placeholder="Enter PIN #1976"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-2 top-2 h-6 w-6 p-0 text-red-400"
                onClick={() => setShowPin(!showPin)}
              >
                {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          
          {error && (
            <Alert className="border-red-500 bg-red-900/20">
              <AlertDescription className="text-red-300">
                {error}
              </AlertDescription>
            </Alert>
          )}
          
          <Button 
            onClick={handleLogin}
            disabled={loading || !email || !password || !pin}
            className="w-full bg-red-600 hover:bg-red-700 text-white"
          >
            {loading ? 'Verifying...' : 'Access Platform'}
          </Button>
          
          <div className="text-center text-xs text-gray-500">
            🚫 Single login route - alaziellc.innovation@gmail.com only
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export { SuperAdminAuth };
export default SuperAdminAuth;