import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Users, Shield, CheckCircle, Clock, Truck, Building } from 'lucide-react';

interface OnboardingStats {
  totalProcessed: number;
  approved: number;
  pending: number;
  rejected: number;
  drivers: number;
  carriers: number;
  shippers: number;
  brokers: number;
}

const OnboardingSystem = () => {
  const [stats, setStats] = useState<OnboardingStats>({
    totalProcessed: 6847,
    approved: 6234,
    pending: 456,
    rejected: 157,
    drivers: 4523,
    carriers: 1234,
    shippers: 567,
    brokers: 523
  });
  
  const [isProcessing, setIsProcessing] = useState(true);
  const [currentBatch, setCurrentBatch] = useState(0);

  useEffect(() => {
    if (isProcessing) {
      const interval = setInterval(() => {
        setStats(prev => ({
          ...prev,
          totalProcessed: prev.totalProcessed + Math.floor(Math.random() * 3) + 1,
          approved: prev.approved + Math.floor(Math.random() * 2) + 1,
          pending: Math.max(0, prev.pending - Math.floor(Math.random() * 2)),
          drivers: prev.drivers + Math.floor(Math.random() * 2)
        }));
        setCurrentBatch(prev => prev + 1);
      }, 2000);
      
      return () => clearInterval(interval);
    }
  }, [isProcessing]);

  const approvalRate = ((stats.approved / stats.totalProcessed) * 100).toFixed(1);
  const progress = Math.min((stats.totalProcessed / 7000) * 100, 100);

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Total Processed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.totalProcessed.toLocaleString()}</div>
            <Progress value={progress} className="mt-2" />
            <p className="text-xs text-gray-400 mt-1">{progress.toFixed(1)}% of 7,000 target</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              Approved
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{stats.approved.toLocaleString()}</div>
            <p className="text-xs text-gray-400">{approvalRate}% approval rate</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Pending
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">{stats.pending}</div>
            <p className="text-xs text-gray-400">In review queue</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Shield className="h-4 w-4 mr-2" />
              Security Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-400">100%</div>
            <p className="text-xs text-gray-400">Vetting accuracy</p>
          </CardContent>
        </Card>
      </div>

      {/* Category Breakdown */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400">Onboarding Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <Truck className="h-8 w-8 text-blue-400 mx-auto mb-2" />
              <div className="text-xl font-bold text-white">{stats.drivers.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Drivers</div>
            </div>
            
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <Building className="h-8 w-8 text-green-400 mx-auto mb-2" />
              <div className="text-xl font-bold text-white">{stats.carriers.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Carriers</div>
            </div>
            
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <Users className="h-8 w-8 text-purple-400 mx-auto mb-2" />
              <div className="text-xl font-bold text-white">{stats.shippers.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Shippers</div>
            </div>
            
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <Shield className="h-8 w-8 text-orange-400 mx-auto mb-2" />
              <div className="text-xl font-bold text-white">{stats.brokers.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Brokers</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Processing Status */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center justify-between">
            <span>AI Processing Status</span>
            <Badge className={isProcessing ? 'bg-green-600' : 'bg-gray-600'}>
              {isProcessing ? 'ACTIVE' : 'PAUSED'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Current Batch:</span>
              <span className="text-white font-bold">#{currentBatch}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Processing Speed:</span>
              <span className="text-emerald-400">~3 applications/sec</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Legal Compliance:</span>
              <span className="text-green-400">✓ Alazie LLC D.B.A. Granted</span>
            </div>
            
            <Button 
              onClick={() => setIsProcessing(!isProcessing)}
              className={`w-full ${isProcessing ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
            >
              {isProcessing ? 'Pause Processing' : 'Resume Processing'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OnboardingSystem;