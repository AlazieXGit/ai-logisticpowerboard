import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { DollarSign, Send, Copy, CheckCircle } from 'lucide-react';

export const FundRequestSystem: React.FC = () => {
  const [requestData, setRequestData] = useState({
    amount: '',
    purpose: '',
    urgency: 'normal',
    accountType: 'operating'
  });

  const [requestSubmitted, setRequestSubmitted] = useState(false);
  const [requestId, setRequestId] = useState('');

  const handleSubmitRequest = () => {
    const newRequestId = `FR-${Date.now()}`;
    setRequestId(newRequestId);
    setRequestSubmitted(true);
  };

  const directBankingLink = "https://kekmpxfmtsyhgwenakxw.supabase.co/functions/v1/banking-operations";

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  if (requestSubmitted) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-green-600">
            <CheckCircle className="h-6 w-6" />
            Fund Request Submitted
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <Badge className="bg-green-500 text-white mb-4">Request ID: {requestId}</Badge>
            <p className="text-gray-600 mb-6">Your fund request has been submitted for processing.</p>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <Label className="font-medium">Direct Banking System Link:</Label>
            <div className="flex items-center gap-2 mt-2">
              <Input value={directBankingLink} readOnly className="text-sm" />
              <Button 
                size="sm" 
                onClick={() => copyToClipboard(directBankingLink)}
                className="flex items-center gap-1"
              >
                <Copy className="h-4 w-4" />
                Copy
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Amount:</span> ${requestData.amount}
            </div>
            <div>
              <span className="font-medium">Account:</span> {requestData.accountType}
            </div>
            <div>
              <span className="font-medium">Urgency:</span> {requestData.urgency}
            </div>
            <div>
              <span className="font-medium">Status:</span> Processing
            </div>
          </div>

          <Button 
            onClick={() => setRequestSubmitted(false)} 
            variant="outline" 
            className="w-full"
          >
            Submit Another Request
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-6 w-6" />
          Fund Request System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="amount">Request Amount ($)</Label>
          <Input
            id="amount"
            type="number"
            value={requestData.amount}
            onChange={(e) => setRequestData({...requestData, amount: e.target.value})}
            placeholder="Enter amount"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="purpose">Purpose</Label>
          <Textarea
            id="purpose"
            value={requestData.purpose}
            onChange={(e) => setRequestData({...requestData, purpose: e.target.value})}
            placeholder="Describe the purpose of this fund request"
            rows={3}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="urgency">Urgency Level</Label>
            <select
              id="urgency"
              value={requestData.urgency}
              onChange={(e) => setRequestData({...requestData, urgency: e.target.value})}
              className="w-full p-2 border rounded-md"
            >
              <option value="low">Low Priority</option>
              <option value="normal">Normal</option>
              <option value="high">High Priority</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="accountType">Account Type</Label>
            <select
              id="accountType"
              value={requestData.accountType}
              onChange={(e) => setRequestData({...requestData, accountType: e.target.value})}
              className="w-full p-2 border rounded-md"
            >
              <option value="operating">Operating Account</option>
              <option value="reserve">Reserve Fund</option>
              <option value="escrow">Escrow Account</option>
              <option value="trust">Trust Account</option>
            </select>
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <Label className="font-medium text-blue-800">Direct Banking Access:</Label>
          <p className="text-sm text-blue-600 mt-1">
            Use the link below to access the banking system directly for immediate processing:
          </p>
          <div className="flex items-center gap-2 mt-2">
            <Input 
              value={directBankingLink} 
              readOnly 
              className="text-xs bg-white"
            />
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => copyToClipboard(directBankingLink)}
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Button 
          onClick={handleSubmitRequest}
          className="w-full flex items-center gap-2"
          disabled={!requestData.amount || !requestData.purpose}
        >
          <Send className="h-4 w-4" />
          Submit Fund Request
        </Button>
      </CardContent>
    </Card>
  );
};

export default FundRequestSystem;