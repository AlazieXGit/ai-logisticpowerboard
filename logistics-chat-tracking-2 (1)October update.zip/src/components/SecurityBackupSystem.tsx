import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Shield, Database, Scan, Lock, AlertTriangle, CheckCircle } from 'lucide-react';

interface SecurityStats {
  filesScanned: number;
  threatsDetected: number;
  backupsCompleted: number;
  systemHealth: number;
  lastScan: Date;
  virusDefinitions: string;
}

const SecurityBackupSystem = () => {
  const [stats, setStats] = useState<SecurityStats>({
    filesScanned: 1247893,
    threatsDetected: 0,
    backupsCompleted: 5,
    systemHealth: 100,
    lastScan: new Date(),
    virusDefinitions: '2024.01.15.001'
  });
  
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [backupProgress, setBackupProgress] = useState(0);

  useEffect(() => {
    // Simulate continuous background scanning
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        filesScanned: prev.filesScanned + Math.floor(Math.random() * 100) + 50,
        lastScan: new Date()
      }));
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const startFullScan = () => {
    setIsScanning(true);
    setScanProgress(0);
    
    const scanInterval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(scanInterval);
          setIsScanning(false);
          setStats(prevStats => ({
            ...prevStats,
            filesScanned: prevStats.filesScanned + 50000,
            lastScan: new Date()
          }));
          return 100;
        }
        return prev + 2;
      });
    }, 100);
  };

  const startBackup = () => {
    setBackupProgress(0);
    
    const backupInterval = setInterval(() => {
      setBackupProgress(prev => {
        if (prev >= 100) {
          clearInterval(backupInterval);
          setStats(prevStats => ({
            ...prevStats,
            backupsCompleted: prevStats.backupsCompleted + 1
          }));
          return 100;
        }
        return prev + 1;
      });
    }, 50);
  };

  return (
    <div className="space-y-6">
      {/* Security Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-red-400 text-sm flex items-center">
              <Shield className="h-4 w-4 mr-2" />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{stats.systemHealth}%</div>
            <Progress value={stats.systemHealth} className="mt-2" />
            <p className="text-xs text-gray-400 mt-1">All systems secure</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-red-400 text-sm flex items-center">
              <Scan className="h-4 w-4 mr-2" />
              Files Scanned
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.filesScanned.toLocaleString()}</div>
            <p className="text-xs text-gray-400">Real-time monitoring</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-red-400 text-sm flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2" />
              Threats Detected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{stats.threatsDetected}</div>
            <p className="text-xs text-gray-400">Zero threats found</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-red-400 text-sm flex items-center">
              <Database className="h-4 w-4 mr-2" />
              Backups
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.backupsCompleted}</div>
            <p className="text-xs text-gray-400">Completed today</p>
          </CardContent>
        </Card>
      </div>

      {/* Security Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center">
              <Scan className="h-5 w-5 mr-2" />
              Virus Scanner
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Last Scan:</span>
              <span className="text-white">{stats.lastScan.toLocaleTimeString()}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Definitions:</span>
              <span className="text-emerald-400">{stats.virusDefinitions}</span>
            </div>
            
            {isScanning && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Scanning...</span>
                  <span className="text-white">{scanProgress}%</span>
                </div>
                <Progress value={scanProgress} className="h-2" />
              </div>
            )}
            
            <Button 
              onClick={startFullScan}
              disabled={isScanning}
              className="w-full bg-red-600 hover:bg-red-700"
            >
              {isScanning ? 'Scanning...' : 'Start Full Scan'}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center">
              <Database className="h-5 w-5 mr-2" />
              Backup System
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-5 gap-2">
              {[1, 2, 3, 4, 5].map((backup) => (
                <div key={backup} className="text-center">
                  <div className={`w-8 h-8 rounded-full mx-auto mb-1 flex items-center justify-center ${
                    backup <= stats.backupsCompleted ? 'bg-green-600' : 'bg-gray-600'
                  }`}>
                    {backup <= stats.backupsCompleted ? (
                      <CheckCircle className="h-4 w-4" />
                    ) : (
                      <Lock className="h-4 w-4" />
                    )}
                  </div>
                  <div className="text-xs text-gray-400">B{backup}</div>
                </div>
              ))}
            </div>
            
            {backupProgress > 0 && backupProgress < 100 && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Backing up...</span>
                  <span className="text-white">{backupProgress}%</span>
                </div>
                <Progress value={backupProgress} className="h-2" />
              </div>
            )}
            
            <Button 
              onClick={startBackup}
              disabled={backupProgress > 0 && backupProgress < 100}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              Create Backup
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Security Status */}
      <Card className="bg-gray-800 border-red-500/30">
        <CardHeader>
          <CardTitle className="text-red-400">Security Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-3">
              <Badge className="bg-green-600">SECURE</Badge>
              <span className="text-gray-300">Real-time Protection</span>
            </div>
            
            <div className="flex items-center gap-3">
              <Badge className="bg-green-600">ACTIVE</Badge>
              <span className="text-gray-300">Anonymous Monitoring</span>
            </div>
            
            <div className="flex items-center gap-3">
              <Badge className="bg-blue-600">ADMIN ONLY</Badge>
              <span className="text-gray-300">Super Admin Access</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityBackupSystem;