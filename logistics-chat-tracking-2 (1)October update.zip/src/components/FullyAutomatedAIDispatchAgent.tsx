import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Truck, Bot, DollarSign, TrendingUp, Zap, Target } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface DispatchMetrics {
  totalLoads: number;
  automatedBookings: number;
  revenueGenerated: number;
  efficiency: number;
}

export const FullyAutomatedAIDispatchAgent: React.FC = () => {
  const [metrics, setMetrics] = useState<DispatchMetrics>({
    totalLoads: 0,
    automatedBookings: 0,
    revenueGenerated: 0,
    efficiency: 0
  });
  const [isActive, setIsActive] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(async () => {
        try {
          const { data } = await supabase.functions.invoke('ai-dispatch-optimizer', {
            body: { action: 'get_metrics' }
          });
          
          if (data) {
            setMetrics({
              totalLoads: data.totalLoads,
              automatedBookings: data.automatedBookings,
              revenueGenerated: data.revenueGenerated,
              efficiency: data.efficiency
            });
          }
        } catch (error) {
          console.error('Error fetching metrics:', error);
        }
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isActive]);

  const toggleAgent = async () => {
    setLoading(true);
    try {
      if (!isActive) {
        const { data } = await supabase.functions.invoke('ai-dispatch-optimizer', {
          body: { action: 'optimize_dispatch' }
        });
        console.log('AI Agent activated:', data);
      }
      setIsActive(!isActive);
    } catch (error) {
      console.error('Error toggling agent:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAutoBook = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('ai-dispatch-optimizer', {
        body: { action: 'auto_book' }
      });
      console.log('Auto booking result:', data);
    } catch (error) {
      console.error('Error auto booking:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-6 w-6 text-blue-600" />
            Fully Automated AI Dispatch Agent 2029
            <Badge variant={isActive ? "default" : "secondary"}>
              {isActive ? "ACTIVE" : "STANDBY"}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Truck className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Total Loads</p>
                    <p className="text-2xl font-bold">{metrics.totalLoads}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-yellow-600" />
                  <div>
                    <p className="text-sm text-gray-600">Auto Bookings</p>
                    <p className="text-2xl font-bold">{metrics.automatedBookings}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Revenue</p>
                    <p className="text-2xl font-bold">${metrics.revenueGenerated.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Efficiency</p>
                    <p className="text-2xl font-bold">{metrics.efficiency}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex gap-4 mb-6">
            <Button 
              onClick={toggleAgent}
              variant={isActive ? "destructive" : "default"}
              size="lg"
              disabled={loading}
            >
              {loading ? "Processing..." : isActive ? "Deactivate Agent" : "Activate AI Agent"}
            </Button>
            <Button onClick={handleAutoBook} variant="outline" disabled={!isActive || loading}>
              Auto Book Load
            </Button>
            <Button variant="outline">View Analytics</Button>
          </div>

          <Progress value={metrics.efficiency} className="mb-4" />
          <p className="text-sm text-gray-600">AI Optimization Level: {metrics.efficiency}%</p>
        </CardContent>
      </Card>
    </div>
  );
};