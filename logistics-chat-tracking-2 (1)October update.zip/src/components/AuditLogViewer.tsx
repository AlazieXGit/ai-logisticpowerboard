import { useState, useEffect } from 'react';
import { adminOperationsService } from '@/services/adminOperationsService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function AuditLogViewer() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ adminId: '', actionType: '' });

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const response = await adminOperationsService.getAuditLogs(
        100,
        filter.adminId || undefined,
        filter.actionType || undefined
      );
      setLogs(response.data || []);
    } catch (error) {
      console.error('Failed to fetch audit logs:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const getActionBadge = (actionType: string) => {
    const colors: Record<string, string> = {
      IP_BLOCK: 'bg-red-500',
      IP_UNBLOCK: 'bg-green-500',
      USER_SUSPEND: 'bg-orange-500',
      USER_UNSUSPEND: 'bg-blue-500',
      PAYMENT_EDIT: 'bg-purple-500'
    };
    return <Badge className={colors[actionType] || 'bg-gray-500'}>{actionType}</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Audit Log</CardTitle>
        <div className="flex gap-4 mt-4">
          <Input
            placeholder="Filter by Admin ID"
            value={filter.adminId}
            onChange={(e) => setFilter({ ...filter, adminId: e.target.value })}
          />
          <Select value={filter.actionType} onValueChange={(val) => setFilter({ ...filter, actionType: val })}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Action Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All</SelectItem>
              <SelectItem value="IP_BLOCK">IP Block</SelectItem>
              <SelectItem value="USER_SUSPEND">User Suspend</SelectItem>
              <SelectItem value="PAYMENT_EDIT">Payment Edit</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={fetchLogs}>Apply Filters</Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Admin</TableHead>
                <TableHead>Target</TableHead>
                <TableHead>Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell>{new Date(log.created_at).toLocaleString()}</TableCell>
                  <TableCell>{getActionBadge(log.action_type)}</TableCell>
                  <TableCell className="text-sm">{log.admin_email}</TableCell>
                  <TableCell className="text-sm">{log.target_id}</TableCell>
                  <TableCell className="text-xs">{JSON.stringify(log.details)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
