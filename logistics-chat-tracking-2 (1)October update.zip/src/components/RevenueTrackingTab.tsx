import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Download, Edit, Save, Plus, DollarSign } from 'lucide-react';

const RevenueTrackingTab = () => {
  const [revenueStreams, setRevenueStreams] = useState([
    {
      id: 1,
      name: 'Payment Processing Fees',
      category: 'Transaction Fees',
      monthlyRevenue: 45000,
      yearlyRevenue: 540000,
      growthRate: 12.5,
      description: 'Revenue from payment processing services',
      accounts: ['PNC Business', 'Wells Fargo Commercial'],
      feeStructure: '2.9% + $0.30 per transaction'
    },
    {
      id: 2,
      name: 'TMS Platform Subscriptions',
      category: 'Software Licensing',
      monthlyRevenue: 28000,
      yearlyRevenue: 336000,
      growthRate: 8.3,
      description: 'Monthly subscription fees from TMS users',
      accounts: ['Stripe Business', 'Square Business'],
      feeStructure: '$299/month per user'
    },
    {
      id: 3,
      name: 'Asset Management Fees',
      category: 'Investment Services',
      monthlyRevenue: 15000,
      yearlyRevenue: 180000,
      growthRate: 15.2,
      description: 'Fees from managing client assets and vehicles',
      accounts: ['Trust Account', 'Escrow Account'],
      feeStructure: '1.5% of managed assets annually'
    }
  ]);

  const [newRevenue, setNewRevenue] = useState({
    name: '',
    category: '',
    monthlyRevenue: '',
    description: '',
    feeStructure: ''
  });

  const [editingId, setEditingId] = useState(null);

  const totalMonthlyRevenue = revenueStreams.reduce((sum, stream) => sum + stream.monthlyRevenue, 0);
  const totalYearlyRevenue = revenueStreams.reduce((sum, stream) => sum + stream.yearlyRevenue, 0);

  const addRevenueStream = () => {
    if (newRevenue.name && newRevenue.category) {
      const revenue = {
        id: Date.now(),
        ...newRevenue,
        monthlyRevenue: parseFloat(newRevenue.monthlyRevenue) || 0,
        yearlyRevenue: (parseFloat(newRevenue.monthlyRevenue) || 0) * 12,
        growthRate: 0,
        accounts: ['New Account']
      };
      setRevenueStreams([...revenueStreams, revenue]);
      setNewRevenue({
        name: '', category: '', monthlyRevenue: '', description: '', feeStructure: ''
      });
    }
  };

  const downloadRevenueReport = () => {
    const reportData = revenueStreams.map(stream => 
      `${stream.name}: $${stream.monthlyRevenue}/month, ${stream.growthRate}% growth`
    ).join('\n');
    
    const element = document.createElement('a');
    element.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(
      `Revenue Tracking Report\n\nTotal Monthly: $${totalMonthlyRevenue.toLocaleString()}\nTotal Yearly: $${totalYearlyRevenue.toLocaleString()}\n\nRevenue Streams:\n${reportData}`
    );
    element.download = 'revenue_report.txt';
    element.click();
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-blue-900 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-green-300 flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Revenue Tracking Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-green-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-green-300 font-semibold">Monthly Revenue</span>
                <DollarSign className="h-4 w-4 text-green-400" />
              </div>
              <p className="text-2xl font-bold text-green-400">${totalMonthlyRevenue.toLocaleString()}</p>
            </div>
            <div className="bg-blue-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-blue-300 font-semibold">Yearly Revenue</span>
                <TrendingUp className="h-4 w-4 text-blue-400" />
              </div>
              <p className="text-2xl font-bold text-blue-400">${totalYearlyRevenue.toLocaleString()}</p>
            </div>
            <div className="bg-purple-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-purple-300 font-semibold">Revenue Streams</span>
              </div>
              <p className="text-2xl font-bold text-purple-400">{revenueStreams.length}</p>
            </div>
            <div className="bg-orange-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-orange-300 font-semibold">Avg Growth</span>
              </div>
              <p className="text-2xl font-bold text-orange-400">
                {(revenueStreams.reduce((sum, s) => sum + s.growthRate, 0) / revenueStreams.length).toFixed(1)}%
              </p>
            </div>
          </div>
          <div className="mt-4">
            <Button onClick={downloadRevenueReport} className="bg-green-600 hover:bg-green-700">
              <Download className="h-4 w-4 mr-2" />
              Download Revenue Report
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-green-300 flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Add New Revenue Stream
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              placeholder="Revenue Stream Name"
              value={newRevenue.name}
              onChange={(e) => setNewRevenue({...newRevenue, name: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Category"
              value={newRevenue.category}
              onChange={(e) => setNewRevenue({...newRevenue, category: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Monthly Revenue"
              type="number"
              value={newRevenue.monthlyRevenue}
              onChange={(e) => setNewRevenue({...newRevenue, monthlyRevenue: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Input
              placeholder="Fee Structure"
              value={newRevenue.feeStructure}
              onChange={(e) => setNewRevenue({...newRevenue, feeStructure: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
          </div>
          <div className="mt-4">
            <Textarea
              placeholder="Revenue Description"
              value={newRevenue.description}
              onChange={(e) => setNewRevenue({...newRevenue, description: e.target.value})}
              className="bg-gray-700 border-gray-600"
            />
            <Button onClick={addRevenueStream} className="mt-4 bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              Add Revenue Stream
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {revenueStreams.map((stream) => (
          <Card key={stream.id} className="bg-gray-800 border-green-500/30">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-green-300">{stream.name}</CardTitle>
                  <Badge className="mt-2 bg-blue-600">{stream.category}</Badge>
                </div>
                <Button
                  size="sm"
                  onClick={() => setEditingId(editingId === stream.id ? null : stream.id)}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-300">{stream.description}</p>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-sm">Monthly Revenue</p>
                  <p className="text-green-400 font-bold text-xl">${stream.monthlyRevenue.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Yearly Revenue</p>
                  <p className="text-blue-400 font-bold text-xl">${stream.yearlyRevenue.toLocaleString()}</p>
                </div>
              </div>

              <div>
                <p className="text-gray-400 text-sm">Growth Rate</p>
                <div className="flex items-center gap-2">
                  <p className="text-orange-400 font-bold">{stream.growthRate}%</p>
                  <Badge className={stream.growthRate > 10 ? 'bg-green-600' : 'bg-yellow-600'}>
                    {stream.growthRate > 10 ? 'High Growth' : 'Moderate Growth'}
                  </Badge>
                </div>
              </div>

              <div>
                <p className="text-gray-400 text-sm">Fee Structure</p>
                <p className="text-gray-300">{stream.feeStructure}</p>
              </div>

              <div>
                <p className="text-gray-400 text-sm">Associated Accounts</p>
                <div className="flex flex-wrap gap-2 mt-1">
                  {stream.accounts.map((account, index) => (
                    <Badge key={index} className="bg-gray-700 text-gray-300">
                      {account}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RevenueTrackingTab;