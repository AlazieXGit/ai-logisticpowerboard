import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, MapPin, Clock, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface LoginUser {
  id: string;
  email: string;
  location: string;
  ip_address: string;
  login_time: string;
  status: 'active' | 'idle' | 'offline';
  role: 'admin' | 'user' | 'super_admin';
  session_duration: string;
}

const LoginUsersDisplay: React.FC = () => {
  const [loginUsers, setLoginUsers] = useState<LoginUser[]>([
    {
      id: '1',
      email: 'alucius@alaziellc.com',
      location: 'Dallas, TX',
      ip_address: '192.168.1.1',
      login_time: '2024-01-15 09:30:00',
      status: 'active',
      role: 'super_admin',
      session_duration: '2h 15m'
    },
    {
      id: '2',
      email: 'admin@alaziellc.com',
      location: 'Houston, TX',
      ip_address: '192.168.1.5',
      login_time: '2024-01-15 08:45:00',
      status: 'active',
      role: 'admin',
      session_duration: '3h 0m'
    },
    {
      id: '3',
      email: 'banking@alaziellc.com',
      location: 'Austin, TX',
      ip_address: '192.168.1.10',
      login_time: '2024-01-15 10:15:00',
      status: 'idle',
      role: 'admin',
      session_duration: '1h 30m'
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-600';
      case 'idle': return 'bg-yellow-600';
      case 'offline': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'super_admin': return 'bg-purple-600';
      case 'admin': return 'bg-blue-600';
      case 'user': return 'bg-gray-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <Card className="bg-gray-900/50 border-gray-600">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Users className="h-5 w-5" />
          Active Login Users & Admin Locations
        </CardTitle>
        <Badge className="bg-green-600 w-fit">{loginUsers.length} Users Online</Badge>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {loginUsers.map((user) => (
            <div key={user.id} className="p-4 bg-gray-800/50 rounded-lg border border-gray-600">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
                  <span className="text-white font-medium">{user.email}</span>
                  <Badge className={getRoleColor(user.role)}>
                    {user.role.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
                <Badge className={getStatusColor(user.status)}>
                  {user.status.toUpperCase()}
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2 text-gray-300">
                  <MapPin className="h-4 w-4" />
                  <span>Location: {user.location}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <Shield className="h-4 w-4" />
                  <span>IP: {user.ip_address}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <Clock className="h-4 w-4" />
                  <span>Login: {user.login_time}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <Clock className="h-4 w-4" />
                  <span>Duration: {user.session_duration}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default LoginUsersDisplay;