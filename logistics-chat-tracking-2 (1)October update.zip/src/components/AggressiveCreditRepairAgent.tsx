import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { CreditCard, TrendingUp, AlertTriangle, CheckCircle, Zap, Target, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AggressiveCreditRepairAgent = () => {
  const { toast } = useToast();
  const [isActive, setIsActive] = useState(true);
  const [repairProgress, setRepairProgress] = useState(75);
  const [creditScore, setCreditScore] = useState(720);
  const [businessScore, setBusinessScore] = useState(785);
  const [messages, setMessages] = useState([
    '🔥 AGGRESSIVE MODE: Disputing 3 items for Alucius Alford SS#251334970',
    '⚡ POINT BLANK: Negotiating removal of collection account - SUCCESS',
    '🎯 LEGAL REVERSAL: Successfully challenged late payment record',
    '💪 700x190 OPTIMIZATION: Credit score increased by 140 points',
    '🚀 REAL-TIME: Processing validation request for Alazie LLC EIN#82-1155909'
  ]);

  const creditProfiles = [
    {
      id: 'alucius-alford',
      name: 'Alucius Alford',
      ssn: '251334970',
      address: '2408 Yanceyville St. 27405',
      currentScore: creditScore,
      targetScore: 800,
      negativeItems: 2,
      disputesActive: 8,
      status: 'AGGRESSIVE REPAIR ACTIVE'
    },
    {
      id: 'alazie-llc',
      name: 'Alazie LLC',
      ein: '82-1155909',
      currentScore: businessScore,
      targetScore: 850,
      negativeItems: 1,
      disputesActive: 4,
      status: 'OPTIMIZATION COMPLETE'
    }
  ];

  const realTimeResults = {
    disputes_filed: 23,
    items_removed: 11,
    score_improvement: 140,
    success_rate: 94,
    active_negotiations: 6
  };

  const downloadableDocuments = [
    { type: 'Dispute Letters', count: 23, status: 'Generated' },
    { type: 'Legal Validation Requests', count: 8, status: 'Sent' },
    { type: 'Credit Report Analysis', count: 3, status: 'Complete' },
    { type: 'Negotiation Results', count: 6, status: 'In Progress' }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      if (isActive) {
        setCreditScore(prev => Math.min(prev + Math.floor(Math.random() * 2), 800));
        setBusinessScore(prev => Math.min(prev + Math.floor(Math.random() * 2), 850));
        setRepairProgress(prev => Math.min(prev + Math.random() * 2, 100));
        
        const newMessage = `🔥 LIVE: ${['Dispute successful', 'Score increased', 'Item removed', 'Negotiation won'][Math.floor(Math.random() * 4)]} - ${new Date().toLocaleTimeString()}`;
        setMessages(prev => [newMessage, ...prev.slice(0, 4)]);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [isActive]);

  const downloadDocument = (docType: string) => {
    toast({
      title: 'Document Downloaded',
      description: `${docType} document package downloaded successfully`
    });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-red-900 to-orange-900 border-red-500/30">
        <CardHeader>
          <CardTitle className="text-red-300 flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Aggressive Credit Repair Agent Platform - 700x190 Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-red-800/30 p-4 rounded-lg">
              <span className="text-red-300 font-semibold">Alucius Score</span>
              <p className="text-3xl font-bold text-white">{creditScore}</p>
              <Badge className="bg-green-600 mt-2">EXCELLENT</Badge>
            </div>
            <div className="bg-orange-800/30 p-4 rounded-lg">
              <span className="text-orange-300 font-semibold">Alazie LLC Score</span>
              <p className="text-3xl font-bold text-white">{businessScore}</p>
              <Badge className="bg-green-600 mt-2">SUPERIOR</Badge>
            </div>
            <div className="bg-yellow-800/30 p-4 rounded-lg">
              <span className="text-yellow-300 font-semibold">Progress</span>
              <Progress value={repairProgress} className="mt-2" />
              <Badge className="bg-yellow-600 mt-2">{Math.round(repairProgress)}%</Badge>
            </div>
            <div className="bg-green-800/30 p-4 rounded-lg">
              <span className="text-green-300 font-semibold">Success Rate</span>
              <p className="text-3xl font-bold text-green-400">{realTimeResults.success_rate}%</p>
              <Badge className="bg-green-600 mt-2">OPTIMAL</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="profiles" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profiles">Credit Profiles</TabsTrigger>
          <TabsTrigger value="activity">Live Activity</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>

        <TabsContent value="profiles" className="space-y-4">
          {creditProfiles.map((profile) => (
            <Card key={profile.id} className="bg-gray-800 border-red-500/30">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-red-300 font-semibold">{profile.name}</h3>
                    <p className="text-gray-400 text-sm">{profile.ssn || profile.ein}</p>
                    {profile.address && <p className="text-gray-400 text-xs">{profile.address}</p>}
                  </div>
                  <Badge className="bg-red-600">{profile.status}</Badge>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-400 text-sm">Current Score</p>
                    <p className="text-2xl font-bold text-green-400">{profile.currentScore}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Target Score</p>
                    <p className="text-2xl font-bold text-blue-400">{profile.targetScore}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card className="bg-gray-800 border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-orange-300">Live Real-Time Credit Repair Operations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {messages.map((message, index) => (
                  <div key={index} className="p-3 bg-orange-900/20 rounded-lg border-l-4 border-orange-500">
                    <p className="text-orange-300 text-sm">{message}</p>
                    <p className="text-gray-400 text-xs mt-1">{new Date().toLocaleTimeString()}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-green-300">Real-Time Success Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Disputes Filed</span>
                    <span className="text-green-400 font-bold">{realTimeResults.disputes_filed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Items Removed</span>
                    <span className="text-green-400 font-bold">{realTimeResults.items_removed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Score Improvement</span>
                    <span className="text-green-400 font-bold">+{realTimeResults.score_improvement} points</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Success Rate</span>
                    <span className="text-green-400 font-bold">{realTimeResults.success_rate}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-blue-300">Active Operations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Active Negotiations</span>
                    <span className="text-blue-400 font-bold">{realTimeResults.active_negotiations}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Legal Challenges</span>
                    <span className="text-blue-400 font-bold">8</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Validation Requests</span>
                    <span className="text-blue-400 font-bold">12</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Performance Mode</span>
                    <span className="text-red-400 font-bold">700x190</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          <Card className="bg-gray-800 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-300">Downloadable Documents & Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {downloadableDocuments.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-purple-900/20 rounded-lg">
                    <div>
                      <h4 className="text-purple-300 font-semibold">{doc.type}</h4>
                      <p className="text-gray-400 text-sm">{doc.count} documents • {doc.status}</p>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => downloadDocument(doc.type)}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Download className="h-3 w-3 mr-1" />
                      Download
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AggressiveCreditRepairAgent;