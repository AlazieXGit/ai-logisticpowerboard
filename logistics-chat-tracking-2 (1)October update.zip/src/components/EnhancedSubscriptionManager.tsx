import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, CreditCard, TrendingUp, ExternalLink, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface SubscriptionTier {
  id: string;
  name: string;
  price: number;
  stripeLink: string;
  features: string[];
  aiBoost: string;
  color: string;
}

const subscriptionTiers: SubscriptionTier[] = [
  {
    id: 'basic',
    name: 'Basic Tier',
    price: 29,
    stripeLink: 'https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00',
    features: ['Load Board Access', 'Basic AI Matching', 'Email Support'],
    aiBoost: '50x',
    color: 'bg-blue-600'
  },
  {
    id: 'professional',
    name: 'Professional Tier',
    price: 99,
    stripeLink: 'https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00',
    features: ['Everything in Basic', 'AI Auto Booking', 'Advanced Analytics'],
    aiBoost: '100x',
    color: 'bg-green-600'
  },
  {
    id: 'enterprise',
    name: 'Enterprise Tier',
    price: 299,
    stripeLink: 'https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00',
    features: ['Everything in Pro', 'Custom AI Solutions', 'Dedicated Support'],
    aiBoost: '250x',
    color: 'bg-purple-600'
  }
];

export const EnhancedSubscriptionManager: React.FC = () => {
  const [processing, setProcessing] = useState<string | null>(null);

  const handleImmediatePayment = async (tier: SubscriptionTier) => {
    setProcessing(tier.id);
    
    try {
      // AI Automation for immediate payment processing
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: {
          tierId: tier.id,
          amount: tier.price,
          stripeLink: tier.stripeLink,
          aiBoost: tier.aiBoost,
          immediate: true
        }
      });

      if (error) throw error;

      // Redirect to Stripe payment link
      window.open(tier.stripeLink, '_blank');
      
    } catch (error) {
      console.error('Payment processing error:', error);
    } finally {
      setProcessing(null);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-gray-900 to-black min-h-screen">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">AI-Powered Subscription Tiers</h2>
        <p className="text-gray-300">Immediate payments with AI automation</p>
      </div>

      <Tabs defaultValue="tiers" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="tiers">Subscription Tiers</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="automation">AI Automation</TabsTrigger>
        </TabsList>

        <TabsContent value="tiers">
          <div className="grid md:grid-cols-3 gap-6">
            {subscriptionTiers.map((tier) => (
              <Card key={tier.id} className="bg-gray-800/30 border-gray-600 relative overflow-hidden">
                <div className={`absolute top-0 left-0 right-0 h-1 ${tier.color}`} />
                
                <CardHeader className="text-center">
                  <CardTitle className="text-xl text-white">{tier.name}</CardTitle>
                  <div className="text-3xl font-bold text-white">
                    ${tier.price}
                    <span className="text-sm text-gray-400">/month</span>
                  </div>
                  <Badge className={`${tier.color} text-white`}>
                    AI Boost {tier.aiBoost}
                  </Badge>
                </CardHeader>

                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <Zap className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="space-y-2">
                    <Button 
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      onClick={() => handleImmediatePayment(tier)}
                      disabled={processing === tier.id}
                    >
                      {processing === tier.id ? 'Processing...' : 'Subscribe Now'}
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => window.open(tier.stripeLink, '_blank')}
                    >
                      Direct Stripe Link
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Subscription Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">1,247</div>
                  <div className="text-sm text-gray-400">Active Subscribers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">$127,890</div>
                  <div className="text-sm text-gray-400">Monthly Revenue</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-500">94.2%</div>
                  <div className="text-sm text-gray-400">Retention Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-500">2.3s</div>
                  <div className="text-sm text-gray-400">Avg Payment Time</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="automation">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">AI Payment Automation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-green-900/20 border border-green-500 rounded-lg">
                <h3 className="text-green-300 font-medium mb-2">Immediate Processing Active</h3>
                <p className="text-gray-300 text-sm">
                  AI automation handles instant payment verification, account routing, and subscription activation.
                </p>
              </div>
              
              <div className="p-4 bg-blue-900/20 border border-blue-500 rounded-lg">
                <h3 className="text-blue-300 font-medium mb-2">Smart Routing</h3>
                <p className="text-gray-300 text-sm">
                  Payments automatically routed to appropriate trust accounts based on subscription tier.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};