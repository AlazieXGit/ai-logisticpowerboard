import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { DollarSign, Users, Cpu, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface ResourceData {
  type: string;
  department: string;
  allocated: number;
  utilized: number;
  efficiency: number;
}

const EnhancedResourceAllocation = () => {
  const [resourceData, setResourceData] = useState<ResourceData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchResourceData();
    const interval = setInterval(fetchResourceData, 60000);
    return () => clearInterval(interval);
  }, []);

  const fetchResourceData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enterprise-analytics-processor', {
        body: { action: 'get_resources' }
      });
      
      if (!error && data?.allocation) {
        setResourceData(data.allocation);
      }
    } catch (error) {
      console.error('Error fetching resource data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getEfficiencyColor = (efficiency: number) => {
    if (efficiency >= 95) return 'text-green-600';
    if (efficiency >= 85) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getEfficiencyIcon = (efficiency: number) => {
    if (efficiency >= 95) return <CheckCircle className="w-4 h-4 text-green-500" />;
    if (efficiency >= 85) return <TrendingUp className="w-4 h-4 text-yellow-500" />;
    return <AlertTriangle className="w-4 h-4 text-red-500" />;
  };

  if (loading) {
    return <div className="p-6">Loading resource allocation data...</div>;
  }

  const budgetData = resourceData.filter(r => r.type === 'Budget');
  const headcountData = resourceData.filter(r => r.type === 'Headcount');

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-blue-900">Resource Allocation</h2>
        <Badge variant="outline" className="bg-purple-50">
          Optimal Distribution • Real-time Tracking
        </Badge>
      </div>

      <Tabs defaultValue="budget" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="budget">Budget</TabsTrigger>
          <TabsTrigger value="human">Human Resources</TabsTrigger>
          <TabsTrigger value="technology">Technology</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
        </TabsList>

        <TabsContent value="budget" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Budget Allocation Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {budgetData.map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{item.department}</span>
                        <div className="flex items-center gap-2">
                          {getEfficiencyIcon(item.efficiency)}
                          <span className={getEfficiencyColor(item.efficiency)}>
                            {item.efficiency.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                      <div className="text-sm text-gray-600">
                        Allocated: ${item.allocated.toLocaleString()} | 
                        Utilized: ${item.utilized.toLocaleString()}
                      </div>
                      <Progress 
                        value={(item.utilized / item.allocated) * 100} 
                        className="h-3" 
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Budget Efficiency Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {(budgetData.reduce((acc, item) => acc + item.efficiency, 0) / budgetData.length).toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-600">Average Efficiency</div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-xl font-bold text-blue-600">
                        ${budgetData.reduce((acc, item) => acc + item.allocated, 0).toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-600">Total Allocated</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-green-600">
                        ${budgetData.reduce((acc, item) => acc + item.utilized, 0).toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-600">Total Utilized</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="human" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Headcount Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {headcountData.map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{item.department}</span>
                        <div className="flex items-center gap-2">
                          {getEfficiencyIcon(item.efficiency)}
                          <span className={getEfficiencyColor(item.efficiency)}>
                            {item.efficiency.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                      <div className="text-sm text-gray-600">
                        Planned: {item.allocated} | Active: {item.utilized}
                      </div>
                      <Progress 
                        value={(item.utilized / item.allocated) * 100} 
                        className="h-3" 
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Workforce Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {headcountData.reduce((acc, item) => acc + item.utilized, 0)}
                      </div>
                      <div className="text-xs text-gray-600">Active Employees</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">92.3%</div>
                      <div className="text-xs text-gray-600">Retention Rate</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Productivity Score</span>
                      <span className="text-sm font-medium">87.5%</span>
                    </div>
                    <Progress value={87.5} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="technology" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="w-5 h-5" />
                  Infrastructure
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Server Utilization</span>
                    <span className="text-sm font-medium">78%</span>
                  </div>
                  <Progress value={78} className="h-2" />
                  <div className="flex justify-between">
                    <span className="text-sm">Storage Usage</span>
                    <span className="text-sm font-medium">65%</span>
                  </div>
                  <Progress value={65} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Software Licenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">License Utilization</span>
                    <span className="text-sm font-medium">89%</span>
                  </div>
                  <Progress value={89} className="h-2" />
                  <div className="text-xs text-gray-600">
                    245 active / 275 total licenses
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cloud Resources</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Compute Usage</span>
                    <span className="text-sm font-medium">72%</span>
                  </div>
                  <Progress value={72} className="h-2" />
                  <div className="text-xs text-gray-600">
                    Cost optimization: 15% savings
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Optimization Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="font-medium text-green-800">High Impact</span>
                  </div>
                  <p className="text-sm text-green-700">
                    Engineering team showing 95% budget efficiency - consider expanding allocation
                  </p>
                </div>
                
                <div className="p-4 bg-yellow-50 rounded-lg border-l-4 border-yellow-500">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-yellow-600" />
                    <span className="font-medium text-yellow-800">Medium Impact</span>
                  </div>
                  <p className="text-sm text-yellow-700">
                    Marketing department has 10% unused budget - opportunity for reallocation
                  </p>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                  <div className="flex items-center gap-2 mb-2">
                    <Cpu className="w-5 h-5 text-blue-600" />
                    <span className="font-medium text-blue-800">Technology</span>
                  </div>
                  <p className="text-sm text-blue-700">
                    Cloud infrastructure optimization could save 15% on monthly costs
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedResourceAllocation;