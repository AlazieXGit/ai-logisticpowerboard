import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Banknote, ArrowDownCircle, CheckCircle, AlertTriangle, CreditCard, Building2, Zap, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import TransactionHistoryPanel from './TransactionHistoryPanel';

const AluciusWithdrawalTab: React.FC = () => {
  const [withdrawalData, setWithdrawalData] = useState({
    amount: '',
    sourceAccount: '',
    method: '',
    routingNumber: '',
    accountNumber: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    description: 'Alucius Alford Unlimited Withdrawal'
  });
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleWithdrawal = async () => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'alucius_unlimited_withdrawal',
          ...withdrawalData,
          admin: 'alaziellc.innovation@gmail.com',
          unlimited_access: true,
          no_limits: true
        }
      });
      
      if (!error) {
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
      }
    } catch (error) {
      console.error('Withdrawal error:', error);
    } finally {
      setProcessing(false);
    }
  };

  const getMethodIcon = (method: string) => {
    switch(method) {
      case 'debit_credit': return <CreditCard className="h-4 w-4" />;
      case 'ach': return <Building2 className="h-4 w-4" />;
      case 'wire': return <Zap className="h-4 w-4" />;
      case 'direct_deposit': return <DollarSign className="h-4 w-4" />;
      default: return <Banknote className="h-4 w-4" />;
    }
  };

  return (
    <Tabs defaultValue="withdrawal" className="w-full">
      <TabsList className="grid w-full grid-cols-2 bg-gray-800">
        <TabsTrigger value="withdrawal" className="data-[state=active]:bg-yellow-600">
          Unlimited Withdrawal
        </TabsTrigger>
        <TabsTrigger value="history" className="data-[state=active]:bg-emerald-600">
          Transaction History
        </TabsTrigger>
      </TabsList>
      
      <TabsContent value="withdrawal">
        <Card className="bg-yellow-900/20 border-yellow-500/50">
          <CardHeader>
            <CardTitle className="text-yellow-400 flex items-center gap-2">
              <Banknote className="h-5 w-5" />
              Alucius Alford - Unlimited Withdrawal & Send
            </CardTitle>
            <div className="flex gap-2">
              <Badge className="bg-yellow-600">UNLIMITED ACCESS</Badge>
              <Badge className="bg-red-600 animate-pulse">SUPER ADMIN ONLY</Badge>
              <Badge className="bg-green-600">ALL METHODS</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-yellow-900/30 p-4 rounded border border-yellow-500/30">
              <div className="flex items-center gap-2 text-yellow-300">
                <AlertTriangle className="h-4 w-4" />
                <span className="font-semibold">UNLIMITED WITHDRAWAL & SEND ACCESS</span>
              </div>
              <p className="text-gray-300 text-sm mt-2">
                Master Alucius Alford: Unlimited transactions via Debit/Credit, ACH, Wire Transfer, Direct Deposit
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Amount (Unlimited)</Label>
                <Input
                  type="number"
                  placeholder="Enter any amount"
                  value={withdrawalData.amount}
                  onChange={(e) => setWithdrawalData({...withdrawalData, amount: e.target.value})}
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-300">Transfer Method</Label>
                <Select value={withdrawalData.method} onValueChange={(value) => setWithdrawalData({...withdrawalData, method: value})}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="Select method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="debit_credit">
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4" />
                        Debit/Credit Card
                      </div>
                    </SelectItem>
                    <SelectItem value="ach">
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4" />
                        ACH Transfer
                      </div>
                    </SelectItem>
                    <SelectItem value="wire">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        Wire Transfer
                      </div>
                    </SelectItem>
                    <SelectItem value="direct_deposit">
                      <div className="flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        Direct Deposit
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Source Account</Label>
              <Select value={withdrawalData.sourceAccount} onValueChange={(value) => setWithdrawalData({...withdrawalData, sourceAccount: value})}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ai_banking">AI Banking - banking@nukieson.com</SelectItem>
                  <SelectItem value="alaziel_banking">Alaziel Banking - banking@alaziellc.com</SelectItem>
                  <SelectItem value="escrow">Escrow Account</SelectItem>
                  <SelectItem value="trust">Trust Account</SelectItem>
                  <SelectItem value="revenue">Revenue Account</SelectItem>
                  <SelectItem value="vendor_payout">Vendor Payout Account</SelectItem>
                  <SelectItem value="unlimited_vault">Unlimited Vault</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(withdrawalData.method === 'ach' || withdrawalData.method === 'wire' || withdrawalData.method === 'direct_deposit') && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Routing Number</Label>
                  <Input
                    placeholder="9-digit routing"
                    value={withdrawalData.routingNumber}
                    onChange={(e) => setWithdrawalData({...withdrawalData, routingNumber: e.target.value})}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Account Number</Label>
                  <Input
                    placeholder="Destination account"
                    value={withdrawalData.accountNumber}
                    onChange={(e) => setWithdrawalData({...withdrawalData, accountNumber: e.target.value})}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
            )}

            {withdrawalData.method === 'debit_credit' && (
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2">
                  <Label className="text-gray-300">Card Number</Label>
                  <Input
                    placeholder="16-digit card number"
                    value={withdrawalData.cardNumber}
                    onChange={(e) => setWithdrawalData({...withdrawalData, cardNumber: e.target.value})}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">CVV</Label>
                  <Input
                    placeholder="CVV"
                    value={withdrawalData.cvv}
                    onChange={(e) => setWithdrawalData({...withdrawalData, cvv: e.target.value})}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
            )}

            <Button 
              onClick={handleWithdrawal} 
              disabled={processing || !withdrawalData.amount || !withdrawalData.sourceAccount || !withdrawalData.method}
              className="w-full bg-yellow-600 hover:bg-yellow-700"
            >
              {processing ? (
                'Processing Unlimited Transaction...'
              ) : success ? (
                <><CheckCircle className="h-4 w-4 mr-2" />Transaction Complete</>
              ) : (
                <>
                  {getMethodIcon(withdrawalData.method)}
                  <span className="ml-2">Execute Unlimited Withdrawal/Send</span>
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </TabsContent>
      
      <TabsContent value="history">
        <TransactionHistoryPanel />
      </TabsContent>
    </Tabs>
  );
};

export default AluciusWithdrawalTab;