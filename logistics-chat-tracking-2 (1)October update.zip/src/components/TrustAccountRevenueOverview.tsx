import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, DollarSign, Building2, Edit, Clock, Calendar } from 'lucide-react';

export const TrustAccountRevenueOverview: React.FC = () => {
  const [totalRevenue, setTotalRevenue] = useState(44300000);
  const [isLive, setIsLive] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-emerald-900 border-green-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="h-6 w-6" />
            Trust Account Revenue Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-green-500 bg-green-900/20">
            <DollarSign className="h-4 w-4" />
            <AlertDescription className="text-green-300">
              LIVE UPDATES - Comprehensive revenue tracking with automated fee calculations
            </AlertDescription>
          </Alert>

          <div className="flex items-center justify-center gap-2 mb-4">
            <Clock className="h-5 w-5 text-green-400" />
            <span className="text-green-300 text-sm">{formatTime(currentTime)}</span>
          </div>

          {/* Split Screen Layout */}
          <div className="grid grid-cols-2 gap-6">
            {/* Total Revenue Side */}
            <Card className="bg-black/40 border-green-400">
              <CardContent className="p-6">
                <div className="text-center space-y-3">
                  <h2 className="text-white text-2xl font-bold">Total Revenue</h2>
                  <div className="text-green-400 text-5xl font-bold">
                    ${totalRevenue.toLocaleString()}
                  </div>
                  <Badge className="bg-green-600 text-white">
                    GROWTH ACTIVE
                  </Badge>
                  <div className="text-green-300 text-sm mt-2">
                    All Platform Revenue Combined
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Actual Revenue Side */}
            <Card className="bg-black/40 border-red-400">
              <CardContent className="p-6">
                <div className="text-center space-y-3">
                  <h2 className="text-white text-2xl font-bold">Actual Revenue</h2>
                  <div className="text-red-400 text-5xl font-bold">
                    ${(totalRevenue * 0.73).toLocaleString()}
                  </div>
                  <Badge className="bg-red-600 text-white">
                    REAL DATA
                  </Badge>
                  <div className="text-red-300 text-sm mt-2">
                    Verified Payment Processor Revenue
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="revenue" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800">
              <TabsTrigger value="revenue" className="text-white">Revenue Tracking</TabsTrigger>
              <TabsTrigger value="processing" className="text-white">Processing Center</TabsTrigger>
              <TabsTrigger value="edit" className="text-white">Edit Controls</TabsTrigger>
            </TabsList>

            <TabsContent value="revenue" className="space-y-4">
              <Card className="bg-black/40 border-green-500">
                <CardHeader>
                  <CardTitle className="text-white">Revenue Sources</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Platform Revenue</span>
                      <span className="text-green-400">$25,800,000</span>
                    </div>
                  </div>
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Trust Account Interest</span>
                      <span className="text-green-400">$8,200,000</span>
                    </div>
                  </div>
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Investment Returns</span>
                      <span className="text-green-400">$6,500,000</span>
                    </div>
                  </div>
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Fee Collections</span>
                      <span className="text-green-400">$3,800,000</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="processing" className="space-y-4">
              <Card className="bg-black/40 border-blue-500">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    Revenue Processing
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-blue-500 bg-blue-900/20">
                    <Calendar className="h-4 w-4" />
                    <AlertDescription className="text-blue-300">
                      Processing revenue through all platforms and back office systems
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Process Platform Revenue
                    </Button>
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      Back Office Processing
                    </Button>
                    <Button className="bg-orange-600 hover:bg-orange-700">
                      Automated Distribution
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700">
                      Revenue Allocation
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="edit" className="space-y-4">
              <Card className="bg-black/40 border-yellow-500">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Edit className="h-5 w-5" />
                    Revenue Edit Controls
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-yellow-500 bg-yellow-900/20">
                    <Edit className="h-4 w-4" />
                    <AlertDescription className="text-yellow-300">
                      Edit tab for processing revenue throughout all platforms and back office
                    </AlertDescription>
                  </Alert>
                  
                  <div className="space-y-3">
                    <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                      Edit Revenue Processing Rules
                    </Button>
                    <Button className="w-full bg-red-600 hover:bg-red-700">
                      Modify Platform Allocations
                    </Button>
                    <Button className="w-full bg-indigo-600 hover:bg-indigo-700">
                      Update Back Office Settings
                    </Button>
                    <Button className="w-full bg-pink-600 hover:bg-pink-700">
                      Configure Automated Systems
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrustAccountRevenueOverview;