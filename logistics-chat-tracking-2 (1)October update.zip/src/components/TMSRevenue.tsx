import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { DollarSign, TrendingUp, Clock, BarChart3, Activity } from 'lucide-react';

interface RevenueData {
  totalRevenue: number;
  aiAutoBookingFees: number;
  adminFees: number;
  processFees: number;
  aiGenFees: number;
  platformFees: number;
  transactionCount: number;
  averageTransaction: number;
  dailyGrowth: number;
}

const TMSRevenue = () => {
  const [revenue, setRevenue] = useState<RevenueData>({
    totalRevenue: 0,
    aiAutoBookingFees: 0,
    adminFees: 0,
    processFees: 0,
    aiGenFees: 0,
    platformFees: 0,
    transactionCount: 0,
    averageTransaction: 0,
    dailyGrowth: 0
  });

  const [liveRevenue, setLiveRevenue] = useState(0);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const revenueInterval = setInterval(() => {
      const newTransaction = Math.random() * 4000 + 1000;
      const fees = {
        aiAutoBooking: newTransaction * 0.05,
        admin: newTransaction * 0.05,
        process: newTransaction * 0.05,
        aiGen: newTransaction * 0.05,
        platform: newTransaction * 0.05
      };
      
      const totalFees = Object.values(fees).reduce((sum, fee) => sum + fee, 0);
      
      setRevenue(prev => {
        const newTotal = prev.totalRevenue + newTransaction + totalFees;
        const newCount = prev.transactionCount + 1;
        
        return {
          totalRevenue: newTotal,
          aiAutoBookingFees: prev.aiAutoBookingFees + fees.aiAutoBooking,
          adminFees: prev.adminFees + fees.admin,
          processFees: prev.processFees + fees.process,
          aiGenFees: prev.aiGenFees + fees.aiGen,
          platformFees: prev.platformFees + fees.platform,
          transactionCount: newCount,
          averageTransaction: newTotal / newCount,
          dailyGrowth: Math.random() * 20 + 5
        };
      });
      
      setLiveRevenue(prev => prev + totalFees);
    }, 1500);

    const clockInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(revenueInterval);
      clearInterval(clockInterval);
    };
  }, []);

  const totalFees = revenue.aiAutoBookingFees + revenue.adminFees + 
    revenue.processFees + revenue.aiGenFees + revenue.platformFees;

  return (
    <div className="space-y-6">
      {/* Live Revenue Clock */}
      <Card className="bg-gradient-to-r from-emerald-800 via-teal-800 to-cyan-800 border-emerald-500/30">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Clock className="h-6 w-6 text-white" />
              <span className="text-white text-lg font-semibold">Live Revenue Tracker</span>
            </div>
            <div className="text-5xl font-bold text-white mb-2">
              ${liveRevenue.toFixed(2)}
            </div>
            <div className="text-emerald-200 text-lg">
              {currentTime.toLocaleTimeString()} • Real-Time
            </div>
            <div className="mt-4 grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{revenue.transactionCount}</div>
                <div className="text-emerald-200 text-sm">Transactions</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">${revenue.averageTransaction.toFixed(2)}</div>
                <div className="text-emerald-200 text-sm">Avg Transaction</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">+{revenue.dailyGrowth.toFixed(1)}%</div>
                <div className="text-emerald-200 text-sm">Daily Growth</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fee Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm">AI Auto-Booking (5%)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">${revenue.aiAutoBookingFees.toFixed(2)}</div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm">Admin Fee (5%)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">${revenue.adminFees.toFixed(2)}</div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm">Process Fee (5%)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">${revenue.processFees.toFixed(2)}</div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm">AI Gen Fee (5%)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">${revenue.aiGenFees.toFixed(2)}</div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm">Platform Fee (5%)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white">${revenue.platformFees.toFixed(2)}</div>
            <Progress value={20} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Revenue Summary */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Revenue Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">${revenue.totalRevenue.toFixed(2)}</div>
              <div className="text-gray-400 text-sm">Total Revenue</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">${totalFees.toFixed(2)}</div>
              <div className="text-gray-400 text-sm">Total Fees (25%)</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-teal-400">{revenue.transactionCount}</div>
              <div className="text-gray-400 text-sm">Transactions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-cyan-400">+{revenue.dailyGrowth.toFixed(1)}%</div>
              <div className="text-gray-400 text-sm">Growth Rate</div>
            </div>
          </div>
          
          <div className="mt-6 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Platform Fee Revenue (25% total)</span>
              <Badge className="bg-emerald-600">${totalFees.toFixed(2)}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Average Revenue per Transaction</span>
              <Badge className="bg-teal-600">
                ${(totalFees / Math.max(revenue.transactionCount, 1)).toFixed(2)}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TMSRevenue;