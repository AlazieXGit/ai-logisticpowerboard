import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Shield, CheckCircle, XCircle, AlertTriangle, RefreshCw } from 'lucide-react';

interface Feature {
  name: string;
  enabled: boolean;
  status: string;
  config: any;
}

const ProductionFeatureManager: React.FC = () => {
  const [features, setFeatures] = useState<Record<string, Feature>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeatures();
  }, []);

  const fetchFeatures = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await fetch('http://localhost:8000/api/admin/features', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setFeatures(data.features);
    } catch (error) {
      console.error('Failed to fetch features:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleFeature = async (featureName: string, enabled: boolean) => {
    try {
      const token = localStorage.getItem('access_token');
      await fetch('http://localhost:8000/api/admin/features/activate', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ feature_name: featureName, enabled, status: 'production' })
      });
      fetchFeatures();
    } catch (error) {
      console.error('Failed to toggle feature:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      production: 'bg-green-600',
      staging: 'bg-yellow-600',
      development: 'bg-blue-600',
      disabled: 'bg-gray-600'
    };
    return <Badge className={colors[status as keyof typeof colors] || 'bg-gray-600'}>{status.toUpperCase()}</Badge>;
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-900 to-slate-800 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-2">
            <Shield className="h-8 w-8 text-blue-400" />
            Production Feature Manager
          </h1>
          <p className="text-gray-400 mt-2">Activate and manage production features</p>
        </div>
        <Button onClick={fetchFeatures} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <div className="grid gap-4">
        {Object.entries(features).map(([name, feature]) => (
          <Card key={name} className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-white flex items-center gap-2">
                    {feature.enabled ? (
                      <CheckCircle className="h-5 w-5 text-green-400" />
                    ) : (
                      <XCircle className="h-5 w-5 text-gray-400" />
                    )}
                    {name.replace(/_/g, ' ').toUpperCase()}
                  </CardTitle>
                  <div className="flex gap-2 mt-2">
                    {getStatusBadge(feature.status)}
                    {feature.config.super_admin_only && (
                      <Badge className="bg-red-600">SUPER ADMIN ONLY</Badge>
                    )}
                  </div>
                </div>
                <Switch
                  checked={feature.enabled}
                  onCheckedChange={(checked) => toggleFeature(name, checked)}
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-400 space-y-1">
                {Object.entries(feature.config).map(([key, value]) => (
                  key !== 'enabled' && key !== 'status' && (
                    <div key={key} className="flex justify-between">
                      <span>{key}:</span>
                      <span className="text-white">{String(value)}</span>
                    </div>
                  )
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ProductionFeatureManager;
