import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, Ban, Shield, AlertTriangle, Terminal, Send } from 'lucide-react';
import PaymentReactivationSystem from './PaymentReactivationSystem';

const PaymentSuspensionSystem: React.FC = () => {
  const [commandInput, setCommandInput] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState('reactivation');
  const [systemReactivated, setSystemReactivated] = useState(false);

  const handleCommand = () => {
    if (commandInput.trim()) {
      setCommandHistory(prev => [...prev, `> ${commandInput}`, `System: Command acknowledged for John Smith - ACCESS DENIED`]);
      setCommandInput('');
    }
  };

  const handleReactivation = () => {
    setSystemReactivated(true);
    localStorage.setItem('paymentSystemReactivated', 'true');
  };

  const suspendedEntities = [
    { name: 'John Smith', type: 'Employee', status: 'PERMANENTLY_SUSPENDED', email: 'john@company.com', reason: 'Fraud Alert' },
  ];

  const reactivatedEntities = [
    { name: 'Jane Contractor', type: 'Contractor', status: 'REACTIVATED', email: 'jane@contractor.com' },
    { name: 'ABC Vendor Corp', type: 'Vendor', status: 'REACTIVATED', email: 'contact@abcvendor.com' },
    { name: 'All Other Employees', type: 'Employee Group', status: 'REACTIVATED', email: 'employees@company.com' },
    { name: 'All Other Vendors', type: 'Vendor Group', status: 'REACTIVATED', email: 'vendors@company.com' },
    { name: 'All Other Contractors', type: 'Contractor Group', status: 'REACTIVATED', email: 'contractors@company.com' },
  ];

  return (
    <div className="space-y-6">
      <Alert className={systemReactivated ? "border-emerald-500 bg-emerald-900/20" : "border-yellow-500 bg-yellow-900/20"}>
        {systemReactivated ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
        <AlertDescription className={`font-semibold ${systemReactivated ? 'text-emerald-400' : 'text-yellow-400'}`}>
          {systemReactivated ? 
            '✅ PAYMENT SYSTEM REACTIVATED - All non-suspended accounts can process payments' :
            '⏳ PAYMENT SYSTEM READY FOR REACTIVATION - Suspended accounts will remain blocked'
          }
        </AlertDescription>
      </Alert>

      <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
        <button
          onClick={() => setActiveTab('reactivation')}
          className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'reactivation'
              ? 'bg-emerald-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          🔄 Reactivation Control
        </button>
        <button
          onClick={() => setActiveTab('suspended')}
          className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'suspended'
              ? 'bg-red-600 text-white border-2 border-red-400'
              : 'text-gray-400 hover:text-white border border-red-500/50'
          }`}
        >
          🚫 Suspended Accounts
        </button>
        <button
          onClick={() => setActiveTab('command')}
          className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'command'
              ? 'bg-gray-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          💻 Command Center
        </button>
      </div>

      {activeTab === 'reactivation' && (
        <PaymentReactivationSystem />
      )}

      {activeTab === 'suspended' && (
        <div className="space-y-6">
          <Card className="bg-red-900/20 border-red-500/50">
            <CardHeader>
              <CardTitle className="text-red-400 flex items-center gap-2">
                <Ban className="h-5 w-5" />
                🚫 PERMANENTLY SUSPENDED - REJECTED
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {suspendedEntities.map((entity, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-red-950/50 rounded-lg border-2 border-red-500/50">
                    <div>
                      <div className="font-bold text-red-300 text-lg">{entity.name}</div>
                      <div className="text-sm text-gray-400">{entity.type} • {entity.email}</div>
                      <div className="text-xs text-red-400 font-semibold mt-1">⚠️ {entity.reason} - Platform Infrastructure Rejected</div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge className="bg-red-600 text-white font-bold px-3 py-1">
                        🛡️ {entity.status}
                      </Badge>
                      <Badge className="bg-orange-600 text-white text-xs">
                        FRAUD ALERT
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-emerald-900/20 border-emerald-500/50">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                ✅ Reactivated Accounts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {reactivatedEntities.map((entity, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-emerald-950/30 rounded border border-emerald-500/30">
                    <div>
                      <div className="font-semibold text-white">{entity.name}</div>
                      <div className="text-sm text-gray-400">{entity.type} • {entity.email}</div>
                    </div>
                    <Badge className="bg-emerald-600">
                      {entity.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'command' && (
        <Card className="bg-gray-900/50 border-red-500/50">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Command Center - John Smith (ACCESS DENIED)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert className="border-red-500 bg-red-900/20">
                <Ban className="h-4 w-4" />
                <AlertDescription className="text-red-400">
                  🚫 John Smith account permanently suspended - All commands rejected
                </AlertDescription>
              </Alert>
              <div className="bg-black/50 p-3 rounded border h-32 overflow-y-auto font-mono text-sm">
                {commandHistory.map((line, idx) => (
                  <div key={idx} className={line.startsWith('>') ? 'text-red-400' : 'text-gray-300'}>
                    {line}
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder="Commands for John Smith will be rejected..."
                  className="bg-black/50 border-red-500/50 text-white"
                  onKeyPress={(e) => e.key === 'Enter' && handleCommand()}
                  disabled
                />
                <Button onClick={handleCommand} className="bg-red-600 hover:bg-red-700" disabled>
                  <Ban className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PaymentSuspensionSystem;