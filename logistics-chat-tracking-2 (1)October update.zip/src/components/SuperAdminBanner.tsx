import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Lock, Eye, AlertTriangle } from 'lucide-react';

interface SuperAdminBannerProps {
  isVisible: boolean;
  onClose: () => void;
}

const SuperAdminBanner: React.FC<SuperAdminBannerProps> = ({ isVisible, onClose }) => {
  if (!isVisible) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-red-900 via-red-800 to-red-900 border-b-2 border-red-500 shadow-2xl">
      <Card className="bg-transparent border-none">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Shield className="h-8 w-8 text-red-300 animate-pulse" />
                <AlertTriangle className="h-6 w-6 text-yellow-400 animate-bounce" />
              </div>
              
              <div className="flex flex-col">
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold text-white">
                    🚨 SUPER ADMIN ACCESS ONLY 🚨
                  </h1>
                  <Badge className="bg-red-600 text-white px-3 py-1 animate-pulse">
                    RESTRICTED ZONE
                  </Badge>
                </div>
                <div className="flex items-center gap-4 mt-1">
                  <span className="text-red-200 text-sm">
                    ⚠️ Authorized Personnel Only - All Actions Monitored
                  </span>
                  <div className="flex items-center gap-1">
                    <Lock className="h-4 w-4 text-yellow-400" />
                    <span className="text-yellow-300 text-xs">SECURED</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4 text-blue-400" />
                    <span className="text-blue-300 text-xs">MONITORED</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-white font-semibold">Alucius Alford</div>
                <div className="text-red-200 text-sm">Master Administrator</div>
              </div>
              <button
                onClick={onClose}
                className="bg-red-700 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                Hide Banner
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SuperAdminBanner;