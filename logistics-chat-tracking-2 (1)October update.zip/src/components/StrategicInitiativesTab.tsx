import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Target, Calendar, Users, DollarSign, TrendingUp, AlertCircle, CheckCircle, Clock } from 'lucide-react';

const StrategicInitiativesTab = () => {
  const strategicProjects = [
    {
      name: 'Digital Transformation Initiative',
      status: 'in-progress',
      progress: 68,
      budget: 500000,
      spent: 340000,
      team: 12,
      deadline: '2024-12-31',
      priority: 'high',
      roi: '245%'
    },
    {
      name: 'Market Expansion - APAC',
      status: 'planning',
      progress: 25,
      budget: 750000,
      spent: 125000,
      team: 8,
      deadline: '2025-06-30',
      priority: 'high',
      roi: '180%'
    },
    {
      name: 'AI Integration Platform',
      status: 'in-progress',
      progress: 82,
      budget: 300000,
      spent: 245000,
      team: 6,
      deadline: '2024-09-15',
      priority: 'medium',
      roi: '320%'
    },
    {
      name: 'Sustainability Program',
      status: 'completed',
      progress: 100,
      budget: 200000,
      spent: 185000,
      team: 4,
      deadline: '2024-03-31',
      priority: 'low',
      roi: '95%'
    }
  ];

  const portfolioMetrics = [
    { label: 'Total Portfolio Value', value: '$1.75M', icon: DollarSign, color: 'text-green-600' },
    { label: 'Active Projects', value: '12', icon: Target, color: 'text-blue-600' },
    { label: 'Team Members', value: '45', icon: Users, color: 'text-purple-600' },
    { label: 'Avg ROI', value: '210%', icon: TrendingUp, color: 'text-orange-600' }
  ];

  const riskAssessment = [
    { project: 'Digital Transformation', risk: 'medium', impact: 'high', mitigation: 'Additional resources allocated' },
    { project: 'Market Expansion', risk: 'high', impact: 'high', mitigation: 'Local partnerships established' },
    { project: 'AI Integration', risk: 'low', impact: 'medium', mitigation: 'Regular testing protocols' },
    { project: 'Sustainability', risk: 'low', impact: 'low', mitigation: 'Completed successfully' }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'in-progress': return <Clock className="h-4 w-4 text-blue-600" />;
      case 'planning': return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {portfolioMetrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{metric.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                </div>
                <metric.icon className={`h-8 w-8 ${metric.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Strategic Project Portfolio
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {strategicProjects.map((project, index) => (
              <div key={index} className="p-4 border rounded-lg bg-white">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(project.status)}
                    <h3 className="font-semibold">{project.name}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(project.priority)}`}>
                      {project.priority}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Expected ROI</div>
                    <div className="font-semibold text-green-600">{project.roi}</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-3">
                  <div>
                    <div className="text-xs text-gray-500">Progress</div>
                    <div className="font-medium">{project.progress}%</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Budget</div>
                    <div className="font-medium">${(project.spent / 1000).toFixed(0)}K / ${(project.budget / 1000).toFixed(0)}K</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Team Size</div>
                    <div className="font-medium">{project.team} members</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Deadline</div>
                    <div className="font-medium">{new Date(project.deadline).toLocaleDateString()}</div>
                  </div>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full" 
                    style={{width: `${project.progress}%`}}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Risk Assessment Matrix
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {riskAssessment.map((risk, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <div className="font-medium">{risk.project}</div>
                  <div className="text-sm text-gray-600">{risk.mitigation}</div>
                </div>
                <div className="flex gap-4">
                  <div className="text-center">
                    <div className="text-xs text-gray-500">Risk Level</div>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      risk.risk === 'high' ? 'bg-red-100 text-red-800' :
                      risk.risk === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.risk}
                    </span>
                  </div>
                  <div className="text-center">
                    <div className="text-xs text-gray-500">Impact</div>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      risk.impact === 'high' ? 'bg-red-100 text-red-800' :
                      risk.impact === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.impact}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StrategicInitiativesTab;