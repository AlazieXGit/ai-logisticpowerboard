import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Building2, Copy, Lock, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AlazielBankingConfig: React.FC = () => {
  const { toast } = useToast();

  const alazielCredentials = {
    companyName: 'Alaziel LLC',
    ein: '82-1155909',
    itin: '821155909', // Tax ID (ITIN)
    businessType: 'Limited Liability Company'
  };

  const bankingAccounts = [
    {
      id: 'alaziel-innovation-banking-2024',
      name: 'Innovation Banking - banking@alaziellc_innovation.com',
      username: `alaziellc_innovation_${alazielCredentials.itin}`,
      accountNumber: '5573-9012-4567-8901',
      routingNumber: '031176110',
      swiftCode: 'INNVUS33',
      balance: 3500000.00,
      type: 'innovation-primary',
      status: 'active',
      hardCopy: true,
      email: 'banking@alaziellc_innovation.com',
      password: 'gotchu!',
      ein: alazielCredentials.ein,
      itin: alazielCredentials.itin
    },
    {
      id: 'alaziel-banking-2024',
      name: 'Alaziel Banking - banking@alaziellc.com',
      username: `alaziellc_${alazielCredentials.itin}`,
      accountNumber: '5573-9012-4567-8902',
      routingNumber: '031176110',
      swiftCode: 'ALAZUS33',
      balance: 1250000.00,
      type: 'corporate',
      status: 'active',
      hardCopy: true,
      email: 'banking@alaziellc.com',
      password: 'gotchu!!',
      ein: alazielCredentials.ein,
      itin: alazielCredentials.itin
    },
    {
      id: 'ai-trust-2024',
      name: 'AI Trust Account - Secure Operations',
      username: `ai_trust_${alazielCredentials.itin}`,
      accountNumber: '5573-9012-4567-8903',
      routingNumber: '031176110',
      swiftCode: 'AITRUS33',
      balance: 5890000.00,
      type: 'trust',
      status: 'active',
      hardCopy: true,
      email: 'banking@alaziellc_innovation.com',
      ein: alazielCredentials.ein,
      itin: alazielCredentials.itin
    }
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Hard Copy Secured', description: 'Banking information copied and secured' });
  };

  return (
    <div className="space-y-4">
      <Card className="bg-purple-900/20 border-purple-500/50">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Alaziel LLC Tax Information
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <span className="text-gray-400 text-xs">Company:</span>
            <div className="text-purple-400 font-semibold">{alazielCredentials.companyName}</div>
          </div>
          <div className="space-y-1">
            <span className="text-gray-400 text-xs">EIN:</span>
            <button 
              onClick={() => copyToClipboard(alazielCredentials.ein)}
              className="text-purple-400 font-semibold hover:underline flex items-center gap-1"
            >
              {alazielCredentials.ein} <Copy className="h-3 w-3" />
            </button>
          </div>
          <div className="space-y-1">
            <span className="text-gray-400 text-xs">ITIN (Tax ID):</span>
            <button 
              onClick={() => copyToClipboard(alazielCredentials.itin)}
              className="text-purple-400 font-semibold hover:underline flex items-center gap-1"
            >
              {alazielCredentials.itin} <Copy className="h-3 w-3" />
            </button>
          </div>
          <div className="space-y-1">
            <span className="text-gray-400 text-xs">Type:</span>
            <div className="text-purple-400 font-semibold">{alazielCredentials.businessType}</div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Updated Banking System - Configuration
            <Lock className="h-4 w-4 text-red-400" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 mb-4">
            <Badge className="bg-red-600 text-white">
              <Trash2 className="h-3 w-3 mr-1" />
              DELETED: banking@nukieson.com - REMOVED FROM SYSTEM
            </Badge>
            <Badge className="bg-blue-600 text-white">
              NEW: banking@alaziellc_innovation.com - ACTIVE
            </Badge>
            <Badge className="bg-green-600 text-white">
              UPDATED: banking@alaziellc.com - PASSWORD: gotchu!!
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {bankingAccounts.map((account) => (
              <Card key={account.id} className="bg-gray-700 border-emerald-500/20">
                <CardHeader>
                  <CardTitle className="text-emerald-300 text-sm flex items-center gap-2">
                    {account.name}
                    {account.hardCopy && <Lock className="h-3 w-3 text-red-400" />}
                    {account.type === 'innovation-primary' && (
                      <Badge className="bg-blue-600 text-xs">NEW</Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400 text-xs">Username:</span>
                    <button 
                      onClick={() => copyToClipboard(account.username)}
                      className="text-emerald-400 text-xs hover:underline flex items-center gap-1"
                    >
                      {account.username} <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 text-xs">Email:</span>
                    <button 
                      onClick={() => copyToClipboard(account.email)}
                      className="text-emerald-400 text-xs hover:underline flex items-center gap-1"
                    >
                      {account.email} <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  {account.password && (
                    <div className="flex justify-between">
                      <span className="text-gray-400 text-xs">Password:</span>
                      <button 
                        onClick={() => copyToClipboard(account.password)}
                        className="text-emerald-400 text-xs hover:underline flex items-center gap-1"
                      >
                        {account.password} <Copy className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-400 text-xs">Account:</span>
                    <button 
                      onClick={() => copyToClipboard(account.accountNumber)}
                      className="text-emerald-400 text-xs hover:underline flex items-center gap-1"
                    >
                      {account.accountNumber} <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 text-xs">EIN:</span>
                    <button 
                      onClick={() => copyToClipboard(account.ein)}
                      className="text-emerald-400 text-xs hover:underline flex items-center gap-1"
                    >
                      {account.ein} <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 text-xs">ITIN:</span>
                    <button 
                      onClick={() => copyToClipboard(account.itin)}
                      className="text-emerald-400 text-xs hover:underline flex items-center gap-1"
                    >
                      {account.itin} <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 text-xs">Routing:</span>
                    <button 
                      onClick={() => copyToClipboard(account.routingNumber)}
                      className="text-emerald-400 text-xs hover:underline flex items-center gap-1"
                    >
                      {account.routingNumber} <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 text-xs">SWIFT:</span>
                    <span className="text-emerald-400 text-xs">{account.swiftCode}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-emerald-500/20">
                    <span className="text-gray-400 text-xs">Balance:</span>
                    <span className="text-emerald-400 text-xs font-bold">
                      ${account.balance.toLocaleString()}
                    </span>
                  </div>
                  <div className="pt-1">
                    <Badge className={
                      account.type === 'innovation-primary' ? 'bg-blue-600 text-white text-xs' : 
                      account.type === 'corporate' ? 'bg-green-600 text-white text-xs' :
                      'bg-red-600 text-white text-xs'
                    }>
                      {account.type === 'innovation-primary' ? 'INNOVATION PRIMARY' : 
                       account.type === 'corporate' ? 'CORPORATE UPDATED' : 'TRUST SECURED'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AlazielBankingConfig;