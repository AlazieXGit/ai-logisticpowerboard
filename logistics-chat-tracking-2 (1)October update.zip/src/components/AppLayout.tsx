import React from 'react';
import DashboardLayout from './DashboardLayout';
import { SessionTimeoutWarning } from './SessionTimeoutWarning';

const AppLayout: React.FC = () => {
  return (
    <div className="w-full">
      <DashboardLayout />
      <SessionTimeoutWarning />
    </div>
  );
};

export default AppLayout;
