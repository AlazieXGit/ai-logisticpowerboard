import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { 
  Send, Wallet, Building2, Smartphone, 
  CreditCard, DollarSign, ArrowRight,
  CheckCircle, AlertCircle
} from 'lucide-react';

interface TransferRequest {
  sourceAccount: string;
  destinationType: string;
  destinationAccount: string;
  amount: number;
  description: string;
}

interface TransferResult {
  success: boolean;
  message: string;
  transactionId?: string;
}

const sourceAccounts = [
  { id: 'ace_flare', name: 'Ace Flare Account', icon: CreditCard },
  { id: 'wells_fargo', name: 'Wells Fargo Business', icon: Building2 },
  { id: 'pnc_virtual', name: 'PNC Virtual Account', icon: Building2 },
  { id: 'trust_main', name: 'Main Trust Account', icon: Wallet },
  { id: 'escrow_primary', name: 'Primary Escrow', icon: Wallet }
];

const destinationTypes = [
  { id: 'cashapp', name: 'Cash App', icon: Smartphone },
  { id: 'chime', name: 'Chime Bank', icon: Building2 },
  { id: 'venmo', name: 'Venmo', icon: Smartphone },
  { id: 'paypal', name: 'PayPal', icon: CreditCard },
  { id: 'zelle', name: 'Zelle', icon: Building2 },
  { id: 'external_bank', name: 'External Bank', icon: Building2 }
];

export function ManualFundDistributionPlatform() {
  const [transfer, setTransfer] = useState<TransferRequest>({
    sourceAccount: '',
    destinationType: '',
    destinationAccount: '',
    amount: 0,
    description: ''
  });
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<TransferResult | null>(null);

  const executeTransfer = async () => {
    if (!transfer.sourceAccount || !transfer.destinationType || !transfer.destinationAccount || transfer.amount <= 0) {
      setResult({
        success: false,
        message: 'Please fill in all required fields'
      });
      return;
    }

    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('manual-fund-distribution', {
        body: transfer
      });
      
      if (error) throw error;
      setResult(data);
      
      if (data.success) {
        setTransfer({
          sourceAccount: '',
          destinationType: '',
          destinationAccount: '',
          amount: 0,
          description: ''
        });
      }
    } catch (error) {
      setResult({
        success: false,
        message: 'Transfer failed: ' + (error as Error).message
      });
    } finally {
      setProcessing(false);
    }
  };

  const getSourceIcon = (accountId: string) => {
    const account = sourceAccounts.find(a => a.id === accountId);
    return account?.icon || Wallet;
  };

  const getDestinationIcon = (typeId: string) => {
    const type = destinationTypes.find(t => t.id === typeId);
    return type?.icon || Building2;
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-purple-900/30 to-blue-800/20 border-purple-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Send className="h-6 w-6 text-purple-400" />
            Manual Fund Distribution Platform
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Source Account</label>
              <Select value={transfer.sourceAccount} onValueChange={(value) => 
                setTransfer(prev => ({ ...prev, sourceAccount: value }))
              }>
                <SelectTrigger className="bg-gray-800 border-gray-600">
                  <SelectValue placeholder="Select source account" />
                </SelectTrigger>
                <SelectContent>
                  {sourceAccounts.map(account => (
                    <SelectItem key={account.id} value={account.id}>
                      <div className="flex items-center gap-2">
                        <account.icon className="h-4 w-4" />
                        {account.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Destination Type</label>
              <Select value={transfer.destinationType} onValueChange={(value) => 
                setTransfer(prev => ({ ...prev, destinationType: value }))
              }>
                <SelectTrigger className="bg-gray-800 border-gray-600">
                  <SelectValue placeholder="Select destination type" />
                </SelectTrigger>
                <SelectContent>
                  {destinationTypes.map(type => (
                    <SelectItem key={type.id} value={type.id}>
                      <div className="flex items-center gap-2">
                        <type.icon className="h-4 w-4" />
                        {type.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-gray-300 text-sm">Destination Account/ID</label>
            <Input
              placeholder="Enter account number, email, or username"
              value={transfer.destinationAccount}
              onChange={(e) => setTransfer(prev => ({ ...prev, destinationAccount: e.target.value }))}
              className="bg-gray-800 border-gray-600"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Amount ($)</label>
              <Input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={transfer.amount || ''}
                onChange={(e) => setTransfer(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                className="bg-gray-800 border-gray-600"
              />
            </div>

            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Description</label>
              <Input
                placeholder="Transfer description"
                value={transfer.description}
                onChange={(e) => setTransfer(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-800 border-gray-600"
              />
            </div>
          </div>

          {transfer.sourceAccount && transfer.destinationType && (
            <div className="p-4 bg-gray-800/30 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {React.createElement(getSourceIcon(transfer.sourceAccount), { 
                    className: "h-5 w-5 text-blue-400" 
                  })}
                  <span className="text-white text-sm">
                    {sourceAccounts.find(a => a.id === transfer.sourceAccount)?.name}
                  </span>
                </div>
                
                <ArrowRight className="h-5 w-5 text-gray-400" />
                
                <div className="flex items-center gap-2">
                  {React.createElement(getDestinationIcon(transfer.destinationType), { 
                    className: "h-5 w-5 text-green-400" 
                  })}
                  <span className="text-white text-sm">
                    {destinationTypes.find(t => t.id === transfer.destinationType)?.name}
                  </span>
                </div>
              </div>
            </div>
          )}

          <Button 
            onClick={executeTransfer}
            disabled={processing || !transfer.sourceAccount || !transfer.destinationType}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            {processing ? 'Processing Transfer...' : 'Execute Transfer'}
          </Button>

          {result && (
            <div className={`p-4 rounded-lg ${
              result.success ? 'bg-green-900/20 border border-green-500' : 'bg-red-900/20 border border-red-500'
            }`}>
              <div className="flex items-center gap-2 mb-2">
                {result.success ? (
                  <CheckCircle className="h-5 w-5 text-green-400" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-red-400" />
                )}
                <Badge className={result.success ? 'bg-green-500' : 'bg-red-500'}>
                  {result.success ? 'Success' : 'Failed'}
                </Badge>
              </div>
              <p className="text-white text-sm">{result.message}</p>
              {result.transactionId && (
                <p className="text-gray-300 text-xs mt-1">
                  Transaction ID: {result.transactionId}
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}