import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, DollarSign, Activity, Users, Clock, BarChart3, Database, CreditCard, Banknote, ArrowUpRight, ArrowDownRight } from 'lucide-react';

const InnovationPlatform = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [liveMetrics, setLiveMetrics] = useState({
    totalRevenue: 847293.67,
    dailyRevenue: 23847.92,
    hourlyRate: 2847.33,
    activeTransactions: 1247,
    completedToday: 892,
    pendingRoutes: 156
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      // Simulate live data updates
      setLiveMetrics(prev => ({
        ...prev,
        totalRevenue: prev.totalRevenue + Math.random() * 100,
        dailyRevenue: prev.dailyRevenue + Math.random() * 50,
        hourlyRate: prev.hourlyRate + Math.random() * 20 - 10,
        activeTransactions: prev.activeTransactions + Math.floor(Math.random() * 10 - 5)
      }));
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const platformData = [
    { name: 'AI Alazie Xpress Loadboard', revenue: 234567.89, percentage: 87, transactions: 456, rate: 2400 },
    { name: 'AI Dev Platform', revenue: 189234.56, percentage: 92, transactions: 234, rate: 1890 },
    { name: 'AI Tax Assistant Platform', revenue: 156789.23, percentage: 78, transactions: 189, rate: 1567 },
    { name: 'Super Admin Dashboard', revenue: 267891.45, percentage: 95, transactions: 368, rate: 2678 }
  ];

  const historicalData = [
    { date: '2025-08-19', revenue: 45678.90, transactions: 234, routes: 89 },
    { date: '2025-08-18', revenue: 52341.67, transactions: 267, routes: 95 },
    { date: '2025-08-17', revenue: 48923.45, transactions: 251, routes: 87 },
    { date: '2025-08-16', revenue: 56789.12, transactions: 289, routes: 102 },
    { date: '2025-08-15', revenue: 61234.78, transactions: 312, routes: 118 }
  ];

  const bankingActivity = [
    { type: 'ACH Transfer', amount: 15678.90, status: 'Completed', time: '10:05 AM' },
    { type: 'Wire Transfer', amount: 23456.78, status: 'Processing', time: '10:03 AM' },
    { type: 'Card Payment', amount: 1234.56, status: 'Completed', time: '10:01 AM' },
    { type: 'Direct Deposit', amount: 8765.43, status: 'Pending', time: '09:58 AM' },
    { type: 'International Wire', amount: 45678.90, status: 'Completed', time: '09:55 AM' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">INNOVATION PLATFORM</h1>
          <p className="text-gray-300">Unified Real-Time Revenue Analytics & Control Center</p>
          <Badge variant="destructive" className="mt-2 bg-red-600 text-white animate-pulse">
            REAL DATA - Last Updated: {currentTime.toLocaleString('en-US', { 
              weekday: 'short', 
              year: 'numeric', 
              month: 'short', 
              day: 'numeric', 
              hour: '2-digit', 
              minute: '2-digit', 
              second: '2-digit',
              timeZoneName: 'short'
            })}
          </Badge>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800 border border-red-500">
            <TabsTrigger value="overview" className="text-white data-[state=active]:bg-red-600">Overview</TabsTrigger>
            <TabsTrigger value="analytics" className="text-white data-[state=active]:bg-red-600">Analytics</TabsTrigger>
            <TabsTrigger value="fees" className="text-white data-[state=active]:bg-red-600">Fees & Collections</TabsTrigger>
            <TabsTrigger value="super-admin" className="text-white data-[state=active]:bg-red-600">Super Admin Control</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="bg-gradient-to-r from-red-900/30 to-red-800/20 border-2 border-red-500">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-red-300 text-sm font-medium">Total Revenue</p>
                      <p className="text-3xl font-bold text-red-400">${liveMetrics.totalRevenue.toLocaleString()}</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-green-900/30 to-green-800/20 border-2 border-green-500">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-300 text-sm font-medium">Daily Revenue</p>
                      <p className="text-3xl font-bold text-green-400">${liveMetrics.dailyRevenue.toLocaleString()}</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-blue-900/30 to-blue-800/20 border-2 border-blue-500">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-300 text-sm font-medium">Active Transactions</p>
                      <p className="text-3xl font-bold text-blue-400">{liveMetrics.activeTransactions}</p>
                    </div>
                    <Activity className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-purple-900/30 to-purple-800/20 border-2 border-purple-500">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-300 text-sm font-medium">Hourly Rate</p>
                      <p className="text-3xl font-bold text-purple-400">${liveMetrics.hourlyRate.toLocaleString()}</p>
                    </div>
                    <Clock className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {platformData.map((platform, index) => (
                <Card key={index} className="bg-gradient-to-r from-slate-800/50 to-slate-700/30 border border-red-500/50">
                  <CardHeader>
                    <CardTitle className="text-red-400 flex items-center justify-between">
                      <span>{platform.name}</span>
                      <Badge className="bg-red-600 text-white animate-pulse">REAL DATA</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold text-red-400">
                          ${platform.revenue.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-300">{platform.percentage}% of projected</span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="text-gray-400">Transactions</div>
                          <div className="text-white font-semibold">{platform.transactions}</div>
                        </div>
                        <div>
                          <div className="text-gray-400">Rate/Hr</div>
                          <div className="text-white font-semibold">${platform.rate}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-r from-blue-900/20 to-blue-800/10 border-blue-500/50">
                <CardHeader>
                  <CardTitle className="text-blue-400">Revenue Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {platformData.map((platform, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-gray-300 text-sm">{platform.name}</span>
                        <span className="text-blue-400 font-semibold">
                          {((platform.revenue / liveMetrics.totalRevenue) * 100).toFixed(1)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-green-900/20 to-green-800/10 border-green-500/50">
                <CardHeader>
                  <CardTitle className="text-green-400">Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Highest Performer</span>
                      <span className="text-green-400 font-semibold">Super Admin Dashboard</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Fastest Growing</span>
                      <span className="text-green-400 font-semibold">AI Dev Platform</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Most Transactions</span>
                      <span className="text-green-400 font-semibold">AI Alazie Xpress</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="fees" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-r from-yellow-900/20 to-yellow-800/10 border-yellow-500/50">
                <CardHeader>
                  <CardTitle className="text-yellow-400 flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Total Fees Collected
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-yellow-400">$2,847,300</div>
                  <div className="text-sm text-gray-300">Today's Collections</div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-red-900/20 to-red-800/10 border-red-500/50">
                <CardHeader>
                  <CardTitle className="text-red-400 flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Processing Fees
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-400">$847,200</div>
                  <div className="text-sm text-gray-300">Real-Time Processing</div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-purple-900/20 to-purple-800/10 border-purple-500/50">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <Banknote className="h-5 w-5" />
                    Transaction Fees
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-purple-400">$1,247,800</div>
                  <div className="text-sm text-gray-300">Automated Collection</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="super-admin" className="mt-6">
            <div className="space-y-6">
              <Card className="bg-gradient-to-r from-red-900/30 to-red-800/20 border-2 border-red-500">
                <CardHeader>
                  <CardTitle className="text-red-400 flex items-center gap-2">
                    <Database className="h-6 w-6" />
                    Real-Time Actual Revenue Display - Super Admin Control
                    <Badge className="bg-red-600 text-white animate-pulse ml-2">REAL DATA</Badge>
                  </CardTitle>
                  <p className="text-gray-300 text-sm">
                    Last Updated: {currentTime.toLocaleString('en-US', { 
                      weekday: 'short', 
                      year: 'numeric', 
                      month: 'short', 
                      day: 'numeric', 
                      hour: '2-digit', 
                      minute: '2-digit', 
                      second: '2-digit',
                      timeZoneName: 'short'
                    })}
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-red-400">Live Transaction Activity</h3>
                      <div className="space-y-2">
                        {bankingActivity.map((activity, index) => (
                          <div key={index} className="flex justify-between items-center p-3 bg-slate-800/50 rounded border border-red-500/30">
                            <div>
                              <div className="text-white font-medium">{activity.type}</div>
                              <div className="text-gray-400 text-sm">{activity.time}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-red-400 font-bold">${activity.amount.toLocaleString()}</div>
                              <div className={`text-xs ${activity.status === 'Completed' ? 'text-green-400' : activity.status === 'Processing' ? 'text-yellow-400' : 'text-blue-400'}`}>
                                {activity.status}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-red-400">Historical Data Analysis</h3>
                      <div className="space-y-2">
                        {historicalData.map((data, index) => (
                          <div key={index} className="p-3 bg-slate-800/50 rounded border border-red-500/30">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-white font-medium">{data.date}</span>
                              <span className="text-red-400 font-bold">${data.revenue.toLocaleString()}</span>
                            </div>
                            <div className="grid grid-cols-2 gap-2 text-sm">
                              <div>
                                <span className="text-gray-400">Transactions: </span>
                                <span className="text-white">{data.transactions}</span>
                              </div>
                              <div>
                                <span className="text-gray-400">Routes: </span>
                                <span className="text-white">{data.routes}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-red-400">Banking System Routes</h3>
                      <div className="space-y-2">
                        <div className="p-3 bg-slate-800/50 rounded border border-green-500/30">
                          <div className="text-green-400 font-medium">Active Routes</div>
                          <div className="text-2xl font-bold text-white">{liveMetrics.pendingRoutes}</div>
                          <div className="text-gray-400 text-sm">Currently Processing</div>
                        </div>
                        <div className="p-3 bg-slate-800/50 rounded border border-blue-500/30">
                          <div className="text-blue-400 font-medium">Completed Today</div>
                          <div className="text-2xl font-bold text-white">{liveMetrics.completedToday}</div>
                          <div className="text-gray-400 text-sm">Successful Transactions</div>
                        </div>
                        <div className="p-3 bg-slate-800/50 rounded border border-yellow-500/30">
                          <div className="text-yellow-400 font-medium">Payment Systems</div>
                          <div className="text-2xl font-bold text-white">24/7</div>
                          <div className="text-gray-400 text-sm">Active Monitoring</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default InnovationPlatform;