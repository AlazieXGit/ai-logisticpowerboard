import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase';
import { Shield, AlertTriangle, Users, Ban } from 'lucide-react';

interface UserSession {
  id: string;
  user_id: string;
  username: string;
  ip_address: string;
  threat_level: number;
  incident_count: number;
  is_quarantined: boolean;
  last_activity: string;
  status: 'active' | 'suspicious' | 'quarantined';
}

interface ThreatIncident {
  id: string;
  user_id: string;
  incident_type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
  details: string;
}

const SessionThreatMonitor: React.FC = () => {
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [incidents, setIncidents] = useState<ThreatIncident[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSessionData();
    const interval = setInterval(loadSessionData, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const loadSessionData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('session-threat-monitor', {
        body: { action: 'get_sessions' }
      });
      
      if (error) throw error;
      
      setSessions(data.sessions || []);
      setIncidents(data.incidents || []);
    } catch (error) {
      console.error('Error loading session data:', error);
      // Mock data for demonstration
      setSessions([
        {
          id: '1',
          user_id: 'user_123',
          username: 'john.doe',
          ip_address: '192.168.1.100',
          threat_level: 2,
          incident_count: 2,
          is_quarantined: false,
          last_activity: new Date().toISOString(),
          status: 'suspicious'
        },
        {
          id: '2',
          user_id: 'user_456',
          username: 'jane.smith',
          ip_address: '10.0.0.50',
          threat_level: 4,
          incident_count: 4,
          is_quarantined: true,
          last_activity: new Date(Date.now() - 300000).toISOString(),
          status: 'quarantined'
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const quarantineUser = async (userId: string) => {
    try {
      const { error } = await supabase.functions.invoke('session-threat-monitor', {
        body: { action: 'quarantine_user', user_id: userId }
      });
      
      if (error) throw error;
      
      await loadSessionData();
    } catch (error) {
      console.error('Error quarantining user:', error);
    }
  };

  const releaseUser = async (userId: string) => {
    try {
      const { error } = await supabase.functions.invoke('session-threat-monitor', {
        body: { action: 'release_user', user_id: userId }
      });
      
      if (error) throw error;
      
      await loadSessionData();
    } catch (error) {
      console.error('Error releasing user:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald-600';
      case 'suspicious': return 'bg-yellow-600';
      case 'quarantined': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const getThreatLevelColor = (level: number) => {
    if (level >= 4) return 'text-red-400';
    if (level >= 3) return 'text-orange-400';
    if (level >= 2) return 'text-yellow-400';
    return 'text-emerald-400';
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Active Sessions</p>
                <p className="text-2xl font-bold text-emerald-400">
                  {sessions.filter(s => s.status === 'active').length}
                </p>
              </div>
              <Users className="w-8 h-8 text-emerald-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Suspicious</p>
                <p className="text-2xl font-bold text-yellow-400">
                  {sessions.filter(s => s.status === 'suspicious').length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Quarantined</p>
                <p className="text-2xl font-bold text-red-400">
                  {sessions.filter(s => s.status === 'quarantined').length}
                </p>
              </div>
              <Ban className="w-8 h-8 text-red-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Incidents</p>
                <p className="text-2xl font-bold text-orange-400">
                  {sessions.reduce((sum, s) => sum + s.incident_count, 0)}
                </p>
              </div>
              <Shield className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle className="text-emerald-400">User Session Monitor</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-400 mx-auto"></div>
              <p className="text-gray-400 mt-2">Loading session data...</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sessions.map((session) => (
                <Alert key={session.id} className="bg-gray-800 border-gray-600">
                  <AlertDescription>
                    <div className="flex justify-between items-center">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold text-white">{session.username}</h4>
                          <Badge className={getStatusColor(session.status)}>
                            {session.status.toUpperCase()}
                          </Badge>
                          <span className={`text-sm font-medium ${getThreatLevelColor(session.threat_level)}`}>
                            Threat Level: {session.threat_level}/5
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm text-gray-400">
                          <div>IP: {session.ip_address}</div>
                          <div>Incidents: {session.incident_count}</div>
                          <div>Last Activity: {new Date(session.last_activity).toLocaleString()}</div>
                          <div>User ID: {session.user_id}</div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {!session.is_quarantined ? (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => quarantineUser(session.user_id)}
                          >
                            Quarantine
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-700"
                            onClick={() => releaseUser(session.user_id)}
                          >
                            Release
                          </Button>
                        )}
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SessionThreatMonitor;