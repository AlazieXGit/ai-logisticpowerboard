import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, Zap, Eye, Mail } from 'lucide-react';

interface CreditUpdate {
  timestamp: string;
  score: number;
  change: number;
  reason: string;
  bureau: string;
}

export default function RealTimeCreditMonitor() {
  const [currentScore, setCurrentScore] = useState(642);
  const [targetScore, setTargetScore] = useState(750);
  const [updates, setUpdates] = useState<CreditUpdate[]>([]);
  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      const change = Math.floor(Math.random() * 5) + 1;
      const newScore = currentScore + change;
      
      const reasons = [
        'Negative item removed',
        'Payment history improved',
        'Credit utilization optimized',
        'Account age increased',
        'Dispute resolved favorably'
      ];

      const bureaus = ['Experian', 'Equifax', 'TransUnion'];
      
      const newUpdate: CreditUpdate = {
        timestamp: new Date().toLocaleTimeString(),
        score: newScore,
        change: change,
        reason: reasons[Math.floor(Math.random() * reasons.length)],
        bureau: bureaus[Math.floor(Math.random() * bureaus.length)]
      };

      setCurrentScore(newScore);
      setUpdates(prev => [newUpdate, ...prev.slice(0, 9)]);
    }, 2000);

    return () => clearInterval(interval);
  }, [currentScore, isLive]);

  const progress = ((currentScore - 300) / (850 - 300)) * 100;
  const targetProgress = ((targetScore - 300) / (850 - 300)) * 100;

  const sendEmailUpdate = () => {
    console.log('Sending email update with current score:', currentScore);
    // Email integration logic
  };

  return (
    <div className="space-y-6">
      <Card className="border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <Eye className="h-6 w-6" />
            Live Credit Score Performance - Point Blank Real Time
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center space-y-2">
            <div className="text-6xl font-bold text-green-600">{currentScore}</div>
            <div className="text-lg text-gray-600">Current Credit Score</div>
            <Badge variant="outline" className="text-green-600 border-green-600">
              <TrendingUp className="h-4 w-4 mr-1" />
              Live Updates Active
            </Badge>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress to Target ({targetScore})</span>
              <span>{Math.round(((currentScore - 300) / (targetScore - 300)) * 100)}%</span>
            </div>
            <Progress value={progress} className="h-3" />
            <div className="flex justify-between text-xs text-gray-500">
              <span>300</span>
              <span>Current: {currentScore}</span>
              <span>Target: {targetScore}</span>
              <span>850</span>
            </div>
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={() => setIsLive(!isLive)}
              variant={isLive ? "destructive" : "default"}
              className="flex-1"
            >
              <Zap className="h-4 w-4 mr-2" />
              {isLive ? 'Pause Live Updates' : 'Resume Live Updates'}
            </Button>
            <Button onClick={sendEmailUpdate} className="flex-1 bg-blue-600 hover:bg-blue-700">
              <Mail className="h-4 w-4 mr-2" />
              Email Update
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            Real-Time AI Credit Changes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {updates.map((update, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border-l-4 border-green-500">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <div>
                    <div className="font-medium">{update.reason}</div>
                    <div className="text-sm text-gray-600">{update.bureau} • {update.timestamp}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold">{update.score}</div>
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +{update.change}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}