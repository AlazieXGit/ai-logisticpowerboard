import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { 
  DollarSign, ArrowRight, Activity, 
  Zap, Shield, TrendingUp 
} from 'lucide-react';

interface BankingData {
  bankingAccounts: {
    primary: { balance: number; routing: string };
    escrow: { balance: number; routing: string };
    trust: { balance: number; routing: string };
    operating: { balance: number; routing: string };
  };
  synergyAI: {
    totalRevenue: number;
    dailyTransactions: number;
    processingFees: number;
    netIncome: number;
  };
  platformBreakdown: {
    tms: number;
    banking: number;
    loadBoard: number;
    aiServices: number;
    creditRepair: number;
  };
}

const SynergyPaymentRouter: React.FC = () => {
  const [bankingData, setBankingData] = useState<BankingData | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchBankingData = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('synergy-payment-routing', {
        body: { action: 'get-combined-total' }
      });
      setBankingData(data);
    } catch (error) {
      console.error('Error fetching banking data:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchBankingData();
    const interval = setInterval(fetchBankingData, 30000);
    return () => clearInterval(interval);
  }, []);

  const processPayment = async (amount: number, targetAccount: string) => {
    try {
      const { data } = await supabase.functions.invoke('synergy-payment-routing', {
        body: { 
          action: 'process-payment',
          data: { amount, targetAccount }
        }
      });
      console.log('Payment processed:', data);
      fetchBankingData(); // Refresh data
    } catch (error) {
      console.error('Payment processing error:', error);
    }
  };

  if (!bankingData) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500">
        <CardHeader>
          <CardTitle className="text-2xl text-purple-400 flex items-center gap-2">
            <Zap className="h-6 w-6" />
            Synergy AI Payment Router
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="accounts" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="accounts">Banking Accounts</TabsTrigger>
          <TabsTrigger value="synergy">Synergy AI</TabsTrigger>
          <TabsTrigger value="platforms">Platform Breakdown</TabsTrigger>
          <TabsTrigger value="routing">Payment Routing</TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(bankingData.bankingAccounts).map(([type, account]) => (
              <Card key={type} className="bg-gray-800/30 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-white capitalize font-semibold">{type}</h3>
                    <Shield className="h-5 w-5 text-green-400" />
                  </div>
                  <div className="text-2xl font-bold text-green-400 mb-1">
                    ${account.balance.toLocaleString()}
                  </div>
                  <div className="text-xs text-gray-400">
                    Routing: {account.routing}
                  </div>
                  <Button 
                    size="sm" 
                    className="w-full mt-3 bg-blue-600"
                    onClick={() => processPayment(1000, type)}
                  >
                    Route Payment
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="synergy" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-purple-900/20 border-purple-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-400 text-sm">Total Revenue</p>
                    <p className="text-2xl font-bold text-white">
                      ${bankingData.synergyAI.totalRevenue.toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-purple-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-900/20 border-blue-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-400 text-sm">Daily Transactions</p>
                    <p className="text-2xl font-bold text-white">
                      {bankingData.synergyAI.dailyTransactions.toLocaleString()}
                    </p>
                  </div>
                  <Activity className="h-8 w-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-yellow-900/20 border-yellow-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-400 text-sm">Processing Fees</p>
                    <p className="text-2xl font-bold text-white">
                      ${bankingData.synergyAI.processingFees.toLocaleString()}
                    </p>
                  </div>
                  <ArrowRight className="h-8 w-8 text-yellow-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-green-900/20 border-green-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-400 text-sm">Net Income</p>
                    <p className="text-2xl font-bold text-white">
                      ${bankingData.synergyAI.netIncome.toLocaleString()}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-400" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="platforms" className="space-y-4">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Platform Revenue Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(bankingData.platformBreakdown).map(([platform, amount]) => (
                  <div key={platform} className="flex items-center justify-between p-3 bg-gray-700/30 rounded">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 bg-blue-500 rounded"></div>
                      <span className="text-white capitalize">{platform.replace(/([A-Z])/g, ' $1').trim()}</span>
                    </div>
                    <div className="text-green-400 font-bold">
                      ${amount.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="routing" className="space-y-4">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Payment Routing Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-900/20 border border-blue-500 rounded">
                  <h4 className="text-blue-400 font-semibold mb-2">Active Endpoint</h4>
                  <code className="text-green-400">/api/payment-routing/combined-total</code>
                  <Badge className="ml-3 bg-green-600">ACTIVE</Badge>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button 
                    className="bg-purple-600 hover:bg-purple-700"
                    onClick={() => fetchBankingData()}
                    disabled={loading}
                  >
                    {loading ? 'Refreshing...' : 'Refresh Data'}
                  </Button>
                  <Button 
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => processPayment(5000, 'primary')}
                  >
                    Test Payment Route
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SynergyPaymentRouter;