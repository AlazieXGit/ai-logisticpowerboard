import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Brain, Zap } from 'lucide-react';

interface MarketRate {
  loadType: string;
  currentRate: number;
  adjustedRate: number;
  marketTrend: 'up' | 'down' | 'stable';
  demandLevel: 'high' | 'medium' | 'low';
  feePercentage: number;
}

const AIMarketAnalysis = () => {
  const [marketRates, setMarketRates] = useState<MarketRate[]>([
    { loadType: 'hot-shot', currentRate: 2.5, adjustedRate: 2.0, marketTrend: 'up', demandLevel: 'high', feePercentage: 2.0 },
    { loadType: 'courier', currentRate: 3.2, adjustedRate: 2.0, marketTrend: 'up', demandLevel: 'high', feePercentage: 2.0 },
    { loadType: 'non-emergency', currentRate: 2.8, adjustedRate: 2.0, marketTrend: 'stable', demandLevel: 'medium', feePercentage: 2.0 },
    { loadType: 'emergency', currentRate: 4.5, adjustedRate: 2.0, marketTrend: 'up', demandLevel: 'high', feePercentage: 2.0 }
  ]);
  
  const [analysisTime, setAnalysisTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setMarketRates(prev => prev.map(rate => ({
        ...rate,
        currentRate: rate.currentRate + (Math.random() - 0.5) * 0.2,
        marketTrend: Math.random() > 0.7 ? (Math.random() > 0.5 ? 'up' : 'down') : rate.marketTrend,
        demandLevel: Math.random() > 0.8 ? (['high', 'medium', 'low'][Math.floor(Math.random() * 3)] as any) : rate.demandLevel
      })));
      setAnalysisTime(new Date());
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-400" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-red-400" />;
      default: return <div className="h-4 w-4 bg-yellow-400 rounded-full" />;
    }
  };

  const getDemandColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-red-600';
      case 'medium': return 'bg-yellow-600';
      default: return 'bg-green-600';
    }
  };

  return (
    <Card className="bg-gray-800 border-emerald-500/30">
      <CardHeader>
        <CardTitle className="text-emerald-400 flex items-center">
          <Brain className="h-5 w-5 mr-2" />
          AI Market Analysis - 2% Special Rate
          <Badge className="ml-2 bg-red-600 animate-pulse">
            <Zap className="h-3 w-3 mr-1" />
            LIMITED TIME
          </Badge>
        </CardTitle>
        <p className="text-xs text-gray-400">Last updated: {analysisTime.toLocaleTimeString()}</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {marketRates.map((rate, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="text-lg font-semibold text-white capitalize">
                  {rate.loadType.replace('-', ' ')}
                </div>
                <Badge className={getDemandColor(rate.demandLevel)}>
                  {rate.demandLevel} demand
                </Badge>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-sm text-gray-400">Market Rate</div>
                  <div className="text-white font-bold">{rate.currentRate.toFixed(2)}%</div>
                </div>
                
                <div className="text-right">
                  <div className="text-sm text-gray-400">AI Adjusted</div>
                  <div className="text-emerald-400 font-bold">{rate.adjustedRate.toFixed(1)}%</div>
                </div>
                
                <div className="flex items-center gap-2">
                  {getTrendIcon(rate.marketTrend)}
                  <Badge className="bg-red-600 animate-pulse">
                    SPECIAL 2%
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 p-3 bg-red-900/30 border border-red-500/50 rounded-lg">
          <div className="text-red-400 font-semibold text-sm mb-1">🔥 LIMITED TIME SPECIAL</div>
          <div className="text-white text-xs">
            AI has adjusted all eligible load types to 2% fee rate based on market analysis.
            This special rate applies to: Hot Shot, Courier, Non-Emergency, and Emergency loads.
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AIMarketAnalysis;