import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Zap, Rocket, Activity, Timer, Target } from 'lucide-react';

interface PerformanceMetrics {
  boostLevel: number;
  bookingSpeed: number;
  successRate: number;
  avgBookingTime: number;
  totalBookings: number;
  optimizationLevel: number;
}

export const PerformanceBoostPanel: React.FC = () => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    boostLevel: 75,
    bookingSpeed: 85,
    successRate: 92,
    avgBookingTime: 3.2,
    totalBookings: 1247,
    optimizationLevel: 87
  });

  const [isBoostActive, setIsBoostActive] = useState(false);

  useEffect(() => {
    const updateMetrics = () => {
      setMetrics(prev => ({
        ...prev,
        boostLevel: Math.min(100, prev.boostLevel + (isBoostActive ? 2 : -1)),
        bookingSpeed: Math.floor(Math.random() * 15) + 80,
        successRate: Math.floor(Math.random() * 8) + 90,
        avgBookingTime: Math.random() * 2 + 2,
        totalBookings: prev.totalBookings + Math.floor(Math.random() * 3),
        optimizationLevel: Math.min(100, prev.optimizationLevel + (isBoostActive ? 1 : 0))
      }));
    };

    const interval = setInterval(updateMetrics, 2000);
    return () => clearInterval(interval);
  }, [isBoostActive]);

  const handleBoostToggle = () => {
    setIsBoostActive(!isBoostActive);
  };

  const getBoostStatus = () => {
    if (metrics.optimizationLevel >= 95) return { text: '100x AI Optimization', color: 'bg-purple-500' };
    if (metrics.optimizationLevel >= 80) return { text: 'Super Boost Active', color: 'bg-green-500' };
    if (metrics.optimizationLevel >= 60) return { text: 'Boost Active', color: 'bg-blue-500' };
    return { text: 'Standard Mode', color: 'bg-gray-500' };
  };

  const boostStatus = getBoostStatus();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold">Performance Boost Control</h3>
        <Button
          onClick={handleBoostToggle}
          variant={isBoostActive ? "destructive" : "default"}
          className="flex items-center gap-2"
        >
          <Zap className="h-4 w-4" />
          {isBoostActive ? 'Disable Boost' : 'Activate Boost'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Rocket className="h-4 w-4 text-purple-500" />
              Optimization Level
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {metrics.optimizationLevel}%
            </div>
            <Badge className={`${boostStatus.color} text-white mt-2`}>
              {boostStatus.text}
            </Badge>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Activity className="h-4 w-4 text-green-500" />
              Booking Speed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {metrics.bookingSpeed}%
            </div>
            <Progress value={metrics.bookingSpeed} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Target className="h-4 w-4 text-blue-500" />
              Success Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {metrics.successRate}%
            </div>
            <p className="text-xs text-gray-600 mt-1">Auto booking success</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Timer className="h-4 w-4 text-orange-500" />
              Avg Booking Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {metrics.avgBookingTime.toFixed(1)}s
            </div>
            <p className="text-xs text-gray-600 mt-1">Lightning fast</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Real-Time Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Total Bookings Today</span>
                <span className="font-bold">{metrics.totalBookings}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Boost Level</span>
                <span className="font-bold">{metrics.boostLevel}%</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">AI Enhancement</span>
                <Badge variant="outline">Next-Gen 100x</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Status</span>
                <Badge className={isBoostActive ? 'bg-green-500' : 'bg-gray-500'}>
                  {isBoostActive ? 'ACTIVE' : 'STANDBY'}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};