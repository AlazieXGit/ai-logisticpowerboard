import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Activity, Cpu, Database, Network, Zap, TrendingUp } from 'lucide-react';

interface AISystemMetrics {
  id: string;
  name: string;
  status: 'active' | 'idle' | 'error';
  cpuUsage: number;
  memoryUsage: number;
  throughput: number;
  accuracy: number;
  uptime: string;
  lastUpdate: string;
}

export default function AISystemMonitor() {
  const [systems, setSystems] = useState<AISystemMetrics[]>([
    {
      id: 'load-matching',
      name: 'AI Load Matching',
      status: 'active',
      cpuUsage: 78,
      memoryUsage: 65,
      throughput: 1250,
      accuracy: 94.7,
      uptime: '99.8%',
      lastUpdate: '2 seconds ago'
    },
    {
      id: 'forecasting',
      name: 'Futuristic Load Forecasting',
      status: 'active',
      cpuUsage: 82,
      memoryUsage: 71,
      throughput: 890,
      accuracy: 96.2,
      uptime: '99.9%',
      lastUpdate: '1 second ago'
    },
    {
      id: 'medical',
      name: 'AI Medical System',
      status: 'idle',
      cpuUsage: 23,
      memoryUsage: 34,
      throughput: 340,
      accuracy: 98.1,
      uptime: '100%',
      lastUpdate: '5 seconds ago'
    },
    {
      id: 'transportation',
      name: 'Transportation Control',
      status: 'active',
      cpuUsage: 91,
      memoryUsage: 88,
      throughput: 2100,
      accuracy: 92.8,
      uptime: '98.7%',
      lastUpdate: '1 second ago'
    }
  ]);

  const [performanceBoost, setPerformanceBoost] = useState({
    active: false,
    multiplier: 200,
    startTime: null as Date | null,
    duration: 0
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setSystems(prev => prev.map(system => ({
        ...system,
        cpuUsage: Math.max(10, Math.min(95, system.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.max(10, Math.min(90, system.memoryUsage + (Math.random() - 0.5) * 8)),
        throughput: Math.max(100, system.throughput + (Math.random() - 0.5) * 200),
        lastUpdate: 'Just now'
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'idle': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const activatePerformanceBoost = () => {
    setPerformanceBoost({
      active: true,
      multiplier: 200,
      startTime: new Date(),
      duration: 0
    });

    setSystems(prev => prev.map(system => ({
      ...system,
      throughput: system.throughput * 2,
      accuracy: Math.min(99.9, system.accuracy + 2),
      status: 'active' as const
    })));

    setTimeout(() => {
      setPerformanceBoost(prev => ({ ...prev, active: false }));
    }, 30000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-blue-400">AI ALAZIE XPRESS - System Monitor</h2>
        <Button
          onClick={activatePerformanceBoost}
          disabled={performanceBoost.active}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          <Zap className="w-4 h-4 mr-2" />
          {performanceBoost.active ? 'BOOST ACTIVE' : '200X PERFORMANCE BOOST'}
        </Button>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {systems.map((system) => (
              <Card key={system.id} className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg text-white">{system.name}</CardTitle>
                    <Badge className={`${getStatusColor(system.status)} text-white`}>
                      {system.status.toUpperCase()}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">CPU Usage</span>
                    <span className="text-white">{system.cpuUsage}%</span>
                  </div>
                  <Progress value={system.cpuUsage} className="h-2" />
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Memory</span>
                    <span className="text-white">{system.memoryUsage}%</span>
                  </div>
                  <Progress value={system.memoryUsage} className="h-2" />
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Throughput</span>
                      <p className="text-white font-semibold">{system.throughput}/min</p>
                    </div>
                    <div>
                      <span className="text-gray-400">Accuracy</span>
                      <p className="text-white font-semibold">{system.accuracy}%</p>
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-500">
                    Last update: {system.lastUpdate}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Performance Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-400">
                    {performanceBoost.active ? '200X' : '1X'}
                  </div>
                  <div className="text-sm text-gray-400">Current Multiplier</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-400">
                    {systems.reduce((acc, sys) => acc + sys.throughput, 0).toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-400">Total Throughput/min</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-400">
                    {(systems.reduce((acc, sys) => acc + sys.accuracy, 0) / systems.length).toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-400">Average Accuracy</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">System Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {systems.map((system) => (
                    <div key={system.id} className="flex items-center justify-between">
                      <span className="text-gray-400">{system.name}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-white">{system.uptime}</span>
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(system.status)}`} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Resource Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-400">Total CPU</span>
                      <span className="text-white">
                        {Math.round(systems.reduce((acc, sys) => acc + sys.cpuUsage, 0) / systems.length)}%
                      </span>
                    </div>
                    <Progress 
                      value={systems.reduce((acc, sys) => acc + sys.cpuUsage, 0) / systems.length} 
                      className="h-2" 
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-400">Total Memory</span>
                      <span className="text-white">
                        {Math.round(systems.reduce((acc, sys) => acc + sys.memoryUsage, 0) / systems.length)}%
                      </span>
                    </div>
                    <Progress 
                      value={systems.reduce((acc, sys) => acc + sys.memoryUsage, 0) / systems.length} 
                      className="h-2" 
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">System Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-green-900/20 border border-green-700 rounded">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <div>
                    <p className="text-green-400 font-semibold">All Systems Operational</p>
                    <p className="text-sm text-gray-400">AI ALAZIE XPRESS running at optimal performance</p>
                  </div>
                </div>
                {performanceBoost.active && (
                  <div className="flex items-center space-x-3 p-3 bg-purple-900/20 border border-purple-700 rounded">
                    <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
                    <div>
                      <p className="text-purple-400 font-semibold">200X Performance Boost Active</p>
                      <p className="text-sm text-gray-400">Enhanced processing mode engaged</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}