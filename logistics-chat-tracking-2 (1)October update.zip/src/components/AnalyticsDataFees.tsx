import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, TrendingUp, DollarSign, Activity } from 'lucide-react';

const AnalyticsDataFees = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('monthly');

  const analyticsData = {
    totalRevenue: 2847592.45,
    platformFees: 284759.25,
    dataProcessingFees: 142379.62,
    transactionFees: 85427.77,
    adminFees: 28475.92
  };

  const feeBreakdown = [
    { category: 'AI Processing', fee: '2.5%', amount: 71189.81, description: 'Automated vehicle analysis' },
    { category: 'International Wire', fee: '$75 + 0.75%', amount: 21356.94, description: 'Global payment processing' },
    { category: 'Data Analytics', fee: '1.5%', amount: 42713.89, description: 'Market intelligence & reporting' },
    { category: 'Platform Usage', fee: '10%', amount: 284759.25, description: 'Core platform access' },
    { category: 'GPS Tracking', fee: '$50/vehicle', amount: 7350.00, description: 'Real-time location services' },
    { category: 'Admin Integration', fee: '1%', amount: 28475.92, description: 'Administrative overhead' }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-300 flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Analytics & Data Fees Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="bg-blue-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-blue-300 font-semibold">Total Revenue</span>
                <DollarSign className="h-4 w-4 text-blue-400" />
              </div>
              <p className="text-2xl font-bold text-green-400">${(analyticsData.totalRevenue / 1000000).toFixed(2)}M</p>
              <p className="text-xs text-gray-400">Monthly collection</p>
            </div>

            <div className="bg-purple-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-purple-300 font-semibold">Platform Fees</span>
                <TrendingUp className="h-4 w-4 text-purple-400" />
              </div>
              <p className="text-2xl font-bold text-purple-400">${(analyticsData.platformFees / 1000).toFixed(0)}K</p>
              <p className="text-xs text-gray-400">10% of transactions</p>
            </div>

            <div className="bg-green-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-green-300 font-semibold">Data Processing</span>
                <Activity className="h-4 w-4 text-green-400" />
              </div>
              <p className="text-2xl font-bold text-green-400">${(analyticsData.dataProcessingFees / 1000).toFixed(0)}K</p>
              <p className="text-xs text-gray-400">AI & analytics fees</p>
            </div>

            <div className="bg-orange-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-orange-300 font-semibold">Transaction</span>
                <DollarSign className="h-4 w-4 text-orange-400" />
              </div>
              <p className="text-2xl font-bold text-orange-400">${(analyticsData.transactionFees / 1000).toFixed(0)}K</p>
              <p className="text-xs text-gray-400">Per-transaction fees</p>
            </div>

            <div className="bg-red-800/30 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-red-300 font-semibold">Admin Fees</span>
                <Activity className="h-4 w-4 text-red-400" />
              </div>
              <p className="text-2xl font-bold text-red-400">${(analyticsData.adminFees / 1000).toFixed(0)}K</p>
              <p className="text-xs text-gray-400">1% admin overhead</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="breakdown" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="breakdown">Fee Breakdown</TabsTrigger>
          <TabsTrigger value="analytics">Analytics Data</TabsTrigger>
          <TabsTrigger value="performance">Performance Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="breakdown" className="space-y-4">
          <div className="grid gap-4">
            {feeBreakdown.map((item, index) => (
              <Card key={index} className="bg-gray-800 border-blue-500/30">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-blue-300 font-semibold">{item.category}</h3>
                        <Badge className="bg-blue-600">{item.fee}</Badge>
                      </div>
                      <p className="text-gray-400 text-sm">{item.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-green-400 font-bold text-lg">${item.amount.toLocaleString()}</p>
                      <p className="text-gray-400 text-sm">Monthly</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-green-300">Data Processing Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Vehicles Processed</span>
                    <span className="text-green-400 font-bold">147</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">AI Analysis Hours</span>
                    <span className="text-green-400 font-bold">2,847</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Data Points Collected</span>
                    <span className="text-green-400 font-bold">1.2M</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">GPS Tracking Events</span>
                    <span className="text-green-400 font-bold">847K</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-purple-300">Revenue Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Growth Rate</span>
                    <span className="text-purple-400 font-bold">+23.5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Profit Margin</span>
                    <span className="text-purple-400 font-bold">67.8%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Cost Per Acquisition</span>
                    <span className="text-purple-400 font-bold">$2,450</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">ROI</span>
                    <span className="text-purple-400 font-bold">340%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card className="bg-gray-800 border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-orange-300">Platform Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-orange-800/20 p-4 rounded-lg">
                  <h4 className="text-orange-300 font-semibold">System Uptime</h4>
                  <p className="text-2xl font-bold text-white">99.97%</p>
                  <p className="text-sm text-gray-400">Last 30 days</p>
                </div>
                <div className="bg-blue-800/20 p-4 rounded-lg">
                  <h4 className="text-blue-300 font-semibold">Processing Speed</h4>
                  <p className="text-2xl font-bold text-white">1.2s</p>
                  <p className="text-sm text-gray-400">Average response</p>
                </div>
                <div className="bg-green-800/20 p-4 rounded-lg">
                  <h4 className="text-green-300 font-semibold">Success Rate</h4>
                  <p className="text-2xl font-bold text-white">98.4%</p>
                  <p className="text-sm text-gray-400">Transaction success</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AnalyticsDataFees;