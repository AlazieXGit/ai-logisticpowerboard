import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { supabase } from '@/lib/supabase';

interface ReportConfig {
  type: 'daily' | 'weekly' | 'monthly' | 'custom';
  emailAddress: string;
  autoSend: boolean;
  includeTransactions: boolean;
  includeRevenue: boolean;
  includeAIPurchasing: boolean;
}

interface GeneratedReport {
  id: string;
  type: string;
  generatedAt: string;
  emailSent: boolean;
  status: 'generating' | 'completed' | 'failed';
}

export default function AutomatedReportGenerator() {
  const [config, setConfig] = useState<ReportConfig>({
    type: 'daily',
    emailAddress: 'alaziellc.innovation@gmail.com',
    autoSend: true,
    includeTransactions: true,
    includeRevenue: true,
    includeAIPurchasing: true
  });
  
  const [reports, setReports] = useState<GeneratedReport[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    // Mock reports data
    setReports([
      {
        id: 'RPT-001',
        type: 'Daily Summary',
        generatedAt: new Date().toISOString(),
        emailSent: true,
        status: 'completed'
      },
      {
        id: 'RPT-002',
        type: 'Weekly Analytics',
        generatedAt: new Date(Date.now() - 86400000).toISOString(),
        emailSent: true,
        status: 'completed'
      }
    ]);
  };

  const generateReport = async () => {
    setLoading(true);
    try {
      const reportData = {
        transactions: [
          { id: 'T001', amount: 1500, type: 'payment', status: 'completed' },
          { id: 'T002', amount: 2300, type: 'transfer', status: 'completed' }
        ],
        totalRevenue: 125000,
        platformFees: 3750,
        netIncome: 121250,
        accounts: {
          primary: 85000,
          escrow: 25000,
          trust: 45000,
          operating: 15000
        },
        aiPurchasing: {
          automotive: [
            { vehicle: '2024 Rolls-Royce Phantom', amount: 460000, status: 'pending' }
          ],
          realEstate: [
            { property: 'Beverly Hills Mansion', amount: 2500000, status: 'completed' }
          ]
        },
        contracts: [
          { id: 'C001', type: 'automotive', status: 'signed' },
          { id: 'RC001', type: 'real_estate', status: 'pending' }
        ]
      };

      const { data, error } = await supabase.functions.invoke('automated-report-generator', {
        body: {
          reportType: config.type,
          emailAddress: config.emailAddress,
          data: reportData
        }
      });

      if (error) throw error;

      const newReport: GeneratedReport = {
        id: data.reportId,
        type: `${config.type} Report`,
        generatedAt: new Date().toISOString(),
        emailSent: data.emailSent,
        status: 'completed'
      };

      setReports(prev => [newReport, ...prev]);

    } catch (error) {
      console.error('Report generation error:', error);
    } finally {
      setLoading(false);
    }
  };

  const scheduleAutomatedReports = async () => {
    try {
      // Schedule automated reports based on config
      console.log('Scheduling automated reports:', config);
      
      // This would integrate with a scheduling service
      alert(`Automated ${config.type} reports scheduled for ${config.emailAddress}`);
      
    } catch (error) {
      console.error('Scheduling error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Automated Report Generator</h2>
        <Badge variant="outline">Email: {config.emailAddress}</Badge>
      </div>

      <Tabs defaultValue="generate" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="generate">Generate Reports</TabsTrigger>
          <TabsTrigger value="schedule">Schedule Reports</TabsTrigger>
          <TabsTrigger value="history">Report History</TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Generate Custom Report</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Report Type</label>
                  <Select value={config.type} onValueChange={(value: any) => setConfig(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily Summary</SelectItem>
                      <SelectItem value="weekly">Weekly Analytics</SelectItem>
                      <SelectItem value="monthly">Monthly Report</SelectItem>
                      <SelectItem value="custom">Custom Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Email Address</label>
                  <Input 
                    value={config.emailAddress}
                    onChange={(e) => setConfig(prev => ({ ...prev, emailAddress: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Include Sections:</label>
                <div className="flex gap-4">
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={config.includeTransactions}
                      onChange={(e) => setConfig(prev => ({ ...prev, includeTransactions: e.target.checked }))}
                    />
                    <span className="text-sm">Transactions</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={config.includeRevenue}
                      onChange={(e) => setConfig(prev => ({ ...prev, includeRevenue: e.target.checked }))}
                    />
                    <span className="text-sm">Revenue Analytics</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={config.includeAIPurchasing}
                      onChange={(e) => setConfig(prev => ({ ...prev, includeAIPurchasing: e.target.checked }))}
                    />
                    <span className="text-sm">AI Purchasing</span>
                  </label>
                </div>
              </div>

              <Button onClick={generateReport} disabled={loading} className="w-full">
                {loading ? 'Generating Report...' : 'Generate & Send Report'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Schedule Automated Reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Frequency</label>
                  <Select value={config.type} onValueChange={(value: any) => setConfig(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily at 9:00 AM</SelectItem>
                      <SelectItem value="weekly">Weekly on Monday</SelectItem>
                      <SelectItem value="monthly">Monthly on 1st</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Auto-Send Email</label>
                  <div className="flex items-center space-x-2 mt-2">
                    <input 
                      type="checkbox" 
                      checked={config.autoSend}
                      onChange={(e) => setConfig(prev => ({ ...prev, autoSend: e.target.checked }))}
                    />
                    <span className="text-sm">Enable automatic email delivery</span>
                  </div>
                </div>
              </div>

              <Button onClick={scheduleAutomatedReports} className="w-full">
                Schedule Automated Reports
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          {reports.map((report) => (
            <Card key={report.id}>
              <CardHeader>
                <CardTitle className="flex justify-between">
                  <span>{report.type}</span>
                  <Badge variant={report.status === 'completed' ? 'default' : 'secondary'}>
                    {report.status}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm">Generated: {new Date(report.generatedAt).toLocaleString()}</p>
                  <p className="text-sm">Email Sent: {report.emailSent ? 'Yes' : 'No'}</p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">Download</Button>
                    <Button size="sm" variant="outline">Resend Email</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}