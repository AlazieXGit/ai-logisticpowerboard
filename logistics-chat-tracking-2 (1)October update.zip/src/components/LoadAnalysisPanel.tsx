import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface Load {
  id: string;
  origin: string;
  destination: string;
  status: 'pending' | 'in-transit' | 'delivered' | 'delayed';
  progress: number;
  priority: 'high' | 'medium' | 'low';
  eta: string;
}

interface LoadAnalysisPanelProps {
  onUpdate?: (loads: Load[]) => void;
}

const LoadAnalysisPanel: React.FC<LoadAnalysisPanelProps> = ({ onUpdate }) => {
  const [loads, setLoads] = useState<Load[]>([
    {
      id: 'LD001',
      origin: 'Dallas, TX',
      destination: 'Atlanta, GA',
      status: 'in-transit',
      progress: 65,
      priority: 'high',
      eta: '2h 30m'
    },
    {
      id: 'LD002',
      origin: 'Chicago, IL',
      destination: 'Denver, CO',
      status: 'delivered',
      progress: 100,
      priority: 'medium',
      eta: 'Completed'
    },
    {
      id: 'LD003',
      origin: 'Miami, FL',
      destination: 'Seattle, WA',
      status: 'pending',
      progress: 0,
      priority: 'low',
      eta: '12h 45m'
    },
    {
      id: 'LD004',
      origin: 'Phoenix, AZ',
      destination: 'Portland, OR',
      status: 'delayed',
      progress: 45,
      priority: 'high',
      eta: '6h 15m'
    }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setLoads(prevLoads => {
        const updatedLoads = prevLoads.map(load => {
          if (load.status === 'in-transit' && load.progress < 100) {
            const newProgress = Math.min(load.progress + Math.random() * 5, 100);
            return {
              ...load,
              progress: newProgress,
              status: newProgress >= 100 ? 'delivered' as const : load.status,
              eta: newProgress >= 100 ? 'Completed' : load.eta
            };
          }
          return load;
        });
        onUpdate?.(updatedLoads);
        return updatedLoads;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [onUpdate]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-500';
      case 'in-transit': return 'bg-blue-500';
      case 'pending': return 'bg-yellow-500';
      case 'delayed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-l-red-500';
      case 'medium': return 'border-l-yellow-500';
      case 'low': return 'border-l-green-500';
      default: return 'border-l-gray-500';
    }
  };

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-pink-100 border-2 border-purple-200 shadow-xl">
      <div className="p-4 border-b bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <h2 className="text-lg font-bold flex items-center gap-2">
          📊 Live Load Analysis
          <Badge variant="secondary" className="bg-white/20 text-white">
            {loads.length} Active
          </Badge>
        </h2>
      </div>
      <div className="p-4 max-h-80 overflow-y-auto">
        <div className="space-y-3">
          {loads.map((load) => (
            <div key={load.id} className={`bg-white border-l-4 ${getPriorityColor(load.priority)} rounded-lg p-3 shadow-md hover:shadow-lg transition-shadow`}>
              <div className="flex items-center justify-between mb-2">
                <div className="font-bold text-sm text-gray-800">{load.id}</div>
                <Badge className={`${getStatusColor(load.status)} text-white text-xs`}>
                  {load.status.toUpperCase()}
                </Badge>
              </div>
              <div className="text-xs text-gray-600 mb-2">
                <div className="flex items-center gap-1">
                  📍 <span className="font-semibold">{load.origin}</span>
                </div>
                <div className="flex items-center gap-1 mt-1">
                  🎯 <span className="font-semibold">{load.destination}</span>
                </div>
              </div>
              {load.status !== 'pending' && (
                <div className="mb-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Progress</span>
                    <span>{load.progress.toFixed(0)}%</span>
                  </div>
                  <Progress value={load.progress} className="h-2" />
                </div>
              )}
              <div className="flex justify-between items-center text-xs">
                <Badge variant="outline" className={`text-xs ${
                  load.priority === 'high' ? 'border-red-300 text-red-600' :
                  load.priority === 'medium' ? 'border-yellow-300 text-yellow-600' :
                  'border-green-300 text-green-600'
                }`}>
                  {load.priority.toUpperCase()} PRIORITY
                </Badge>
                <div className="text-gray-500 font-semibold">
                  ETA: {load.eta}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};

export default LoadAnalysisPanel;