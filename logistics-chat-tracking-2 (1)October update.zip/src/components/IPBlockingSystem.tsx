import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Ban, AlertTriangle } from 'lucide-react';

interface BlockedIP {
  ip: string;
  reason: string;
  timestamp: string;
  blockedBy: string;
}

const IPBlockingSystem: React.FC = () => {
  const [blockedIPs, setBlockedIPs] = useState<BlockedIP[]>([]);
  const [currentUserIP, setCurrentUserIP] = useState<string>('');

  useEffect(() => {
    // Get user's IP (simulated)
    const getUserIP = async () => {
      try {
        const response = await fetch('https://api.ipify.org?format=json');
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setCurrentUserIP(data.ip);
      } catch (error) {
        console.error('Error fetching IP:', error);
        setCurrentUserIP('192.168.1.100'); // Fallback to target IP
      }
    };
    getUserIP();

    // Load existing blocked IPs from localStorage
    try {
      const stored = localStorage.getItem('blockedIPs');
      if (stored) {
        setBlockedIPs(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading blocked IPs from localStorage:', error);
    }
  }, []);

  const blockIPImmediate = (ip: string, reason: string) => {
    const newBlock: BlockedIP = {
      ip,
      reason,
      timestamp: new Date().toISOString(),
      blockedBy: 'Super Admin Alucius'
    };

    const updated = [...blockedIPs, newBlock];
    setBlockedIPs(updated);
    localStorage.setItem('blockedIPs', JSON.stringify(updated));

    // Immediate system lockout for this IP
    if (ip === currentUserIP || ip === '192.168.1.100') {
      alert('ACCOUNT LOCKED: This IP has been immediately blocked from system access.');
      window.location.href = '/blocked';
    }
  };

  const isIPBlocked = (ip: string): boolean => {
    return blockedIPs.some(blocked => blocked.ip === ip);
  };

  // Auto-block target IP on component mount
  useEffect(() => {
    const targetIP = '192.168.1.100';
    if (!isIPBlocked(targetIP)) {
      blockIPImmediate(targetIP, 'Immediate lockout requested by Super Admin');
    }
  }, []);

  return (
    <div className="space-y-6">
      <Alert className="border-red-500 bg-red-900/20">
        <Ban className="h-4 w-4" />
        <AlertDescription className="text-red-300">
          IP 192.168.1.100 has been IMMEDIATELY LOCKED OUT of the system
        </AlertDescription>
      </Alert>

      <Card className="bg-black/80 border-red-500">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Shield className="h-6 w-6" />
            IP Blocking System - Active Lockouts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {blockedIPs.map((blocked, index) => (
              <div key={index} className="bg-red-900/20 p-4 rounded border border-red-500">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-red-300 font-mono text-lg">{blocked.ip}</p>
                    <p className="text-gray-400 text-sm">{blocked.reason}</p>
                    <p className="text-gray-500 text-xs">
                      Blocked: {new Date(blocked.timestamp).toLocaleString()}
                    </p>
                    <p className="text-gray-500 text-xs">By: {blocked.blockedBy}</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-red-400" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default IPBlockingSystem;