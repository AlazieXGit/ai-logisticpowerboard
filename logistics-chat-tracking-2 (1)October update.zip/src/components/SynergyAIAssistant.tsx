import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Bot, Send, Mic, Settings, Brain, Zap } from 'lucide-react';

const SynergyAIAssistant: React.FC = () => {
  const [message, setMessage] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [chatHistory, setChatHistory] = useState([
    { role: 'assistant', content: 'Hello! I\'m your Synergy AI Assistant. How can I help you today?' },
  ]);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    setChatHistory(prev => [...prev, 
      { role: 'user', content: message },
      { role: 'assistant', content: 'I understand your request. Let me process that for you...' }
    ]);
    setMessage('');
  };

  const aiCapabilities = [
    { name: 'Natural Language Processing', status: 'Active', fee: '$0.02/request' },
    { name: 'Code Generation', status: 'Active', fee: '$0.05/request' },
    { name: 'Data Analysis', status: 'Active', fee: '$0.03/request' },
    { name: 'Image Recognition', status: 'Active', fee: '$0.04/request' },
    { name: 'Voice Processing', status: 'Active', fee: '$0.06/request' },
  ];

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <Card className="bg-slate-800/50 border-purple-500/20 h-[600px] flex flex-col">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center">
                <Bot className="h-6 w-6 mr-2 text-purple-400" />
                Synergy AI Assistant
              </CardTitle>
              <Badge className="bg-green-600/20 text-green-300">Online</Badge>
            </div>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {chatHistory.map((msg, index) => (
                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    msg.role === 'user' 
                      ? 'bg-purple-600 text-white' 
                      : 'bg-slate-700 text-gray-300'
                  }`}>
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Ask me anything..."
                className="bg-slate-700 border-slate-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              <Button
                onClick={() => setIsListening(!isListening)}
                variant="outline"
                className={`${isListening ? 'bg-red-600' : 'bg-slate-700'} border-slate-600`}
              >
                <Mic className="h-4 w-4" />
              </Button>
              <Button onClick={handleSendMessage} className="bg-purple-600 hover:bg-purple-700">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card className="bg-slate-800/50 border-purple-500/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Brain className="h-5 w-5 mr-2 text-purple-400" />
              AI Capabilities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {aiCapabilities.map((capability, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-slate-700/50 rounded">
                  <div>
                    <div className="text-white text-sm">{capability.name}</div>
                    <div className="text-purple-400 text-xs">{capability.fee}</div>
                  </div>
                  <Badge className="bg-green-600/20 text-green-300 text-xs">
                    {capability.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-purple-500/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Zap className="h-5 w-5 mr-2 text-yellow-400" />
              Usage Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-300">Requests</span>
                <span className="text-white">1,247</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Revenue</span>
                <span className="text-green-400">$89.42</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Active Users</span>
                <span className="text-blue-400">342</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
          <Settings className="h-4 w-4 mr-2" />
          Configure Assistant
        </Button>
      </div>
    </div>
  );
};

export default SynergyAIAssistant;