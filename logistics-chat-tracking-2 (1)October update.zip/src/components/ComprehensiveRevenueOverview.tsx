import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, DollarSign, Activity, Target, 
  Download, BarChart3, PieChart, Zap 
} from 'lucide-react';

interface PlatformData {
  platform: string;
  revenue: number;
  transactions: number;
  growthRate: number;
  status: 'active' | 'processing' | 'optimizing';
  fees: number;
  netProfit: number;
}

const ComprehensiveRevenueOverview: React.FC = () => {
  const [platformData] = useState<PlatformData[]>([
    {
      platform: 'Trust Banking System',
      revenue: 15800000,
      transactions: 18420,
      growthRate: 28.7,
      status: 'active',
      fees: 158000,
      netProfit: 15642000
    },
    {
      platform: 'AI Loadboard Platform',
      revenue: 9200000,
      transactions: 12850,
      growthRate: 31.4,
      status: 'active',
      fees: 92000,
      netProfit: 9108000
    },
    {
      platform: 'Payment Processing',
      revenue: 7500000,
      transactions: 8950,
      growthRate: 25.8,
      status: 'active',
      fees: 75000,
      netProfit: 7425000
    },
    {
      platform: 'Credit Repair AI',
      revenue: 6200000,
      transactions: 4200,
      growthRate: 35.2,
      status: 'optimizing',
      fees: 62000,
      netProfit: 6138000
    },
    {
      platform: 'Automotive AI',
      revenue: 5600000,
      transactions: 2850,
      growthRate: 29.6,
      status: 'active',
      fees: 56000,
      netProfit: 5544000
    }
  ]);

  const totalRevenue = platformData.reduce((sum, p) => sum + p.revenue, 0);
  const totalTransactions = platformData.reduce((sum, p) => sum + p.transactions, 0);
  const avgGrowthRate = platformData.reduce((sum, p) => sum + p.growthRate, 0) / platformData.length;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-emerald-600 to-green-700 text-white">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-3xl font-bold flex items-center gap-2">
                <TrendingUp className="h-8 w-8" />
                Enhanced Revenue Tracking Dashboard
              </CardTitle>
              <p className="text-emerald-100 mt-2">Real-time platform revenue analysis with advanced metrics</p>
              <p className="text-emerald-200 text-sm mt-1">Alazie LLC EIN: 82-1155909</p>
            </div>
            <Button className="bg-white text-emerald-600 hover:bg-emerald-50">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <p className="text-emerald-200 text-sm">Total Combined Revenue</p>
              <p className="text-4xl font-bold">${totalRevenue.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-emerald-200 text-sm">Active Platforms</p>
              <p className="text-3xl font-bold">{platformData.length}</p>
            </div>
            <div>
              <p className="text-emerald-200 text-sm">Total Transactions</p>
              <p className="text-3xl font-bold">{totalTransactions.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-emerald-200 text-sm">Avg Growth Rate</p>
              <p className="text-3xl font-bold">{avgGrowthRate.toFixed(1)}%</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Platform Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="development">Development</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {platformData.map((platform) => (
              <Card key={platform.platform} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{platform.platform}</span>
                    <Badge className={`${
                      platform.status === 'active' ? 'bg-green-500' :
                      platform.status === 'processing' ? 'bg-yellow-500' : 'bg-blue-500'
                    } text-white`}>
                      {platform.status.toUpperCase()}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Revenue</span>
                      <span className="text-2xl font-bold text-green-600">
                        ${platform.revenue.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Transactions</span>
                      <span className="font-medium">{platform.transactions.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Growth Rate</span>
                      <span className="text-green-500 font-bold">+{platform.growthRate}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Net Profit</span>
                      <span className="text-emerald-600 font-semibold">
                        ${platform.netProfit.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Revenue Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {platformData.map((platform) => (
                    <div key={platform.platform} className="flex items-center justify-between">
                      <span className="text-sm">{platform.platform}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full"
                            style={{ 
                              width: `${(platform.revenue / Math.max(...platformData.map(p => p.revenue))) * 100}%` 
                            }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">
                          ${(platform.revenue / 1000000).toFixed(1)}M
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Fees Collected</span>
                    <span className="font-bold text-red-500">
                      ${platformData.reduce((sum, p) => sum + p.fees, 0).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Net Profit</span>
                    <span className="font-bold text-green-500">
                      ${platformData.reduce((sum, p) => sum + p.netProfit, 0).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Profit Margin</span>
                    <span className="font-bold text-blue-500">
                      {((platformData.reduce((sum, p) => sum + p.netProfit, 0) / totalRevenue) * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Platform Integrations & Components
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  'Stripe Payment Gateway',
                  'Synergy Router System', 
                  'Banking Direct Integration',
                  'Trust Account Management',
                  'AI Loadboard System',
                  'Credit Repair Platform',
                  'Automotive AI Services',
                  'Real-time Analytics',
                  'Revenue Tracking'
                ].map((integration) => (
                  <div key={integration} className="p-3 bg-gray-50 rounded-lg border">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{integration}</span>
                      <Badge className="bg-green-500 text-white text-xs">ACTIVE</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="development" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Integrated Development Platform
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-gray-900 rounded-lg">
                  <div className="text-green-400 font-mono text-sm">
                    // Super Admin Development Access
                    <br />
                    // Real-time code editing and infrastructure management
                    <br />
                    // Available functions: edit, preview, deploy, monitor
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Code Editor
                  </Button>
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    Infrastructure Preview
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ComprehensiveRevenueOverview;