import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  Activity,
  BarChart3,
  PieChart,
  LineChart,
  Target
} from 'lucide-react';

interface AnalyticsData {
  totalRevenue: number;
  activeUsers: number;
  aiProcessingVolume: number;
  automationEfficiency: number;
  creditRepairSuccess: number;
  platformGrowth: number;
}

export const SynergyPlatformAnalytics: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalRevenue: 0,
    activeUsers: 0,
    aiProcessingVolume: 0,
    automationEfficiency: 0,
    creditRepairSuccess: 0,
    platformGrowth: 0
  });

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadAnalytics();
    const interval = setInterval(loadAnalytics, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadAnalytics = async () => {
    setIsLoading(true);
    try {
      // Simulate real-time analytics data
      setAnalytics({
        totalRevenue: Math.floor(Math.random() * 1000000) + 500000,
        activeUsers: Math.floor(Math.random() * 10000) + 5000,
        aiProcessingVolume: Math.floor(Math.random() * 50000) + 25000,
        automationEfficiency: Math.floor(Math.random() * 30) + 70,
        creditRepairSuccess: Math.floor(Math.random() * 20) + 75,
        platformGrowth: Math.floor(Math.random() * 15) + 10
      });
    } catch (error) {
      console.error('Analytics loading error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Platform Analytics</h2>
          <p className="text-gray-400">Comprehensive Synergy AI Performance Metrics</p>
        </div>
        <Button onClick={loadAnalytics} disabled={isLoading} className="bg-blue-600 hover:bg-blue-700">
          {isLoading ? 'Refreshing...' : 'Refresh Data'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${analytics.totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-green-400">+{analytics.platformGrowth}% from last month</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Active Users</CardTitle>
            <Users className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{analytics.activeUsers.toLocaleString()}</div>
            <p className="text-xs text-blue-400">Real-time active sessions</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">AI Processing</CardTitle>
            <Activity className="h-4 w-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{analytics.aiProcessingVolume.toLocaleString()}</div>
            <p className="text-xs text-purple-400">Requests processed today</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Success Rate</CardTitle>
            <Target className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{analytics.creditRepairSuccess}%</div>
            <p className="text-xs text-green-400">Credit repair success</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">System Performance</CardTitle>
              <CardDescription className="text-gray-400">Real-time platform metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Automation Efficiency</span>
                  <span className="text-white">{analytics.automationEfficiency}%</span>
                </div>
                <Progress value={analytics.automationEfficiency} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">AI Response Time</span>
                  <span className="text-green-400">0.3s avg</span>
                </div>
                <Progress value={90} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Revenue Streams</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">AI Processing Fees</span>
                    <Badge variant="secondary">${(analytics.totalRevenue * 0.4).toLocaleString()}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Credit Repair Services</span>
                    <Badge variant="secondary">${(analytics.totalRevenue * 0.3).toLocaleString()}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Automation Tools</span>
                    <Badge variant="secondary">${(analytics.totalRevenue * 0.2).toLocaleString()}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Platform Subscriptions</span>
                    <Badge variant="secondary">${(analytics.totalRevenue * 0.1).toLocaleString()}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Growth Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Monthly Growth</span>
                    <div className="flex items-center">
                      <TrendingUp className="h-4 w-4 text-green-400 mr-1" />
                      <span className="text-green-400">{analytics.platformGrowth}%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">User Retention</span>
                    <span className="text-blue-400">94%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">AI Accuracy</span>
                    <span className="text-purple-400">98.7%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="automation" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Automation Hub Status</CardTitle>
              <CardDescription className="text-gray-400">Intelligent workflow performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">247</div>
                  <p className="text-sm text-gray-300">Active Workflows</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">15.2k</div>
                  <p className="text-sm text-gray-300">Tasks Completed</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">99.1%</div>
                  <p className="text-sm text-gray-300">Success Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">AI-Generated Insights</CardTitle>
              <CardDescription className="text-gray-400">Intelligent platform recommendations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-800">
                  <h4 className="font-semibold text-blue-400">Revenue Optimization</h4>
                  <p className="text-sm text-gray-300 mt-1">AI suggests increasing automation fees by 12% could boost revenue by $47k monthly.</p>
                </div>
                <div className="p-4 bg-green-900/20 rounded-lg border border-green-800">
                  <h4 className="font-semibold text-green-400">User Engagement</h4>
                  <p className="text-sm text-gray-300 mt-1">Credit repair success rate improvements detected. Consider expanding service offerings.</p>
                </div>
                <div className="p-4 bg-purple-900/20 rounded-lg border border-purple-800">
                  <h4 className="font-semibold text-purple-400">System Performance</h4>
                  <p className="text-sm text-gray-300 mt-1">AI processing efficiency up 23% this week. Optimal performance maintained.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};