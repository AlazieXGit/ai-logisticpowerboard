import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { TrendingUp, ArrowRight, Building2, Zap, CheckCircle, Lock, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface RevenueSource {
  id: string;
  name: string;
  platform: string;
  currentAccount: string;
  monthlyRevenue: number;
  status: 'active' | 'redirecting' | 'locked';
  redirectEnabled: boolean;
  lockedIndefinitely: boolean;
}

const RevenueRedirectionSystem: React.FC = () => {
  const [revenueSources, setRevenueSources] = useState<RevenueSource[]>([]);
  const [homeAccount] = useState('Revocable Trust for Alucius Alford - TRUST-AA-2024-001');
  const [isLocked, setIsLocked] = useState(true);
  const [memorandumReceived, setMemorandumReceived] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadRevenueSources();
    lockAllRevenueIndefinitely();
  }, []);

  const loadRevenueSources = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_revenue_sources' }
      });
      
      if (error) throw error;
      const sources = data.sources || [];
      // Mark all as locked indefinitely
      setRevenueSources(sources.map(source => ({
        ...source,
        status: 'locked' as const,
        redirectEnabled: true,
        lockedIndefinitely: true
      })));
    } catch (error) {
      console.error('Error loading revenue sources:', error);
    }
  };

  const lockAllRevenueIndefinitely = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'lock_revenue_indefinitely',
          trustAccount: homeAccount,
          authorizedBy: 'System - Pending Alucius Alford Memorandum'
        }
      });

      if (error) throw error;
      
      toast({ 
        title: 'Revenue Locked', 
        description: 'All revenue redirected to trust and locked indefinitely until memorandum from Alucius Alford',
        variant: 'default'
      });
    } catch (error) {
      console.error('Error locking revenue:', error);
    }
  };

  const attemptUnlock = () => {
    if (!memorandumReceived) {
      toast({ 
        title: 'Access Denied', 
        description: 'Revenue remains locked until memorandum is received from Alucius Alford',
        variant: 'destructive'
      });
      return;
    }
    
    // This would require additional authentication in a real system
    setIsLocked(false);
    toast({ 
      title: 'Revenue Unlocked', 
      description: 'Revenue redirection unlocked by Alucius Alford memorandum',
    });
  };

  const totalMonthlyRevenue = revenueSources.reduce((sum, source) => sum + source.monthlyRevenue, 0);
  const redirectedRevenue = revenueSources
    .filter(source => source.redirectEnabled)
    .reduce((sum, source) => sum + source.monthlyRevenue, 0);

  return (
    <div className="space-y-6">
      <Card className="bg-red-900/20 border-red-500">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Lock className="h-5 w-5" />
            REVENUE LOCKED INDEFINITELY
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-red-900/30 p-4 rounded-lg border border-red-500">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-5 w-5 text-red-400" />
              <span className="text-red-300 font-bold">HARD COPY REVENUE RESOURCE REDIRECT - LOCKED</span>
            </div>
            <p className="text-red-200 text-sm">
              All revenue sources have been permanently redirected to the Revocable Trust for Alucius Alford.
              This lock cannot be removed until a memorandum is received from Alucius Alford.
            </p>
          </div>
          
          <div className="space-y-2">
            <Label className="text-red-300">Trust Account (Locked Destination)</Label>
            <Input
              value={homeAccount}
              disabled
              className="bg-red-900/20 border-red-500 text-red-200"
            />
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <input 
                type="checkbox" 
                checked={memorandumReceived}
                onChange={(e) => setMemorandumReceived(e.target.checked)}
                className="rounded"
              />
              <Label className="text-yellow-300">Memorandum received from Alucius Alford</Label>
            </div>
            <Button 
              onClick={attemptUnlock}
              disabled={!memorandumReceived}
              className="bg-yellow-600 hover:bg-yellow-700 disabled:bg-gray-600"
            >
              Attempt Unlock
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Revenue Status Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-emerald-900/20 p-4 rounded-lg border border-emerald-500/30">
              <div className="text-emerald-300 text-sm">Total Monthly Revenue</div>
              <div className="text-2xl font-bold text-white">${totalMonthlyRevenue.toLocaleString()}</div>
            </div>
            <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
              <div className="text-red-300 text-sm">Locked & Redirected</div>
              <div className="text-2xl font-bold text-white">${redirectedRevenue.toLocaleString()}</div>
            </div>
            <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
              <div className="text-red-300 text-sm">Lock Status</div>
              <div className="text-2xl font-bold text-red-400">INDEFINITE</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {revenueSources.map((source) => (
          <Card key={source.id} className="bg-gray-800 border-red-500/30">
            <CardHeader>
              <CardTitle className="text-red-400 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  {source.name}
                </div>
                <Badge className="bg-red-600">
                  <Lock className="h-3 w-3 mr-1" />
                  LOCKED
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-300">Platform:</span>
                  <span className="text-white">{source.platform}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Monthly Revenue:</span>
                  <span className="text-emerald-400 font-bold">${source.monthlyRevenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Redirected To:</span>
                  <span className="text-red-300 text-sm">Trust Account</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-3 border-t border-red-500/30">
                <div className="flex items-center gap-2">
                  <span className="text-red-300">Status:</span>
                  <span className="text-red-400 font-bold">LOCKED INDEFINITELY</span>
                </div>
                <div className="flex items-center gap-1 text-red-400">
                  <ArrowRight className="h-4 w-4" />
                  <span className="text-xs">TRUST</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RevenueRedirectionSystem;