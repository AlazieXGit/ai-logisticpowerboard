import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Building2, DollarSign, CheckCircle, AlertCircle, Link } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

export const PlaidIntegration = () => {
  const { toast } = useToast();
  const [transferAmount, setTransferAmount] = useState('');
  const [processing, setProcessing] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState('');
  
  // Original Plaid configuration
  const plaidConfig = {
    clientId: 'PLAID_CLIENT_ID',
    secret: 'PLAID_SECRET',
    environment: 'sandbox',
    products: ['transactions', 'auth', 'identity']
  };

  const connectedAccounts = [
    {
      id: 'acc_1',
      name: 'Wells Fargo Business Checking',
      accountNumber: '****5678',
      routingNumber: '026009593',
      balance: 125000.50,
      status: 'connected'
    },
    {
      id: 'acc_2', 
      name: 'PNC Bank Business Savings',
      accountNumber: '****1234',
      routingNumber: '043000096',
      balance: 67543.21,
      status: 'connected'
    },
    {
      id: 'acc_3',
      name: 'Chase Business Account',
      accountNumber: '****9876',
      routingNumber: '021000021',
      balance: 89765.44,
      status: 'pending'
    }
  ];

  const processACHTransfer = async () => {
    if (!transferAmount || parseFloat(transferAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid transfer amount",
        variant: "destructive"
      });
      return;
    }

    if (!selectedAccount) {
      toast({
        title: "No Account Selected",
        description: "Please select a bank account",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          amount: parseFloat(transferAmount),
          account_id: selectedAccount,
          transfer_type: 'ach',
          description: `Plaid ACH Transfer - $${transferAmount}`
        }
      });

      if (error) throw error;

      toast({
        title: "Transfer Initiated",
        description: `ACH transfer of $${transferAmount} initiated successfully`,
      });
      
      setTransferAmount('');
      setSelectedAccount('');
    } catch (error) {
      console.error('Transfer error:', error);
      toast({
        title: "Transfer Failed",
        description: "Unable to process ACH transfer. Please try again.",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-blue-900 border-green-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            PLAID BANKING INTEGRATION
            <Badge className="bg-green-600">CONNECTED</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">ACH Transfer Processor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Select Bank Account</label>
              <select 
                value={selectedAccount}
                onChange={(e) => setSelectedAccount(e.target.value)}
                className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
              >
                <option value="">Select Account</option>
                {connectedAccounts.map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.name} - {account.accountNumber}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Transfer Amount ($)</label>
              <Input
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <Button 
              onClick={processACHTransfer}
              disabled={processing}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              {processing ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Processing...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Process ACH Transfer
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Plaid Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-400" />
                <span className="text-green-400 text-sm">Sandbox Mode Active</span>
              </div>
              <div className="space-y-2">
                <label className="text-gray-400 text-sm">Client ID</label>
                <code className="block bg-gray-700 p-2 rounded text-xs text-green-400">
                  {plaidConfig.clientId}
                </code>
              </div>
              <div className="space-y-2">
                <label className="text-gray-400 text-sm">Environment</label>
                <Badge className="bg-yellow-600">{plaidConfig.environment}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Connected Bank Accounts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {connectedAccounts.map((account) => (
              <div key={account.id} className="flex justify-between items-center p-3 border border-gray-600 rounded">
                <div>
                  <p className="text-white font-semibold">{account.name}</p>
                  <p className="text-gray-400 text-sm">
                    {account.accountNumber} • Routing: {account.routingNumber}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold">${account.balance.toLocaleString()}</p>
                  <Badge className={
                    account.status === 'connected' ? 'bg-green-600' : 
                    account.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                  }>
                    {account.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Recent ACH Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { id: 'ach_1234567890', amount: 2500.00, status: 'completed', date: '2025-01-07 14:30', account: 'Wells Fargo ****5678' },
              { id: 'ach_0987654321', amount: 1750.50, status: 'pending', date: '2025-01-07 13:15', account: 'PNC Bank ****1234' },
              { id: 'ach_1122334455', amount: 5000.00, status: 'completed', date: '2025-01-07 12:45', account: 'Chase ****9876' }
            ].map((transaction) => (
              <div key={transaction.id} className="flex justify-between items-center p-3 border border-gray-600 rounded">
                <div>
                  <p className="text-white font-mono text-sm">{transaction.id}</p>
                  <p className="text-gray-400 text-xs">{transaction.account}</p>
                  <p className="text-gray-400 text-xs">{transaction.date}</p>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold">${transaction.amount.toLocaleString()}</p>
                  <Badge className={
                    transaction.status === 'completed' ? 'bg-green-600' : 
                    transaction.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                  }>
                    {transaction.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PlaidIntegration;