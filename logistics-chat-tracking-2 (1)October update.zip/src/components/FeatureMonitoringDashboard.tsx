import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Activity, AlertTriangle, TrendingUp, Users, Zap, XCircle } from 'lucide-react';

interface FeatureHealth {
  feature_name: string;
  status: 'healthy' | 'degraded' | 'critical' | 'disabled';
  error_rate: number;
  avg_response_time: number;
  active_users: number;
  total_requests: number;
  failed_requests: number;
}

interface FeatureAlert {
  id: string;
  feature_name: string;
  alert_type: string;
  severity: string;
  message: string;
  created_at: string;
  acknowledged: boolean;
}

export default function FeatureMonitoringDashboard() {
  const [features, setFeatures] = useState<FeatureHealth[]>([]);
  const [alerts, setAlerts] = useState<FeatureAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeWindow, setTimeWindow] = useState(60);
  const [apiError, setApiError] = useState(false);

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 10000); // Update every 10s
    return () => clearInterval(interval);
  }, [timeWindow]);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(`/api/monitoring/dashboard?time_window=${timeWindow}`);
      
      // Check if response is ok and is JSON
      if (!response.ok) {
        throw new Error(`API returned ${response.status}`);
      }
      
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('API did not return JSON');
      }
      
      const data = await response.json();
      setFeatures(data.health || []);
      setAlerts(data.alerts || []);
      setApiError(false);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching monitoring data:', error);
      setApiError(true);
      // Use mock data as fallback
      setFeatures([
        { feature_name: 'Payment Processing', status: 'healthy', error_rate: 0.5, avg_response_time: 120, active_users: 45, total_requests: 1250, failed_requests: 6 },
        { feature_name: 'Trust Account System', status: 'healthy', error_rate: 0.2, avg_response_time: 95, active_users: 32, total_requests: 890, failed_requests: 2 },
        { feature_name: 'AI Dispatch Agent', status: 'degraded', error_rate: 3.5, avg_response_time: 450, active_users: 18, total_requests: 340, failed_requests: 12 },
        { feature_name: 'Loadboard System', status: 'healthy', error_rate: 1.1, avg_response_time: 180, active_users: 67, total_requests: 2100, failed_requests: 23 },
      ]);
      setAlerts([]);
      setLoading(false);
    }
  };


  const acknowledgeAlert = async (alertId: string) => {
    try {
      await fetch(`/api/monitoring/alerts/${alertId}/acknowledge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ admin_id: 'current-user-id' })
      });
      fetchDashboardData();
    } catch (error) {
      console.error('Error acknowledging alert:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'bg-green-500';
      case 'degraded': return 'bg-yellow-500';
      case 'critical': return 'bg-red-500';
      case 'disabled': return 'bg-gray-500';
      default: return 'bg-gray-400';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  const criticalFeatures = features.filter(f => f.status === 'critical' || f.status === 'disabled');
  const degradedFeatures = features.filter(f => f.status === 'degraded');
  const healthyFeatures = features.filter(f => f.status === 'healthy');

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-900 to-slate-800 min-h-screen">
      {apiError && (
        <Alert className="bg-yellow-900/20 border-yellow-700">
          <AlertTriangle className="h-4 w-4 text-yellow-400" />
          <AlertDescription className="text-yellow-200">
            Backend API unavailable. Displaying mock data for demonstration.
          </AlertDescription>
        </Alert>
      )}
      
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Feature Monitoring Dashboard</h1>
          <p className="text-slate-400">Real-time feature health and performance tracking</p>
        </div>
        <div className="flex gap-2">
          {[15, 60, 240, 1440].map(minutes => (
            <Button
              key={minutes}
              variant={timeWindow === minutes ? 'default' : 'outline'}
              onClick={() => setTimeWindow(minutes)}
              size="sm"
            >
              {minutes < 60 ? `${minutes}m` : `${minutes / 60}h`}
            </Button>
          ))}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Total Features</p>
                <p className="text-3xl font-bold text-white">{features.length}</p>
              </div>
              <Activity className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-900/20 border-green-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-400">Healthy</p>
                <p className="text-3xl font-bold text-white">{healthyFeatures.length}</p>
              </div>
              <Zap className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-900/20 border-yellow-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-yellow-400">Degraded</p>
                <p className="text-3xl font-bold text-white">{degradedFeatures.length}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-900/20 border-red-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-400">Critical</p>
                <p className="text-3xl font-bold text-white">{criticalFeatures.length}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Alerts */}
      {alerts.length > 0 && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              Active Alerts ({alerts.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {alerts.map(alert => (
              <Alert key={alert.id} className="bg-slate-700 border-slate-600">
                <AlertDescription className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant={getSeverityColor(alert.severity) as any}>
                      {alert.severity}
                    </Badge>
                    <span className="text-white font-medium">{alert.feature_name}</span>
                    <span className="text-slate-300">{alert.message}</span>
                  </div>
                  {!alert.acknowledged && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => acknowledgeAlert(alert.id)}
                    >
                      Acknowledge
                    </Button>
                  )}
                </AlertDescription>
              </Alert>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Feature Health Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {features.map(feature => (
          <Card key={feature.feature_name} className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white text-lg">{feature.feature_name}</CardTitle>
                <Badge className={getStatusColor(feature.status)}>
                  {feature.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-400">Error Rate</p>
                  <p className="text-2xl font-bold text-white">{feature.error_rate.toFixed(2)}%</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400">Avg Response</p>
                  <p className="text-2xl font-bold text-white">{feature.avg_response_time.toFixed(0)}ms</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400">Active Users</p>
                  <p className="text-2xl font-bold text-white">{feature.active_users}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400">Total Requests</p>
                  <p className="text-2xl font-bold text-white">{feature.total_requests}</p>
                </div>
              </div>
              
              {feature.failed_requests > 0 && (
                <div className="pt-2 border-t border-slate-700">
                  <p className="text-sm text-red-400">
                    {feature.failed_requests} failed requests
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
