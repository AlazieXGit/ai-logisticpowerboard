import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Copy, Eye, EyeOff } from 'lucide-react';

const ComprehensiveBankingSystemsPlatform = () => {
  const [showSensitive, setShowSensitive] = useState(false);
  const [activeBank, setActiveBank] = useState('pnc');

  const bankingProfiles = {
    pnc: {
      name: 'PNC Bank - XPRESS AI MASTER',
      accounts: [
        {
          nickname: 'XPRESS-AI-MASTER',
          accountNumber: '5563935267',
          routingNumber: '054000030',
          accountType: 'Primary Operating',
          balance: '$2,847,592.45',
          swiftCode: 'PNCCUS33',
          fedWire: '054000030',
          address: '300 Fifth Avenue, Pittsburgh, PA 15222',
          dailyLimit: '$1,000,000',
          monthlyFee: '$25',
          transactionFee: '$0.50'
        },
        {
          nickname: 'RESERVE-FUND',
          accountNumber: '5563935275',
          routingNumber: '054000030',
          accountType: 'Reserve Account',
          balance: '$1,456,789.23',
          swiftCode: 'PNCCUS33',
          fedWire: '054000030',
          address: '300 Fifth Avenue, Pittsburgh, PA 15222',
          dailyLimit: '$500,000',
          monthlyFee: '$15',
          transactionFee: '$0.25'
        }
      ]
    },
    wellsfargo: {
      name: 'Wells Fargo - Corporate Banking',
      accounts: [
        {
          nickname: 'WF-CORPORATE-MAIN',
          accountNumber: '4567891234',
          routingNumber: '121000248',
          accountType: 'Business Checking',
          balance: '$3,245,678.90',
          swiftCode: 'WFBIUS6S',
          fedWire: '121000248',
          address: '420 Montgomery Street, San Francisco, CA 94104',
          dailyLimit: '$2,000,000',
          monthlyFee: '$35',
          transactionFee: '$0.75'
        }
      ]
    },
    chase: {
      name: 'JPMorgan Chase - Business Elite',
      accounts: [
        {
          nickname: 'CHASE-ELITE-CORP',
          accountNumber: '7891234567',
          routingNumber: '021000021',
          accountType: 'Corporate Elite',
          balance: '$5,678,901.23',
          swiftCode: 'CHASUS33',
          fedWire: '021000021',
          address: '270 Park Avenue, New York, NY 10017',
          dailyLimit: '$5,000,000',
          monthlyFee: '$50',
          transactionFee: '$1.00'
        }
      ]
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Comprehensive Banking Systems Platform</h2>
        <Button
          onClick={() => setShowSensitive(!showSensitive)}
          variant="outline"
          size="sm"
          className="text-white border-white/20"
        >
          {showSensitive ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
          {showSensitive ? 'Hide' : 'Show'} Sensitive Data
        </Button>
      </div>

      <Tabs value={activeBank} onValueChange={setActiveBank} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="pnc" className="text-white">PNC Bank</TabsTrigger>
          <TabsTrigger value="wellsfargo" className="text-white">Wells Fargo</TabsTrigger>
          <TabsTrigger value="chase" className="text-white">Chase Bank</TabsTrigger>
        </TabsList>

        {Object.entries(bankingProfiles).map(([key, bank]) => (
          <TabsContent key={key} value={key} className="space-y-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  {bank.name}
                  <Badge variant="secondary">{bank.accounts.length} Account{bank.accounts.length > 1 ? 's' : ''}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {bank.accounts.map((account, index) => (
                  <div key={index} className="bg-gray-900 p-4 rounded-lg space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-semibold text-white">{account.nickname}</h3>
                      <Badge className="bg-green-600">{account.accountType}</Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Account Number</p>
                        <div className="flex items-center space-x-2">
                          <p className="text-white font-mono">
                            {showSensitive ? account.accountNumber : '****' + account.accountNumber.slice(-4)}
                          </p>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(account.accountNumber)}
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Routing Number</p>
                        <div className="flex items-center space-x-2">
                          <p className="text-white font-mono">{account.routingNumber}</p>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(account.routingNumber)}
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Balance</p>
                        <p className="text-white font-semibold text-lg">{account.balance}</p>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">SWIFT Code</p>
                        <p className="text-white font-mono">{account.swiftCode}</p>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Fed Wire</p>
                        <p className="text-white font-mono">{account.fedWire}</p>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Daily Limit</p>
                        <p className="text-white">{account.dailyLimit}</p>
                      </div>
                    </div>
                    
                    <div className="pt-2 border-t border-gray-700">
                      <p className="text-sm text-gray-400 mb-1">Bank Address</p>
                      <p className="text-white text-sm">{account.address}</p>
                    </div>
                    
                    <div className="flex space-x-4 text-sm">
                      <span className="text-gray-400">Monthly Fee: <span className="text-white">{account.monthlyFee}</span></span>
                      <span className="text-gray-400">Transaction Fee: <span className="text-white">{account.transactionFee}</span></span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default ComprehensiveBankingSystemsPlatform;