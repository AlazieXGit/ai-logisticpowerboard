import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Copy, ArrowRight, Building2, CreditCard, TrendingUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const AccountConnectionsOverview = () => {
  const { toast } = useToast();

  const externalConnections = [
    {
      id: 'wells-fargo-primary',
      bankName: 'Wells Fargo Bank',
      accountNumber: '4567891234',
      routingNumber: '121000248',
      accountType: 'Business Checking',
      balance: 1847592.34,
      status: 'Active',
      connectionType: 'Primary Operating'
    },
    {
      id: 'chase-reserve',
      bankName: 'JPMorgan Chase Bank',
      accountNumber: '8901234567',
      routingNumber: '021000021',
      accountType: 'Business Savings',
      balance: 2456789.12,
      status: 'Active',
      connectionType: 'Reserve Fund'
    },
    {
      id: 'boa-investment',
      bankName: 'Bank of America',
      accountNumber: '2345678901',
      routingNumber: '026009593',
      accountType: 'Investment Account',
      balance: 987654.89,
      status: 'Active',
      connectionType: 'Growth Investment'
    },
    {
      id: 'regions-escrow',
      bankName: 'Regions Bank',
      accountNumber: '6789012345',
      routingNumber: '062000019',
      accountType: 'Escrow Account',
      balance: 3456789.67,
      status: 'Active',
      connectionType: 'Trust & Escrow'
    }
  ];

  const transactionFlow = [
    {
      id: 'tx-001',
      amount: 125000.00,
      origin: { bank: 'Wells Fargo', account: '4567891234' },
      destination: { bank: 'PNC Virtual', account: '5563935267' },
      date: '2024-01-15',
      type: 'Wire Transfer',
      status: 'Completed'
    },
    {
      id: 'tx-002', 
      amount: 89500.00,
      origin: { bank: 'Chase Bank', account: '8901234567' },
      destination: { bank: 'PNC Virtual', account: '5563935275' },
      date: '2024-01-14',
      type: 'ACH Transfer',
      status: 'Completed'
    },
    {
      id: 'tx-003',
      amount: 234000.00,
      origin: { bank: 'PNC Virtual', account: '5563935267' },
      destination: { bank: 'Bank of America', account: '2345678901' },
      date: '2024-01-13',
      type: 'Investment Transfer',
      status: 'Completed'
    }
  ];

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: `${label} copied successfully`,
    });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900 to-blue-900 border-purple-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            EXTERNAL ACCOUNT CONNECTIONS OVERVIEW
            <Badge className="bg-green-600">ALL CONNECTED ACCOUNTS</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid gap-4">
        {externalConnections.map((connection) => (
          <Card key={connection.id} className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <h3 className="text-white font-semibold text-lg">{connection.bankName}</h3>
                    <Badge className={connection.status === 'Active' ? 'bg-green-600' : 'bg-red-600'}>
                      {connection.status}
                    </Badge>
                  </div>
                  <p className="text-gray-400">{connection.connectionType} • {connection.accountType}</p>
                  <div className="flex gap-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(connection.accountNumber, 'Account Number')}
                    >
                      <Copy className="h-4 w-4 mr-1" />
                      {connection.accountNumber}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(connection.routingNumber, 'Routing Number')}
                    >
                      <Copy className="h-4 w-4 mr-1" />
                      {connection.routingNumber}
                    </Button>
                  </div>
                </div>
                <div className="text-right">
                  <Badge className="bg-blue-600 text-lg px-3 py-1">
                    ${connection.balance.toLocaleString()}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="h-6 w-6" />
            TRANSACTION FLOW CHART
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {transactionFlow.map((transaction) => (
            <div key={transaction.id} className="border border-gray-600 rounded p-4 bg-gray-900/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <p className="text-blue-400 font-semibold">{transaction.origin.bank}</p>
                    <p className="text-gray-400 text-sm">{transaction.origin.account}</p>
                  </div>
                  <ArrowRight className="h-6 w-6 text-green-400" />
                  <div className="text-center">
                    <p className="text-purple-400 font-semibold">{transaction.destination.bank}</p>
                    <p className="text-gray-400 text-sm">{transaction.destination.account}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-green-400 font-bold text-lg">${transaction.amount.toLocaleString()}</p>
                  <p className="text-gray-400 text-sm">{transaction.type}</p>
                  <p className="text-gray-500 text-xs">{transaction.date}</p>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};