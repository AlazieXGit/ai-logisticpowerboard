import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Building2, CreditCard, ArrowRightLeft, 
  CheckCircle, AlertCircle, DollarSign
} from 'lucide-react';

interface BankAccount {
  id: string;
  name: string;
  type: 'Internal Source' | 'External Destination';
  accountNumber: string;
  routingNumber: string;
  balance: number;
  dailyLimit: number;
  status: 'Active' | 'Inactive' | 'Pending';
  processor: string;
}

const InternalBankingSourcesManager: React.FC = () => {
  const [accounts] = useState<BankAccount[]>([
    {
      id: '1',
      name: 'PNC Business Account',
      type: 'Internal Source',
      accountNumber: '****4521',
      routingNumber: '043000096',
      balance: 125000,
      dailyLimit: 125000,
      status: 'Active',
      processor: 'Stripe Payment System'
    },
    {
      id: '2',
      name: 'Wells Fargo Business',
      type: 'Internal Source',
      accountNumber: '****7892',
      routingNumber: '121000248',
      balance: 75000,
      dailyLimit: 75000,
      status: 'Active',
      processor: 'Square Invoice System'
    },
    {
      id: '3',
      name: 'Trust Main Account',
      type: 'Internal Source',
      accountNumber: '****8903',
      routingNumber: '031000053',
      balance: 250000,
      dailyLimit: 250000,
      status: 'Active',
      processor: 'ACH Network Registration'
    },
    {
      id: '4',
      name: 'Synergy Unified Account',
      type: 'Internal Source',
      accountNumber: '****9876',
      routingNumber: '021000021',
      balance: 500000,
      dailyLimit: 500000,
      status: 'Active',
      processor: 'Synergy Payment Router'
    }
  ]);

  const [transferAmount, setTransferAmount] = useState('');
  const [selectedSource, setSelectedSource] = useState('');
  const [selectedDestination, setSelectedDestination] = useState('');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-500';
      case 'Inactive': return 'bg-red-500';
      case 'Pending': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const handleTransfer = () => {
    console.log('Transfer initiated:', {
      amount: transferAmount,
      source: selectedSource,
      destination: selectedDestination
    });
  };

  const internalSources = accounts.filter(acc => acc.type === 'Internal Source');
  const totalBalance = internalSources.reduce((sum, acc) => sum + acc.balance, 0);
  const totalDailyLimit = internalSources.reduce((sum, acc) => sum + acc.dailyLimit, 0);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800/30 border-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400">Total Balance</p>
                <p className="text-2xl font-bold text-green-400">
                  ${totalBalance.toLocaleString()}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400">Daily Limit</p>
                <p className="text-2xl font-bold text-blue-400">
                  ${totalDailyLimit.toLocaleString()}
                </p>
              </div>
              <ArrowRightLeft className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400">Active Sources</p>
                <p className="text-2xl font-bold text-purple-400">
                  {internalSources.filter(acc => acc.status === 'Active').length}
                </p>
              </div>
              <Building2 className="h-8 w-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400">Processors</p>
                <p className="text-2xl font-bold text-orange-400">4</p>
              </div>
              <CreditCard className="h-8 w-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Internal Banking Sources */}
      <Card className="bg-gray-800/30 border-gray-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Internal Banking Sources - Fund Transfer Network
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {internalSources.map((account) => (
            <div key={account.id} className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <Badge className={`${getStatusColor(account.status)} text-white`}>
                      {account.status}
                    </Badge>
                    <span className="font-semibold text-white text-lg">
                      {account.name}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-gray-400">Account Number</p>
                      <p className="text-white font-mono">{account.accountNumber}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Routing Number</p>
                      <p className="text-white font-mono">{account.routingNumber}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Available Balance</p>
                      <p className="text-green-400 font-semibold">
                        ${account.balance.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-400">Daily Transfer Limit</p>
                      <p className="text-blue-400 font-semibold">
                        ${account.dailyLimit.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2">
                    <p className="text-gray-400 text-sm">Connected Processor</p>
                    <p className="text-purple-400 font-medium">{account.processor}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {account.status === 'Active' ? (
                    <CheckCircle className="h-6 w-6 text-green-400" />
                  ) : (
                    <AlertCircle className="h-6 w-6 text-red-400" />
                  )}
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Quick Transfer Interface */}
      <Card className="bg-gray-800/30 border-blue-500">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5" />
            Quick Transfer - Internal to External
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-gray-400 text-sm">Transfer Amount</label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                className="bg-gray-700/30 border-gray-600 text-white"
              />
            </div>
            <div>
              <label className="text-gray-400 text-sm">Source Account</label>
              <select 
                value={selectedSource}
                onChange={(e) => setSelectedSource(e.target.value)}
                className="w-full p-2 bg-gray-700/30 border border-gray-600 rounded text-white"
              >
                <option value="">Select source</option>
                {internalSources.map(acc => (
                  <option key={acc.id} value={acc.id}>{acc.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-gray-400 text-sm">Destination</label>
              <Input
                placeholder="External account"
                value={selectedDestination}
                onChange={(e) => setSelectedDestination(e.target.value)}
                className="bg-gray-700/30 border-gray-600 text-white"
              />
            </div>
          </div>
          <Button 
            onClick={handleTransfer}
            className="w-full bg-blue-600 hover:bg-blue-700"
            disabled={!transferAmount || !selectedSource || !selectedDestination}
          >
            <ArrowRightLeft className="h-4 w-4 mr-2" />
            Initiate Transfer
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default InternalBankingSourcesManager;