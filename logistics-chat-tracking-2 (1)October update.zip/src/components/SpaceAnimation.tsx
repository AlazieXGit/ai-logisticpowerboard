import React, { useEffect, useState } from 'react';

interface SpaceObject {
  id: string;
  type: 'meteor' | 'comet' | 'star';
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
}

interface Rocket {
  id: string;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  speed: number;
}

interface Explosion {
  id: string;
  x: number;
  y: number;
  text: string;
  opacity: number;
}

const SpaceAnimation: React.FC = () => {
  const [objects, setObjects] = useState<SpaceObject[]>([]);
  const [rockets, setRockets] = useState<Rocket[]>([]);
  const [explosions, setExplosions] = useState<Explosion[]>([]);
  const [sequence, setSequence] = useState(0);

  const texts = [
    'THE FUTURE IS HERE!',
    'INTELLECT AND INTELLIGENCE',
    'ADVANCED',
    'INNOVATION'
  ];

  useEffect(() => {
    const createObject = (): SpaceObject => {
      const types: ('meteor' | 'comet' | 'star')[] = ['meteor', 'meteor', 'comet', 'star'];
      const type = types[Math.floor(Math.random() * types.length)];
      const side = Math.floor(Math.random() * 4);
      let x, y, vx, vy;
      
      switch(side) {
        case 0: // top
          x = Math.random() * window.innerWidth;
          y = -50;
          vx = (Math.random() - 0.5) * 0.5;
          vy = Math.random() * 0.3 + 0.1;
          break;
        case 1: // right
          x = window.innerWidth + 50;
          y = Math.random() * window.innerHeight;
          vx = -(Math.random() * 0.3 + 0.1);
          vy = (Math.random() - 0.5) * 0.5;
          break;
        case 2: // bottom
          x = Math.random() * window.innerWidth;
          y = window.innerHeight + 50;
          vx = (Math.random() - 0.5) * 0.5;
          vy = -(Math.random() * 0.3 + 0.1);
          break;
        default: // left
          x = -50;
          y = Math.random() * window.innerHeight;
          vx = Math.random() * 0.3 + 0.1;
          vy = (Math.random() - 0.5) * 0.5;
      }

      return {
        id: Math.random().toString(36),
        type,
        x, y, vx, vy,
        size: Math.random() * 3 + 2
      };
    };

    const interval = setInterval(() => {
      if (Math.random() < 0.3) {
        setObjects(prev => [...prev, createObject()]);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const animate = () => {
      setObjects(prev => prev.map(obj => ({
        ...obj,
        x: obj.x + obj.vx,
        y: obj.y + obj.vy
      })).filter(obj => 
        obj.x > -100 && obj.x < window.innerWidth + 100 &&
        obj.y > -100 && obj.y < window.innerHeight + 100
      ));

      setRockets(prev => prev.map(rocket => {
        const dx = rocket.targetX - rocket.x;
        const dy = rocket.targetY - rocket.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < 20) {
          return null;
        }
        
        return {
          ...rocket,
          x: rocket.x + (dx / dist) * rocket.speed,
          y: rocket.y + (dy / dist) * rocket.speed
        };
      }).filter(Boolean) as Rocket[]);

      setExplosions(prev => prev.map(exp => ({
        ...exp,
        opacity: exp.opacity - 0.01
      })).filter(exp => exp.opacity > 0));
    };

    const animationId = requestAnimationFrame(function frame() {
      animate();
      requestAnimationFrame(frame);
    });

    return () => cancelAnimationFrame(animationId);
  }, []);

  useEffect(() => {
    const rocketInterval = setInterval(() => {
      if (objects.length > 0 && Math.random() < 0.4) {
        const target = objects[Math.floor(Math.random() * objects.length)];
        const rocket: Rocket = {
          id: Math.random().toString(36),
          x: Math.random() * window.innerWidth,
          y: window.innerHeight + 50,
          targetX: target.x,
          targetY: target.y,
          speed: 3
        };
        setRockets(prev => [...prev, rocket]);
        
        setTimeout(() => {
          const explosion: Explosion = {
            id: Math.random().toString(36),
            x: target.x,
            y: target.y,
            text: texts[sequence % texts.length],
            opacity: 1
          };
          setExplosions(prev => [...prev, explosion]);
          setObjects(prev => prev.filter(obj => obj.id !== target.id));
          setSequence(prev => prev + 1);
        }, 2000);
      }
    }, 5000);

    return () => clearInterval(rocketInterval);
  }, [objects, sequence, texts]);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {objects.map(obj => (
        <div
          key={obj.id}
          className={`absolute rounded-full ${
            obj.type === 'meteor' ? 'bg-orange-400 shadow-orange-300' :
            obj.type === 'comet' ? 'bg-blue-300 shadow-blue-200' :
            'bg-yellow-300 shadow-yellow-200'
          } shadow-lg animate-pulse`}
          style={{
            left: obj.x,
            top: obj.y,
            width: obj.size,
            height: obj.size,
            boxShadow: `0 0 ${obj.size * 2}px currentColor`
          }}
        />
      ))}
      
      {rockets.map(rocket => (
        <div
          key={rocket.id}
          className="absolute w-3 h-6 bg-red-500 rounded-full shadow-red-400"
          style={{
            left: rocket.x,
            top: rocket.y,
            boxShadow: '0 0 10px #ef4444'
          }}
        />
      ))}
      
      {explosions.map(explosion => (
        <div
          key={explosion.id}
          className="absolute text-2xl font-bold bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent animate-bounce"
          style={{
            left: explosion.x - 100,
            top: explosion.y - 20,
            opacity: explosion.opacity,
            textShadow: '0 0 20px rgba(139, 92, 246, 0.8)'
          }}
        >
          {explosion.text}
        </div>
      ))}
    </div>
  );
};

export default SpaceAnimation;