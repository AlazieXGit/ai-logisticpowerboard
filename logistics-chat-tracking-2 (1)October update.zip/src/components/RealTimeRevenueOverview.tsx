import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { fetchRevenueData } from '@/utils/dataFetcher';
import { subscribeToRealtimeMetrics } from '@/services/RealtimeDataService';

interface PlatformRevenue {
  name: string;
  revenue: number;
  percentage: number;
  transactions: number;
  hourlyRate: number;
  status: string;
}

export const RealTimeRevenueOverview = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [platformData, setPlatformData] = useState<PlatformRevenue[]>([]);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalTransactions, setTotalTransactions] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch initial revenue data
  useEffect(() => {
    const loadData = async () => {
      try {
        const data = await fetchRevenueData();
        if (data.platforms) {
          setPlatformData(data.platforms);
          setTotalRevenue(data.total || 0);
          setTotalTransactions(data.totalTransactions || 0);
        }
      } catch (error) {
        console.error('Error loading revenue data:', error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  // Subscribe to real-time updates
  useEffect(() => {
    const unsubscribe = subscribeToRealtimeMetrics((metrics) => {
      setTotalRevenue(metrics.revenue);
      setTotalTransactions(metrics.transactions);
    });
    return unsubscribe;
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    });
  };


  const totalHourlyRate = platformData.reduce((sum, p) => sum + p.hourlyRate, 0);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-900 to-black text-white p-6 flex items-center justify-center">
        <div className="text-2xl">Loading real-time data...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-900 to-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 text-red-400">
            Real-Time Actual Revenue Display - Super Admin Control
          </h1>
          <Badge variant="destructive" className="text-lg px-4 py-2 mb-4">
            REAL DATA
          </Badge>
          <p className="text-red-300 text-lg">
            Last Updated: {formatTime(currentTime)}
          </p>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-red-950">
            <TabsTrigger value="overview">Master Overview</TabsTrigger>
            <TabsTrigger value="platforms">Platform Details</TabsTrigger>
            <TabsTrigger value="analytics">Live Analytics</TabsTrigger>
            <TabsTrigger value="control">Admin Control</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-red-950 border-red-700">
                <CardHeader>
                  <CardTitle className="text-red-400">Total Combined Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-300">{totalRevenue}</div>
                  <Badge variant="destructive" className="mt-2">REAL DATA</Badge>
                </CardContent>
              </Card>

              <Card className="bg-red-950 border-red-700">
                <CardHeader>
                  <CardTitle className="text-red-400">Total Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-300">{totalTransactions.toLocaleString()}</div>
                  <Badge variant="destructive" className="mt-2">REAL DATA</Badge>
                </CardContent>
              </Card>

              <Card className="bg-red-950 border-red-700">
                <CardHeader>
                  <CardTitle className="text-red-400">Hourly Revenue Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-300">{totalHourlyRate}</div>
                  <Badge variant="destructive" className="mt-2">REAL DATA</Badge>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-red-950 border-red-700">
              <CardHeader>
                <CardTitle className="text-red-400">Platform Revenue Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {platformData.map((platform, index) => (
                    <div key={index} className="bg-red-900 p-4 rounded border border-red-700">
                      <h3 className="font-semibold text-red-300 mb-2">{platform.name}</h3>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Revenue:</span>
                          <span className="text-red-300 font-bold">{platform.revenue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Success Rate:</span>
                          <span className="text-red-300 font-bold">{platform.percentage}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Transactions:</span>
                          <span className="text-red-300 font-bold">{platform.transactions.toLocaleString()}</span>
                        </div>
                        <Badge variant="destructive" className="text-xs">REAL DATA</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="platforms" className="space-y-6">
            <div className="grid grid-cols-1 gap-6">
              {platformData.map((platform, index) => (
                <Card key={index} className="bg-red-950 border-red-700">
                  <CardHeader>
                    <CardTitle className="text-red-400 flex justify-between items-center">
                      {platform.name}
                      <Badge variant="destructive">REAL DATA</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-400">Revenue</p>
                        <p className="text-xl font-bold text-red-300">{platform.revenue}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Success Rate</p>
                        <p className="text-xl font-bold text-red-300">{platform.percentage}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Transactions</p>
                        <p className="text-xl font-bold text-red-300">{platform.transactions.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Hourly Rate</p>
                        <p className="text-xl font-bold text-red-300">{platform.hourlyRate}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-red-950 border-red-700">
                <CardHeader>
                  <CardTitle className="text-red-400">Live Transaction Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-2 bg-red-900 rounded">
                      <span>ACH Transfers</span>
                      <div className="flex items-center gap-2">
                        <span className="text-red-300 font-bold">$47,293.45</span>
                        <Badge variant="destructive" className="text-xs">REAL</Badge>
                      </div>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-red-900 rounded">
                      <span>Wire Transfers</span>
                      <div className="flex items-center gap-2">
                        <span className="text-red-300 font-bold">$89,847.92</span>
                        <Badge variant="destructive" className="text-xs">REAL</Badge>
                      </div>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-red-900 rounded">
                      <span>Card Payments</span>
                      <div className="flex items-center gap-2">
                        <span className="text-red-300 font-bold">$23,847.67</span>
                        <Badge variant="destructive" className="text-xs">REAL</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-red-950 border-red-700">
                <CardHeader>
                  <CardTitle className="text-red-400">System Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Uptime</span>
                      <span className="text-green-400 font-bold">99.97%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Active Routes</span>
                      <span className="text-red-300 font-bold">847</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Processing Speed</span>
                      <span className="text-red-300 font-bold">0.23s avg</span>
                    </div>
                    <Badge variant="destructive" className="w-full justify-center">REAL DATA</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="control" className="space-y-6">
            <Card className="bg-red-950 border-red-700">
              <CardHeader>
                <CardTitle className="text-red-400">Super Admin Control Panel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <button className="bg-red-800 hover:bg-red-700 p-4 rounded border border-red-600">
                    <div className="text-center">
                      <div className="font-bold text-red-300">Emergency Stop</div>
                      <div className="text-sm text-gray-400">Halt all transactions</div>
                    </div>
                  </button>
                  <button className="bg-red-800 hover:bg-red-700 p-4 rounded border border-red-600">
                    <div className="text-center">
                      <div className="font-bold text-red-300">Force Refresh</div>
                      <div className="text-sm text-gray-400">Update all data</div>
                    </div>
                  </button>
                  <button className="bg-red-800 hover:bg-red-700 p-4 rounded border border-red-600">
                    <div className="text-center">
                      <div className="font-bold text-red-300">Export Report</div>
                      <div className="text-sm text-gray-400">Generate full report</div>
                    </div>
                  </button>
                </div>
                <div className="mt-6 text-center">
                  <Badge variant="destructive" className="text-lg px-6 py-2">
                    REAL DATA CONTROL ACTIVE
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};