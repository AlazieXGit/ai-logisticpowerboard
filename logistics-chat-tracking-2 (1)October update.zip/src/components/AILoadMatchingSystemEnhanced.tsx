import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { MapPin, Truck, DollarSign, Clock, Bot, BookOpen } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface LoadMatch {
  id: string;
  origin: string;
  destination: string;
  distance: number;
  rate: number;
  weight: number;
  equipment: string;
  urgency: 'high' | 'medium' | 'low';
  aiScore: number;
}

export const AILoadMatchingSystemEnhanced: React.FC = () => {
  const [matches, setMatches] = useState<LoadMatch[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<LoadMatch | null>(null);
  const [bookingMode, setBookingMode] = useState<'auto' | 'manual'>('auto');

  useEffect(() => {
    // Simulate AI load matching
    const mockMatches: LoadMatch[] = [
      {
        id: '1',
        origin: 'Dallas, TX',
        destination: 'Atlanta, GA',
        distance: 925,
        rate: 3250,
        weight: 45000,
        equipment: 'Dry Van',
        urgency: 'high',
        aiScore: 95
      },
      {
        id: '2',
        origin: 'Los Angeles, CA',
        destination: 'Phoenix, AZ',
        distance: 370,
        rate: 1850,
        weight: 38000,
        equipment: 'Reefer',
        urgency: 'medium',
        aiScore: 88
      },
      {
        id: '3',
        origin: 'Chicago, IL',
        destination: 'Detroit, MI',
        distance: 280,
        rate: 1200,
        weight: 42000,
        equipment: 'Flatbed',
        urgency: 'low',
        aiScore: 82
      }
    ];
    setMatches(mockMatches);
  }, []);

  const handleAutoBook = async (match: LoadMatch) => {
    try {
      const { data } = await supabase.functions.invoke('ai-dispatch-optimizer', {
        body: { action: 'auto_book', loadData: match }
      });
      console.log('Auto booking result:', data);
    } catch (error) {
      console.error('Error auto booking:', error);
    }
  };

  const handleManualBook = (match: LoadMatch) => {
    setSelectedMatch(match);
    console.log('Manual booking load:', match);
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-6 w-6 text-blue-600" />
            AI Load Matching System 2029
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={bookingMode} onValueChange={(value) => setBookingMode(value as 'auto' | 'manual')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="auto">Auto Booking</TabsTrigger>
              <TabsTrigger value="manual">Manual Booking</TabsTrigger>
            </TabsList>

            <TabsContent value="auto" className="space-y-4">
              <div className="grid gap-4">
                {matches.map((match) => (
                  <Card key={match.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">{match.origin} → {match.destination}</span>
                            <Badge className={`${getUrgencyColor(match.urgency)} text-white`}>
                              {match.urgency.toUpperCase()}
                            </Badge>
                          </div>
                          <div className="flex gap-4 text-sm text-gray-600">
                            <span>{match.distance} miles</span>
                            <span>{match.weight} lbs</span>
                            <span>{match.equipment}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <DollarSign className="h-4 w-4 text-green-600" />
                            <span className="font-bold text-green-600">${match.rate}</span>
                            <Badge variant="outline">AI Score: {match.aiScore}%</Badge>
                          </div>
                        </div>
                        <Button onClick={() => handleAutoBook(match)} className="bg-blue-600">
                          Auto Book
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="manual" className="space-y-4">
              <div className="grid gap-4">
                {matches.map((match) => (
                  <Card key={match.id} className="border-l-4 border-l-orange-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">{match.origin} → {match.destination}</span>
                            <Badge className={`${getUrgencyColor(match.urgency)} text-white`}>
                              {match.urgency.toUpperCase()}
                            </Badge>
                          </div>
                          <div className="flex gap-4 text-sm text-gray-600">
                            <span>{match.distance} miles</span>
                            <span>{match.weight} lbs</span>
                            <span>{match.equipment}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <DollarSign className="h-4 w-4 text-green-600" />
                            <span className="font-bold text-green-600">${match.rate}</span>
                            <Badge variant="outline">AI Score: {match.aiScore}%</Badge>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button onClick={() => handleManualBook(match)} variant="outline">
                            <BookOpen className="h-4 w-4 mr-2" />
                            Manual Book
                          </Button>
                          <Button onClick={() => handleAutoBook(match)} className="bg-green-600">
                            Quick Book
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};