import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowDownToLine, Building2, CheckCircle, AlertCircle, Lock, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import DepositTestPanel from './DepositTestPanel';

interface DirectDepositProcessorProps {
  accountType?: 'main' | 'escrow' | 'trust';
}

const DirectDepositProcessor: React.FC<DirectDepositProcessorProps> = ({ accountType = 'main' }) => {
  const [amount, setAmount] = useState('');
  const [userId, setUserId] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [selectedAccount, setSelectedAccount] = useState(accountType);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const alazielAccounts = {
    main: {
      name: 'Alaziel Banking - Main Operations',
      accountNumber: '5573-9012-4567-8901',
      routingNumber: '031176110',
      hardCopy: true
    },
    escrow: {
      name: 'Alaziel Banking - Escrow Account',
      accountNumber: '5573-9012-4567-8902',
      routingNumber: '031176110',
      hardCopy: true
    },
    trust: {
      name: 'Alaziel Banking - Trust Account',
      accountNumber: '5573-9012-4567-8903',
      routingNumber: '031176110',
      hardCopy: true
    }
  };

  const processDeposit = async () => {
    if (!amount || !userId) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'process_deposit',
          user_id: userId,
          amount: parseFloat(amount),
          currency: currency,
          accountType: selectedAccount
        }
      });

      if (error) throw error;
      
      toast({
        title: 'Deposit Processed',
        description: `Deposit ID: ${data.deposit_id} | Net Amount: $${data.net_amount}`,
        variant: 'default'
      });
      
      setAmount('');
      setUserId('');
    } catch (error: any) {
      toast({
        title: 'Error processing deposit',
        description: error.message || 'Direct deposit processing failed',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: 'Banking information copied to clipboard' });
  };

  const currentAccount = alazielAccounts[selectedAccount as keyof typeof alazielAccounts];

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <ArrowDownToLine className="h-5 w-5" />
            Alaziel Banking - Direct Deposit Processor
            <Lock className="h-4 w-4 text-red-400" />
            <Badge className="bg-red-600 text-white">HARD COPY</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-emerald-900/20 p-4 rounded-lg border border-emerald-500/30">
            <div className="flex items-center gap-2 mb-2">
              <Building2 className="h-4 w-4 text-emerald-400" />
              <span className="text-emerald-300 font-semibold">Target Account</span>
              {currentAccount.hardCopy && <Lock className="h-3 w-3 text-red-400" />}
            </div>
            <div className="space-y-1">
              <p className="text-white font-medium">{currentAccount.name}</p>
              <div className="flex items-center gap-2">
                <p className="text-gray-300 text-sm">Account: {currentAccount.accountNumber}</p>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => copyToClipboard(currentAccount.accountNumber)}
                  className="text-emerald-400 hover:bg-emerald-900/20 p-1"
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-emerald-300">User ID *</Label>
              <Input
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="Enter user ID"
                className="bg-gray-700 border-emerald-500/30 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-emerald-300">Amount *</Label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-gray-700 border-emerald-500/30 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-emerald-300">Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="bg-gray-700 border-emerald-500/30">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="BTC">BTC (Unsupported)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={processDeposit}
            disabled={isProcessing}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
          >
            {isProcessing ? (
              <>
                <AlertCircle className="h-4 w-4 mr-2 animate-spin" />
                Processing Deposit...
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4 mr-2" />
                Process Deposit
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <DepositTestPanel />
    </div>
  );
};

export default DirectDepositProcessor;