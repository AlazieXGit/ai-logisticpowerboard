import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, DollarSign, CreditCard, Building, AlertTriangle, CheckCircle, Clock, TrendingUp, Send, FileText } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { LiveClock } from './LiveClock';

const PaymentProcessingForum: React.FC = () => {
  const [transferAmount, setTransferAmount] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [routingNumber, setRoutingNumber] = useState('');

  const aceFlareDeposits = [
    { date: '2025-01-15', amount: '$2,450.00', status: 'Completed', ref: 'ACE-001' },
    { date: '2025-01-14', amount: '$1,875.50', status: 'Completed', ref: 'ACE-002' },
    { date: '2025-01-13', amount: '$3,200.75', status: 'Completed', ref: 'ACE-003' },
    { date: '2025-01-12', amount: '$950.25', status: 'Pending', ref: 'ACE-004' }
  ];

  const accountBalances = [
    { name: 'Wells Fargo Business', balance: '$45,892.33', account: '****7892', routing: '121000248' },
    { name: 'Stripe Connect', balance: '$23,456.78', account: 'acct_1234567890', routing: 'N/A' },
    { name: 'Square Payments', balance: '$18,765.44', account: 'sq0idp-1234567890', routing: 'N/A' },
    { name: 'Plaid Connected', balance: '$67,543.21', account: '****5678', routing: '026009593' }
  ];

  return (
    <div className="space-y-6">
      <LiveClock />
      <Card className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Payment Processing Forum - Complete Dashboard
          </CardTitle>
          <Badge className="bg-green-600 w-fit">LIVE PROCESSING ACTIVE</Badge>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Wells Fargo Validity Notice */}
          <Alert className="border-red-500 bg-red-900/30">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-red-300">
              <strong>NOTICE OF ADDENDUM TO SUPER ADMIN:</strong> Wells Fargo Account ****7892 was not legally recognized for micro deposit verification as the account is not valid for automated clearing house (ACH) micro-deposit validation. Banking system validity requires manual verification through alternative authentication methods. Account remains active for manual transfers only.
            </AlertDescription>
          </Alert>

          {/* Account Balances */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gray-800/50 border-gray-600">
              <CardHeader>
                <CardTitle className="text-green-400 text-lg">Account Balances & Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {accountBalances.map((account, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-gray-700/50 rounded">
                    <div>
                      <p className="text-white font-semibold">{account.name}</p>
                      <p className="text-gray-300 text-sm">Account: {account.account}</p>
                      <p className="text-gray-300 text-sm">Routing: {account.routing}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-green-400 font-bold">{account.balance}</p>
                      <Badge className="bg-green-600">ACTIVE</Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Ace Flare Deposits Tracking */}
            <Card className="bg-gray-800/50 border-yellow-500">
              <CardHeader>
                <CardTitle className="text-yellow-400 text-lg">Ace Flare Deposits Tracker</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {aceFlareDeposits.map((deposit, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-yellow-900/20 rounded border border-yellow-500/30">
                    <div>
                      <p className="text-white font-semibold">{deposit.ref}</p>
                      <p className="text-gray-300 text-sm">{deposit.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-yellow-400 font-bold">{deposit.amount}</p>
                      <Badge className={deposit.status === 'Completed' ? 'bg-green-600' : 'bg-orange-600'}>
                        {deposit.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Manual Transfer Instructions */}
          <Card className="bg-gray-800/50 border-blue-500">
            <CardHeader>
              <CardTitle className="text-blue-400 text-lg">Manual External Transfer Instructions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="border-blue-500 bg-blue-900/20">
                <FileText className="h-4 w-4" />
                <AlertDescription className="text-blue-300">
                  <strong>MANUAL TRANSFER PROTOCOL:</strong> All external transfers must be initiated through Back Office or Super Admin platforms with proper authorization codes.
                </AlertDescription>
              </Alert>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-white font-semibold">Transfer Amount</label>
                  <Input
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    placeholder="$0.00"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-white font-semibold">Recipient Account</label>
                  <Input
                    value={recipientAccount}
                    onChange={(e) => setRecipientAccount(e.target.value)}
                    placeholder="Account Number"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-white font-semibold">Routing Number</label>
                  <Input
                    value={routingNumber}
                    onChange={(e) => setRoutingNumber(e.target.value)}
                    placeholder="Routing Number"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                <Send className="h-4 w-4 mr-2" />
                Initiate Manual Transfer
              </Button>
            </CardContent>
          </Card>

        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentProcessingForum;