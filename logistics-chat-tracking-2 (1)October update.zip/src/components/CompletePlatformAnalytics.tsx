import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, TrendingDown, AlertTriangle, 
  CheckCircle, BarChart3, PieChart 
} from 'lucide-react';
import { getDataAnalysisReport } from '@/utils/dataFetcher';
import { DataAnalysisReport } from '@/lib/dataAnalytics';

const CompletePlatformAnalytics: React.FC = () => {
  const [analyticsData, setAnalyticsData] = useState<DataAnalysisReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const data = await getDataAnalysisReport();
        setAnalyticsData(data);
      } catch (error) {
        console.error('Error fetching analytics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!analyticsData) {
    return (
      <div className="text-center text-red-400 p-8">
        Failed to load analytics data
      </div>
    );
  }

  const { mockDataAnalysis, realDataAnalysis, combinedInsights, projections } = analyticsData;

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gray-800/30 border-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Live Transactions</p>
                <p className="text-2xl font-bold text-blue-400">
                  {realDataAnalysis.liveTransactions.toLocaleString()}
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Volume</p>
                <p className="text-2xl font-bold text-green-400">
                  ${realDataAnalysis.actualVolume.toLocaleString()}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Active Users</p>
                <p className="text-2xl font-bold text-purple-400">
                  {realDataAnalysis.realUserActivity.toLocaleString()}
                </p>
              </div>
              <PieChart className="h-8 w-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/30 border-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">System Performance</p>
                <p className="text-2xl font-bold text-orange-400">
                  {realDataAnalysis.systemPerformance}%
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Combined Insights */}
      <Card className="bg-gray-800/30 border-cyan-500">
        <CardHeader>
          <CardTitle className="text-cyan-400">Combined Data Insights</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-gray-400 text-sm mb-2">Accuracy Score</p>
              <div className="flex items-center gap-2">
                <Progress 
                  value={combinedInsights.accuracyScore} 
                  className="flex-1"
                />
                <span className="text-white font-semibold">
                  {combinedInsights.accuracyScore.toFixed(1)}%
                </span>
              </div>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-2">Variance</p>
              <div className="flex items-center gap-2">
                <Progress 
                  value={Math.min(100, combinedInsights.variancePercentage)} 
                  className="flex-1"
                />
                <span className="text-white font-semibold">
                  {combinedInsights.variancePercentage.toFixed(1)}%
                </span>
              </div>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-2">Trend Alignment</p>
              <Badge className={`
                ${combinedInsights.trendAlignment.includes('Positive') ? 'bg-green-500' : 
                  combinedInsights.trendAlignment === 'Neutral' ? 'bg-yellow-500' : 'bg-red-500'}
              `}>
                {combinedInsights.trendAlignment}
              </Badge>
            </div>
          </div>

          {combinedInsights.riskFactors.length > 0 && (
            <div>
              <p className="text-red-400 font-semibold mb-2 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Risk Factors
              </p>
              <ul className="space-y-1">
                {combinedInsights.riskFactors.map((risk, index) => (
                  <li key={index} className="text-red-300 text-sm">• {risk}</li>
                ))}
              </ul>
            </div>
          )}

          {combinedInsights.opportunities.length > 0 && (
            <div>
              <p className="text-green-400 font-semibold mb-2 flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Opportunities
              </p>
              <ul className="space-y-1">
                {combinedInsights.opportunities.map((opportunity, index) => (
                  <li key={index} className="text-green-300 text-sm">• {opportunity}</li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Projections */}
      <Card className="bg-gray-800/30 border-purple-500">
        <CardHeader>
          <CardTitle className="text-purple-400">Revenue Projections</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-semibold mb-2">Next Quarter</h4>
              <p className="text-2xl font-bold text-blue-400 mb-1">
                ${projections.nextQuarter.expectedRevenue.toLocaleString()}
              </p>
              <p className="text-gray-400 text-sm">
                {projections.nextQuarter.userGrowth.toLocaleString()} users
              </p>
              <Badge className={`mt-2 ${
                projections.nextQuarter.riskLevel === 'Low' ? 'bg-green-500' :
                projections.nextQuarter.riskLevel === 'Medium' ? 'bg-yellow-500' : 'bg-red-500'
              }`}>
                {projections.nextQuarter.riskLevel} Risk
              </Badge>
            </div>
            
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-semibold mb-2">Next Year</h4>
              <p className="text-2xl font-bold text-green-400 mb-1">
                ${projections.nextYear.expectedRevenue.toLocaleString()}
              </p>
              <p className="text-gray-400 text-sm">
                {projections.nextYear.userGrowth.toLocaleString()} users
              </p>
              <Badge className={`mt-2 ${
                projections.nextYear.riskLevel === 'Low' ? 'bg-green-500' :
                projections.nextYear.riskLevel === 'Medium' ? 'bg-yellow-500' : 'bg-red-500'
              }`}>
                {projections.nextYear.riskLevel} Risk
              </Badge>
            </div>
            
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-semibold mb-2">5-Year Outlook</h4>
              <p className="text-2xl font-bold text-purple-400 mb-1">
                ${projections.fiveYearOutlook.expectedRevenue.toLocaleString()}
              </p>
              <p className="text-gray-400 text-sm">
                {projections.fiveYearOutlook.userGrowth.toLocaleString()} users
              </p>
              <Badge className={`mt-2 ${
                projections.fiveYearOutlook.riskLevel === 'Low' ? 'bg-green-500' :
                projections.fiveYearOutlook.riskLevel === 'Medium' ? 'bg-yellow-500' : 'bg-red-500'
              }`}>
                {projections.fiveYearOutlook.riskLevel} Risk
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CompletePlatformAnalytics;