import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, User, Lock, AlertTriangle, Copy, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Credential {
  id: string;
  platform: string;
  username: string;
  password: string;
  status: 'active' | 'suspended' | 'deleted';
  lastAccess: Date;
}

const MasterCredentialsManager: React.FC = () => {
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  useEffect(() => {
    loadCredentials();
  }, []);

  const loadCredentials = async () => {
    // Show only the single Super Admin credential
    const masterCredential: Credential = {
      id: '1',
      platform: 'Super Admin Access',
      username: 'alaziellc.innovation@gmail.com',
      password: 'gotchupin1976',
      status: 'active',
      lastAccess: new Date()
    };

    setCredentials([masterCredential]);
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const suspendAllOtherAccounts = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('master-credentials-manager', {
        body: { 
          action: 'suspend_all_except_master',
          master_email: 'alaziellc.innovation@gmail.com'
        }
      });
      
      if (!error) {
        console.log('All other accounts suspended successfully');
      }
    } catch (error) {
      console.error('Error suspending accounts:', error);
    }
  };
  return (
    <div className="space-y-6">
      <Card className="bg-red-900/20 border-red-500/50">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            MASTER CREDENTIALS VAULT - SINGLE ADMIN ACCESS
            <Badge className="bg-red-600 text-white animate-pulse">ALUCIUS ALFORD ONLY</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-gray-300">🔒 All other admin accounts have been suspended</p>
              <Button
                onClick={suspendAllOtherAccounts}
                className="bg-red-600 hover:bg-red-700"
              >
                <AlertTriangle className="h-4 w-4 mr-2" />
                Confirm Suspension
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {credentials.map((cred) => (
          <Card key={cred.id} className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-emerald-400 flex items-center gap-2">
                  <User className="h-4 w-4" />
                  {cred.platform}
                </CardTitle>
                <Badge className="bg-green-600">
                  {cred.status.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Username</label>
                  <div className="flex items-center gap-2">
                    <div className="bg-gray-700 border border-emerald-500/30 text-white p-2 rounded flex-1">
                      {cred.username}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(cred.username, 'username')}
                      className="text-emerald-400"
                    >
                      {copiedField === 'username' ? (
                        <CheckCircle className="h-4 w-4" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-gray-300 text-sm">Password</label>
                  <div className="flex items-center gap-2">
                    <div className="bg-gray-700 border border-emerald-500/30 text-white p-2 rounded flex-1">
                      {cred.password}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(cred.password, 'password')}
                      className="text-emerald-400"
                    >
                      {copiedField === 'password' ? (
                        <CheckCircle className="h-4 w-4" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-gray-300 text-sm">PIN</label>
                <div className="flex items-center gap-2">
                  <div className="bg-gray-700 border border-emerald-500/30 text-white p-2 rounded flex-1">
                    1976
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard('1976', 'pin')}
                    className="text-emerald-400"
                  >
                    {copiedField === 'pin' ? (
                      <CheckCircle className="h-4 w-4" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="text-xs text-gray-500">
                Last access: {cred.lastAccess.toLocaleString()}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-yellow-900/20 border-yellow-500/50">
        <CardHeader>
          <CardTitle className="text-yellow-400 flex items-center gap-2">
            <Lock className="h-4 w-4" />
            Security Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-300">Active Admin Accounts</span>
              <Badge className="bg-green-600">1</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Suspended Accounts</span>
              <Badge className="bg-red-600">ALL OTHERS</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Security Level</span>
              <Badge className="bg-green-600">MAXIMUM</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MasterCredentialsManager;