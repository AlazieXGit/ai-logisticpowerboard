import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { creditServices, CreditReport } from '@/lib/creditServices';

export const CreditReportViewer: React.FC = () => {
  const [creditReport, setCreditReport] = useState<CreditReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    ssn: '',
    dateOfBirth: '',
    street: '',
    city: '',
    state: '',
    zipCode: ''
  });

  const handleSoftPull = async () => {
    setLoading(true);
    try {
      const report = await creditServices.performSoftPull({
        firstName: formData.firstName,
        lastName: formData.lastName,
        ssn: formData.ssn,
        dateOfBirth: formData.dateOfBirth,
        address: {
          street: formData.street,
          city: formData.city,
          state: formData.state,
          zipCode: formData.zipCode
        }
      });
      setCreditReport(report);
    } catch (error) {
      console.error('Credit pull failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 740) return 'bg-green-500';
    if (score >= 670) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>iSoftpull Credit Report - Soft Pull</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              placeholder="First Name"
              value={formData.firstName}
              onChange={(e) => setFormData({...formData, firstName: e.target.value})}
            />
            <Input
              placeholder="Last Name"
              value={formData.lastName}
              onChange={(e) => setFormData({...formData, lastName: e.target.value})}
            />
            <Input
              placeholder="SSN"
              value={formData.ssn}
              onChange={(e) => setFormData({...formData, ssn: e.target.value})}
            />
            <Input
              placeholder="Date of Birth"
              type="date"
              value={formData.dateOfBirth}
              onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})}
            />
          </div>
          <Button onClick={handleSoftPull} disabled={loading} className="w-full">
            {loading ? 'Processing...' : 'Run Soft Credit Check'}
          </Button>
        </CardContent>
      </Card>

      {creditReport && (
        <Card>
          <CardHeader>
            <CardTitle>Credit Report Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center text-white font-bold text-xl ${getScoreColor(creditReport.creditScore.score)}`}>
                  {creditReport.creditScore.score}
                </div>
                <div>
                  <p className="font-semibold">{creditReport.creditScore.scoreType} Score</p>
                  <p className="text-sm text-gray-600">{creditReport.creditScore.range}</p>
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Credit Accounts</h3>
                {creditReport.accounts.map((account, index) => (
                  <div key={index} className="border rounded p-3 mb-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{account.creditor}</span>
                      <Badge variant={account.status === 'Current' ? 'default' : 'destructive'}>
                        {account.status}
                      </Badge>
                    </div>
                    <p className="text-sm">Balance: ${account.balance.toLocaleString()}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};