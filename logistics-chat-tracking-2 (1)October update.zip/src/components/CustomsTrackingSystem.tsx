import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import GPSTrackingSystem from './GPSTrackingSystem';
import LiveShipmentTracker from './LiveShipmentTracker';
import { 
  Package, Plane, Ship, Truck, MapPin, 
  Clock, FileText, Download, Eye, Navigation 
} from 'lucide-react';

const CustomsTrackingSystem = () => {
  const [trackingNumber, setTrackingNumber] = useState('');
  
  const [shipments] = useState([
    {
      trackingNumber: 'DHL-DE-789456123',
      product: 'AI Autopilot System V3',
      vendor: 'Tesla International Robotics',
      buyer: 'Alucius Alford',
      origin: 'Berlin, Germany',
      destination: '2408 yanceyville St greensboro NC 27405',
      status: 'In Transit',
      customsStatus: 'Cleared',
      currentLocation: 'Frankfurt International Airport',
      estimatedDelivery: '2025-01-18',
      documents: [
        { name: 'Commercial Invoice', type: 'PDF', size: '245KB' },
        { name: 'Customs Declaration', type: 'PDF', size: '156KB' },
        { name: 'Insurance Certificate', type: 'PDF', size: '89KB' }
      ],
      timeline: [
        { date: '2025-01-15', time: '09:30', event: 'Order Confirmed', location: 'Berlin, DE' },
        { date: '2025-01-15', time: '14:20', event: 'Customs Documentation Submitted', location: 'Berlin, DE' },
        { date: '2025-01-16', time: '08:15', event: 'Customs Cleared - Export', location: 'Frankfurt, DE' },
        { date: '2025-01-16', time: '16:45', event: 'Departed Frankfurt', location: 'Frankfurt Airport' },
        { date: '2025-01-17', time: '02:30', event: 'In Transit', location: 'Over Atlantic' }
      ]
    },
    {
      id: 'CT-2025-002',
      trackingNumber: 'UPS-JP-456789012',
      product: 'Robotic Assembly Unit',
      vendor: 'Toyota AI Robotics Japan',
      buyer: 'Alucius Alford',
      origin: 'Tokyo, Japan',
      destination: 'Atlanta, GA, USA',
      status: 'Customs Processing',
      customsStatus: 'Under Review',
      currentLocation: 'US Customs - Atlanta',
      estimatedDelivery: '2025-01-20',
      documents: [
        { name: 'Commercial Invoice', type: 'PDF', size: '298KB' },
        { name: 'Customs Declaration', type: 'PDF', size: '167KB' },
        { name: 'Insurance Certificate', type: 'PDF', size: '92KB' },
        { name: 'Technical Specifications', type: 'PDF', size: '1.2MB' }
      ],
      timeline: [
        { date: '2025-01-14', time: '11:00', event: 'Order Confirmed', location: 'Tokyo, JP' },
        { date: '2025-01-14', time: '16:30', event: 'Shipped from Warehouse', location: 'Tokyo, JP' },
        { date: '2025-01-15', time: '09:45', event: 'Customs Cleared - Export', location: 'Narita Airport' },
        { date: '2025-01-16', time: '14:20', event: 'Arrived in USA', location: 'LAX Airport' },
        { date: '2025-01-17', time: '10:15', event: 'Customs Processing', location: 'Atlanta, GA' }
      ]
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Delivered': return 'bg-green-500';
      case 'In Transit': return 'bg-blue-500';
      case 'Customs Processing': return 'bg-yellow-500';
      case 'Delayed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getCustomsStatusColor = (status: string) => {
    switch (status) {
      case 'Cleared': return 'bg-green-500';
      case 'Under Review': return 'bg-yellow-500';
      case 'Hold': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Customs & Shipping Tracking</h2>
        <div className="flex gap-2">
          <Input
            placeholder="Enter tracking number..."
            value={trackingNumber}
            onChange={(e) => setTrackingNumber(e.target.value)}
            className="w-64 bg-gray-700 border-gray-600"
          />
          <Button className="bg-blue-600 hover:bg-blue-700">
            Track
          </Button>
        </div>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid grid-cols-5 bg-gray-800/50">
          <TabsTrigger value="active">Active Shipments</TabsTrigger>
          <TabsTrigger value="live">Live Tracking</TabsTrigger>
          <TabsTrigger value="gps">GPS Tracking</TabsTrigger>
          <TabsTrigger value="customs">Customs Status</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          {shipments.map((shipment) => (
            <Card key={shipment.id} className="bg-gray-800/50 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-blue-400" />
                    {shipment.product}
                  </div>
                  <Badge className={getStatusColor(shipment.status)}>
                    {shipment.status}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Tracking #</p>
                    <p className="text-blue-300 font-mono">{shipment.trackingNumber}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">From</p>
                    <p className="text-white">{shipment.origin}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">To</p>
                    <p className="text-white">{shipment.destination}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">ETA</p>
                    <p className="text-green-400">{shipment.estimatedDelivery}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-red-400" />
                  <span className="text-white">Current Location: {shipment.currentLocation}</span>
                </div>

                <div className="space-y-2">
                  <h4 className="text-white font-medium">Shipment Timeline</h4>
                  <div className="space-y-2 max-h-32 overflow-y-auto">
                    {shipment.timeline.map((event, idx) => (
                      <div key={idx} className="flex items-center gap-3 text-sm">
                        <div className="flex items-center gap-2 min-w-0">
                          <Clock className="h-3 w-3 text-blue-400 flex-shrink-0" />
                          <span className="text-gray-400">{event.date} {event.time}</span>
                        </div>
                        <span className="text-white">{event.event}</span>
                        <span className="text-gray-400">- {event.location}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        <TabsContent value="live">
          <LiveShipmentTracker />
        </TabsContent>

        <TabsContent value="gps">
          <GPSTrackingSystem />
        </TabsContent>

        <TabsContent value="customs" className="space-y-4">
          {shipments.map((shipment) => (
            <Card key={shipment.id} className="bg-gray-800/50 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span>{shipment.product}</span>
                  <Badge className={getCustomsStatusColor(shipment.customsStatus)}>
                    {shipment.customsStatus}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Buyer</p>
                    <p className="text-white">{shipment.buyer}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Vendor</p>
                    <p className="text-white">{shipment.vendor}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Customs Status</p>
                    <p className="text-yellow-300">{shipment.customsStatus}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Current Location</p>
                    <p className="text-blue-300">{shipment.currentLocation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          {shipments.map((shipment) => (
            <Card key={shipment.id} className="bg-gray-800/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white">{shipment.product} - Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {shipment.documents.map((doc, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 bg-gray-700/30 rounded">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-blue-400" />
                        <span className="text-white">{doc.name}</span>
                        <Badge variant="outline" className="text-xs">{doc.type}</Badge>
                        <span className="text-gray-400 text-xs">{doc.size}</span>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="text-xs">
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button size="sm" className="bg-green-600 hover:bg-green-700 text-xs">
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CustomsTrackingSystem;