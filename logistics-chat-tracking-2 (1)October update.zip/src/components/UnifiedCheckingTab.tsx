import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Building2, DollarSign, ArrowUpRight, ArrowDownRight, Eye, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';

interface UnifiedCheckingTabProps {
  onAccountSelect?: (account: any) => void;
}

const UnifiedCheckingTab: React.FC<UnifiedCheckingTabProps> = ({ onAccountSelect }) => {
  const [transactions, setTransactions] = useState([]);
  const [selectedAccount, setSelectedAccount] = useState('main');

  const checkingAccounts = {
    main: {
      id: 'main',
      name: 'Alaziel Banking - Main Checking',
      accountNumber: '5573-9012-4567-8901',
      routingNumber: '031176110',
      balance: 2847563.89,
      type: 'Primary Operating',
      swift: 'ALAZUS33MAIN'
    },
    escrow: {
      id: 'escrow',
      name: 'Alaziel Banking - Escrow Checking',
      accountNumber: '5573-9012-4567-8902',
      routingNumber: '031176110',
      balance: 4256789.12,
      type: 'Escrow Operations',
      swift: 'ALAZUS33ESCR'
    },
    trust: {
      id: 'trust',
      name: 'Alaziel Banking - Trust Checking',
      accountNumber: '5573-9012-4567-8903',
      routingNumber: '031176110',
      balance: 2895647.33,
      type: 'Trust Operations',
      swift: 'ALAZUS33TRST'
    }
  };

  const mockTransactions = [
    { id: 1, date: '2024-01-15', description: 'Vendor Payment - Infrastructure', amount: -50000.00, type: 'debit', account: 'main' },
    { id: 2, date: '2024-01-15', description: 'Client Deposit - TMS Revenue', amount: 125000.00, type: 'credit', account: 'main' },
    { id: 3, date: '2024-01-14', description: 'Escrow Release - Load #4521', amount: -75000.00, type: 'debit', account: 'escrow' },
    { id: 4, date: '2024-01-14', description: 'Trust Fund Deposit', amount: 200000.00, type: 'credit', account: 'trust' },
    { id: 5, date: '2024-01-13', description: 'Contractor Payment - Weekly', amount: -25000.00, type: 'debit', account: 'main' }
  ];

  useEffect(() => {
    loadTransactions();
  }, [selectedAccount]);

  const loadTransactions = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'get_account_transactions',
          accountId: selectedAccount
        }
      });
      if (!error && data) {
        setTransactions(data.transactions || mockTransactions);
      } else {
        setTransactions(mockTransactions);
      }
    } catch (error) {
      setTransactions(mockTransactions);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const currentAccount = checkingAccounts[selectedAccount as keyof typeof checkingAccounts];
  const accountTransactions = transactions.filter(t => t.account === selectedAccount);

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Unified Checking Accounts - Separate Account Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedAccount} onValueChange={setSelectedAccount}>
            <TabsList className="grid w-full grid-cols-3 bg-gray-700">
              <TabsTrigger value="main" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                Main Checking
              </TabsTrigger>
              <TabsTrigger value="escrow" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                Escrow Checking
              </TabsTrigger>
              <TabsTrigger value="trust" className="text-emerald-300 data-[state=active]:bg-emerald-600">
                Trust Checking
              </TabsTrigger>
            </TabsList>

            <TabsContent value={selectedAccount} className="mt-6">
              <div className="mb-6 p-4 bg-emerald-900/20 border border-emerald-500/30 rounded-lg">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <span className="text-gray-400 text-sm">Account Name</span>
                    <div className="text-white font-semibold">{currentAccount.name}</div>
                  </div>
                  <div>
                    <span className="text-gray-400 text-sm">Account Number</span>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-mono">{currentAccount.accountNumber}</span>
                      <Button size="sm" variant="ghost" onClick={() => copyToClipboard(currentAccount.accountNumber)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-400 text-sm">Routing Number</span>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-mono">{currentAccount.routingNumber}</span>
                      <Button size="sm" variant="ghost" onClick={() => copyToClipboard(currentAccount.routingNumber)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-400 text-sm">Current Balance</span>
                    <div className="text-emerald-400 font-bold text-xl">
                      ${currentAccount.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex gap-2 flex-wrap">
                  <Badge className="bg-emerald-600">{currentAccount.type}</Badge>
                  <Badge className="bg-blue-600">SWIFT: {currentAccount.swift}</Badge>
                  <Badge className="bg-purple-600">Alaziel Banking</Badge>
                </div>
              </div>

              <Card className="bg-gray-700 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    Transaction History - {currentAccount.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-600">
                        <TableHead className="text-gray-300">Date</TableHead>
                        <TableHead className="text-gray-300">Description</TableHead>
                        <TableHead className="text-gray-300">Type</TableHead>
                        <TableHead className="text-gray-300 text-right">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {accountTransactions.map((transaction) => (
                        <TableRow key={transaction.id} className="border-gray-600">
                          <TableCell className="text-gray-300">{transaction.date}</TableCell>
                          <TableCell className="text-white">{transaction.description}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {transaction.type === 'credit' ? (
                                <ArrowDownRight className="h-4 w-4 text-green-400" />
                              ) : (
                                <ArrowUpRight className="h-4 w-4 text-red-400" />
                              )}
                              <Badge className={transaction.type === 'credit' ? 'bg-green-600' : 'bg-red-600'}>
                                {transaction.type.toUpperCase()}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell className={`text-right font-bold ${
                            transaction.type === 'credit' ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {transaction.type === 'credit' ? '+' : ''}
                            ${Math.abs(transaction.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default UnifiedCheckingTab;