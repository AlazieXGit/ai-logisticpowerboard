import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, AlertCircle, DollarSign, Calendar, Filter, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Transaction {
  id: string;
  account_email: string;
  transaction_type: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed';
  description: string;
  created_at: string;
  confirmation_code: string;
  recipient?: string;
  sender?: string;
}

const AccountTransactionConfirmation: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState({
    status: 'all',
    type: 'all',
    dateRange: '7days'
  });
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadTransactions();
  }, [filter]);

  const loadTransactions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'get_all_transactions',
          filters: filter
        }
      });
      if (data?.transactions) {
        setTransactions(data.transactions);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
    setLoading(false);
  };

  const confirmTransaction = async (transactionId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'confirm_transaction',
          transaction_id: transactionId
        }
      });
      if (data?.success) {
        await loadTransactions();
      }
    } catch (error) {
      console.error('Error confirming transaction:', error);
    }
  };

  const exportTransactions = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'export_transactions',
          filters: filter,
          search: searchTerm
        }
      });
      if (data?.csv) {
        const blob = new Blob([data.csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `transactions_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
      }
    } catch (error) {
      console.error('Error exporting transactions:', error);
    }
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.account_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.confirmation_code.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-600"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-600"><AlertCircle className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'failed':
        return <Badge className="bg-red-600"><AlertCircle className="h-3 w-3 mr-1" />Failed</Badge>;
      default:
        return <Badge className="bg-gray-600">{status}</Badge>;
    }
  };

  const totalAmount = filteredTransactions.reduce((sum, t) => sum + t.amount, 0);
  const completedCount = filteredTransactions.filter(t => t.status === 'completed').length;
  const pendingCount = filteredTransactions.filter(t => t.status === 'pending').length;

  return (
    <div className="space-y-6">
      <Card className="bg-green-900/20 border-green-500/50">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Account Transaction Confirmations
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card className="bg-gray-800/50 border-gray-600">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-400">{completedCount}</div>
                <div className="text-sm text-gray-300">Completed</div>
              </CardContent>
            </Card>
            <Card className="bg-gray-800/50 border-gray-600">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-yellow-400">{pendingCount}</div>
                <div className="text-sm text-gray-300">Pending</div>
              </CardContent>
            </Card>
            <Card className="bg-gray-800/50 border-gray-600">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-400">{filteredTransactions.length}</div>
                <div className="text-sm text-gray-300">Total Transactions</div>
              </CardContent>
            </Card>
            <Card className="bg-gray-800/50 border-gray-600">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-400">${totalAmount.toLocaleString()}</div>
                <div className="text-sm text-gray-300">Total Amount</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div>
              <Label className="text-gray-300">Search</Label>
              <Input
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Status</Label>
              <Select value={filter.status} onValueChange={(value) => setFilter({...filter, status: value})}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Type</Label>
              <Select value={filter.type} onValueChange={(value) => setFilter({...filter, type: value})}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="transfer">Transfer</SelectItem>
                  <SelectItem value="deposit">Deposit</SelectItem>
                  <SelectItem value="withdrawal">Withdrawal</SelectItem>
                  <SelectItem value="payment">Payment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Date Range</Label>
              <Select value={filter.dateRange} onValueChange={(value) => setFilter({...filter, dateRange: value})}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1day">Last 24 Hours</SelectItem>
                  <SelectItem value="7days">Last 7 Days</SelectItem>
                  <SelectItem value="30days">Last 30 Days</SelectItem>
                  <SelectItem value="90days">Last 90 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                onClick={exportTransactions}
                className="bg-blue-600 hover:bg-blue-700 w-full"
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {loading && (
            <div className="text-center py-8 text-gray-400">Loading transactions...</div>
          )}

          {/* Transactions List */}
          <div className="space-y-3">
            {filteredTransactions.map((transaction) => (
              <Card key={transaction.id} className="bg-gray-800/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-3">
                        <DollarSign className="h-4 w-4 text-green-400" />
                        <span className="text-white font-semibold">${transaction.amount.toLocaleString()}</span>
                        {getStatusBadge(transaction.status)}
                        <Badge className="bg-blue-600">{transaction.transaction_type}</Badge>
                      </div>
                      <div className="text-sm text-gray-300">
                        <div><strong>Account:</strong> {transaction.account_email}</div>
                        <div><strong>Description:</strong> {transaction.description}</div>
                        <div><strong>Confirmation:</strong> {transaction.confirmation_code}</div>
                        {transaction.recipient && <div><strong>Recipient:</strong> {transaction.recipient}</div>}
                        {transaction.sender && <div><strong>Sender:</strong> {transaction.sender}</div>}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <Calendar className="h-3 w-3" />
                        {new Date(transaction.created_at).toLocaleString()}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {transaction.status === 'pending' && (
                        <Button
                          size="sm"
                          onClick={() => confirmTransaction(transaction.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Confirm
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-blue-500 text-blue-400"
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredTransactions.length === 0 && !loading && (
            <div className="text-center py-8 text-gray-400">
              No transactions found matching your criteria.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountTransactionConfirmation;