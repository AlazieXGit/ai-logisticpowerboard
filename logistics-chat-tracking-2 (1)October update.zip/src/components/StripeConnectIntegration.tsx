import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { CreditCard, Link, DollarSign, CheckCircle, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const StripeConnectIntegration = () => {
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [processing, setProcessing] = useState(false);

  const LIVE_STRIPE_CONFIG = {
    publishableKey: 'pk_live_51Nel9QESMiZyND6V5ixJK2PkqjlaMSG58kfYMAjcAs3X7AIEKbWQyIevTZq4KIuTJ96uvdjxVWzkuw3gFUfdfsgA00fQaqC5Gu',
    paymentLink: 'https://buy.stripe.com/fZudR93xS0jf1kq4PTcQU02',
    connectSetup: 'https://connect.stripe.com/d/setup/s/_StKxYRy3NqfUnvDSW7w5t6V0VW/YWNjdF8xUnhZSE1DbXZ5OFZhUVFa/9f9ec6f38af26a765',
    dashboard: 'https://dashboard.stripe.com/b/acct_1RxYHMCmvy8VaQQZ/account/status'
  };

  const processDirectPayment = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid payment amount",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    
    setTimeout(() => {
      window.open(LIVE_STRIPE_CONFIG.paymentLink, '_blank');
      toast({
        title: "Payment Link Opened",
        description: `Stripe payment link opened for $${amount}`,
      });
      setProcessing(false);
      setAmount('');
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900 to-indigo-900 border-purple-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="h-6 w-6" />
            STRIPE CONNECT INTEGRATION
            <Badge className="bg-green-600">LIVE ACTIVE</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Direct Payment Processing</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-gray-300 text-sm">Payment Amount ($)</label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <Button 
              onClick={processDirectPayment}
              disabled={processing}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              {processing ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Opening Stripe...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Process via Stripe
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Live Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-400" />
                <span className="text-green-400 text-sm">Live Mode Connected</span>
              </div>
              <div className="space-y-2">
                <label className="text-gray-400 text-sm">Publishable Key</label>
                <code className="block bg-gray-700 p-2 rounded text-xs text-blue-400 break-all">
                  {LIVE_STRIPE_CONFIG.publishableKey.substring(0, 30)}...
                </code>
              </div>
              <div className="space-y-2">
                <label className="text-gray-400 text-sm">Status</label>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span className="text-green-400 text-sm">Active & Ready</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-purple-900 border-purple-500">
          <CardHeader>
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <Link className="h-4 w-4" />
              Payment Link
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => window.open(LIVE_STRIPE_CONFIG.paymentLink, '_blank')}
              className="w-full bg-purple-600 hover:bg-purple-700 text-sm"
            >
              Open Payment Link
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-blue-900 border-blue-500">
          <CardHeader>
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <Link className="h-4 w-4" />
              Connect Setup
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => window.open(LIVE_STRIPE_CONFIG.connectSetup, '_blank')}
              className="w-full bg-blue-600 hover:bg-blue-700 text-sm"
            >
              Setup Connect
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-green-900 border-green-500">
          <CardHeader>
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Dashboard
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => window.open(LIVE_STRIPE_CONFIG.dashboard, '_blank')}
              className="w-full bg-green-600 hover:bg-green-700 text-sm"
            >
              Open Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StripeConnectIntegration;