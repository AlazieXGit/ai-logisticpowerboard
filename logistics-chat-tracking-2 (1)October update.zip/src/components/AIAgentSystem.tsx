import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Bot, Brain, Zap, Target, TrendingUp, Users, 
  Building, Truck, Package, MapPin 
} from 'lucide-react';

interface AIAgent {
  id: string;
  name: string;
  type: string;
  performance: number;
  status: 'active' | 'optimizing' | 'idle';
  tasks: number;
  efficiency: number;
}

const AIAgentSystem: React.FC = () => {
  const [agents, setAgents] = useState<AIAgent[]>([
    { id: '1', name: 'Shipper AI', type: 'shipper', performance: 95, status: 'active', tasks: 2847, efficiency: 98 },
    { id: '2', name: 'Carrier AI', type: 'carrier', performance: 92, status: 'active', tasks: 3156, efficiency: 96 },
    { id: '3', name: 'Broker AI', type: 'broker', performance: 89, status: 'optimizing', tasks: 1923, efficiency: 94 },
    { id: '4', name: 'Driver AI', type: 'driver', performance: 97, status: 'active', tasks: 4521, efficiency: 99 },
    { id: '5', name: 'Warehouse AI', type: 'warehouse', performance: 91, status: 'active', tasks: 2634, efficiency: 95 },
    { id: '6', name: 'Distribution AI', type: 'distribution', performance: 88, status: 'idle', tasks: 1876, efficiency: 92 }
  ]);

  const [totalEnrolled, setTotalEnrolled] = useState(54000);
  const [contractsGenerated, setContractsGenerated] = useState(8750);

  useEffect(() => {
    const interval = setInterval(() => {
      setAgents(prev => prev.map(agent => ({
        ...agent,
        performance: Math.min(100, agent.performance + Math.random() * 2 - 1),
        tasks: agent.tasks + Math.floor(Math.random() * 10),
        efficiency: Math.min(100, agent.efficiency + Math.random() * 1.5 - 0.5)
      })));
      
      setTotalEnrolled(prev => prev + Math.floor(Math.random() * 5));
      setContractsGenerated(prev => prev + Math.floor(Math.random() * 3));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getAgentIcon = (type: string) => {
    switch (type) {
      case 'shipper': return <Package className="h-5 w-5" />;
      case 'carrier': return <Truck className="h-5 w-5" />;
      case 'broker': return <Users className="h-5 w-5" />;
      case 'driver': return <MapPin className="h-5 w-5" />;
      case 'warehouse': return <Building className="h-5 w-5" />;
      case 'distribution': return <Target className="h-5 w-5" />;
      default: return <Bot className="h-5 w-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-600';
      case 'optimizing': return 'bg-yellow-600';
      case 'idle': return 'bg-gray-600';
      default: return 'bg-blue-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/30 border-blue-500">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Brain className="h-6 w-6 text-blue-400" />
            <CardTitle className="text-blue-400">AI Agent Control System</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-5 w-5 text-blue-400" />
                <span className="text-blue-300">Total Enrolled</span>
              </div>
              <div className="text-2xl font-bold text-white">{totalEnrolled.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Companies registered</div>
            </div>
            
            <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-5 w-5 text-green-400" />
                <span className="text-green-300">Contracts Generated</span>
              </div>
              <div className="text-2xl font-bold text-white">{contractsGenerated.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Auto-generated deals</div>
            </div>
            
            <div className="bg-purple-900/20 p-4 rounded-lg border border-purple-500/30">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="h-5 w-5 text-purple-400" />
                <span className="text-purple-300">AI Performance</span>
              </div>
              <div className="text-2xl font-bold text-white">900x</div>
              <div className="text-sm text-gray-400">Enhanced intelligence</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {agents.map((agent) => (
              <Card key={agent.id} className="bg-gray-700/30 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {getAgentIcon(agent.type)}
                      <span className="font-medium text-white">{agent.name}</span>
                    </div>
                    <Badge className={getStatusColor(agent.status)}>
                      {agent.status}
                    </Badge>
                  </div>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-300">Performance</span>
                        <span className="text-blue-400">{agent.performance.toFixed(1)}%</span>
                      </div>
                      <Progress value={agent.performance} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-300">Efficiency</span>
                        <span className="text-green-400">{agent.efficiency.toFixed(1)}%</span>
                      </div>
                      <Progress value={agent.efficiency} className="h-2" />
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Tasks Completed</span>
                      <span className="text-yellow-400">{agent.tasks.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AIAgentSystem;