import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, Shield } from 'lucide-react';

export const PNCVirtualAccountsOverview = () => {
  const pncAccounts = [
    {
      name: "PNC Virtual Primary",
      purpose: "Primary Operating",
      accountNumber: "5563935267",
      routingNumber: "054000030",
      balance: "$2,847,592.45",
      status: "Active",
      icon: <DollarSign className="h-5 w-5" />
    },
    {
      name: "PNC Reserve Account", 
      purpose: "Reserve Fund",
      accountNumber: "5563935275",
      routingNumber: "054000030", 
      balance: "$1,456,789.23",
      status: "Active",
      icon: <Shield className="h-5 w-5" />
    },
    {
      name: "PNC Growth Account",
      purpose: "Investment Growth - AI ALAZIE XPRESS Revenue",
      accountNumber: "5563935283",
      routingNumber: "054000030",
      balance: "Auto-Updated via API",
      status: "Active - Revenue Routing",
      icon: <TrendingUp className="h-5 w-5" />
    }
  ];

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-white mb-4">PNC Virtual Accounts Overview</h2>
      <div className="grid gap-4">
        {pncAccounts.map((account, index) => (
          <Card key={index} className="bg-gray-800 border-blue-500">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  {account.icon}
                  {account.name}
                </CardTitle>
                <Badge variant={account.status.includes('Revenue') ? 'default' : 'secondary'}>
                  {account.status}
                </Badge>
              </div>
              <p className="text-gray-300 text-sm">{account.purpose}</p>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Account:</span>
                  <span className="text-white ml-2 font-mono">{account.accountNumber}</span>
                </div>
                <div>
                  <span className="text-gray-400">Routing:</span>
                  <span className="text-white ml-2 font-mono">{account.routingNumber}</span>
                </div>
              </div>
              <div className="pt-2">
                <span className="text-gray-400">Balance:</span>
                <span className="text-green-400 ml-2 font-bold text-lg">{account.balance}</span>
              </div>
              {account.accountNumber === "5563935283" && (
                <div className="mt-3 p-3 bg-orange-500/20 rounded-lg border border-orange-500">
                  <p className="text-orange-300 text-sm font-medium">
                    🚀 Revenue Routing Active - All AI ALAZIE XPRESS fees, subscriptions, and boost payments automatically routed here
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};