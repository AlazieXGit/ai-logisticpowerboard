import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Files, Download, Eye, Shield, Lock, FileText, Building2, CreditCard, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface FileItem {
  id: string;
  name: string;
  type: string;
  category: string;
  size: string;
  lastModified: string;
  securityLevel: 'high' | 'maximum' | 'enterprise';
  status: 'active' | 'archived' | 'secured';
}

const SuperAdminFilesDisplay: React.FC = () => {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null);

  useEffect(() => {
    loadAllFiles();
  }, []);

  const loadAllFiles = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'get_all_admin_files',
          includeCategories: ['banking', 'legal', 'tax', 'business', 'platform']
        }
      });
      
      if (!error && data?.files) {
        setFiles(data.files);
      } else {
        // Mock data for demonstration
        setFiles(mockFiles);
      }
    } catch (error) {
      console.error('Error loading files:', error);
      setFiles(mockFiles);
    } finally {
      setLoading(false);
    }
  };

  const mockFiles: FileItem[] = [
    // Banking Files
    { id: '1', name: 'Alaziel_Banking_Corp_Charter.pdf', type: 'PDF', category: 'banking', size: '2.4 MB', lastModified: '2024-01-15', securityLevel: 'maximum', status: 'secured' },
    { id: '2', name: 'Account_5573-9012-4567-8901_Statements.pdf', type: 'PDF', category: 'banking', size: '1.8 MB', lastModified: '2024-01-14', securityLevel: 'enterprise', status: 'active' },
    { id: '3', name: 'Square_Account_3236618840224_Records.pdf', type: 'PDF', category: 'banking', size: '3.2 MB', lastModified: '2024-01-13', securityLevel: 'high', status: 'active' },
    { id: '4', name: 'Chime_DD_169111467356_Setup.pdf', type: 'PDF', category: 'banking', size: '1.1 MB', lastModified: '2024-01-12', securityLevel: 'high', status: 'active' },
    
    // Legal Files
    { id: '5', name: 'Alazie_LLC_Operating_Agreement.pdf', type: 'PDF', category: 'legal', size: '4.7 MB', lastModified: '2024-01-10', securityLevel: 'maximum', status: 'secured' },
    { id: '6', name: 'Virtual_Business_Address_Contract.pdf', type: 'PDF', category: 'legal', size: '2.1 MB', lastModified: '2024-01-11', securityLevel: 'enterprise', status: 'active' },
    { id: '7', name: 'Platform_Development_Agreement.pdf', type: 'PDF', category: 'legal', size: '3.8 MB', lastModified: '2024-01-09', securityLevel: 'maximum', status: 'secured' },
    
    // Tax Files
    { id: '8', name: '2024_Tax_Documents_Alazie_LLC.pdf', type: 'PDF', category: 'tax', size: '2.9 MB', lastModified: '2024-01-08', securityLevel: 'enterprise', status: 'active' },
    { id: '9', name: '1099_Forms_Generated.pdf', type: 'PDF', category: 'tax', size: '1.6 MB', lastModified: '2024-01-07', securityLevel: 'high', status: 'active' },
    
    // Business Files
    { id: '10', name: 'Business_License_Alazie_LLC.pdf', type: 'PDF', category: 'business', size: '1.3 MB', lastModified: '2024-01-06', securityLevel: 'enterprise', status: 'active' },
    { id: '11', name: 'Insurance_Policies_Commercial.pdf', type: 'PDF', category: 'business', size: '5.2 MB', lastModified: '2024-01-05', securityLevel: 'high', status: 'active' }
  ];

  const getSecurityColor = (level: string) => {
    switch (level) {
      case 'maximum': return 'bg-red-600';
      case 'enterprise': return 'bg-orange-600';
      case 'high': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'banking': return <CreditCard className="h-4 w-4" />;
      case 'legal': return <Shield className="h-4 w-4" />;
      case 'tax': return <FileText className="h-4 w-4" />;
      case 'business': return <Building2 className="h-4 w-4" />;
      default: return <Files className="h-4 w-4" />;
    }
  };

  const filesByCategory = {
    banking: files.filter(f => f.category === 'banking'),
    legal: files.filter(f => f.category === 'legal'),
    tax: files.filter(f => f.category === 'tax'),
    business: files.filter(f => f.category === 'business'),
    all: files
  };

  const FileList: React.FC<{ files: FileItem[] }> = ({ files }) => (
    <div className="space-y-3">
      {files.map((file) => (
        <Card key={file.id} className="bg-gray-800/50 border-emerald-500/30 hover:border-emerald-400/50 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {getCategoryIcon(file.category)}
                <div>
                  <div className="text-white font-medium text-sm">{file.name}</div>
                  <div className="text-gray-400 text-xs">{file.size} • {file.lastModified}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={getSecurityColor(file.securityLevel)}>
                  <Lock className="h-3 w-3 mr-1" />
                  {file.securityLevel.toUpperCase()}
                </Badge>
                <Button size="sm" variant="outline" className="border-emerald-500 text-emerald-400 hover:bg-emerald-500 hover:text-white">
                  <Eye className="h-3 w-3 mr-1" />
                  View
                </Button>
                <Button size="sm" variant="outline" className="border-emerald-500 text-emerald-400 hover:bg-emerald-500 hover:text-white">
                  <Download className="h-3 w-3 mr-1" />
                  Download
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  if (loading) {
    return (
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardContent className="p-6 text-center">
          <div className="text-emerald-400">Loading all Super Admin files...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-emerald-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Files className="h-5 w-5" />
            Super Admin Alaziel Banking - All Files Display
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Badge className="bg-red-600 p-3 justify-center">
              <div className="text-center">
                <div className="text-sm font-bold">{filesByCategory.legal.length}</div>
                <div className="text-xs">Legal Documents</div>
              </div>
            </Badge>
            <Badge className="bg-emerald-600 p-3 justify-center">
              <div className="text-center">
                <div className="text-sm font-bold">{filesByCategory.banking.length}</div>
                <div className="text-xs">Banking Files</div>
              </div>
            </Badge>
            <Badge className="bg-orange-600 p-3 justify-center">
              <div className="text-center">
                <div className="text-sm font-bold">{filesByCategory.tax.length}</div>
                <div className="text-xs">Tax Documents</div>
              </div>
            </Badge>
            <Badge className="bg-blue-600 p-3 justify-center">
              <div className="text-center">
                <div className="text-sm font-bold">{filesByCategory.business.length}</div>
                <div className="text-xs">Business Files</div>
              </div>
            </Badge>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-gray-800 border border-emerald-500/30">
          <TabsTrigger value="all" className="text-emerald-300 data-[state=active]:bg-emerald-600">All Files</TabsTrigger>
          <TabsTrigger value="banking" className="text-emerald-300 data-[state=active]:bg-emerald-600">Banking</TabsTrigger>
          <TabsTrigger value="legal" className="text-emerald-300 data-[state=active]:bg-emerald-600">Legal</TabsTrigger>
          <TabsTrigger value="tax" className="text-emerald-300 data-[state=active]:bg-emerald-600">Tax</TabsTrigger>
          <TabsTrigger value="business" className="text-emerald-300 data-[state=active]:bg-emerald-600">Business</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-4">
          <FileList files={filesByCategory.all} />
        </TabsContent>
        
        <TabsContent value="banking" className="mt-4">
          <FileList files={filesByCategory.banking} />
        </TabsContent>
        
        <TabsContent value="legal" className="mt-4">
          <FileList files={filesByCategory.legal} />
        </TabsContent>
        
        <TabsContent value="tax" className="mt-4">
          <FileList files={filesByCategory.tax} />
        </TabsContent>
        
        <TabsContent value="business" className="mt-4">
          <FileList files={filesByCategory.business} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SuperAdminFilesDisplay;