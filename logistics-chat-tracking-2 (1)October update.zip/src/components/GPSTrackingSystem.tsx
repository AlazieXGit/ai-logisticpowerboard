import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation, Truck, Clock, AlertTriangle } from 'lucide-react';

interface GPSLocation {
  lat: number;
  lng: number;
  address: string;
  timestamp: string;
}

interface ShipmentGPS {
  id: string;
  orderNumber: string;
  currentLocation: GPSLocation;
  destination: GPSLocation;
  estimatedArrival: string;
  status: 'in_transit' | 'delayed' | 'on_schedule' | 'arrived';
  speed: number;
  distance: number;
  carrier: string;
}

const GPSTrackingSystem: React.FC = () => {
  const [shipments, setShipments] = useState<ShipmentGPS[]>([
    {
      id: 'GPS001',
      orderNumber: 'ORD-H001-2024',
      currentLocation: {
        lat: 52.5200,
        lng: 13.4050,
        address: 'Berlin, Germany',
        timestamp: new Date().toISOString()
      },
      destination: {
        lat: 40.7128,
        lng: -74.0060,
        address: 'Alucius Alford Residence, New York, NY, USA',
        timestamp: ''
      },
      estimatedArrival: '2024-01-15 14:30',
      status: 'in_transit',
      speed: 65,
      distance: 3847,
      carrier: 'Tesla International Robotics'
    },
    {
      id: 'GPS002',
      orderNumber: 'ORD-H004-2024',
      currentLocation: {
        lat: 48.1351,
        lng: 11.5820,
        address: 'Munich, Germany',
        timestamp: new Date().toISOString()
      },
      destination: {
        lat: 34.0522,
        lng: -118.2437,
        address: 'Alucius Alford Estate, Los Angeles, CA, USA',
        timestamp: ''
      },
      estimatedArrival: '2024-01-16 09:15',
      status: 'on_schedule',
      speed: 72,
      distance: 5674,
      carrier: 'BMW Robotics Division'
    },
    {
      id: 'GPS003',
      orderNumber: 'RR-PHANTOM-2024',
      currentLocation: {
        lat: 51.5074,
        lng: -0.1278,
        address: 'Rolls-Royce London, UK',
        timestamp: new Date().toISOString()
      },
      destination: {
        lat: 40.7589,
        lng: -73.9851,
        address: 'Alucius Alford - Manhattan Penthouse, NY, USA',
        timestamp: ''
      },
      estimatedArrival: '2024-01-18 16:00',
      status: 'in_transit',
      speed: 0,
      distance: 3459,
      carrier: 'Rolls-Royce Premium Delivery'
    }
  ]);

  const [selectedShipment, setSelectedShipment] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setShipments(prev => prev.map(shipment => ({
        ...shipment,
        currentLocation: {
          ...shipment.currentLocation,
          timestamp: new Date().toISOString()
        },
        speed: Math.floor(Math.random() * 20) + 60,
        distance: shipment.distance - Math.floor(Math.random() * 10) + 5
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in_transit': return 'bg-blue-600';
      case 'on_schedule': return 'bg-green-600';
      case 'delayed': return 'bg-yellow-600';
      case 'arrived': return 'bg-purple-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Navigation className="h-6 w-6 text-blue-400" />
        <h2 className="text-2xl font-bold text-white">Real-Time GPS Tracking</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {shipments.map((shipment) => (
          <Card key={shipment.id} className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-white flex items-center gap-2">
                  <Truck className="h-5 w-5" />
                  {shipment.orderNumber}
                </CardTitle>
                <Badge className={getStatusColor(shipment.status)}>
                  {shipment.status.replace('_', ' ').toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-gray-300">
                <strong>Carrier:</strong> {shipment.carrier}
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="h-4 w-4 text-green-400 mt-1" />
                  <div>
                    <div className="text-white font-medium">Current Location</div>
                    <div className="text-gray-400 text-sm">{shipment.currentLocation.address}</div>
                    <div className="text-xs text-gray-500">
                      Last updated: {new Date(shipment.currentLocation.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <MapPin className="h-4 w-4 text-red-400 mt-1" />
                  <div>
                    <div className="text-white font-medium">Destination</div>
                    <div className="text-gray-400 text-sm">{shipment.destination.address}</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-3 border-t border-gray-600">
                <div className="text-center">
                  <div className="text-blue-400 font-bold text-lg">{shipment.speed} mph</div>
                  <div className="text-gray-400 text-xs">Current Speed</div>
                </div>
                <div className="text-center">
                  <div className="text-green-400 font-bold text-lg">{shipment.distance} mi</div>
                  <div className="text-gray-400 text-xs">Remaining</div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <Clock className="h-4 w-4 text-yellow-400" />
                <div className="text-sm">
                  <span className="text-gray-400">ETA:</span>
                  <span className="text-white ml-2">{shipment.estimatedArrival}</span>
                </div>
              </div>

              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => setSelectedShipment(shipment.id)}
              >
                View Live Map
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedShipment && (
        <Card className="bg-gray-800/50 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">Live GPS Map View</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-700 h-64 rounded-lg flex items-center justify-center">
              <div className="text-center text-gray-400">
                <MapPin className="h-12 w-12 mx-auto mb-2" />
                <p>Interactive GPS Map</p>
                <p className="text-sm">Real-time location tracking for {selectedShipment}</p>
              </div>
            </div>
            <Button 
              className="mt-4" 
              variant="outline"
              onClick={() => setSelectedShipment(null)}
            >
              Close Map
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default GPSTrackingSystem;