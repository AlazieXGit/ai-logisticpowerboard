import React, { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import SummaryCards from "./SummaryCards";
import RevenueTable from "./RevenueTable";

export default function BackOfficeManualTransfer() {
  const [mainTab, setMainTab] = useState("Finance");
  const [subTab, setSubTab] = useState("Manual Transfer Protocol");
  const [form, setForm] = useState({
    sourceAccount: "Ops Settlement 001",
    destinationAccount: "External – ACH •••• 7921",
    amount: "",
    currency: "USD",
    memo: "",
    transferType: "ACH",
    backOfficeAuthCode: "BO-9XK2-41QF",
    superAdminAuthCode: "SA-7LMN-33TZ",
    platformFeeBps: 45,
  });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);

  const mockTotals = {
    totalRevenue: 2847562.45,
    automatedServiceFees: 156780.32,
    platformFees: 89432.11,
    opsAdminFees: 67890.45,
    dispatchFees: 45123.78,
    savings: 234567.89,
    profit: 567890.12
  };

  const mockPlatforms = [
    { name: "TMS Platform", revenue: 890123.45, fees: 45678.90 },
    { name: "Dispatch System", revenue: 567890.12, fees: 23456.78 },
    { name: "Banking Platform", revenue: 1234567.89, fees: 67890.12 }
  ];

  const mainTabs = ["Finance", "Operations", "Risk", "Settings"];
  const financeSubTabs = ["Overview", "Manual Transfer Protocol", "Automations", "Reconciliations", "Dispatch Fees"];

  const onChange = (name: string, value: string) => setForm({ ...form, [name]: value });

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setResult(null);
    
    // Simulate API call
    setTimeout(() => {
      setResult({ ok: true, data: { reference: "TXN-" + Date.now() } });
      setBusy(false);
    }, 2000);
  };

  return (
    <div className="p-6 space-y-6 bg-slate-900 min-h-screen text-white">
      {/* First row tabs */}
      <Tabs value={mainTab} onValueChange={setMainTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800">
          {mainTabs.map((t) => (
            <TabsTrigger key={t} value={t} className="data-[state=active]:bg-slate-700">
              {t}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* Second row tabs */}
      {mainTab === "Finance" && (
        <Tabs value={subTab} onValueChange={setSubTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800">
            {financeSubTabs.map((t) => (
              <TabsTrigger key={t} value={t} className="data-[state=active]:bg-slate-700 text-xs">
                {t}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      )}

      <SummaryCards totals={mockTotals} />

      {mainTab === "Finance" && subTab === "Manual Transfer Protocol" && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Manual Transfer Protocol (MTP)</CardTitle>
            <p className="text-slate-400">All external transfers initiated by Back Office or Super Admin with authorization codes</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="sourceAccount" className="text-white">Source Account</Label>
                  <Input
                    id="sourceAccount"
                    value={form.sourceAccount}
                    onChange={(e) => onChange("sourceAccount", e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="destinationAccount" className="text-white">Destination Account</Label>
                  <Input
                    id="destinationAccount"
                    value={form.destinationAccount}
                    onChange={(e) => onChange("destinationAccount", e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="amount" className="text-white">Amount</Label>
                    <Input
                      id="amount"
                      type="number"
                      min="0.01"
                      step="0.01"
                      value={form.amount}
                      onChange={(e) => onChange("amount", e.target.value)}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="currency" className="text-white">Currency</Label>
                    <Select value={form.currency} onValueChange={(value) => onChange("currency", value)}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-700 border-slate-600">
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="GBP">GBP</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="backOfficeAuthCode" className="text-white">Back Office Auth Code</Label>
                  <Input
                    id="backOfficeAuthCode"
                    value={form.backOfficeAuthCode}
                    readOnly
                    className="bg-slate-600 border-slate-500 text-blue-300"
                  />
                </div>
                <div>
                  <Label htmlFor="superAdminAuthCode" className="text-white">Super Admin Auth Code</Label>
                  <Input
                    id="superAdminAuthCode"
                    value={form.superAdminAuthCode}
                    readOnly
                    className="bg-slate-600 border-slate-500 text-blue-300"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={busy}
                  className="w-full bg-cyan-600 hover:bg-cyan-700"
                >
                  {busy ? "Processing..." : "Initiate Manual Transfer"}
                </Button>
                
                {result && (
                  <Alert className={result.ok ? "border-green-500" : "border-red-500"}>
                    <AlertDescription className={result.ok ? "text-green-400" : "text-red-400"}>
                      {result.ok ? (
                        <>Transfer queued. Reference: {result.data.reference}</>
                      ) : (
                        <>Transfer failed: {result.message}</>
                      )}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <RevenueTable platforms={mockPlatforms} />
    </div>
  );
}