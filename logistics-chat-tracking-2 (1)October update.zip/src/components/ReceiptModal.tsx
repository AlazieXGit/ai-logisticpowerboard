import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Download, Mail, FileText } from 'lucide-react';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: {
    vehicle: string;
    price: string;
    orderDate: string;
    trackingNumber: string;
    dealership: string;
  };
}

export default function ReceiptModal({ isOpen, onClose, order }: ReceiptModalProps) {
  const handleEmailReceipt = () => {
    // Email receipt functionality
    console.log('Sending receipt to alaziellc.innovation@gmail.com');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Purchase Receipt
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Card>
            <CardContent className="p-6">
              <div className="text-center mb-4">
                <h3 className="text-lg font-bold">Alazie LLC</h3>
                <p className="text-sm text-gray-600">2408 Yanceyville St. Greensboro N.C. 27405</p>
              </div>
              
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>Vehicle:</span>
                  <span className="font-semibold">{order.vehicle}</span>
                </div>
                <div className="flex justify-between">
                  <span>Price:</span>
                  <span className="font-semibold">{order.price}</span>
                </div>
                <div className="flex justify-between">
                  <span>Order Date:</span>
                  <span>{order.orderDate}</span>
                </div>
                <div className="flex justify-between">
                  <span>Dealership:</span>
                  <span>{order.dealership}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tracking:</span>
                  <span className="font-mono">{order.trackingNumber}</span>
                </div>
              </div>
              
              <div className="border-t pt-4 mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">Total:</span>
                  <span className="text-lg font-bold">{order.price}</span>
                </div>
                <Badge className="bg-green-600 mt-2">Payment Complete</Badge>
              </div>
              
              <div className="flex gap-2 mt-6">
                <Button size="sm" onClick={handleEmailReceipt}>
                  <Mail className="h-4 w-4 mr-2" />
                  Email Receipt
                </Button>
                <Button size="sm" variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
                <Button size="sm" variant="outline" onClick={onClose}>
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}