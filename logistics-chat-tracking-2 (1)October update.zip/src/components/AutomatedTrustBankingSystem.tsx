import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowRight, Shield, DollarSign, AlertTriangle, CheckCircle, TrendingUp, Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AutomatedTrustBankingSystem = () => {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [revenueStreams, setRevenueStreams] = useState([]);
  const [liveRevenue, setLiveRevenue] = useState(0);

  const TRUST_ACCOUNT = {
    name: 'Alaziel Banking - Trust Account',
    accountNumber: '5573-9012-4567-8903',
    routingNumber: '031176110',
    balance: 2500000
  };

  const PRIMARY_ACCOUNT = {
    name: 'Alaziel Banking - Primary Operations',
    accountNumber: '4472-8901-3456-7892',
    routingNumber: '021000021',
    balance: 150000
  };

  const ESCROW_ACCOUNT = {
    name: 'Alaziel Banking - Escrow',
    accountNumber: '3361-7890-2345-6781',
    routingNumber: '011401533',
    balance: 100000,
    locked: true,
    minimumBalance: 5000000
  };

  // Live revenue ticker
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveRevenue(prev => prev + Math.floor(Math.random() * 500) + 100);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const processRevenueToTrust = async () => {
    setIsProcessing(true);
    
    const mockRevenue = [
      { source: 'Synergy AI Subscriptions', amount: 4900, category: 'synergy_ai_subscriptions' },
      { source: 'Banking Platform Fees', amount: 2500, category: 'platform_fees' },
      { source: 'AI Service Usage', amount: 1200, category: 'ai_service_fees' },
      { source: 'Admin Processing Fees', amount: 800, category: 'admin_fees' },
      { source: 'Transaction Fees', amount: 650, category: 'transaction_fees' }
    ];

    const totalRevenue = mockRevenue.reduce((sum, item) => sum + item.amount, 0);

    setTimeout(() => {
      setRevenueStreams(mockRevenue.map(item => ({
        ...item,
        id: `REV-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        status: 'completed',
        route: 'Primary → Trust Account',
        timestamp: new Date().toISOString()
      })));

      toast({
        title: 'Revenue Processed',
        description: `$${totalRevenue.toLocaleString()} automatically routed to Trust Account`
      });

      setIsProcessing(false);
    }, 2000);
  };

  const transferEscrowFunds = async () => {
    const transferAmount = ESCROW_ACCOUNT.balance - ESCROW_ACCOUNT.minimumBalance;
    
    if (transferAmount > 0) {
      toast({
        title: 'Escrow Transfer Complete',
        description: `$${transferAmount.toLocaleString()} transferred to Trust Account. $${ESCROW_ACCOUNT.minimumBalance.toLocaleString()} remains in escrow.`
      });
    } else {
      toast({
        title: 'Escrow Status',
        description: `Escrow account already at minimum $${ESCROW_ACCOUNT.minimumBalance.toLocaleString()} balance`
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-300 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Automated Trust Banking System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="accounts" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="accounts">Account Overview</TabsTrigger>
              <TabsTrigger value="live-revenue">Live Revenue Total</TabsTrigger>
            </TabsList>
            
            <TabsContent value="accounts" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-800/30 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-blue-300 font-semibold">Trust Account</span>
                    <Badge className="bg-green-600">Active</Badge>
                  </div>
                  <p className="text-2xl font-bold text-green-400">${TRUST_ACCOUNT.balance.toLocaleString()}</p>
                  <p className="text-xs text-gray-400">Primary Revenue Destination</p>
                </div>

                <div className="bg-yellow-800/30 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-yellow-300 font-semibold">Primary Account</span>
                    <Badge className="bg-yellow-600">Processing Hub</Badge>
                  </div>
                  <p className="text-2xl font-bold text-yellow-400">${PRIMARY_ACCOUNT.balance.toLocaleString()}</p>
                  <p className="text-xs text-gray-400">Payment Processing</p>
                </div>

                <div className="bg-red-800/30 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-red-300 font-semibold">Escrow Account</span>
                    <Badge className="bg-red-600">Locked</Badge>
                  </div>
                  <p className="text-2xl font-bold text-red-400">${ESCROW_ACCOUNT.balance.toLocaleString()}</p>
                  <p className="text-xs text-gray-400">Minimum Balance: ${ESCROW_ACCOUNT.minimumBalance.toLocaleString()}</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="live-revenue" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-gradient-to-r from-green-900 to-emerald-900 border-green-500/30">
                  <CardHeader>
                    <CardTitle className="text-green-300 flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Live Revenue Stream
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <p className="text-4xl font-bold text-green-400 mb-2">
                        ${liveRevenue.toLocaleString()}
                      </p>
                      <p className="text-green-300 mb-4">Total Revenue Today</p>
                      <div className="flex items-center justify-center gap-2 text-sm text-green-400">
                        <Activity className="h-4 w-4 animate-pulse" />
                        Live Updates Every 3 Seconds
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-blue-500/30">
                  <CardHeader>
                    <CardTitle className="text-blue-400">Revenue Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Platform Fees</span>
                        <span className="text-green-400">${(liveRevenue * 0.4).toFixed(0)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">AI Services</span>
                        <span className="text-green-400">${(liveRevenue * 0.3).toFixed(0)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Subscriptions</span>
                        <span className="text-green-400">${(liveRevenue * 0.2).toFixed(0)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Transaction Fees</span>
                        <span className="text-green-400">${(liveRevenue * 0.1).toFixed(0)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400">Revenue Routing Control</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-gray-300">
              <DollarSign className="h-4 w-4" />
              All revenue automatically routes to Trust Account
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-300">
              <ArrowRight className="h-4 w-4" />
              Override 24hr daily deposit limits
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-300">
              <CheckCircle className="h-4 w-4" />
              Direct deposit through Primary Account
            </div>
            
            <Button 
              onClick={processRevenueToTrust}
              disabled={isProcessing}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              {isProcessing ? 'Processing Revenue...' : 'Process All Revenue to Trust'}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-orange-500/30">
          <CardHeader>
            <CardTitle className="text-orange-400">Escrow Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-gray-300">
              <AlertTriangle className="h-4 w-4" />
              Maintain ${ESCROW_ACCOUNT.minimumBalance.toLocaleString()} minimum balance
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-300">
              <ArrowRight className="h-4 w-4" />
              Transfer excess to Trust Account
            </div>
            
            <Button 
              onClick={transferEscrowFunds}
              className="w-full bg-orange-600 hover:bg-orange-700"
            >
              Transfer Escrow Excess to Trust
            </Button>
          </CardContent>
        </Card>
      </div>

      {revenueStreams.length > 0 && (
        <Card className="bg-gray-800 border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-blue-400">Recent Revenue Transfers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {revenueStreams.map((stream) => (
                <div key={stream.id} className="flex items-center justify-between p-3 bg-blue-900/20 rounded-lg">
                  <div>
                    <p className="font-semibold text-blue-300">{stream.source}</p>
                    <p className="text-xs text-gray-400">{stream.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-400">${stream.amount.toLocaleString()}</p>
                    <p className="text-xs text-gray-400">{stream.route}</p>
                  </div>
                  <Badge className="bg-green-600">Completed</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AutomatedTrustBankingSystem;