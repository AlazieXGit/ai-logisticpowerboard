import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { CreditCard, DollarSign, Send, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const ManualPaymentProcessor: React.FC = () => {
  const [paymentData, setPaymentData] = useState({
    amount: '',
    recipient: '',
    paymentType: '',
    routingNumber: '',
    accountNumber: '',
    description: ''
  });
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  const handlePayment = async () => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'manual_payment',
          ...paymentData,
          admin: 'alaziellc.innovation@gmail.com'
        }
      });
      
      if (!error) {
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
      }
    } catch (error) {
      console.error('Payment error:', error);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-green-900/20 border-green-500/50">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Manual Payment Processing - Alucius Alford Access
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Payment Amount</Label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={paymentData.amount}
                onChange={(e) => setPaymentData({...paymentData, amount: e.target.value})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Recipient</Label>
              <Input
                placeholder="Vendor/Recipient name"
                value={paymentData.recipient}
                onChange={(e) => setPaymentData({...paymentData, recipient: e.target.value})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          </div>
          
          <div>
            <Label className="text-gray-300">Payment Type</Label>
            <Select value={paymentData.paymentType} onValueChange={(value) => setPaymentData({...paymentData, paymentType: value})}>
              <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="direct_deposit">Direct Deposit</SelectItem>
                <SelectItem value="wire_transfer">Wire Transfer</SelectItem>
                <SelectItem value="ach">ACH Transfer</SelectItem>
                <SelectItem value="virtual_payment">Virtual Payment</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Bank Routing Number</Label>
              <Input
                placeholder="9-digit routing number"
                value={paymentData.routingNumber}
                onChange={(e) => setPaymentData({...paymentData, routingNumber: e.target.value})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Account Number</Label>
              <Input
                placeholder="Account number"
                value={paymentData.accountNumber}
                onChange={(e) => setPaymentData({...paymentData, accountNumber: e.target.value})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          </div>

          <div>
            <Label className="text-gray-300">Description</Label>
            <Input
              placeholder="Payment description"
              value={paymentData.description}
              onChange={(e) => setPaymentData({...paymentData, description: e.target.value})}
              className="bg-gray-800 border-gray-600 text-white"
            />
          </div>

          <Button 
            onClick={handlePayment} 
            disabled={processing || !paymentData.amount || !paymentData.recipient}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            {processing ? (
              'Processing...'
            ) : success ? (
              <><CheckCircle className="h-4 w-4 mr-2" />Payment Sent</>
            ) : (
              <><Send className="h-4 w-4 mr-2" />Send Payment</>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default ManualPaymentProcessor;