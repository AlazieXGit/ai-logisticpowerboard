import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, TrendingUp, TrendingDown } from 'lucide-react';

interface HealthData {
  timestamp: string;
  uptime: number;
  performance: number;
  transactions: number;
}

interface SystemHealthChartProps {
  data: HealthData[];
  title?: string;
}

export const SystemHealthChart: React.FC<SystemHealthChartProps> = ({ 
  data, 
  title = "System Health Monitor" 
}) => {
  const latestData = data[data.length - 1] || { uptime: 0, performance: 0, transactions: 0 };
  const previousData = data[data.length - 2] || latestData;
  
  const uptimeTrend = latestData.uptime - previousData.uptime;
  const perfTrend = latestData.performance - previousData.performance;

  return (
    <Card className="bg-gradient-to-br from-blue-900/30 to-purple-900/30 border-blue-500">
      <CardHeader>
        <CardTitle className="text-blue-400 flex items-center gap-2">
          <Activity className="h-5 w-5" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-blue-300 text-sm">System Uptime</span>
              {uptimeTrend >= 0 ? 
                <TrendingUp className="h-4 w-4 text-green-400" /> : 
                <TrendingDown className="h-4 w-4 text-red-400" />
              }
            </div>
            <div className="text-2xl font-bold text-blue-400">{latestData.uptime.toFixed(1)}%</div>
          </div>
          
          <div className="bg-purple-900/20 p-4 rounded-lg border border-purple-500/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Performance</span>
              {perfTrend >= 0 ? 
                <TrendingUp className="h-4 w-4 text-green-400" /> : 
                <TrendingDown className="h-4 w-4 text-red-400" />
              }
            </div>
            <div className="text-2xl font-bold text-purple-400">{latestData.performance.toFixed(1)}%</div>
          </div>
          
          <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30">
            <span className="text-green-300 text-sm">Transactions</span>
            <div className="text-2xl font-bold text-green-400">{latestData.transactions.toLocaleString()}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
