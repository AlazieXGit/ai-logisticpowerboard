import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowDown, DollarSign, TrendingUp, Calculator } from 'lucide-react';

const FinalDestinationAccountTotal = () => {
  const [totalProcessed, setTotalProcessed] = useState(0);
  const [finalBalance, setFinalBalance] = useState(0);

  // All revenue sources and fees
  // Enhanced revenue sources and fees with routing from all streams
  const revenueBreakdown = [
    { category: 'Synergy AI Platform Revenue', amount: 45000, type: 'income', source: 'platform' },
    { category: 'AI Services Subscriptions', amount: 32500, type: 'income', source: 'subscriptions' },
    { category: 'Credit Repair Services', amount: 28000, type: 'income', source: 'credit_repair' },
    { category: 'Transaction Processing Revenue', amount: 22500, type: 'income', source: 'transactions' },
    { category: 'Automation Workflows Revenue', amount: 18200, type: 'income', source: 'automation' },
    { category: 'Analytics Services Revenue', amount: 15800, type: 'income', source: 'analytics' },
    { category: 'AI Assistant Services', amount: 12000, type: 'income', source: 'ai_assistant' },
    { category: 'Platform Integration Fees', amount: 8500, type: 'income', source: 'integrations' },
    { category: 'Synergy Platform Fees (3.2%)', amount: -5824, type: 'fee', category_type: 'platform' },
    { category: 'AI Processing & Maintenance', amount: -3900, type: 'fee', category_type: 'ai_services' },
    { category: 'Credit Repair Processing Fees', amount: -2800, type: 'fee', category_type: 'credit' },
    { category: 'Transaction Processing Fees (2.1%)', amount: -3465, type: 'fee', category_type: 'transactions' },
    { category: 'Automation License Fees', amount: -1820, type: 'fee', category_type: 'automation' },
    { category: 'Security & Compliance Fees', amount: -1580, type: 'fee', category_type: 'security' },
    { category: 'Admin & Operational Fees', amount: -1200, type: 'fee', category_type: 'admin' }
  ];

  const totalIncome = revenueBreakdown
    .filter(item => item.type === 'income')
    .reduce((sum, item) => sum + item.amount, 0);

  const totalFees = revenueBreakdown
    .filter(item => item.type === 'fee')
    .reduce((sum, item) => sum + Math.abs(item.amount), 0);

  const netTotal = totalIncome - totalFees;

  useEffect(() => {
    const interval = setInterval(() => {
      setTotalProcessed(prev => {
        if (prev >= 100) {
          setFinalBalance(netTotal);
          return 100;
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [netTotal]);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-emerald-900 to-teal-900 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-300 flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            SYNERGY AI - Final Destination Account Total (All Revenue Streams Routed)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-emerald-300 text-sm font-semibold">Total Income</p>
                <p className="text-2xl font-bold text-green-400">
                  ${totalIncome.toLocaleString()}
                </p>
              </div>
              <div className="text-center">
                <p className="text-red-300 text-sm font-semibold">Total Fees</p>
                <p className="text-2xl font-bold text-red-400">
                  -${totalFees.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-center">
              <ArrowDown className="h-8 w-8 text-emerald-400" />
            </div>

            <div className="space-y-4">
              <div className="text-center p-4 bg-emerald-900/30 rounded-lg border border-emerald-500/30">
                <p className="text-emerald-300 text-sm font-semibold mb-2">Final Balance</p>
                <p className="text-3xl font-bold text-emerald-400">
                  ${finalBalance.toLocaleString()}
                </p>
                <Badge className="mt-2 bg-emerald-600">
                  Net After All Deductions
                </Badge>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Processing</span>
                  <span className="text-emerald-400">{totalProcessed}%</span>
                </div>
                <Progress value={totalProcessed} className="h-2" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Revenue Sources
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {revenueBreakdown
                .filter(item => item.type === 'income')
                .map((item, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-green-900/20 rounded">
                  <span className="text-green-300 text-sm">{item.category}</span>
                  <span className="text-green-400 font-semibold">
                    ${item.amount.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Platform Fees & Deductions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {revenueBreakdown
                .filter(item => item.type === 'fee')
                .map((item, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-red-900/20 rounded">
                  <span className="text-red-300 text-sm">{item.category}</span>
                  <span className="text-red-400 font-semibold">
                    ${Math.abs(item.amount).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FinalDestinationAccountTotal;