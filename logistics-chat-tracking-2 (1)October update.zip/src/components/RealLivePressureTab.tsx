import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Activity, Users, Target, DollarSign, Zap } from 'lucide-react';
import { RevenueFeesDisplay } from './RevenueFeesDisplay';
import { PerformanceBoostPanel } from './PerformanceBoostPanel';

interface PressureMetrics {
  totalRevenue: number;
  activeClients: number;
  targetProgress: number;
  conversionRate: number;
  systemLoad: number;
  contractsProcessed: number;
}

export const RealLivePressureTab: React.FC = () => {
  const [metrics, setMetrics] = useState<PressureMetrics>({
    totalRevenue: 0,
    activeClients: 0,
    targetProgress: 0,
    conversionRate: 0,
    systemLoad: 0,
    contractsProcessed: 0
  });

  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    const updateMetrics = () => {
      setMetrics({
        totalRevenue: Math.floor(Math.random() * 500000) + 250000,
        activeClients: Math.floor(Math.random() * 1500) + 2500,
        targetProgress: Math.min(95, Math.floor(Math.random() * 30) + 65),
        conversionRate: Math.floor(Math.random() * 15) + 75,
        systemLoad: Math.floor(Math.random() * 40) + 30,
        contractsProcessed: Math.floor(Math.random() * 50) + 125
      });
    };

    updateMetrics();
    const interval = setInterval(updateMetrics, 3000);
    return () => clearInterval(interval);
  }, []);

  const targetClients = 9000;
  const enhancedGoal = 20000;
  const progressToTarget = (metrics.activeClients / targetClients) * 100;
  const progressToEnhanced = (metrics.activeClients / enhancedGoal) * 100;

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Real/Live Pressure Analytics</h2>
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${isLive ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
          <span className="text-sm font-medium">{isLive ? 'LIVE' : 'OFFLINE'}</span>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Fees</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="border-l-4 border-l-green-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  Live Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  ${metrics.totalRevenue.toLocaleString()}
                </div>
                <p className="text-sm text-gray-600 mt-1">Real-time revenue tracking</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-500" />
                  Active Clients
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  {metrics.activeClients.toLocaleString()}
                </div>
                <p className="text-sm text-gray-600 mt-1">Currently enrolled</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-purple-500" />
                  System Load
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">
                  {metrics.systemLoad}%
                </div>
                <Progress value={metrics.systemLoad} className="mt-2" />
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Target Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Initial Target (9,000)</span>
                    <span className="text-sm text-gray-600">{progressToTarget.toFixed(1)}%</span>
                  </div>
                  <Progress value={progressToTarget} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Enhanced Goal (20,000)</span>
                    <span className="text-sm text-gray-600">{progressToEnhanced.toFixed(1)}%</span>
                  </div>
                  <Progress value={progressToEnhanced} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Live Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Conversion Rate</span>
                  <Badge variant="secondary">{metrics.conversionRate}%</Badge>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Contracts Processed</span>
                  <Badge variant="outline">{metrics.contractsProcessed}</Badge>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">D.B.A Agreements</span>
                  <Badge variant="default">Active</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue">
          <RevenueFeesDisplay />
        </TabsContent>

        <TabsContent value="performance">
          <PerformanceBoostPanel />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Booking Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Auto Bookings Today</span>
                  <Badge>{Math.floor(Math.random() * 200) + 150}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Load Matches</span>
                  <Badge variant="outline">{Math.floor(Math.random() * 100) + 75}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Contract Generations</span>
                  <Badge variant="secondary">{Math.floor(Math.random() * 50) + 25}</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Operation Angles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Front Office View</span>
                  <Badge className="bg-green-500">Active</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Back Office Control</span>
                  <Badge className="bg-blue-500">Monitoring</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Super Admin Access</span>
                  <Badge className="bg-purple-500">Full Control</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};