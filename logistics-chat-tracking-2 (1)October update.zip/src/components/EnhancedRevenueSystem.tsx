import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DollarSign, TrendingUp, Target, Zap, ArrowUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface RevenueStream {
  id: string;
  name: string;
  amount: number;
  growth: number;
  status: 'active' | 'optimizing' | 'pending';
}

const EnhancedRevenueSystem: React.FC = () => {
  const [revenueStreams, setRevenueStreams] = useState<RevenueStream[]>([
    { id: '1', name: 'Stripe Payments', amount: 50000, growth: 15.2, status: 'active' },
    { id: '2', name: 'Banking Fees', amount: 25000, growth: 8.7, status: 'active' },
    { id: '3', name: 'TMS Operations', amount: 35000, growth: 22.1, status: 'optimizing' },
    { id: '4', name: 'Vendor Commissions', amount: 18000, growth: 12.5, status: 'active' }
  ]);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [isOptimizing, setIsOptimizing] = useState(false);

  useEffect(() => {
    const total = revenueStreams.reduce((sum, stream) => sum + stream.amount, 0);
    setTotalRevenue(total);
  }, [revenueStreams]);

  const optimizeRevenue = async () => {
    setIsOptimizing(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('revenue', {
        body: { action: 'optimize_streams' }
      });
      
      if (data && !error) {
        setRevenueStreams(prev => prev.map(stream => ({
          ...stream,
          amount: stream.amount * (1 + Math.random() * 0.1),
          growth: stream.growth + Math.random() * 5
        })));
      }
    } catch (error) {
      console.error('Revenue optimization error:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900/20 to-emerald-900/20 border-green-500/50">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            ENHANCED REVENUE OPTIMIZATION SYSTEM
            <Badge className="bg-green-600 animate-pulse">ACTIVE</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">
                {formatCurrency(totalRevenue)}
              </div>
              <div className="text-sm text-gray-300">Total Monthly Revenue</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">
                {revenueStreams.length}
              </div>
              <div className="text-sm text-gray-300">Active Streams</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">
                {((revenueStreams.reduce((sum, s) => sum + s.growth, 0) / revenueStreams.length)).toFixed(1)}%
              </div>
              <div className="text-sm text-gray-300">Avg Growth</div>
            </div>
            <div className="text-center">
              <Button
                onClick={optimizeRevenue}
                disabled={isOptimizing}
                className="bg-green-600 hover:bg-green-700"
              >
                {isOptimizing ? (
                  <Target className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Zap className="h-4 w-4 mr-2" />
                )}
                {isOptimizing ? 'Optimizing...' : 'Optimize Revenue'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="streams" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="streams">Revenue Streams</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="projections">Projections</TabsTrigger>
        </TabsList>

        <TabsContent value="streams" className="space-y-4">
          {revenueStreams.map((stream) => (
            <Card key={stream.id} className="bg-gray-900/20 border-gray-500/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{stream.name}</h3>
                    <p className="text-gray-300">{formatCurrency(stream.amount)}/month</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2">
                      <ArrowUp className="h-4 w-4 text-green-400" />
                      <span className="text-green-400 font-semibold">
                        +{stream.growth.toFixed(1)}%
                      </span>
                    </div>
                    <Badge 
                      className={
                        stream.status === 'active' ? 'bg-green-600' :
                        stream.status === 'optimizing' ? 'bg-yellow-600' :
                        'bg-gray-600'
                      }
                    >
                      {stream.status.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-blue-900/20 border-blue-500/50">
              <CardHeader>
                <CardTitle className="text-blue-400">Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Conversion Rate</span>
                    <span className="text-green-400 font-bold">8.7%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Customer LTV</span>
                    <span className="text-blue-400 font-bold">$2,450</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Churn Rate</span>
                    <span className="text-yellow-400 font-bold">2.1%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-purple-900/20 border-purple-500/50">
              <CardHeader>
                <CardTitle className="text-purple-400">Optimization Opportunities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-sm text-gray-300">• Increase TMS pricing by 15%</div>
                  <div className="text-sm text-gray-300">• Expand Stripe integration</div>
                  <div className="text-sm text-gray-300">• Add premium banking tiers</div>
                  <div className="text-sm text-gray-300">• Optimize vendor commissions</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="projections" className="space-y-4">
          <Card className="bg-emerald-900/20 border-emerald-500/50">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Revenue Projections
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-400">
                    {formatCurrency(totalRevenue * 1.2)}
                  </div>
                  <div className="text-sm text-gray-300">Next Month</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">
                    {formatCurrency(totalRevenue * 4.5)}
                  </div>
                  <div className="text-sm text-gray-300">Next Quarter</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">
                    {formatCurrency(totalRevenue * 15)}
                  </div>
                  <div className="text-sm text-gray-300">Next Year</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedRevenueSystem;