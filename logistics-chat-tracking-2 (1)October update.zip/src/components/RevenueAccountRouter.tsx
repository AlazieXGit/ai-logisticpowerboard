import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DollarSign, TrendingUp, Building, Bot, Cog, Users } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface RevenueAccount {
  id: string;
  name: string;
  balance: number;
  icon: React.ReactNode;
  color: string;
}

export const RevenueAccountRouter: React.FC = () => {
  const [accounts, setAccounts] = useState<RevenueAccount[]>([
    {
      id: 'alazie-primary',
      name: 'Alazie LLC Primary',
      balance: 2847592,
      icon: <Building className="h-5 w-5" />,
      color: 'bg-lime-600'
    },
    {
      id: 'tms-operations',
      name: 'TMS Operations Revenue',
      balance: 1234567,
      icon: <TrendingUp className="h-5 w-5" />,
      color: 'bg-blue-600'
    },
    {
      id: 'ai-development',
      name: 'AI Development Fund',
      balance: 987654,
      icon: <Bot className="h-5 w-5" />,
      color: 'bg-purple-600'
    },
    {
      id: 'subscription-revenue',
      name: 'Subscription Revenue',
      balance: 3456789,
      icon: <Users className="h-5 w-5" />,
      color: 'bg-green-600'
    },
    {
      id: 'platform-fees',
      name: 'Platform Fee Collection',
      balance: 2198765,
      icon: <Cog className="h-5 w-5" />,
      color: 'bg-orange-600'
    },
    {
      id: 'auto-booking',
      name: 'Auto Booking Revenue',
      balance: 1876543,
      icon: <DollarSign className="h-5 w-5" />,
      color: 'bg-red-600'
    }
  ]);

  const [totalRevenue, setTotalRevenue] = useState(0);

  useEffect(() => {
    loadRevenueData();
    const interval = setInterval(loadRevenueData, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadRevenueData = async () => {
    try {
      const { data } = await supabase.functions.invoke('revenue', {
        body: { action: 'get_account_balances' }
      });

      if (data?.accounts) {
        setAccounts(prev => prev.map(account => ({
          ...account,
          balance: data.accounts[account.id] || 0
        })));
        
        const total = Object.values(data.accounts).reduce((sum: number, balance: any) => sum + balance, 0);
        setTotalRevenue(total);
      }
    } catch (error) {
      console.error('Error loading revenue data:', error);
    }
  };

  const routeRevenue = async (feeBreakdown: any) => {
    try {
      await supabase.functions.invoke('revenue', {
        body: {
          action: 'route_fees',
          fees: {
            admin: feeBreakdown.adminFee,
            'ai-gen': feeBreakdown.aiGenFee,
            'auto-booking': feeBreakdown.autoBookingFee,
            service: feeBreakdown.serviceFee,
            platform: feeBreakdown.platformFee
          }
        }
      });
      
      loadRevenueData();
    } catch (error) {
      console.error('Error routing revenue:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-blue-900 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-6 w-6" />
            Total Platform Revenue
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">
            ${totalRevenue.toLocaleString()}
          </div>
          <p className="text-green-200">All automated service fees</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {accounts.map((account) => (
          <Card key={account.id} className={`${account.color} text-white`}>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                {account.icon}
                {account.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${account.balance.toLocaleString()}
              </div>
              <Badge variant="secondary" className="mt-2">
                {((account.balance / totalRevenue) * 100 || 0).toFixed(1)}%
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};