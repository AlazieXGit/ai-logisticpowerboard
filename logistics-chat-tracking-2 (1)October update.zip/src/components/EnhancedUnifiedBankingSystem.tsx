import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, CreditCard, ArrowRight, Copy, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import RealtimeRevenueTicker from './RealtimeRevenueTicker';

interface BankAccount {
  id: string;
  nickname: string;
  accountNumber: string;
  routingNumber: string;
  accountType: string;
  balance: number;
  status: 'active' | 'pending' | 'verified';
  pin: string;
}

const EnhancedUnifiedBankingSystem: React.FC = () => {
  const [accounts, setAccounts] = useState<BankAccount[]>([
    {
      id: '1',
      nickname: 'Primary Withdrawal (PNC Virtual)',
      accountNumber: '5563935267',
      routingNumber: '054000030',
      accountType: 'Checking',
      balance: 5000,
      status: 'verified',
      pin: '2014'
    },
    {
      id: '2',
      nickname: 'Reserve Account (PNC)',
      accountNumber: '5563935275',
      routingNumber: '054000030',
      accountType: 'Savings',
      balance: 5000,
      status: 'verified',
      pin: '2014'
    },
    {
      id: '3',
      nickname: 'Growth Account (PNC)',
      accountNumber: '5563935283',
      routingNumber: '054000030',
      accountType: 'Business',
      balance: 5000,
      status: 'verified',
      pin: '2014'
    }
  ]);

  const [newAccount, setNewAccount] = useState({
    nickname: '',
    accountNumber: '',
    routingNumber: '',
    accountType: 'Checking'
  });

  const { toast } = useToast();

  useEffect(() => {
    const interval = setInterval(() => {
      setAccounts(prev => prev.map(account => ({
        ...account,
        balance: account.balance + Math.random() * 200
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: `${type} copied to clipboard` });
  };

  const verifyAccount = (accountId: string) => {
    setAccounts(prev => prev.map(account => 
      account.id === accountId 
        ? { ...account, status: 'verified' as const }
        : account
    ));
    toast({ title: 'Account Verified', description: 'Bank account verification complete' });
  };

  const addNewAccount = () => {
    if (!newAccount.nickname || !newAccount.accountNumber || !newAccount.routingNumber) {
      toast({ title: 'Error', description: 'Please fill all required fields' });
      return;
    }

    const account: BankAccount = {
      id: Date.now().toString(),
      ...newAccount,
      balance: 0,
      status: 'pending',
      pin: '2014'
    };

    setAccounts(prev => [...prev, account]);
    setNewAccount({ nickname: '', accountNumber: '', routingNumber: '', accountType: 'Checking' });
    toast({ title: 'Account Added', description: 'New account added successfully' });
  };

  return (
    <div className="space-y-6">
      <RealtimeRevenueTicker />
      
      <Card className="bg-gray-900/50 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            ENHANCED UNIFIED BANKING SYSTEM
            <Badge className="bg-emerald-600 text-white">PNC INTEGRATED</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="accounts" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="accounts">Active Accounts</TabsTrigger>
              <TabsTrigger value="add">Add Account</TabsTrigger>
              <TabsTrigger value="stripe">Stripe Dashboard</TabsTrigger>
              <TabsTrigger value="codes">Connection Codes</TabsTrigger>
            </TabsList>

            <TabsContent value="accounts" className="space-y-4">
              {accounts.map((account) => (
                <Card key={account.id} className="bg-gray-800 border-emerald-500/30">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-emerald-400 text-lg">
                        {account.nickname}
                      </CardTitle>
                      <div className="flex gap-2">
                        <Badge className={
                          account.status === 'verified' ? 'bg-green-600' :
                          account.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                        }>
                          {account.status.toUpperCase()}
                        </Badge>
                        <Badge className="bg-blue-600">{account.accountType}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label className="text-gray-300">Account Number</Label>
                        <div className="flex items-center gap-2">
                          <Input
                            value={account.accountNumber}
                            readOnly
                            className="bg-gray-700 border-emerald-500/30 text-white font-mono"
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(account.accountNumber, 'Account')}
                            className="text-emerald-400"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-gray-300">Routing Number</Label>
                        <div className="flex items-center gap-2">
                          <Input
                            value={account.routingNumber}
                            readOnly
                            className="bg-gray-700 border-emerald-500/30 text-white font-mono"
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(account.routingNumber, 'Routing')}
                            className="text-emerald-400"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-gray-300">Balance</Label>
                        <p className="text-emerald-400 text-xl font-bold">
                          ${account.balance.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div>
                          <Label className="text-gray-300">PIN</Label>
                          <p className="text-emerald-400 font-mono">{account.pin}</p>
                        </div>
                      </div>
                      {account.status !== 'verified' && (
                        <Button
                          onClick={() => verifyAccount(account.id)}
                          className="bg-emerald-600 hover:bg-emerald-700"
                        >
                          <Shield className="h-4 w-4 mr-2" />
                          Verify Account
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="add" className="space-y-4">
              <Card className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Add New External Account</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-gray-300">Account Nickname *</Label>
                      <Input
                        value={newAccount.nickname}
                        onChange={(e) => setNewAccount(prev => ({ ...prev, nickname: e.target.value }))}
                        placeholder="Enter account nickname"
                        className="bg-gray-700 border-emerald-500/30 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-gray-300">Account Type</Label>
                      <select
                        value={newAccount.accountType}
                        onChange={(e) => setNewAccount(prev => ({ ...prev, accountType: e.target.value }))}
                        className="w-full p-2 bg-gray-700 border border-emerald-500/30 rounded text-white"
                      >
                        <option value="Checking">Checking</option>
                        <option value="Savings">Savings</option>
                        <option value="Business">Business</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-gray-300">Account Number *</Label>
                      <Input
                        value={newAccount.accountNumber}
                        onChange={(e) => setNewAccount(prev => ({ ...prev, accountNumber: e.target.value }))}
                        placeholder="Enter account number"
                        className="bg-gray-700 border-emerald-500/30 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-gray-300">Routing Number *</Label>
                      <Input
                        value={newAccount.routingNumber}
                        onChange={(e) => setNewAccount(prev => ({ ...prev, routingNumber: e.target.value }))}
                        placeholder="Enter routing number"
                        className="bg-gray-700 border-emerald-500/30 text-white"
                      />
                    </div>
                  </div>

                  <Button
                    onClick={addNewAccount}
                    className="bg-emerald-600 hover:bg-emerald-700 w-full"
                  >
                    Add Account <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stripe" className="space-y-4">
              <Card className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400 flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Stripe Payment Dashboard Access
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300">
                    Access your Stripe account dashboard to monitor payments, view transactions, and manage connected accounts.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button 
                      onClick={() => window.open('https://dashboard.stripe.com/b/acct_1RxYHMCmvy8VaQQZ/account/status', '_blank')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Open Stripe Dashboard
                    </Button>
                    <Button 
                      onClick={() => window.open('https://connect.stripe.com/d/setup/s/_StKxYRy3NqfUnvDSW7w5t6V0VW/YWNjdF8xUnhZSE1DbXZ5OFZhUVFa/9f9ec6f38af26a765', '_blank')}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Building2 className="h-4 w-4 mr-2" />
                      Setup Stripe Connect
                    </Button>
                  </div>
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <h4 className="text-emerald-400 font-semibold mb-2">Account Information</h4>
                    <div className="space-y-1 text-sm text-gray-300">
                      <p>Account ID: acct_1RxYHMCmvy8VaQQZ</p>
                      <p>Status: Active</p>
                      <p>Integration: Live Mode</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="codes" className="space-y-4">
              <Card className="bg-gray-800 border-emerald-500/30">
                <CardHeader>
                  <CardTitle className="text-emerald-400">Banking Connection Codes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-emerald-400 font-semibold">Primary Account Codes</h3>
                      <div className="space-y-2">
                        <Label className="text-gray-300">Account: 5563935267</Label>
                        <Label className="text-gray-300">Routing: 054000030</Label>
                        <Label className="text-gray-300">PIN: 2014</Label>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-emerald-400 font-semibold">API Integration</h3>
                      <div className="space-y-2">
                        <Label className="text-gray-300">Username: ValdezAlaciasCarter</Label>
                        <Label className="text-gray-300">Password: gotchupin1976</Label>
                        <Label className="text-gray-300">Direct Access Password: gotchupin1976</Label>
                        <Label className="text-gray-300">Email: alaziellc.innovation</Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedUnifiedBankingSystem;