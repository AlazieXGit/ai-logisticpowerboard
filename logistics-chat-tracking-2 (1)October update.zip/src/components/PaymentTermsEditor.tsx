import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { DollarSign, Edit, Trash2, Plus, Loader2 } from 'lucide-react';
import { 
  createPaymentTerm, updatePaymentTerm, getPaymentTerms, 
  deletePaymentTerm, type PaymentTerm 
} from '@/services/adminOperationsService';
import { useToast } from '@/hooks/use-toast';

const PaymentTermsEditor: React.FC = () => {
  const [terms, setTerms] = useState<PaymentTerm[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    term_name: '',
    platform_fee_percentage: 0,
    carrier_percentage: 0,
    broker_percentage: 0
  });
  const { toast } = useToast();

  const loadTerms = async () => {
    setLoading(true);
    try {
      const data = await getPaymentTerms();
      setTerms(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load payment terms",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTerms();
    const interval = setInterval(loadTerms, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async () => {
    try {
      if (editingId) {
        await updatePaymentTerm(editingId, formData, 'Super Admin');
        toast({ title: "Success", description: "Payment term updated" });
      } else {
        await createPaymentTerm({ ...formData, created_by: 'Super Admin' });
        toast({ title: "Success", description: "Payment term created" });
      }
      setFormData({ term_name: '', platform_fee_percentage: 0, carrier_percentage: 0, broker_percentage: 0 });
      setEditingId(null);
      loadTerms();
    } catch (error) {
      toast({ title: "Error", description: "Operation failed", variant: "destructive" });
    }
  };

  const handleEdit = (term: PaymentTerm) => {
    setEditingId(term.id);
    setFormData({
      term_name: term.term_name,
      platform_fee_percentage: term.platform_fee_percentage,
      carrier_percentage: term.carrier_percentage,
      broker_percentage: term.broker_percentage
    });
  };

  const handleDelete = async (termId: string) => {
    if (!confirm('Are you sure you want to delete this payment term?')) return;
    try {
      await deletePaymentTerm(termId);
      toast({ title: "Success", description: "Payment term deleted" });
      loadTerms();
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900/80 border-green-500">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <DollarSign className="h-6 w-6" />
            {editingId ? 'Edit Payment Term' : 'Create Payment Term'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Term Name</Label>
              <Input
                value={formData.term_name}
                onChange={(e) => setFormData({...formData, term_name: e.target.value})}
                placeholder="e.g., Standard Terms"
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Platform Fee %</Label>
              <Input
                type="number"
                value={formData.platform_fee_percentage}
                onChange={(e) => setFormData({...formData, platform_fee_percentage: parseFloat(e.target.value)})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Carrier %</Label>
              <Input
                type="number"
                value={formData.carrier_percentage}
                onChange={(e) => setFormData({...formData, carrier_percentage: parseFloat(e.target.value)})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300">Broker %</Label>
              <Input
                type="number"
                value={formData.broker_percentage}
                onChange={(e) => setFormData({...formData, broker_percentage: parseFloat(e.target.value)})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
              {editingId ? <Edit className="h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
              {editingId ? 'Update' : 'Create'}
            </Button>
            {editingId && (
              <Button onClick={() => { setEditingId(null); setFormData({ term_name: '', platform_fee_percentage: 0, carrier_percentage: 0, broker_percentage: 0 }); }} variant="outline">
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-black/80 border-green-500">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            Active Payment Terms ({terms.length})
            {loading && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {terms.map((term) => (
              <div key={term.id} className="bg-green-900/20 p-4 rounded border border-green-500">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-green-300 font-semibold text-lg">{term.term_name}</h3>
                    <div className="grid grid-cols-3 gap-4 mt-2">
                      <div>
                        <p className="text-gray-400 text-xs">Platform Fee</p>
                        <p className="text-white font-bold">{term.platform_fee_percentage}%</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs">Carrier</p>
                        <p className="text-white font-bold">{term.carrier_percentage}%</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs">Broker</p>
                        <p className="text-white font-bold">{term.broker_percentage}%</p>
                      </div>
                    </div>
                    <p className="text-gray-500 text-xs mt-2">Created: {new Date(term.created_at).toLocaleString()}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(term)} className="border-blue-500 text-blue-400">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleDelete(term.id)} className="border-red-500 text-red-400">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentTermsEditor;
