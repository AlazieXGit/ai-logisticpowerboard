import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  CreditCard, Shield, AlertTriangle, CheckCircle, 
  ExternalLink, Copy, Settings, Globe
} from 'lucide-react';

const ExpandedPaymentIntegrationInstructions = () => {
  const [copiedText, setCopiedText] = useState('');

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(''), 2000);
  };

  const paymentProviders = [
    {
      name: 'Stripe',
      logo: '💳',
      status: 'Primary',
      features: ['Credit Cards', 'ACH', 'International', 'Subscriptions'],
      setupSteps: [
        'Create Stripe account at stripe.com',
        'Complete business verification',
        'Generate API keys from Dashboard',
        'Configure webhooks for real-time updates',
        'Set up Connect for marketplace payments'
      ]
    },
    {
      name: 'Plaid',
      logo: '🏦',
      status: 'Banking',
      features: ['Bank Verification', 'ACH Transfers', 'Account Data', 'Balance Checks'],
      setupSteps: [
        'Register at plaid.com/developers',
        'Complete KYC verification process',
        'Generate client_id and secret keys',
        'Configure Link integration',
        'Set up webhook endpoints'
      ]
    },
    {
      name: 'Square',
      logo: '⬜',
      status: 'POS',
      features: ['In-Person', 'Online', 'Invoicing', 'Inventory'],
      setupSteps: [
        'Create Square Developer account',
        'Generate application credentials',
        'Configure OAuth flow',
        'Set up payment webhooks',
        'Test sandbox environment'
      ]
    },
    {
      name: 'PayPal',
      logo: '💙',
      status: 'Global',
      features: ['PayPal Payments', 'Venmo', 'International', 'Express Checkout'],
      setupSteps: [
        'Create PayPal Business account',
        'Access Developer Dashboard',
        'Generate REST API credentials',
        'Configure IPN notifications',
        'Set up Express Checkout'
      ]
    },
    {
      name: 'Dwolla',
      logo: '🔷',
      status: 'ACH Specialist',
      features: ['ACH Only', 'Bank Transfers', 'Mass Payments', 'White Label'],
      setupSteps: [
        'Register Dwolla account',
        'Complete business verification',
        'Generate API key and secret',
        'Set up webhook subscriptions',
        'Configure customer onboarding'
      ]
    },
    {
      name: 'Authorize.Net',
      logo: '🔐',
      status: 'Enterprise',
      features: ['Credit Cards', 'eCheck', 'Recurring', 'Fraud Detection'],
      setupSteps: [
        'Create merchant account',
        'Generate API credentials',
        'Configure payment gateway',
        'Set up Silent Post URL',
        'Enable fraud protection'
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 p-4 rounded-lg border border-blue-500/30">
        <h2 className="text-2xl font-bold text-blue-400 mb-2">
          AI ALAZIE XPRESS ENTERPRISE - Payment Integration Center
        </h2>
        <p className="text-gray-300">
          Comprehensive payment provider integration for live transactions and deposits
        </p>
      </div>

      <Tabs defaultValue="stripe" className="w-full">
        <TabsList className="grid grid-cols-6 bg-gray-800/50">
          <TabsTrigger value="stripe">Stripe</TabsTrigger>
          <TabsTrigger value="plaid">Plaid</TabsTrigger>
          <TabsTrigger value="square">Square</TabsTrigger>
          <TabsTrigger value="paypal">PayPal</TabsTrigger>
          <TabsTrigger value="dwolla">Dwolla</TabsTrigger>
          <TabsTrigger value="authorize">Authorize.Net</TabsTrigger>
        </TabsList>

        {paymentProviders.map((provider) => (
          <TabsContent key={provider.name.toLowerCase()} value={provider.name.toLowerCase()}>
            <Card className="bg-gray-800/30 border-blue-500">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center gap-2">
                  <span className="text-2xl">{provider.logo}</span>
                  {provider.name} Integration Setup
                  <Badge className="bg-green-500">{provider.status}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-white font-semibold">Features</h3>
                    <div className="flex flex-wrap gap-2">
                      {provider.features.map((feature, index) => (
                        <Badge key={index} className="bg-purple-500">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-white font-semibold">Setup Steps</h3>
                    <ol className="space-y-2">
                      {provider.setupSteps.map((step, index) => (
                        <li key={index} className="flex items-start gap-2 text-gray-300">
                          <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                            {index + 1}
                          </span>
                          <span className="text-sm">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>

                {provider.name === 'Stripe' && (
                  <div className="bg-gray-700/30 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-3">Stripe Configuration</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Publishable Key:</span>
                        <Button 
                          size="sm" 
                          onClick={() => copyToClipboard('pk_live_...', 'Stripe Publishable Key')}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          {copiedText === 'Stripe Publishable Key' ? 'Copied!' : 'Copy'}
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Secret Key:</span>
                        <Button 
                          size="sm" 
                          onClick={() => copyToClipboard('sk_live_...', 'Stripe Secret Key')}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          {copiedText === 'Stripe Secret Key' ? 'Copied!' : 'Copy'}
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Webhook Endpoint:</span>
                        <Button 
                          size="sm" 
                          onClick={() => copyToClipboard('https://your-domain.com/webhooks/stripe', 'Webhook URL')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          {copiedText === 'Webhook URL' ? 'Copied!' : 'Copy'}
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {provider.name === 'Plaid' && (
                  <div className="bg-gray-700/30 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-3">Plaid Configuration</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Client ID:</span>
                        <Button 
                          size="sm" 
                          onClick={() => copyToClipboard('your_client_id', 'Plaid Client ID')}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          {copiedText === 'Plaid Client ID' ? 'Copied!' : 'Copy'}
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Secret Key:</span>
                        <Button 
                          size="sm" 
                          onClick={() => copyToClipboard('your_secret_key', 'Plaid Secret')}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          {copiedText === 'Plaid Secret' ? 'Copied!' : 'Copy'}
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Environment:</span>
                        <Badge className="bg-yellow-500">Production</Badge>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-yellow-900/20 p-4 rounded-lg border border-yellow-500/30">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5" />
                    <div>
                      <h4 className="text-yellow-400 font-semibold">Security Notice</h4>
                      <p className="text-gray-300 text-sm mt-1">
                        Always use environment variables for API keys. Never commit secrets to version control.
                        Enable webhook signature verification for production environments.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button className="bg-green-600 hover:bg-green-700">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Test Connection
                  </Button>
                  <Button variant="outline" className="border-blue-500 text-blue-400">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Documentation
                  </Button>
                  <Button variant="outline" className="border-purple-500 text-purple-400">
                    <Settings className="h-4 w-4 mr-2" />
                    Advanced Config
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      <Card className="bg-gray-800/30 border-green-500">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Integration Status Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-semibold mb-2">Active Integrations</h4>
              <p className="text-2xl font-bold text-green-400">6</p>
              <p className="text-gray-400 text-sm">Payment providers</p>
            </div>
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-semibold mb-2">Daily Volume</h4>
              <p className="text-2xl font-bold text-blue-400">$247K</p>
              <p className="text-gray-400 text-sm">Processed today</p>
            </div>
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-semibold mb-2">Success Rate</h4>
              <p className="text-2xl font-bold text-purple-400">99.7%</p>
              <p className="text-gray-400 text-sm">Last 30 days</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ExpandedPaymentIntegrationInstructions;