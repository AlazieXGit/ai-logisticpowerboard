import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Filter, Save, Download, X, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';

interface FilterState {
  search: string;
  dateFrom: Date | undefined;
  dateTo: Date | undefined;
  businessType: string;
  priority: string;
  status: string;
  accountType: string;
}

interface ApprovalFiltersProps {
  onFilterChange: (filters: FilterState) => void;
  onExport: (filters: FilterState) => void;
}

export function ApprovalFilters({ onFilterChange, onExport }: ApprovalFiltersProps) {
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    dateFrom: undefined,
    dateTo: undefined,
    businessType: 'all',
    priority: 'all',
    status: 'all',
    accountType: 'all',
  });

  const [savedPresets, setSavedPresets] = useState<Array<{ name: string; filters: FilterState }>>([
    { name: 'High Priority Pending', filters: { ...filters, priority: 'high', status: 'pending' } },
    { name: 'Recent Submissions', filters: { ...filters, dateFrom: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } },
  ]);

  const [presetName, setPresetName] = useState('');
  const [showSavePreset, setShowSavePreset] = useState(false);

  const handleFilterUpdate = (key: keyof FilterState, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleClearFilters = () => {
    const clearedFilters: FilterState = {
      search: '',
      dateFrom: undefined,
      dateTo: undefined,
      businessType: 'all',
      priority: 'all',
      status: 'all',
      accountType: 'all',
    };
    setFilters(clearedFilters);
    onFilterChange(clearedFilters);
  };

  const handleSavePreset = () => {
    if (presetName.trim()) {
      setSavedPresets([...savedPresets, { name: presetName, filters }]);
      setPresetName('');
      setShowSavePreset(false);
    }
  };

  const handleLoadPreset = (preset: { name: string; filters: FilterState }) => {
    setFilters(preset.filters);
    onFilterChange(preset.filters);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Filter className="w-5 h-5" />
          Advanced Filters
        </h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowSavePreset(!showSavePreset)}>
            <Save className="w-4 h-4 mr-2" />
            Save Preset
          </Button>
          <Button variant="outline" size="sm" onClick={() => onExport(filters)}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="ghost" size="sm" onClick={handleClearFilters}>
            <X className="w-4 h-4 mr-2" />
            Clear
          </Button>
        </div>
      </div>

      {showSavePreset && (
        <div className="flex gap-2 p-3 bg-blue-50 rounded-lg">
          <Input
            placeholder="Preset name..."
            value={presetName}
            onChange={(e) => setPresetName(e.target.value)}
          />
          <Button onClick={handleSavePreset}>Save</Button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <Label>Search</Label>
          <Input
            placeholder="Search accounts..."
            value={filters.search}
            onChange={(e) => handleFilterUpdate('search', e.target.value)}
          />
        </div>

        <div>
          <Label>Date From</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start">
                <CalendarIcon className="w-4 h-4 mr-2" />
                {filters.dateFrom ? format(filters.dateFrom, 'PPP') : 'Select date'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={filters.dateFrom}
                onSelect={(date) => handleFilterUpdate('dateFrom', date)}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div>
          <Label>Date To</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start">
                <CalendarIcon className="w-4 h-4 mr-2" />
                {filters.dateTo ? format(filters.dateTo, 'PPP') : 'Select date'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={filters.dateTo}
                onSelect={(date) => handleFilterUpdate('dateTo', date)}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div>
          <Label>Business Type</Label>
          <Select value={filters.businessType} onValueChange={(v) => handleFilterUpdate('businessType', v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="individual">Individual</SelectItem>
              <SelectItem value="company">Company</SelectItem>
              <SelectItem value="non_profit">Non-Profit</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Priority Level</Label>
          <Select value={filters.priority} onValueChange={(v) => handleFilterUpdate('priority', v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Status</Label>
          <Select value={filters.status} onValueChange={(v) => handleFilterUpdate('status', v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="under_review">Under Review</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Account Type</Label>
          <Select value={filters.accountType} onValueChange={(v) => handleFilterUpdate('accountType', v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="standard">Standard</SelectItem>
              <SelectItem value="express">Express</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {savedPresets.length > 0 && (
        <div>
          <Label className="mb-2 block">Saved Presets</Label>
          <div className="flex flex-wrap gap-2">
            {savedPresets.map((preset, idx) => (
              <Button
                key={idx}
                variant="outline"
                size="sm"
                onClick={() => handleLoadPreset(preset)}
              >
                {preset.name}
              </Button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
