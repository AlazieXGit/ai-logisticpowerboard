import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, DollarSign, ArrowRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Transfer {
  id: string;
  amount: number;
  from_account: string;
  to_account: string;
  status: 'pending' | 'completed' | 'failed' | 'denied';
  created_at: string;
}

const RevenueTransferDisplay = () => {
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetchTransfers();
  }, []);

  const fetchTransfers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('transfers')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) {
        console.error('Error fetching transfers:', error);
      } else {
        setTransfers(data || []);
      }
    } catch (error) {
      console.error('Error:', error);
    }
    setLoading(false);
  };

  const testRevenueProcessor = async () => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('revenue-processor', {
        body: {
          action: 'create_transfer',
          from_account: '5563935267',
          to_account: '7788990011',
          amount: 25000
        }
      });

      if (error) {
        console.error('Revenue processor error:', error);
      } else {
        console.log('Revenue processor success:', data);
        fetchTransfers();
      }
    } catch (error) {
      console.error('Error:', error);
    }
    setProcessing(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-600';
      case 'pending': return 'bg-yellow-600';
      case 'failed': return 'bg-red-600';
      case 'denied': return 'bg-gray-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <Card className="bg-gray-800/30 border-cyan-500/30">
      <CardHeader>
        <CardTitle className="text-cyan-400 flex items-center justify-between">
          <span className="flex items-center">
            <DollarSign className="w-5 h-5 mr-2" />
            Revenue Processor - Live Transfers
          </span>
          <div className="flex space-x-2">
            <Button
              onClick={testRevenueProcessor}
              disabled={processing}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
            >
              {processing ? 'Processing...' : 'Test Transfer'}
            </Button>
            <Button
              onClick={fetchTransfers}
              disabled={loading}
              size="sm"
              variant="outline"
              className="text-white border-white/20"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-gray-400">Loading transfers...</div>
        ) : transfers.length === 0 ? (
          <div className="text-gray-400">No transfers found.</div>
        ) : (
          <div className="space-y-3">
            {transfers.map((transfer) => (
              <div
                key={transfer.id}
                className="p-4 rounded-lg bg-gray-900/50 border border-gray-700 flex flex-col md:flex-row justify-between items-start md:items-center"
              >
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-white font-mono text-sm">{transfer.from_account}</span>
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                    <span className="text-white font-mono text-sm">{transfer.to_account}</span>
                  </div>
                  <div className="text-green-300 font-bold text-lg">
                    ${transfer.amount.toLocaleString()}
                  </div>
                  <div className="text-xs text-gray-500">
                    {new Date(transfer.created_at).toLocaleString()}
                  </div>
                </div>
                <Badge className={`mt-3 md:mt-0 ${getStatusColor(transfer.status)}`}>
                  {transfer.status.toUpperCase()}
                </Badge>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RevenueTransferDisplay;