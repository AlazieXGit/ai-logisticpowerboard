import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/lib/supabase';
import { 
  TrendingUp, TrendingDown, Activity, DollarSign, 
  CreditCard, BarChart3, PieChart, Clock,
  CheckCircle, RefreshCw
} from 'lucide-react';

interface RouteAnalytics {
  id: string;
  name: string;
  transactions: number;
  revenue: number;
  status: 'active' | 'inactive' | 'error';
  successRate: number;
  avgProcessingTime: number;
  dailyGrowth: number;
  fees: number;
  profit: number;
}

interface PaymentRoutingData {
  routingNumber: string;
  total: number;
  accounts: Array<{
    accountId: string;
    availableBalance: number;
  }>;
  routedTo: string;
  message: string;
}

const EnhancedPaymentRoutingAnalytics: React.FC = () => {
  const [routingData, setRoutingData] = useState<PaymentRoutingData | null>(null);
  const [loading, setLoading] = useState(false);
  const [routes] = useState<RouteAnalytics[]>([
    {
      id: '1',
      name: 'Stripe Gateway',
      transactions: 1247,
      revenue: 45890,
      status: 'active',
      successRate: 98.5,
      avgProcessingTime: 2.3,
      dailyGrowth: 12.4,
      fees: 1376.70,
      profit: 44513.30
    },
    {
      id: '2', 
      name: 'Synergy Router',
      transactions: 892,
      revenue: 32150,
      status: 'active',
      successRate: 97.8,
      avgProcessingTime: 1.8,
      dailyGrowth: 8.7,
      fees: 964.50,
      profit: 31185.50
    },
    {
      id: '3',
      name: 'Banking Direct', 
      transactions: 654,
      revenue: 28900,
      status: 'active',
      successRate: 99.2,
      avgProcessingTime: 3.1,
      dailyGrowth: 15.2,
      fees: 867.00,
      profit: 28033.00
    }
  ]);

  const fetchRoutingData = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('payment-routing-combined-total');
      if (error) throw error;
      setRoutingData(data);
    } catch (error) {
      console.error('Error fetching routing data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRoutingData();
  }, []);

  const totalRevenue = routes.reduce((sum, route) => sum + route.revenue, 0);
  const totalTransactions = routes.reduce((sum, route) => sum + route.transactions, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-900/30 to-green-800/20 border-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Total Revenue</p>
                <p className="text-2xl font-bold text-green-400">
                  ${totalRevenue.toLocaleString()}
                </p>
                <p className="text-green-300 text-xs flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +18.5% today
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/20 border-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Smart Routing Total</p>
                <p className="text-2xl font-bold text-blue-400">
                  ${routingData ? (routingData.total / 100).toLocaleString() : '0'}
                </p>
                <p className="text-blue-300 text-xs">
                  {routingData?.accounts.length || 0} accounts
                </p>
              </div>
              <CreditCard className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/20 border-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Routing Number</p>
                <p className="text-lg font-bold text-purple-400">
                  {routingData?.routingNumber || 'Loading...'}
                </p>
                <p className="text-purple-300 text-xs">
                  Active routing
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-900/30 to-orange-800/20 border-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Last Routed To</p>
                <p className="text-sm font-bold text-orange-400">
                  {routingData?.routedTo || 'N/A'}
                </p>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={fetchRoutingData}
                  disabled={loading}
                  className="text-xs p-1 h-6"
                >
                  <RefreshCw className={`h-3 w-3 ${loading ? 'animate-spin' : ''}`} />
                </Button>
              </div>
              <PieChart className="h-8 w-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {routingData && (
        <Card className="bg-gray-800/30 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">Real-time Account Balances</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {routingData.accounts.map((account, index) => (
                <div key={account.accountId} className="p-4 bg-gray-700/30 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-300 text-sm">Account {account.accountId}</p>
                      <p className="text-xl font-bold text-green-400">
                        ${(account.availableBalance / 100).toLocaleString()}
                      </p>
                    </div>
                    {account.accountId === routingData.routedTo && (
                      <Badge className="bg-green-500">Target</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 p-4 bg-blue-900/20 rounded-lg">
              <p className="text-blue-300 text-sm">{routingData.message}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export { EnhancedPaymentRoutingAnalytics };
export default EnhancedPaymentRoutingAnalytics;