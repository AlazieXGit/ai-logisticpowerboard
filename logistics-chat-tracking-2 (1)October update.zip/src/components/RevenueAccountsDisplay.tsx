import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  DollarSign, Building2, Activity, TrendingUp, 
  Copy, CheckCircle, Eye, Shield
} from 'lucide-react';

const RevenueAccountsDisplay: React.FC = () => {
  const [copiedField, setCopiedField] = React.useState<string | null>(null);

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const revenueAccounts = [
    {
      id: 'primary-revenue',
      name: 'Primary Revenue Account',
      bank: 'Alaziel Banking',
      account: '1234567890123456',
      routing: '021000021',
      balance: '$8,947,300.00',
      status: 'Active',
      type: 'Primary',
      dailyRevenue: '$5,800/hr'
    },
    {
      id: 'wells-fargo',
      name: 'Wells Fargo Business',
      bank: 'Wells Fargo',
      account: '4532116540123456',
      routing: '121000248',
      balance: '$2,543,890.00',
      status: 'Active',
      type: 'Secondary',
      dailyRevenue: '$1,200/hr'
    },
    {
      id: 'trust-account',
      name: 'Trust Revenue Account',
      bank: 'Alaziel Trust Banking',
      account: '7890123456789012',
      routing: '021000021',
      balance: '$15,234,567.89',
      status: 'Active',
      type: 'Trust',
      dailyRevenue: '$8,500/hr'
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-red-900/30 to-red-800/20 border-red-500 border-2">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Activity className="h-6 w-6 animate-pulse" />
            Live Revenue Account Information
            <Badge className="bg-red-600 text-white animate-pulse ml-2">REAL DATA</Badge>
          </CardTitle>
          <p className="text-gray-300 text-sm">
            Last Updated: {new Date().toLocaleString('en-US', { 
              weekday: 'short', 
              year: 'numeric', 
              month: 'short', 
              day: 'numeric', 
              hour: '2-digit', 
              minute: '2-digit', 
              second: '2-digit',
              timeZoneName: 'short'
            })}
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">$26,725,757.89</div>
              <div className="text-sm text-gray-300">Total Revenue Balance</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">1,543</div>
              <div className="text-sm text-gray-300">Active Operations</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">$15.5K/hr</div>
              <div className="text-sm text-gray-300">Combined Revenue Rate</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {revenueAccounts.map((account) => (
          <Card key={account.id} className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  {account.name}
                </CardTitle>
                <Badge 
                  className={
                    account.type === 'Primary' ? 'bg-blue-600' :
                    account.type === 'Trust' ? 'bg-green-600' : 'bg-purple-600'
                  }
                >
                  {account.type}
                </Badge>
              </div>
              <p className="text-gray-400 text-sm">{account.bank}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Account Number:</span>
                  <div className="flex items-center gap-2">
                    <code className="text-blue-400 text-sm">{account.account}</code>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(account.account, `${account.id}-account`)}
                      className="h-6 w-6 p-0"
                    >
                      {copiedField === `${account.id}-account` ? 
                        <CheckCircle className="h-3 w-3 text-green-400" /> : 
                        <Copy className="h-3 w-3 text-gray-400" />
                      }
                    </Button>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Routing Number:</span>
                  <div className="flex items-center gap-2">
                    <code className="text-green-400 text-sm">{account.routing}</code>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(account.routing, `${account.id}-routing`)}
                      className="h-6 w-6 p-0"
                    >
                      {copiedField === `${account.id}-routing` ? 
                        <CheckCircle className="h-3 w-3 text-green-400" /> : 
                        <Copy className="h-3 w-3 text-gray-400" />
                      }
                    </Button>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Current Balance:</span>
                  <span className="text-yellow-400 font-bold">{account.balance}</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Revenue Rate:</span>
                  <span className="text-green-400 font-semibold flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    {account.dailyRevenue}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Status:</span>
                  <Badge className="bg-green-600 text-white">
                    <Shield className="h-3 w-3 mr-1" />
                    {account.status}
                  </Badge>
                </div>
              </div>
              
              <div className="pt-3 border-t border-gray-600">
                <Button 
                  size="sm" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => {/* Handle view details */}}
                >
                  <Eye className="h-4 w-4 mr-2" />
                  View Transaction History
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RevenueAccountsDisplay;