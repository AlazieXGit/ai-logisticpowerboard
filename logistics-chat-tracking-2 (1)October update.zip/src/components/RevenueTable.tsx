import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface Platform {
  name: string;
  revenue: number;
  fees: number;
}

interface RevenueTableProps {
  platforms: Platform[];
}

export default function RevenueTable({ platforms }: RevenueTableProps) {
  const fmt = (n: number) => n.toLocaleString(undefined, { 
    style: "currency", 
    currency: "USD" 
  });

  const totalRevenue = platforms.reduce((sum, p) => sum + p.revenue, 0);
  const totalFees = platforms.reduce((sum, p) => sum + p.fees, 0);
  const netRevenue = totalRevenue - totalFees;

  const getStatusBadge = (revenue: number) => {
    if (revenue > 1000000) return <Badge className="bg-green-600">High Performance</Badge>;
    if (revenue > 500000) return <Badge className="bg-yellow-600">Good Performance</Badge>;
    return <Badge className="bg-blue-600">Standard</Badge>;
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex justify-between items-center">
          <span>Platform Revenue Overview</span>
          <div className="flex gap-4 text-sm">
            <span className="text-green-400">Total: {fmt(totalRevenue)}</span>
            <span className="text-red-400">Fees: {fmt(totalFees)}</span>
            <span className="text-cyan-400">Net: {fmt(netRevenue)}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="border-slate-600">
              <TableHead className="text-slate-300">Platform</TableHead>
              <TableHead className="text-slate-300">Revenue</TableHead>
              <TableHead className="text-slate-300">Fees</TableHead>
              <TableHead className="text-slate-300">Net Revenue</TableHead>
              <TableHead className="text-slate-300">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {platforms.map((platform) => (
              <TableRow key={platform.name} className="border-slate-600">
                <TableCell className="text-white font-medium">
                  {platform.name}
                </TableCell>
                <TableCell className="text-green-400">
                  {fmt(platform.revenue)}
                </TableCell>
                <TableCell className="text-red-400">
                  {fmt(platform.fees)}
                </TableCell>
                <TableCell className="text-cyan-400">
                  {fmt(platform.revenue - platform.fees)}
                </TableCell>
                <TableCell>
                  {getStatusBadge(platform.revenue)}
                </TableCell>
              </TableRow>
            ))}
            <TableRow className="border-slate-600 border-t-2">
              <TableCell className="text-white font-bold">TOTAL</TableCell>
              <TableCell className="text-green-400 font-bold">{fmt(totalRevenue)}</TableCell>
              <TableCell className="text-red-400 font-bold">{fmt(totalFees)}</TableCell>
              <TableCell className="text-cyan-400 font-bold">{fmt(netRevenue)}</TableCell>
              <TableCell>
                <Badge className="bg-purple-600">Consolidated</Badge>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}