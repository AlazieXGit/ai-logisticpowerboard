import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Receipt, DollarSign, Calendar, Clock, ArrowRight } from 'lucide-react';

interface TransferReceipt {
  id: string;
  amount: number;
  fromAccount: string;
  toAccount: string;
  type: string;
  status: 'completed' | 'pending' | 'failed';
  timestamp: Date;
  confirmationNumber: string;
  fees: number;
}

const EnhancedBankingTransferReceipts: React.FC = () => {
  const [transfers, setTransfers] = useState<TransferReceipt[]>([]);
  const [totalTransferred, setTotalTransferred] = useState(0);

  useEffect(() => {
    // Simulate real transfer data
    const mockTransfers: TransferReceipt[] = [
      {
        id: '1',
        amount: 20000,
        fromAccount: 'Primary Revenue Account',
        toAccount: 'Cash App #5186776357552',
        type: 'Bi-Monthly Transfer',
        status: 'completed',
        timestamp: new Date(),
        confirmationNumber: 'TXN-20250107-001',
        fees: 0
      },
      {
        id: '2',
        amount: 5000,
        fromAccount: 'Primary Revenue Account',
        toAccount: 'Flare External #70008136506008',
        type: 'Verification Transfer',
        status: 'completed',
        timestamp: new Date(Date.now() - 3600000),
        confirmationNumber: 'TXN-20250107-002',
        fees: 0
      },
      {
        id: '3',
        amount: 15750.50,
        fromAccount: 'TMS Revenue Pool',
        toAccount: 'Chime Debit #4232231011655357',
        type: 'Daily Revenue Transfer',
        status: 'completed',
        timestamp: new Date(Date.now() - 7200000),
        confirmationNumber: 'TXN-20250107-003',
        fees: 0
      },
      {
        id: '4',
        amount: 8925.75,
        fromAccount: 'Subscription Revenue',
        toAccount: 'Ace Flare Savings #70008136506008',
        type: 'Weekly Revenue Transfer',
        status: 'pending',
        timestamp: new Date(Date.now() - 1800000),
        confirmationNumber: 'TXN-20250107-004',
        fees: 0
      }
    ];

    setTransfers(mockTransfers);
    setTotalTransferred(mockTransfers.reduce((sum, t) => sum + t.amount, 0));
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-600';
      case 'pending': return 'bg-yellow-600';
      case 'failed': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900/30 to-blue-900/30 border-green-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Receipt className="h-8 w-8 text-green-400" />
              <CardTitle className="text-2xl text-green-400">
                Banking Transfer Receipts
              </CardTitle>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-300">Total Transferred Today</div>
              <div className="text-2xl font-bold text-green-400">
                {formatCurrency(totalTransferred)}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4">
        {transfers.map((transfer) => (
          <Card key={transfer.id} className="bg-gray-800/50 border-gray-600">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-green-600/20 p-2 rounded-lg">
                    <DollarSign className="h-6 w-6 text-green-400" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-white">
                      {formatCurrency(transfer.amount)}
                    </div>
                    <div className="text-sm text-gray-400">{transfer.type}</div>
                  </div>
                </div>
                <Badge className={`${getStatusColor(transfer.status)} text-white`}>
                  {transfer.status.toUpperCase()}
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="space-y-2">
                  <div className="text-sm text-gray-400">From Account</div>
                  <div className="text-white font-medium">{transfer.fromAccount}</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm text-gray-400">To Account</div>
                  <div className="text-white font-medium">{transfer.toAccount}</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-blue-400" />
                    <span className="text-sm text-gray-300">
                      {transfer.timestamp.toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-purple-400" />
                    <span className="text-sm text-gray-300">
                      {transfer.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-400">Confirmation #</div>
                  <div className="text-sm text-blue-400 font-mono">
                    {transfer.confirmationNumber}
                  </div>
                </div>
              </div>

              {transfer.status === 'completed' && (
                <div className="mt-4 p-3 bg-green-900/20 border border-green-500/30 rounded-lg">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span className="text-green-300 font-medium">
                      Transfer Completed Successfully
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EnhancedBankingTransferReceipts;