import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle, CheckCircle, Eye, Lock } from 'lucide-react';

interface SecurityEvent {
  id: string;
  type: 'login' | 'transaction' | 'access' | 'threat';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: Date;
  resolved: boolean;
}

const SecurityAuditSystem: React.FC = () => {
  const [securityEvents, setSecurityEvents] = useState<SecurityEvent[]>([]);
  const [auditStatus, setAuditStatus] = useState<'idle' | 'scanning' | 'complete'>('idle');
  const [threatLevel, setThreatLevel] = useState<'low' | 'medium' | 'high'>('low');

  useEffect(() => {
    generateSecurityEvents();
    const interval = setInterval(generateSecurityEvents, 30000);
    return () => clearInterval(interval);
  }, []);

  const generateSecurityEvents = () => {
    const events: SecurityEvent[] = [
      {
        id: '1',
        type: 'login',
        severity: 'low',
        message: 'Super Admin login from verified IP',
        timestamp: new Date(),
        resolved: true
      },
      {
        id: '2',
        type: 'transaction',
        severity: 'medium',
        message: 'Large payment processed - $50,000',
        timestamp: new Date(Date.now() - 300000),
        resolved: true
      },
      {
        id: '3',
        type: 'access',
        severity: 'high',
        message: 'Credentials access attempt detected',
        timestamp: new Date(Date.now() - 600000),
        resolved: false
      }
    ];
    setSecurityEvents(events);
  };

  const runSecurityAudit = async () => {
    setAuditStatus('scanning');
    await new Promise(resolve => setTimeout(resolve, 5000));
    setAuditStatus('complete');
    setThreatLevel('low');
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'bg-green-600';
      case 'medium': return 'bg-yellow-600';
      case 'high': return 'bg-orange-600';
      case 'critical': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-red-900/20 to-orange-900/20 border-red-500/50">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            SECURITY AUDIT & MONITORING SYSTEM
            <Badge className={`${threatLevel === 'low' ? 'bg-green-600' : 'bg-red-600'} animate-pulse`}>
              THREAT LEVEL: {threatLevel.toUpperCase()}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">
                {securityEvents.filter(e => e.resolved).length}
              </div>
              <div className="text-sm text-gray-300">Resolved Events</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-400">
                {securityEvents.filter(e => !e.resolved).length}
              </div>
              <div className="text-sm text-gray-300">Active Threats</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">99.8%</div>
              <div className="text-sm text-gray-300">Security Score</div>
            </div>
            <div className="text-center">
              <Button
                onClick={runSecurityAudit}
                disabled={auditStatus === 'scanning'}
                className="bg-red-600 hover:bg-red-700"
              >
                {auditStatus === 'scanning' ? (
                  <Eye className="h-4 w-4 mr-2 animate-pulse" />
                ) : (
                  <Shield className="h-4 w-4 mr-2" />
                )}
                {auditStatus === 'scanning' ? 'Scanning...' : 'Run Audit'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-900/20 border-gray-500/50">
          <CardHeader>
            <CardTitle className="text-gray-400">Recent Security Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {securityEvents.map((event) => (
                <div key={event.id} className="flex items-center justify-between p-2 bg-gray-800/50 rounded">
                  <div className="flex items-center gap-3">
                    {event.resolved ? (
                      <CheckCircle className="h-4 w-4 text-green-400" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-red-400" />
                    )}
                    <div>
                      <div className="text-sm text-white">{event.message}</div>
                      <div className="text-xs text-gray-400">
                        {event.timestamp.toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                  <Badge className={getSeverityColor(event.severity)}>
                    {event.severity.toUpperCase()}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-blue-900/20 border-blue-500/50">
          <CardHeader>
            <CardTitle className="text-blue-400 flex items-center gap-2">
              <Lock className="h-4 w-4" />
              Security Measures
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Master Credentials</span>
                <Badge className="bg-green-600">SECURED</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Payment Systems</span>
                <Badge className="bg-green-600">ENCRYPTED</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Database Access</span>
                <Badge className="bg-green-600">PROTECTED</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">API Endpoints</span>
                <Badge className="bg-green-600">AUTHENTICATED</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Session Management</span>
                <Badge className="bg-green-600">ACTIVE</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {auditStatus === 'complete' && (
        <Card className="bg-green-900/20 border-green-500/50">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Security Audit Complete
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-gray-300">
              <p>✅ All systems secure</p>
              <p>✅ No vulnerabilities detected</p>
              <p>✅ Master credentials protected</p>
              <p>✅ Payment systems encrypted</p>
              <p>✅ Access controls functioning</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SecurityAuditSystem;