import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface DepositData {
  id: string;
  amount: number;
  date: string;
  description: string;
  account_number: string;
  routing_number: string;
  status: 'pending' | 'confirmed' | 'processed';
}

interface DepositDetectionSystemProps {
  onDepositDetected: (deposits: DepositData[]) => void;
}

export const DepositDetectionSystem: React.FC<DepositDetectionSystemProps> = ({ 
  onDepositDetected 
}) => {
  const [isMonitoring, setIsMonitoring] = useState(true);
  const [lastCheck, setLastCheck] = useState<Date>(new Date());

  // AI-powered deposit detection with automatic connection
  // AI-powered deposit detection with automatic connection
  const detectIncomingDeposits = async () => {
    try {
      // Check for new deposits in banking_transactions table
      const { data: transactions, error } = await supabase
        .from('banking_transactions')
        .select('*')
        .eq('transaction_type', 'deposit')
        .eq('account_number', '4567891234')
        .gte('created_at', lastCheck.toISOString())
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error checking deposits:', error);
        // Return empty array on error to prevent crashes
        onDepositDetected([]);
        return;
      }

      // Filter for PNC trial deposits
      const trialDeposits = transactions?.filter(tx => 
        tx.description?.includes('PNC Bank Trial Deposit') && 
        tx.amount < 1.00 && 
        tx.amount > 0
      ) || [];

      if (trialDeposits.length > 0) {
        // Automatically process and connect deposits
        await processDepositConnection(trialDeposits);
        onDepositDetected(trialDeposits);
      }

      setLastCheck(new Date());
    } catch (error) {
      console.error('Deposit detection error:', error);
      // Provide fallback data on network error
      onDepositDetected([]);
    }
  };

  // Automatic connection system for faster processing
  const processDepositConnection = async (deposits: any[]) => {
    for (const deposit of deposits) {
      try {
        // Auto-connect to PNC system for verification
        await supabase.functions.invoke('banking-operations', {
          body: {
            action: 'auto_connect_deposit',
            deposit_id: deposit.id,
            account_number: '4567891234',
            routing_number: '121000248',
            pnc_credentials: {
              username: 'pncvirtual1',
              password: 'gotchupin1976'
            }
          }
        });

        // Update deposit status to confirmed
        await supabase
          .from('banking_transactions')
          .update({ 
            status: 'confirmed',
            processed_at: new Date().toISOString()
          })
          .eq('id', deposit.id);

      } catch (error) {
        console.error('Auto-connection error:', error);
      }
    }
  };

  // Real-time monitoring with 30-second intervals
  useEffect(() => {
    if (!isMonitoring) return;

    const interval = setInterval(detectIncomingDeposits, 30000);
    
    // Initial check
    detectIncomingDeposits();

    return () => clearInterval(interval);
  }, [isMonitoring, lastCheck]);

  // Real-time subscription for immediate detection
  useEffect(() => {
    const subscription = supabase
      .channel('deposit_detection')
      .on('postgres_changes', 
        { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'banking_transactions',
          filter: 'account_number=eq.4567891234'
        }, 
        (payload) => {
          const newTransaction = payload.new as any;
          if (newTransaction.transaction_type === 'deposit' && 
              newTransaction.description?.includes('PNC Bank Trial Deposit')) {
            detectIncomingDeposits();
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return null; // This is a background service component
};