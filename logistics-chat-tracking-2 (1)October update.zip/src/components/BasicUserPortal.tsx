import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Truck, BarChart3, CreditCard, User, Lock } from 'lucide-react';

export const BasicUserPortal: React.FC = () => {
  const [subscription] = useState('basic');
  
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Basic User Portal</h1>
              <p className="text-gray-600">Limited access logistics platform</p>
            </div>
            <Badge variant="outline" className="bg-blue-50 text-blue-700">
              BASIC Plan
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="loads">Loads</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Active Loads</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3</div>
                  <p className="text-xs text-muted-foreground">Basic plan limit</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$2,450</div>
                  <p className="text-xs text-muted-foreground">Limited tracking</p>
                </CardContent>
              </Card>
            </div>
            
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-yellow-600" />
                  <p className="text-sm text-yellow-700">Upgrade to Premium for advanced analytics and unlimited loads!</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="loads">
            <Card>
              <CardHeader>
                <CardTitle>Load Board - Basic Access</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">View up to 5 loads per day</p>
                <div className="space-y-2">
                  <div className="p-3 border rounded bg-gray-50">
                    <p className="font-medium">Load #001 - Atlanta to Miami</p>
                    <p className="text-sm text-gray-600">$1,200 | 450 miles</p>
                  </div>
                  <div className="p-3 border rounded bg-gray-50">
                    <p className="font-medium">Load #002 - Dallas to Houston</p>
                    <p className="text-sm text-gray-600">$800 | 240 miles</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing">
            <Card>
              <CardHeader>
                <CardTitle>Billing Information</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Current Plan: Basic ($29/month)</p>
                <Button>Upgrade to Premium</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Profile Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Basic profile management</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};