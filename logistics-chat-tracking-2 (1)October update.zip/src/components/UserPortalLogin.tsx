import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, UserPlus, LogIn } from 'lucide-react';

interface UserPortalLoginProps {
  onLogin: (userType: 'subscriber' | 'general') => void;
}

export const UserPortalLogin: React.FC<UserPortalLoginProps> = ({ onLogin }) => {
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    companyName: '',
    subscriptionType: 'basic'
  });

  const handleLogin = (userType: 'subscriber' | 'general') => {
    // Simulate login validation
    if (loginData.email && loginData.password) {
      onLogin(userType);
    }
  };

  const handleRegister = () => {
    if (loginData.email && loginData.password && loginData.confirmPassword) {
      onLogin('subscriber');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold flex items-center justify-center gap-2">
            <User className="h-6 w-6" />
            User Portal Access
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={loginData.email}
                  onChange={(e) => setLoginData({...loginData, email: e.target.value})}
                  placeholder="Enter your email"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={loginData.password}
                  onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                  placeholder="Enter your password"
                />
              </div>
              
              <div className="space-y-2">
                <Button 
                  onClick={() => handleLogin('subscriber')} 
                  className="w-full"
                >
                  <LogIn className="h-4 w-4 mr-2" />
                  Login as Subscriber
                </Button>
                <Button 
                  onClick={() => handleLogin('general')} 
                  variant="outline" 
                  className="w-full"
                >
                  <User className="h-4 w-4 mr-2" />
                  General User Access
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="register" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="company">Company Name</Label>
                <Input
                  id="company"
                  value={loginData.companyName}
                  onChange={(e) => setLoginData({...loginData, companyName: e.target.value})}
                  placeholder="Enter company name"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reg-email">Email</Label>
                <Input
                  id="reg-email"
                  type="email"
                  value={loginData.email}
                  onChange={(e) => setLoginData({...loginData, email: e.target.value})}
                  placeholder="Enter your email"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reg-password">Password</Label>
                <Input
                  id="reg-password"
                  type="password"
                  value={loginData.password}
                  onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                  placeholder="Create password"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm Password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  value={loginData.confirmPassword}
                  onChange={(e) => setLoginData({...loginData, confirmPassword: e.target.value})}
                  placeholder="Confirm password"
                />
              </div>
              
              <Button onClick={handleRegister} className="w-full">
                <UserPlus className="h-4 w-4 mr-2" />
                Register & Subscribe
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};