import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Globe, Ship, FileCheck, CreditCard, 
  TrendingUp, BarChart3, Users, MessageCircle 
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TradeData {
  totalImports: number;
  totalExports: number;
  customsProcessed: number;
  letterOfCredit: number;
  tradeFinance: number;
}

const InternationalTradeHub: React.FC = () => {
  const [tradeData, setTradeData] = useState<TradeData>({
    totalImports: 2450000,
    totalExports: 3200000,
    customsProcessed: 1250,
    letterOfCredit: 850000,
    tradeFinance: 1750000
  });
  const [aiAnalysis, setAiAnalysis] = useState('');
  const [loading, setLoading] = useState(false);

  const generateAIAnalysis = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-insights', {
        body: {
          type: 'trade_analysis',
          data: tradeData,
          focus: 'international_trade_operations'
        }
      });
      
      if (error) throw error;
      setAiAnalysis(data.analysis);
    } catch (error) {
      console.error('AI Analysis error:', error);
      setAiAnalysis('AI analysis temporarily unavailable. Trade operations continue normally.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateAIAnalysis();
  }, []);

  const tradeMetrics = [
    { label: 'Total Imports', value: tradeData.totalImports, icon: <Ship className="h-4 w-4" />, color: 'blue' },
    { label: 'Total Exports', value: tradeData.totalExports, icon: <Globe className="h-4 w-4" />, color: 'green' },
    { label: 'Customs Processed', value: tradeData.customsProcessed, icon: <FileCheck className="h-4 w-4" />, color: 'purple' },
    { label: 'Letters of Credit', value: tradeData.letterOfCredit, icon: <CreditCard className="h-4 w-4" />, color: 'orange' }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Globe className="h-5 w-5" />
            International Trade Hub - AI Analysis Center
          </CardTitle>
          <Badge className="bg-green-600 w-fit">GLOBAL OPERATIONS ACTIVE</Badge>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Trade Overview</TabsTrigger>
              <TabsTrigger value="customs">Customs Management</TabsTrigger>
              <TabsTrigger value="finance">Trade Finance</TabsTrigger>
              <TabsTrigger value="ai-analysis">AI Analysis</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {tradeMetrics.map((metric, index) => (
                  <Card key={index} className="bg-gray-800/30 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        {metric.icon}
                        <span className="text-white text-sm">{metric.label}</span>
                      </div>
                      <div className="text-2xl font-bold text-white">
                        ${metric.value.toLocaleString()}
                      </div>
                      <Badge className={`bg-${metric.color}-600 mt-2`}>ACTIVE</Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Import/Export Operations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Active Import Routes</span>
                      <Badge className="bg-blue-600">23 Routes</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Export Destinations</span>
                      <Badge className="bg-green-600">31 Countries</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Processing Time</span>
                      <Badge className="bg-purple-600">2.3 Days Avg</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="customs" className="space-y-4">
              <Alert className="border-green-500 bg-green-900/20">
                <AlertDescription className="text-green-300">
                  🚢 Automated Customs Processing - 98.5% Success Rate
                </AlertDescription>
              </Alert>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-white">Customs Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Pending Clearance</span>
                        <span className="text-yellow-400">12 Shipments</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Cleared Today</span>
                        <span className="text-green-400">89 Shipments</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Flagged for Review</span>
                        <span className="text-red-400">3 Shipments</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-white">Automated Processing</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        Process Pending Customs
                      </Button>
                      <Button className="w-full bg-green-600 hover:bg-green-700">
                        Generate Compliance Reports
                      </Button>
                      <Button className="w-full bg-purple-600 hover:bg-purple-700">
                        Update Tariff Schedules
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="finance" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-green-400">Letters of Credit</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Active L/Cs</span>
                        <span className="text-white">47</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Total Value</span>
                        <span className="text-green-400">${tradeData.letterOfCredit.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Expiring Soon</span>
                        <span className="text-yellow-400">8 L/Cs</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-blue-400">Trade Financing</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Available Credit</span>
                        <span className="text-blue-400">${tradeData.tradeFinance.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Utilized</span>
                        <span className="text-white">68%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Interest Rate</span>
                        <span className="text-green-400">3.2% APR</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gray-800/30 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white">Financing Operations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <Button className="bg-green-600 hover:bg-green-700">
                      Issue New L/C
                    </Button>
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Request Trade Finance
                    </Button>
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      Currency Exchange
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="ai-analysis" className="space-y-4">
              <Card className="bg-purple-900/20 border-purple-500/50">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    AI Trade Analysis & Insights
                  </CardTitle>
                  <Button 
                    onClick={generateAIAnalysis} 
                    disabled={loading}
                    className="bg-purple-600 hover:bg-purple-700 w-fit"
                  >
                    {loading ? 'Analyzing...' : 'Refresh Analysis'}
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <p className="text-gray-300 leading-relaxed">
                      {aiAnalysis || 'AI analysis loading...'}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-white">Trade Predictions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Q4 Import Growth</span>
                        <Badge className="bg-green-600">+12.5%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Export Opportunities</span>
                        <Badge className="bg-blue-600">+8.3%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Risk Assessment</span>
                        <Badge className="bg-yellow-600">LOW</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-white">Optimization Suggestions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <p className="text-green-400">• Consolidate shipments to reduce costs by 15%</p>
                      <p className="text-blue-400">• Optimize customs processing times</p>
                      <p className="text-purple-400">• Diversify supplier base in Asia-Pacific</p>
                      <p className="text-yellow-400">• Hedge currency exposure for EUR trades</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default InternationalTradeHub;