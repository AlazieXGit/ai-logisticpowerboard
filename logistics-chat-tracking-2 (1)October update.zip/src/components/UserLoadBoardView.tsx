import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Truck, MapPin, DollarSign, Clock, Shield, 
  Star, CheckCircle, AlertTriangle
} from 'lucide-react';

interface Load {
  id: string;
  origin: string;
  destination: string;
  distance: number;
  rate: number;
  weight: number;
  type: 'freight' | 'medical' | 'courier';
  urgency: 'low' | 'medium' | 'high' | 'critical';
  available: boolean;
}

const UserLoadBoardView: React.FC = () => {
  const [loads, setLoads] = useState<Load[]>([]);
  const [registeredLoads, setRegisteredLoads] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Simulate available loads for users
    const generateLoads = () => {
      const newLoads: Load[] = Array.from({ length: 8 }, (_, i) => ({
        id: `USER-LOAD-${Date.now()}-${i}`,
        origin: ['Dallas, TX', 'Atlanta, GA', 'Chicago, IL', 'Phoenix, AZ'][Math.floor(Math.random() * 4)],
        destination: ['Miami, FL', 'Seattle, WA', 'New York, NY', 'Los Angeles, CA'][Math.floor(Math.random() * 4)],
        distance: Math.floor(Math.random() * 1500) + 300,
        rate: Math.floor(Math.random() * 3000) + 2000,
        weight: Math.floor(Math.random() * 35000) + 10000,
        type: ['freight', 'medical', 'courier'][Math.floor(Math.random() * 3)] as Load['type'],
        urgency: ['low', 'medium', 'high', 'critical'][Math.floor(Math.random() * 4)] as Load['urgency'],
        available: Math.random() > 0.2
      }));
      setLoads(newLoads);
    };

    generateLoads();
    const interval = setInterval(generateLoads, 8000);
    return () => clearInterval(interval);
  }, []);

  const handleRegister = (loadId: string) => {
    setRegisteredLoads(prev => [...prev, loadId]);
    // Simulate notification to admin
    console.log(`User registered for load: ${loadId}`);
  };

  const getUrgencyColor = (urgency: Load['urgency']) => {
    switch (urgency) {
      case 'critical': return 'bg-red-600';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const getTypeIcon = (type: Load['type']) => {
    switch (type) {
      case 'medical': return <Shield className="h-4 w-4" />;
      case 'courier': return <Clock className="h-4 w-4" />;
      default: return <Truck className="h-4 w-4" />;
    }
  };

  const filteredLoads = loads.filter(load => 
    load.origin.toLowerCase().includes(searchTerm.toLowerCase()) ||
    load.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
    load.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 border-blue-500">
        <CardHeader>
          <CardTitle className="text-2xl text-blue-400 flex items-center gap-3">
            <Truck className="h-8 w-8" />
            Available Load Board
          </CardTitle>
          <p className="text-gray-300">Register for automated load booking system</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{loads.filter(l => l.available).length}</div>
              <div className="text-sm text-gray-300">Available Loads</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">{registeredLoads.length}</div>
              <div className="text-sm text-gray-300">Registered</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">AI</div>
              <div className="text-sm text-gray-300">Auto-Matching</div>
            </div>
          </div>
          
          <Input
            placeholder="Search by origin, destination, or type..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-gray-700 text-white border-gray-600"
          />
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {filteredLoads.map((load) => (
          <Card key={load.id} className="bg-gray-800/50 border-gray-600 hover:border-blue-500 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    {getTypeIcon(load.type)}
                    <Badge className={getUrgencyColor(load.urgency)}>
                      {load.urgency.toUpperCase()}
                    </Badge>
                    {!load.available && (
                      <Badge className="bg-gray-600">UNAVAILABLE</Badge>
                    )}
                  </div>
                  <div>
                    <div className="text-white font-semibold">{load.id}</div>
                    <div className="text-sm text-gray-400 flex items-center gap-2">
                      <MapPin className="h-3 w-3" />
                      {load.origin} → {load.destination}
                    </div>
                    <div className="text-xs text-gray-500">
                      {load.weight.toLocaleString()} lbs • {load.distance} miles
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-green-400 font-bold flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {load.rate.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-400">
                      ${(load.rate / load.distance).toFixed(2)}/mile
                    </div>
                  </div>
                  {load.available ? (
                    registeredLoads.includes(load.id) ? (
                      <Badge className="bg-green-600 flex items-center gap-1">
                        <CheckCircle className="h-3 w-3" />
                        REGISTERED
                      </Badge>
                    ) : (
                      <Button
                        onClick={() => handleRegister(load.id)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Register
                      </Button>
                    )
                  ) : (
                    <Badge className="bg-gray-600 flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" />
                      UNAVAILABLE
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredLoads.length === 0 && (
        <Card className="bg-gray-800/50 border-gray-600">
          <CardContent className="p-8 text-center">
            <div className="text-gray-400">No loads match your search criteria</div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default UserLoadBoardView;