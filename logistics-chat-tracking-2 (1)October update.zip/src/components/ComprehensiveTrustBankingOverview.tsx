import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, DollarSign, TrendingUp, Shield, Building2 } from 'lucide-react';

interface RevenueStream {
  name: string;
  amount: number;
  percentage: number;
  status: 'active' | 'pending' | 'processing';
}

interface TrustAccount {
  id: string;
  name: string;
  balance: number;
  type: 'main' | 'escrow' | 'operating';
  status: 'active' | 'frozen' | 'pending';
}

export const ComprehensiveTrustBankingOverview: React.FC = () => {
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [trustBalance, setTrustBalance] = useState(0);
  const [escrowBalance, setEscrowBalance] = useState(0);

  const revenueStreams: RevenueStream[] = [
    { name: 'Xpress AI Alazie Platform', amount: 125000, percentage: 35, status: 'active' },
    { name: 'Loadboard AI Platform', amount: 89000, percentage: 25, status: 'active' },
    { name: 'AI Alazie Xpress Platform', amount: 67000, percentage: 19, status: 'processing' },
    { name: 'Synergy Platform', amount: 45000, percentage: 13, status: 'active' },
    { name: 'Lenders & Investors Platform', amount: 28000, percentage: 8, status: 'pending' }
  ];

  const trustAccounts: TrustAccount[] = [
    { id: 'trust-main', name: 'Alaziel Trust Main Account', balance: 2450000, type: 'main', status: 'active' },
    { id: 'trust-escrow', name: 'Alaziel Escrow Account', balance: 890000, type: 'escrow', status: 'active' },
    { id: 'trust-operating', name: 'Operating Reserve', balance: 156000, type: 'operating', status: 'active' }
  ];

  useEffect(() => {
    const total = revenueStreams.reduce((sum, stream) => sum + stream.amount, 0);
    setTotalRevenue(total);
    setTrustBalance(trustAccounts.find(acc => acc.type === 'main')?.balance || 0);
    setEscrowBalance(trustAccounts.find(acc => acc.type === 'escrow')?.balance || 0);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Alaziel Banking System</h1>
          <p className="text-blue-200">AI-Powered Trust Banking & Revenue Management</p>
          <Badge className="mt-2 bg-green-600">FDIC Insured • ACH Certified • Dwolla Integrated</Badge>
        </div>

        {/* Revenue Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-slate-800/50 border-blue-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-blue-200">Total Platform Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">${totalRevenue.toLocaleString()}</div>
              <div className="text-xs text-green-400">+12.5% from last month</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-green-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-green-200">Trust Account Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">${trustBalance.toLocaleString()}</div>
              <div className="text-xs text-green-400">Main Operating Account</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-purple-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-purple-200">Escrow Holdings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">${escrowBalance.toLocaleString()}</div>
              <div className="text-xs text-purple-400">Secured & Protected</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-yellow-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-yellow-200">AI Processing Fees</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">$45,230</div>
              <div className="text-xs text-yellow-400">Automated Revenue</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="revenue" className="space-y-6">
          <TabsList className="bg-slate-800/50 border border-blue-500/20">
            <TabsTrigger value="revenue">Revenue Streams</TabsTrigger>
            <TabsTrigger value="accounts">Trust Accounts</TabsTrigger>
            <TabsTrigger value="routing">Payment Routing</TabsTrigger>
            <TabsTrigger value="compliance">Legal Compliance</TabsTrigger>
          </TabsList>

          <TabsContent value="revenue" className="space-y-4">
            <Card className="bg-slate-800/50 border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Platform Revenue Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {revenueStreams.map((stream, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-white font-medium">{stream.name}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant={stream.status === 'active' ? 'default' : 'secondary'}>
                          {stream.status}
                        </Badge>
                        <span className="text-white font-bold">${stream.amount.toLocaleString()}</span>
                      </div>
                    </div>
                    <Progress value={stream.percentage} className="h-2" />
                    <div className="text-xs text-gray-400">{stream.percentage}% of total revenue</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="accounts" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {trustAccounts.map((account) => (
                <Card key={account.id} className="bg-slate-800/50 border-green-500/20">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{account.name}</CardTitle>
                    <Badge variant={account.status === 'active' ? 'default' : 'secondary'}>
                      {account.status.toUpperCase()}
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-400 mb-2">
                      ${account.balance.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-300 capitalize">{account.type} Account</div>
                    <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="routing" className="space-y-4">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Automated Payment Routing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-white">Revenue Flow</h4>
                    <div className="text-sm text-gray-300 space-y-1">
                      <div>1. Platform Revenue Collection</div>
                      <div>2. Fee Calculation & Deduction</div>
                      <div>3. Trust Account Deposit</div>
                      <div>4. Escrow Overflow Protection</div>
                      <div>5. Final Balance Reconciliation</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-white">Integration Status</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Dwolla ACH</span>
                        <Badge className="bg-green-600">Connected</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Stripe Processing</span>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Banking APIs</span>
                        <Badge className="bg-green-600">Verified</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="compliance" className="space-y-4">
            <Card className="bg-slate-800/50 border-yellow-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Legal & Compliance Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-white mb-3">Banking Registrations</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-300">FDIC Registration</span>
                        <Badge className="bg-green-600">Approved</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">OCC Compliance</span>
                        <Badge className="bg-green-600">Certified</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">ACH Network</span>
                        <Badge className="bg-green-600">Member</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">BSA/AML Compliance</span>
                        <Badge className="bg-green-600">Current</Badge>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-3">AI Banking Policies</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-300">AI Risk Assessment</span>
                        <Badge className="bg-green-600">Approved</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Automated Decision Policy</span>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Data Privacy Compliance</span>
                        <Badge className="bg-green-600">GDPR/CCPA</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Audit Trail System</span>
                        <Badge className="bg-green-600">Enabled</Badge>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-6 p-4 bg-blue-900/30 rounded-lg border border-blue-500/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Building2 className="w-5 h-5 text-blue-400" />
                    <span className="font-semibold text-white">Alaziel LLC Banking Charter</span>
                  </div>
                  <p className="text-sm text-gray-300">
                    Registered with all national banking associations. Full compliance with federal and state 
                    banking regulations. AI-powered automation systems approved for commercial banking operations.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex justify-center gap-4 pt-6">
          <Button className="bg-green-600 hover:bg-green-700">
            Access Dwolla Sandbox
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            Generate Compliance Report
          </Button>
          <Button className="bg-purple-600 hover:bg-purple-700">
            Trust Account Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};