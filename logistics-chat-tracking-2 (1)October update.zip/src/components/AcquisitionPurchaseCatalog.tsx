import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Car, MapPin, DollarSign, Truck, Clock, CheckCircle } from 'lucide-react';

const AcquisitionPurchaseCatalog = () => {
  const [selectedCategory, setSelectedCategory] = useState('luxury');

  const catalogItems = {
    luxury: [
      {
        id: 'LUX001',
        name: 'Rolls-Royce Phantom',
        price: 450000,
        dealer: 'Rolls-Royce London',
        location: 'London, UK',
        status: 'Available',
        shipping: 'Express Air Freight',
        eta: '2025-01-25 16:00 EST',
        specs: ['V12 Engine', '563 HP', 'Luxury Interior', 'Suicide Doors'],
        image: '/placeholder.svg'
      },
      {
        id: 'LUX002',
        name: 'Ferrari 488 GTB',
        price: 320000,
        dealer: 'Ferrari Maranello',
        location: 'Maranello, Italy',
        status: 'Reserved',
        shipping: 'Enclosed Transport',
        eta: '2025-01-22 14:30 EST',
        specs: ['V8 Twin-Turbo', '661 HP', 'Carbon Fiber', '0-60 in 3.0s'],
        image: '/placeholder.svg'
      },
      {
        id: 'LUX003',
        name: 'BMW X7 M50i',
        price: 85000,
        dealer: 'BMW Munich Premium',
        location: 'Munich, Germany',
        status: 'In Transit',
        shipping: 'Ocean Freight',
        eta: '2025-01-20 10:15 EST',
        specs: ['V8 Engine', '523 HP', '7-Seater', 'Executive Package'],
        image: '/placeholder.svg'
      }
    ],
    robotics: [
      {
        id: 'ROB001',
        name: 'Tesla Humanoid Robot',
        price: 125000,
        dealer: 'Tesla Robotics Division',
        location: 'Austin, TX',
        status: 'Manufacturing',
        shipping: 'Specialized Transport',
        eta: '2025-02-15 12:00 EST',
        specs: ['AI-Powered', '5.8ft Height', '125lb Weight', 'Bipedal'],
        image: '/placeholder.svg'
      },
      {
        id: 'ROB002',
        name: 'BMW Quality Control Robot',
        price: 98000,
        dealer: 'BMW Robotics Division',
        location: 'Munich, Germany',
        status: 'Ready to Ship',
        shipping: 'Air Freight',
        eta: '2025-01-28 09:00 EST',
        specs: ['Industrial Grade', 'Quality Inspection', 'AI Vision', '24/7 Operation'],
        image: '/placeholder.svg'
      }
    ]
  };

  const deliveryInfo = {
    address: '2408 yanceyville St greensboro NC 27405',
    contact: 'Alucius Alford',
    phone: '336-458-8449',
    email: 'alaziellc.innovation@gmail.com'
  };

  const currentItems = catalogItems[selectedCategory as keyof typeof catalogItems];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-blue-900 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-green-300 flex items-center gap-2">
            <Car className="h-5 w-5" />
            In-Depth Acquisition Purchase Catalog
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <h4 className="text-green-300 font-semibold mb-2">Delivery Information</h4>
            <div className="bg-gray-800/50 p-4 rounded-lg">
              <p className="text-white font-semibold">{deliveryInfo.contact}</p>
              <p className="text-gray-300">{deliveryInfo.address}</p>
              <p className="text-gray-300">{deliveryInfo.phone} | {deliveryInfo.email}</p>
            </div>
          </div>

          <Tabs defaultValue="luxury" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="luxury" onClick={() => setSelectedCategory('luxury')}>
                Luxury Vehicles
              </TabsTrigger>
              <TabsTrigger value="robotics" onClick={() => setSelectedCategory('robotics')}>
                AI Robotics
              </TabsTrigger>
              <TabsTrigger value="tracking">Live Tracking</TabsTrigger>
            </TabsList>

            <TabsContent value="luxury" className="space-y-4">
              <div className="grid gap-4">
                {currentItems.map((item) => (
                  <Card key={item.id} className="bg-gray-800 border-green-500/30">
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-4">
                          <div className="w-full h-32 bg-gray-700 rounded-lg flex items-center justify-center">
                            <Car className="h-8 w-8 text-gray-400" />
                          </div>
                          <div>
                            <h3 className="text-green-300 font-bold text-lg">{item.name}</h3>
                            <p className="text-green-400 font-bold text-2xl">${item.price.toLocaleString()}</p>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-blue-400" />
                            <div>
                              <p className="text-white font-semibold">{item.dealer}</p>
                              <p className="text-gray-400 text-sm">{item.location}</p>
                            </div>
                          </div>
                          <div>
                            <Badge className={
                              item.status === 'Available' ? 'bg-green-600' :
                              item.status === 'Reserved' ? 'bg-yellow-600' :
                              item.status === 'In Transit' ? 'bg-blue-600' : 'bg-orange-600'
                            }>
                              {item.status}
                            </Badge>
                          </div>
                          <div className="space-y-1">
                            <p className="text-gray-300 text-sm">Shipping: {item.shipping}</p>
                            <p className="text-blue-400 text-sm flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              ETA: {item.eta}
                            </p>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className="text-white font-semibold">Specifications</h4>
                          <div className="space-y-1">
                            {item.specs.map((spec, index) => (
                              <div key={index} className="flex items-center gap-2">
                                <CheckCircle className="h-3 w-3 text-green-400" />
                                <span className="text-gray-300 text-sm">{spec}</span>
                              </div>
                            ))}
                          </div>
                          <div className="space-y-2 mt-4">
                            <Button className="w-full bg-green-600 hover:bg-green-700">
                              <DollarSign className="h-4 w-4 mr-2" />
                              Purchase Now
                            </Button>
                            <Button variant="outline" className="w-full border-blue-500 text-blue-300">
                              <Truck className="h-4 w-4 mr-2" />
                              Track Shipment
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="robotics" className="space-y-4">
              <div className="grid gap-4">
                {catalogItems.robotics.map((item) => (
                  <Card key={item.id} className="bg-gray-800 border-purple-500/30">
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-4">
                          <div className="w-full h-32 bg-gray-700 rounded-lg flex items-center justify-center">
                            <Car className="h-8 w-8 text-gray-400" />
                          </div>
                          <div>
                            <h3 className="text-purple-300 font-bold text-lg">{item.name}</h3>
                            <p className="text-green-400 font-bold text-2xl">${item.price.toLocaleString()}</p>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-blue-400" />
                            <div>
                              <p className="text-white font-semibold">{item.dealer}</p>
                              <p className="text-gray-400 text-sm">{item.location}</p>
                            </div>
                          </div>
                          <div>
                            <Badge className={
                              item.status === 'Ready to Ship' ? 'bg-green-600' :
                              item.status === 'Manufacturing' ? 'bg-orange-600' : 'bg-blue-600'
                            }>
                              {item.status}
                            </Badge>
                          </div>
                          <div className="space-y-1">
                            <p className="text-gray-300 text-sm">Shipping: {item.shipping}</p>
                            <p className="text-blue-400 text-sm flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              ETA: {item.eta}
                            </p>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className="text-white font-semibold">Specifications</h4>
                          <div className="space-y-1">
                            {item.specs.map((spec, index) => (
                              <div key={index} className="flex items-center gap-2">
                                <CheckCircle className="h-3 w-3 text-purple-400" />
                                <span className="text-gray-300 text-sm">{spec}</span>
                              </div>
                            ))}
                          </div>
                          <div className="space-y-2 mt-4">
                            <Button className="w-full bg-purple-600 hover:bg-purple-700">
                              <DollarSign className="h-4 w-4 mr-2" />
                              Order Robot
                            </Button>
                            <Button variant="outline" className="w-full border-blue-500 text-blue-300">
                              <Truck className="h-4 w-4 mr-2" />
                              Track Production
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="tracking" className="space-y-4">
              <Card className="bg-gray-800 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-300">GPS Assurance & Live Tracking</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-blue-900/20 p-4 rounded-lg">
                      <h4 className="text-blue-300 font-semibold mb-2">Real-Time GPS Tracking</h4>
                      <p className="text-gray-300 text-sm mb-3">All shipments include 24/7 GPS monitoring with real-time updates</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <p className="text-white font-semibold">Current Shipments:</p>
                          <p className="text-gray-300">• BMW X7 - Atlantic Ocean (Day 3)</p>
                          <p className="text-gray-300">• Ferrari 488 - Milan, Italy (Preparing)</p>
                          <p className="text-gray-300">• Rolls-Royce - London Showroom (Ready)</p>
                        </div>
                        <div className="space-y-2">
                          <p className="text-white font-semibold">Delivery Guarantee:</p>
                          <p className="text-gray-300">• GPS coordinates updated every 15 minutes</p>
                          <p className="text-gray-300">• Temperature & humidity monitoring</p>
                          <p className="text-gray-300">• Secure transport with armed escorts</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default AcquisitionPurchaseCatalog;