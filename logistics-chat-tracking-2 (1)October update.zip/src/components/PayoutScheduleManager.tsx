import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Calendar, DollarSign, Save } from 'lucide-react'
import { StripeConnectService } from '@/services/StripeConnectService'
import { supabase } from '@/lib/supabase'

interface PayoutScheduleManagerProps {
  connectAccountId: string
}

export default function PayoutScheduleManager({ connectAccountId }: PayoutScheduleManagerProps) {
  const [schedule, setSchedule] = useState({
    schedule_type: 'weekly' as 'daily' | 'weekly' | 'monthly' | 'manual',
    day_of_week: 1,
    day_of_month: 1,
    minimum_payout_amount: 25.00,
  })
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    loadSchedule()
  }, [connectAccountId])

  const loadSchedule = async () => {
    const { data } = await supabase
      .from('payout_schedules')
      .select('*')
      .eq('connect_account_id', connectAccountId)
      .eq('is_active', true)
      .single()

    if (data) {
      setSchedule({
        schedule_type: data.schedule_type,
        day_of_week: data.day_of_week || 1,
        day_of_month: data.day_of_month || 1,
        minimum_payout_amount: parseFloat(data.minimum_payout_amount),
      })
    }
  }

  const handleSave = async () => {
    setSaving(true)
    setMessage('')
    try {
      await StripeConnectService.updatePayoutSchedule(connectAccountId, schedule)
      setMessage('Payout schedule updated successfully!')
    } catch (err) {
      setMessage('Failed to update schedule')
    } finally {
      setSaving(false)
    }
  }

  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payout Schedule</CardTitle>
        <CardDescription>Configure when you receive payouts</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Schedule Type</Label>
          <Select value={schedule.schedule_type} onValueChange={(v: any) => setSchedule({ ...schedule, schedule_type: v })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="manual">Manual</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {schedule.schedule_type === 'weekly' && (
          <div>
            <Label>Day of Week</Label>
            <Select value={schedule.day_of_week.toString()} onValueChange={(v) => setSchedule({ ...schedule, day_of_week: parseInt(v) })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {dayNames.map((day, idx) => (
                  <SelectItem key={idx} value={idx.toString()}>{day}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {schedule.schedule_type === 'monthly' && (
          <div>
            <Label>Day of Month</Label>
            <Input
              type="number"
              min="1"
              max="31"
              value={schedule.day_of_month}
              onChange={(e) => setSchedule({ ...schedule, day_of_month: parseInt(e.target.value) })}
            />
          </div>
        )}

        <div>
          <Label>Minimum Payout Amount ($)</Label>
          <Input
            type="number"
            step="0.01"
            min="0"
            value={schedule.minimum_payout_amount}
            onChange={(e) => setSchedule({ ...schedule, minimum_payout_amount: parseFloat(e.target.value) })}
          />
        </div>

        <Button onClick={handleSave} disabled={saving} className="w-full">
          <Save className="h-4 w-4 mr-2" />
          {saving ? 'Saving...' : 'Save Schedule'}
        </Button>

        {message && (
          <p className={`text-sm ${message.includes('success') ? 'text-green-600' : 'text-red-600'}`}>
            {message}
          </p>
        )}
      </CardContent>
    </Card>
  )
}
