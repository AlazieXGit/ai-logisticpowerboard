import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { FileText, Download, Car, Building, DollarSign, Calendar, User, Mail, Eye, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import DocumentViewerModal from './DocumentViewerModal';

export default function PurchaseDocumentsPlatform() {
  const { toast } = useToast();
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const [documentViewerOpen, setDocumentViewerOpen] = useState(false);

  const handleDownloadComplete = (purchase: any, docName: string) => {
    const documentContent = `
PURCHASE DOCUMENT - ${docName}
==============================

Purchase Details:
Item: ${purchase.item}
Purchase Price: ${purchase.amount}
Purchase Date: ${purchase.date}
Account: ${purchase.account}
Transaction ID: ${purchase.transactionId}

Owner Information:
Name: Alucius Alford
Delivery Address: 2408 yanceyville St greensboro NC 27405
Email: alaziellc.innovation@gmail.com
Phone: 336-458-8449

File Reference: file:///C:/Users/VALUED~1/AppData/Local/Temp/MicrosoftEdgeDownloads/d8462cfa-1de0-4912-a1b5-4ee28f1e47c0/deed.pdf

This document certifies the purchase and ownership details for the above item.

Generated: ${new Date().toLocaleString()}
    `;
      documents: ['Purchase Contract', 'Title Transfer', 'Insurance Policy', 'Delivery Receipt']
    },
    {
      id: 'VEH-002',
      type: 'vehicle',
      item: 'BMW i7 xDrive60',
      price: '$120,000',
      date: '2025-08-09',
      status: 'Delivered',
      account: 'PNC Business Account ****1234',
      transactionId: 'TXN-BMW-002',
      documents: ['Purchase Contract', 'Title Transfer', 'Insurance Policy', 'Delivery Receipt']
    }
  ];

  const propertyPurchases = [
    {
      id: 'PROP-001',
      type: 'property',
      item: '123 Main St, Dillon, SC 29536',
      price: '$285,000',
      date: '2025-08-09',
      status: 'Closed',
      account: 'PNC Business Account ****4521',
      transactionId: 'TXN-PROP-001',
      documents: ['Property Deed.pdf', 'Purchase Agreement.pdf', 'Title Insurance.pdf', 'Survey.pdf']
    },
    {
      id: 'PROP-002',
      type: 'property',
      item: '789 Conway Rd, Conway, SC 29526',
      price: '$420,000',
      date: '2025-08-09',
      status: 'Closed',
      account: 'PNC Business Account ****4521',
      transactionId: 'TXN-PROP-002',
      documents: ['Property Deed.pdf', 'Lease Agreements.pdf', 'Financial Analysis.pdf', 'Inspection Report.pdf']
    }
  ];

  const allPurchases = [...vehiclePurchases, ...propertyPurchases];

  const handleDownloadDocument = (purchase: any, docType: string) => {
    const content = `
${docType.toUpperCase()}

Purchase ID: ${purchase.id}
Item: ${purchase.item}
Price: ${purchase.price}
Date: ${purchase.date}
Status: ${purchase.status}

BUYER INFORMATION:
Name: Alucius Alford
Company: Alazie LLC
Email: alaziellc.innovation@gmail.com
Address: 2408 Yanceyville St. Greensboro N.C. 27405

PAYMENT DETAILS:
Account: ${purchase.account}
Transaction ID: ${purchase.transactionId}
Amount: ${purchase.price}

This document is legally binding and has been electronically signed.
Generated on: ${new Date().toLocaleDateString()}
    `;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${purchase.id}_${docType.replace(' ', '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-blue-500" />
            Purchase Documents & Contracts Platform
            <Badge variant="outline" className="ml-2">All Purchases</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Purchases</TabsTrigger>
          <TabsTrigger value="vehicles">Vehicles</TabsTrigger>
          <TabsTrigger value="properties">Properties</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="space-y-4">
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-700">
                  <FileText className="h-5 w-5" />
                  All Purchase Documents & Contracts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allPurchases.map((purchase) => (
                    <Card key={purchase.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              {purchase.type === 'vehicle' ? 
                                <Car className="h-4 w-4 text-blue-500" /> : 
                                <Building className="h-4 w-4 text-green-500" />
                              }
                              <h4 className="font-semibold">{purchase.item}</h4>
                            </div>
                            <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                              <div className="flex items-center gap-1">
                                <DollarSign className="h-3 w-3" />
                                {purchase.price}
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {purchase.date}
                              </div>
                              <div>Account: {purchase.account}</div>
                              <div>Transaction: {purchase.transactionId}</div>
                            </div>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {purchase.status}
                          </Badge>
                        </div>
                        
                        <div className="space-y-2">
                          <h5 className="font-medium text-sm">Available Documents:</h5>
                          <div className="flex flex-wrap gap-2">
                            {purchase.documents.map((doc, index) => (
                              <Button
                                key={index}
                                size="sm"
                                variant="outline"
                                onClick={() => handleDownloadDocument(purchase, doc)}
                                className="text-xs"
                              >
                                <Download className="h-3 w-3 mr-1" />
                                {doc}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="vehicles">
          <div className="space-y-4">
            {vehiclePurchases.map((purchase) => (
              <Card key={purchase.id} className="border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Car className="h-4 w-4 text-blue-500" />
                        <h4 className="font-semibold">{purchase.item}</h4>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div>Price: {purchase.price}</div>
                        <div>Date: {purchase.date}</div>
                        <div>Account: {purchase.account}</div>
                      </div>
                    </div>
                    <Badge variant="outline" className="bg-green-50 text-green-700">
                      {purchase.status}
                    </Badge>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {purchase.documents.map((doc, index) => (
                      <Button
                        key={index}
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownloadDocument(purchase, doc)}
                      >
                        <Download className="h-3 w-3 mr-1" />
                        {doc}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="properties">
          <div className="space-y-4">
            {propertyPurchases.map((purchase) => (
              <Card key={purchase.id} className="border-l-4 border-l-green-500">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Building className="h-4 w-4 text-green-500" />
                        <h4 className="font-semibold">{purchase.item}</h4>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div>Price: {purchase.price}</div>
                        <div>Date: {purchase.date}</div>
                        <div>Account: {purchase.account}</div>
                      </div>
                    </div>
                    <Badge variant="outline" className="bg-green-50 text-green-700">
                      {purchase.status}
                    </Badge>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {purchase.documents.map((doc, index) => (
                      <Button
                        key={index}
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownloadDocument(purchase, doc)}
                      >
                        <Download className="h-3 w-3 mr-1" />
                        {doc}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="transactions">
          <Card>
            <CardHeader>
              <CardTitle>Transaction Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Purchase Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div>Total Purchases: {allPurchases.length}</div>
                    <div>Vehicle Purchases: {vehiclePurchases.length}</div>
                    <div>Property Purchases: {propertyPurchases.length}</div>
                    <div>Total Value: $955,000</div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Account Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-1">
                      <User className="h-3 w-3" />
                      Owner: Alucius Alford
                    </div>
                    <div>Company: Alazie LLC</div>
                    <div className="flex items-center gap-1">
                      <Mail className="h-3 w-3" />
                      Email: alaziellc.innovation@gmail.com
                    </div>
                    <div>Payment Account: PNC Business Account</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}