import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Settings, DollarSign, Shield, Activity, 
  CreditCard, Server, Globe, FileText
} from 'lucide-react';
import AIAutomotiveShippingPlatform from './AIAutomotiveShippingPlatform';
import InternationalVendorManager from './InternationalVendorManager';
import CustomsTrackingSystem from './CustomsTrackingSystem';
import EnhancedDeveloperPlatform from './EnhancedDeveloperPlatform';
import CompletePlatformAnalytics from './CompletePlatformAnalytics';
import PaymentIntegrationInstructions from './PaymentIntegrationInstructions';

const BackOfficeControlCenter = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  const [paymentRoutes] = useState([
    {
      id: '1',
      source: 'Stripe Connect',
      destination: 'Wells Fargo Business',
      status: 'Active',
      route: 'acct_1234567890 → 121000248-****7892',
      lastTransfer: '2025-01-15 14:30:22',
      amount: '$2,450.00',
      dailyLimit: '$125,000'
    },
    {
      id: '2',
      source: 'Square Payments',
      destination: 'Plaid Connected Account',
      status: 'Active',
      route: 'sq0idp-1234567890 → 026009593-****5678',
      lastTransfer: '2025-01-15 13:45:11',
      amount: '$1,875.50',
      dailyLimit: '$75,000'
    }
  ]);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-500';
      case 'Pending': return 'bg-yellow-500';
      case 'Completed': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-green-400">AI ALAZIE XPRESS - Back Office Control Center</h1>
            <p className="text-gray-400">ALUCIUS ALFORD - MASTER ADMIN</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-mono text-green-400">
              {currentTime.toLocaleTimeString()}
            </div>
            <div className="text-gray-400">
              {currentTime.toLocaleDateString('en-US', { 
                weekday: 'short', 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
              })}
            </div>
          </div>
        </div>

        <Tabs defaultValue="developer" className="w-full">
          {/* First Tab Row */}
          <TabsList className="grid grid-cols-9 bg-gray-800/50 mb-2">
            <TabsTrigger value="developer">Developer Platform</TabsTrigger>
            <TabsTrigger value="shipping">AI Automotive Shipping</TabsTrigger>
            <TabsTrigger value="vendors">International Vendors</TabsTrigger>
            <TabsTrigger value="customs">Customs Tracking</TabsTrigger>
            <TabsTrigger value="routing">Payment Routing</TabsTrigger>
            <TabsTrigger value="transfers">Manual Transfer</TabsTrigger>
            <TabsTrigger value="revenue">Revenue Live</TabsTrigger>
            <TabsTrigger value="dash">Dash</TabsTrigger>
            <TabsTrigger value="tax-returns">Annual Tax Return File</TabsTrigger>
          </TabsList>

          {/* Second Tab Row */}
          <TabsList className="grid grid-cols-9 bg-gray-800/50 mb-2">
            <TabsTrigger value="analytics">Complete Analytics</TabsTrigger>
            <TabsTrigger value="data-insights">Data Insights</TabsTrigger>
            <TabsTrigger value="projections">Revenue Projections</TabsTrigger>
            <TabsTrigger value="performance">System Performance</TabsTrigger>
            <TabsTrigger value="monitoring">Real-time Monitor</TabsTrigger>
            <TabsTrigger value="reports">Advanced Reports</TabsTrigger>
            <TabsTrigger value="security">Security Center</TabsTrigger>
            <TabsTrigger value="compliance">Compliance Hub</TabsTrigger>
            <TabsTrigger value="operations">Operations Center</TabsTrigger>
          </TabsList>

          {/* Third Tab Row */}
          <TabsList className="grid grid-cols-10 bg-gray-800/50 mb-6">
            <TabsTrigger value="banking">Banking Systems</TabsTrigger>
            <TabsTrigger value="payments">Payment Processing</TabsTrigger>
            <TabsTrigger value="payment-setup">Payment Setup</TabsTrigger>
            <TabsTrigger value="transactions">Transaction Control</TabsTrigger>
            <TabsTrigger value="accounts">Account Management</TabsTrigger>
            <TabsTrigger value="integrations">API Integrations</TabsTrigger>
            <TabsTrigger value="automation">AI Automation</TabsTrigger>
            <TabsTrigger value="logistics">Logistics Hub</TabsTrigger>
            <TabsTrigger value="support">Support Center</TabsTrigger>
            <TabsTrigger value="admin">Admin Tools</TabsTrigger>
          </TabsList>

          <TabsContent value="developer">
            <Card className="bg-gray-800/30 border-cyan-500">
              <CardHeader>
                <CardTitle className="text-cyan-400 flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Enhanced Developer Platform with AI Integrations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EnhancedDeveloperPlatform />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shipping">
            <AIAutomotiveShippingPlatform />
          </TabsContent>

          <TabsContent value="vendors">
            <Card className="bg-gray-800/30 border-cyan-500">
              <CardHeader>
                <CardTitle className="text-cyan-400 flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  International Vendor Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <InternationalVendorManager />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="customs">
            <Card className="bg-gray-800/30 border-orange-500">
              <CardHeader>
                <CardTitle className="text-orange-400 flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Customs & Shipping Tracking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CustomsTrackingSystem />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="routing" className="space-y-6">
            <Card className="bg-gray-800/30 border-green-500">
              <CardHeader>
                <CardTitle className="text-green-400 flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Routing System
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {paymentRoutes.map((route) => (
                    <div key={route.id} className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge className={`${getStatusColor(route.status)} text-white`}>
                              {route.status}
                            </Badge>
                            <span className="font-semibold text-white">
                              {route.source} → {route.destination}
                            </span>
                          </div>
                          <p className="text-gray-400 text-sm mb-1">
                            Route: {route.route}
                          </p>
                          <p className="text-gray-400 text-sm mb-1">
                            Last Transfer: {route.lastTransfer}
                          </p>
                          <p className="text-gray-400 text-sm">
                            Amount: {route.amount} | Daily Limit: {route.dailyLimit}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transfers">
            <Card className="bg-gray-800/30 border-purple-500">
              <CardHeader>
                <CardTitle className="text-purple-400">Manual Transfer Protocol</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    <DollarSign className="h-4 w-4 mr-2" />
                    Initiate Transfer
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Activity className="h-4 w-4 mr-2" />
                    View Transfer History
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="revenue">
            <Card className="bg-gray-800/30 border-green-500">
              <CardHeader>
                <CardTitle className="text-green-400">Revenue Live</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl font-bold text-green-400 mb-2">$847,293.45</div>
                  <p className="text-gray-400">Total Revenue Today</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security">
            <Card className="bg-gray-800/30 border-blue-500">
              <CardHeader>
                <CardTitle className="text-blue-400">Security Check</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>System Status:</span>
                    <Badge className="bg-green-500">SECURE</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Security Scan:</span>
                    <span className="text-gray-400">2 minutes ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="dash">
            <Card className="bg-gray-800/30 border-blue-500">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Platform Dashboard & Policies
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <h3 className="text-white font-semibold mb-2">Platform URLs</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Privacy Policy:</span>
                        <a 
                          href="https://alazieexpress.com/privacy-policy" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:text-blue-300 underline"
                        >
                          https://alazieexpress.com/privacy-policy
                        </a>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Terms of Service:</span>
                        <a 
                          href="https://alazieexpress.com/terms" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:text-blue-300 underline"
                        >
                          https://alazieexpress.com/terms
                        </a>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Support Center:</span>
                        <a 
                          href="https://alazieexpress.com/support" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:text-blue-300 underline"
                        >
                          https://alazieexpress.com/support
                        </a>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <h3 className="text-white font-semibold mb-2">Platform Status</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Platform Version:</span>
                        <Badge className="bg-green-500">v2.5.1</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Last Updated:</span>
                        <span className="text-gray-400">2025-01-15 12:00:00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tax-returns">
            <Card className="bg-gray-800/30 border-orange-500">
              <CardHeader>
                <CardTitle className="text-orange-400 flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Annual Tax Return Filing System
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <h3 className="text-white font-semibold mb-2">Filed Tax Returns (2024)</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Federal Return:</span>
                        <Badge className="bg-green-500">Filed - Accepted</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">State Return (NC):</span>
                        <Badge className="bg-green-500">Filed - Accepted</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Business Return:</span>
                        <Badge className="bg-blue-500">In Progress</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <h3 className="text-white font-semibold mb-2">AI Tax Assistant Performance</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Processing Speed:</span>
                        <Badge className="bg-purple-500">x600 Performance</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Optimization Level:</span>
                        <Badge className="bg-blue-500">x100 Optimization</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Success Rate:</span>
                        <Badge className="bg-green-500">400x Boost</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Complete Analytics Tab */}
          <TabsContent value="analytics">
            <Card className="bg-gray-800/30 border-cyan-500">
              <CardHeader>
                <CardTitle className="text-cyan-400 flex items-center gap-2">
                  <Server className="h-5 w-5" />
                  Complete Platform Analytics & Data Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CompletePlatformAnalytics />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Data Insights Tab */}
          <TabsContent value="data-insights">
            <Card className="bg-gray-800/30 border-purple-500">
              <CardHeader>
                <CardTitle className="text-purple-400">Real-time Data Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="bg-gray-700/30 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-2">Transaction Volume</h4>
                    <p className="text-2xl font-bold text-green-400">$2.4M</p>
                    <p className="text-gray-400 text-sm">+15% from last month</p>
                  </div>
                  <div className="bg-gray-700/30 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-2">Active Users</h4>
                    <p className="text-2xl font-bold text-blue-400">12,847</p>
                    <p className="text-gray-400 text-sm">+8% growth rate</p>
                  </div>
                  <div className="bg-gray-700/30 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-2">System Uptime</h4>
                    <p className="text-2xl font-bold text-purple-400">99.9%</p>
                    <p className="text-gray-400 text-sm">Last 30 days</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance">
            <Card className="bg-gray-800/30 border-green-500">
              <CardHeader>
                <CardTitle className="text-green-400">System Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>API Response Time:</span>
                    <Badge className="bg-green-500">145ms avg</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Database Query Speed:</span>
                    <Badge className="bg-blue-500">23ms avg</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Error Rate:</span>
                    <Badge className="bg-green-500">0.02%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Memory Usage:</span>
                    <Badge className="bg-yellow-500">68%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Banking Systems Tab */}
          <TabsContent value="banking">
            <Card className="bg-gray-800/30 border-blue-500">
              <CardHeader>
                <CardTitle className="text-blue-400">Banking Systems Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-700/30 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-2">Connected Banks</h4>
                    <ul className="space-y-2">
                      <li className="flex justify-between">
                        <span>Wells Fargo Business</span>
                        <Badge className="bg-green-500">Active</Badge>
                      </li>
                      <li className="flex justify-between">
                        <span>PNC Bank</span>
                        <Badge className="bg-green-500">Active</Badge>
                      </li>
                      <li className="flex justify-between">
                        <span>Chase Business</span>
                        <Badge className="bg-yellow-500">Pending</Badge>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-gray-700/30 p-4 rounded-lg">
                    <h4 className="text-white font-semibold mb-2">Account Balances</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Operating Account:</span>
                        <span className="text-green-400">$847,293.45</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Trust Account:</span>
                        <span className="text-blue-400">$2,156,789.12</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Escrow Account:</span>
                        <span className="text-purple-400">$456,123.78</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payment Setup Tab */}
          <TabsContent value="payment-setup">
            <Card className="bg-gray-800/30 border-orange-500">
              <CardHeader>
                <CardTitle className="text-orange-400 flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Live Payment Integration Setup
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PaymentIntegrationInstructions />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default BackOfficeControlCenter;