import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { creditServices } from '@/lib/creditServices';
import { AlertCircle, CheckCircle, XCircle } from 'lucide-react';

interface PrequalificationResult {
  approved: boolean;
  creditScore: number;
  reason: string;
  recommendedAmount: number;
  interestRate: number;
}

export const CreditPrequalificationSystem: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PrequalificationResult | null>(null);
  const [customerData, setCustomerData] = useState({
    firstName: '',
    lastName: '',
    ssn: '',
    income: '',
    requestedAmount: ''
  });

  const handlePrequalification = async () => {
    setLoading(true);
    try {
      // Perform soft credit pull
      const creditScore = await creditServices.getFicoScore(customerData.ssn);
      
      // Prequalification logic
      const income = parseFloat(customerData.income);
      const requested = parseFloat(customerData.requestedAmount);
      const score = creditScore.score;
      
      let approved = false;
      let reason = '';
      let recommendedAmount = 0;
      let interestRate = 0;

      if (score >= 740) {
        approved = true;
        recommendedAmount = Math.min(requested, income * 5);
        interestRate = 3.5;
        reason = 'Excellent credit score qualifies for premium rates';
      } else if (score >= 670) {
        approved = true;
        recommendedAmount = Math.min(requested, income * 3);
        interestRate = 6.5;
        reason = 'Good credit score qualifies for standard rates';
      } else if (score >= 580) {
        approved = requested <= income * 2;
        recommendedAmount = Math.min(requested, income * 2);
        interestRate = 12.5;
        reason = approved ? 'Fair credit - limited approval' : 'Requested amount too high for credit score';
      } else {
        approved = false;
        reason = 'Credit score below minimum requirements';
      }

      setResult({
        approved,
        creditScore: score,
        reason,
        recommendedAmount,
        interestRate
      });
    } catch (error) {
      console.error('Prequalification failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5" />
            <span>Credit Prequalification - Soft Pull</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              placeholder="First Name"
              value={customerData.firstName}
              onChange={(e) => setCustomerData({...customerData, firstName: e.target.value})}
            />
            <Input
              placeholder="Last Name"
              value={customerData.lastName}
              onChange={(e) => setCustomerData({...customerData, lastName: e.target.value})}
            />
            <Input
              placeholder="SSN"
              value={customerData.ssn}
              onChange={(e) => setCustomerData({...customerData, ssn: e.target.value})}
            />
            <Input
              placeholder="Annual Income"
              type="number"
              value={customerData.income}
              onChange={(e) => setCustomerData({...customerData, income: e.target.value})}
            />
            <Input
              placeholder="Requested Amount"
              type="number"
              value={customerData.requestedAmount}
              onChange={(e) => setCustomerData({...customerData, requestedAmount: e.target.value})}
            />
          </div>
          <Button onClick={handlePrequalification} disabled={loading} className="w-full">
            {loading ? 'Processing...' : 'Run Prequalification'}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              {result.approved ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <XCircle className="w-5 h-5 text-red-500" />
              )}
              <span>Prequalification Result</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span>Status:</span>
                <Badge variant={result.approved ? 'default' : 'destructive'}>
                  {result.approved ? 'APPROVED' : 'DECLINED'}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>Credit Score:</span>
                <span className="font-semibold">{result.creditScore}</span>
              </div>
              {result.approved && (
                <>
                  <div className="flex items-center justify-between">
                    <span>Approved Amount:</span>
                    <span className="font-semibold">${result.recommendedAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Interest Rate:</span>
                    <span className="font-semibold">{result.interestRate}%</span>
                  </div>
                </>
              )}
              <div className="border-t pt-3">
                <p className="text-sm text-gray-600">{result.reason}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};