import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Building2, 
  Truck, 
  CreditCard, 
  Database, 
  Users, 
  FileText, 
  BarChart3, 
  Shield,
  DollarSign,
  Activity,
  TrendingUp,
  Clock
} from 'lucide-react';
import LiveClock from './LiveClock';

const ComprehensiveDataBreakdown: React.FC = () => {
  const [selectedTab, setSelectedTab] = useState('banking');

  const tabData = {
    banking: {
      icon: <Building2 className="h-5 w-5" />,
      title: 'Banking System Data',
      totalAccounts: 847,
      activeTransactions: 234,
      totalVolume: '$2,847,392.50',
      details: [
        { label: 'Wells Fargo Accounts', value: '342', status: 'active' },
        { label: 'PNC Bank Accounts', value: '198', status: 'active' },
        { label: 'Ace Flare Accounts', value: '156', status: 'active' },
        { label: 'Trust Accounts', value: '89', status: 'active' },
        { label: 'Escrow Accounts', value: '62', status: 'active' }
      ]
    },
    tms: {
      icon: <Truck className="h-5 w-5" />,
      title: 'TMS System Data',
      totalAccounts: 456,
      activeTransactions: 89,
      totalVolume: '$1,234,567.89',
      details: [
        { label: 'Active Loads', value: '234', status: 'active' },
        { label: 'Completed Loads', value: '1,847', status: 'completed' },
        { label: 'Carriers Registered', value: '456', status: 'active' },
        { label: 'Brokers Active', value: '123', status: 'active' },
        { label: 'Revenue Generated', value: '$456,789', status: 'active' }
      ]
    },
    payments: {
      icon: <CreditCard className="h-5 w-5" />,
      title: 'Payment Processor Data',
      totalAccounts: 1234,
      activeTransactions: 567,
      totalVolume: '$4,567,890.12',
      details: [
        { label: 'Stripe Transactions', value: '2,345', status: 'active' },
        { label: 'Square Payments', value: '1,876', status: 'active' },
        { label: 'ACH Transfers', value: '987', status: 'active' },
        { label: 'Wire Transfers', value: '234', status: 'active' },
        { label: 'Failed Transactions', value: '23', status: 'error' }
      ]
    },
    database: {
      icon: <Database className="h-5 w-5" />,
      title: 'Database Administration',
      totalAccounts: 50,
      activeTransactions: 12,
      totalVolume: '99.8% Uptime',
      details: [
        { label: 'Total Tables', value: '156', status: 'active' },
        { label: 'Active Connections', value: '234', status: 'active' },
        { label: 'Storage Used', value: '2.4TB', status: 'active' },
        { label: 'Backup Status', value: 'Current', status: 'active' },
        { label: 'Query Performance', value: '98.5%', status: 'active' }
      ]
    },
    users: {
      icon: <Users className="h-5 w-5" />,
      title: 'User Management Data',
      totalAccounts: 2847,
      activeTransactions: 456,
      totalVolume: '2,847 Users',
      details: [
        { label: 'Active Users', value: '2,234', status: 'active' },
        { label: 'Premium Users', value: '456', status: 'active' },
        { label: 'Super Admins', value: '12', status: 'active' },
        { label: 'Suspended Users', value: '34', status: 'error' },
        { label: 'New Registrations', value: '89', status: 'active' }
      ]
    },
    documents: {
      icon: <FileText className="h-5 w-5" />,
      title: 'Document System Data',
      totalAccounts: 15678,
      activeTransactions: 234,
      totalVolume: '15,678 Files',
      details: [
        { label: 'Legal Documents', value: '4,567', status: 'active' },
        { label: 'Tax Documents', value: '3,456', status: 'active' },
        { label: 'Contracts', value: '2,345', status: 'active' },
        { label: 'Reports', value: '1,234', status: 'active' },
        { label: 'Storage Used', value: '890GB', status: 'active' }
      ]
    },
    analytics: {
      icon: <BarChart3 className="h-5 w-5" />,
      title: 'Analytics Dashboard Data',
      totalAccounts: 100,
      activeTransactions: 45,
      totalVolume: '100% Coverage',
      details: [
        { label: 'Revenue Tracking', value: 'Active', status: 'active' },
        { label: 'Performance Metrics', value: '98.7%', status: 'active' },
        { label: 'User Analytics', value: 'Real-time', status: 'active' },
        { label: 'Financial Reports', value: 'Current', status: 'active' },
        { label: 'System Health', value: '99.2%', status: 'active' }
      ]
    },
    security: {
      icon: <Shield className="h-5 w-5" />,
      title: 'Security Center Data',
      totalAccounts: 0,
      activeTransactions: 0,
      totalVolume: 'Secure',
      details: [
        { label: 'Threat Level', value: 'Low', status: 'active' },
        { label: 'Active Sessions', value: '456', status: 'active' },
        { label: 'Failed Logins', value: '12', status: 'warning' },
        { label: 'Security Alerts', value: '0', status: 'active' },
        { label: 'System Status', value: 'Secure', status: 'active' }
      ]
    }
  };

  const currentData = tabData[selectedTab as keyof typeof tabData];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Comprehensive Data Breakdown</h2>
        <LiveClock />
      </div>

      <Card className="bg-purple-900/20 border-purple-500/50">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <Database className="h-5 w-5" />
            Complete Platform Data Analysis
          </CardTitle>
          <Badge className="bg-purple-600 w-fit">REAL-TIME DATA MONITORING</Badge>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
              <TabsTrigger value="banking">Banking</TabsTrigger>
              <TabsTrigger value="tms">TMS</TabsTrigger>
              <TabsTrigger value="payments">Payments</TabsTrigger>
              <TabsTrigger value="database">Database</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
            </TabsList>
            
            {Object.entries(tabData).map(([key, data]) => (
              <TabsContent key={key} value={key} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="bg-blue-900/20 border-blue-500/50">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        {data.icon}
                        <div>
                          <p className="text-blue-400 text-sm">Total Accounts</p>
                          <p className="text-2xl font-bold text-white">{data.totalAccounts.toLocaleString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-green-900/20 border-green-500/50">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <Activity className="h-5 w-5 text-green-400" />
                        <div>
                          <p className="text-green-400 text-sm">Active Transactions</p>
                          <p className="text-2xl font-bold text-white">{data.activeTransactions.toLocaleString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-yellow-900/20 border-yellow-500/50">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <TrendingUp className="h-5 w-5 text-yellow-400" />
                        <div>
                          <p className="text-yellow-400 text-sm">Total Volume</p>
                          <p className="text-2xl font-bold text-white">{data.totalVolume}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      {data.icon}
                      {data.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {data.details.map((detail, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <span className="text-gray-300">{detail.label}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-white font-semibold">{detail.value}</span>
                          <Badge 
                            className={
                              detail.status === 'active' ? 'bg-green-600' :
                              detail.status === 'error' ? 'bg-red-600' :
                              detail.status === 'warning' ? 'bg-yellow-600' :
                              'bg-blue-600'
                            }
                          >
                            {detail.status.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ComprehensiveDataBreakdown;