import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowDown, DollarSign, TrendingUp, Calculator, Building2 } from 'lucide-react';

const AlazieAccountFlowTotal = () => {
  const [totalProcessed, setTotalProcessed] = useState(0);
  const [finalBalance, setFinalBalance] = useState(0);

  // AI Alazie Xpress revenue sources and fees
  const revenueBreakdown = [
    { category: 'TMS Operations Revenue', amount: 45000, type: 'income' },
    { category: 'AI Banking Services', amount: 32000, type: 'income' },
    { category: 'Corporate Banking Fees', amount: 28500, type: 'income' },
    { category: 'Trust Account Management', amount: 22000, type: 'income' },
    { category: 'Escrow Services', amount: 18500, type: 'income' },
    { category: 'AI Development Licensing', amount: 15000, type: 'income' },
    { category: 'Platform Transaction Fees', amount: 12000, type: 'income' },
    { category: 'Banking Compliance Fees (2.5%)', amount: -4287, type: 'fee' },
    { category: 'AI Processing & Maintenance', amount: -3200, type: 'fee' },
    { category: 'Corporate Admin Fees', amount: -2850, type: 'fee' },
    { category: 'Trust Management Fees (1.8%)', amount: -2772, type: 'fee' },
    { category: 'Security & Compliance', amount: -1850, type: 'fee' },
    { category: 'Platform Licensing Fees', amount: -1500, type: 'fee' }
  ];

  const totalIncome = revenueBreakdown
    .filter(item => item.type === 'income')
    .reduce((sum, item) => sum + item.amount, 0);

  const totalFees = revenueBreakdown
    .filter(item => item.type === 'fee')
    .reduce((sum, item) => sum + Math.abs(item.amount), 0);

  const netTotal = totalIncome - totalFees;

  useEffect(() => {
    const interval = setInterval(() => {
      setTotalProcessed(prev => {
        if (prev >= 100) {
          setFinalBalance(netTotal);
          return 100;
        }
        return prev + 1.5;
      });
    }, 120);

    return () => clearInterval(interval);
  }, [netTotal]);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-lime-900 to-green-900 border-lime-500/30">
        <CardHeader>
          <CardTitle className="text-lime-300 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            AI ALAZIE XPRESS - Final Destination Account Total
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-lime-300 text-sm font-semibold">Total Corporate Income</p>
                <p className="text-2xl font-bold text-green-400">
                  ${totalIncome.toLocaleString()}
                </p>
              </div>
              <div className="text-center">
                <p className="text-red-300 text-sm font-semibold">Total Platform Fees</p>
                <p className="text-2xl font-bold text-red-400">
                  -${totalFees.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-center">
              <ArrowDown className="h-8 w-8 text-lime-400" />
            </div>

            <div className="space-y-4">
              <div className="text-center p-4 bg-lime-900/30 rounded-lg border border-lime-500/30">
                <p className="text-lime-300 text-sm font-semibold mb-2">Final Corporate Balance</p>
                <p className="text-3xl font-bold text-lime-400">
                  ${finalBalance.toLocaleString()}
                </p>
                <Badge className="mt-2 bg-lime-600">
                  Net After All Corporate Deductions
                </Badge>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Processing Revenue Flow</span>
                  <span className="text-lime-400">{totalProcessed}%</span>
                </div>
                <Progress value={totalProcessed} className="h-2" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800 border-lime-500/30">
          <CardHeader>
            <CardTitle className="text-lime-400 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              AI ALAZIE XPRESS Revenue Sources
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {revenueBreakdown
                .filter(item => item.type === 'income')
                .map((item, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-lime-900/20 rounded">
                  <span className="text-lime-300 text-sm">{item.category}</span>
                  <span className="text-lime-400 font-semibold">
                    ${item.amount.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-red-500/30">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Corporate Fees & Deductions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {revenueBreakdown
                .filter(item => item.type === 'fee')
                .map((item, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-red-900/20 rounded">
                  <span className="text-red-300 text-sm">{item.category}</span>
                  <span className="text-red-400 font-semibold">
                    ${Math.abs(item.amount).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AlazieAccountFlowTotal;