import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { 
  CreditCard, DollarSign, Settings, Save, 
  ArrowUpRight, Building2, Shield, Zap 
} from 'lucide-react';

interface PaymentRoute {
  id: string;
  name: string;
  endpoint: string;
  status: 'active' | 'inactive';
  totalProcessed: number;
}

export const EnhancedPaymentProcessor: React.FC = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [amount, setAmount] = useState('');
  const [selectedRoute, setSelectedRoute] = useState('primary-revenue-routing');
  const [paymentRoutes] = useState<PaymentRoute[]>([
    { id: '1', name: 'Primary Revenue', endpoint: 'primary-revenue-routing', status: 'active', totalProcessed: 485750.50 },
    { id: '2', name: 'Trust Account', endpoint: 'trust-account-routing', status: 'active', totalProcessed: 289500.25 },
    { id: '3', name: 'Escrow Account', endpoint: 'escrow-routing', status: 'active', totalProcessed: 425000.00 },
    { id: '4', name: 'Operating Account', endpoint: 'operating-routing', status: 'active', totalProcessed: 167890.75 }
  ]);

  const handlePaymentProcess = async (type: 'manual' | 'automated') => {
    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('realtime-transaction-processor', {
        body: { 
          action: 'processPayment',
          data: { 
            amount: parseFloat(amount),
            routingEndpoint: selectedRoute,
            type
          }
        }
      });

      if (data && data.success) {
        alert(`Payment processed successfully! Transaction ID: ${data.transactionId}`);
        setAmount('');
      } else {
        alert('Payment processing failed');
      }
    } catch (error) {
      console.error('Payment processing error:', error);
      alert('Payment processing error');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/20 to-green-900/20 border-blue-500">
        <CardHeader>
          <CardTitle className="text-2xl text-blue-400 flex items-center gap-2">
            <CreditCard className="h-6 w-6" />
            Enhanced Payment Processing Hub
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Manual Processing</h3>
              <div className="space-y-3">
                <input
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600"
                />
                <select
                  value={selectedRoute}
                  onChange={(e) => setSelectedRoute(e.target.value)}
                  className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600"
                >
                  {paymentRoutes.map(route => (
                    <option key={route.id} value={route.endpoint}>
                      {route.name} - ${route.totalProcessed.toLocaleString()}
                    </option>
                  ))}
                </select>
                <Button 
                  onClick={() => handlePaymentProcess('manual')}
                  disabled={isProcessing || !amount}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {isProcessing ? 'Processing...' : 'Process Manual Payment'}
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Automated Processing</h3>
              <div className="space-y-3">
                <Button 
                  onClick={() => handlePaymentProcess('automated')}
                  disabled={isProcessing}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <Zap className="h-4 w-4 mr-2" />
                  {isProcessing ? 'Processing...' : 'Enable Auto Processing'}
                </Button>
                <div className="text-sm text-gray-300">
                  Automated processing will handle transactions based on predefined rules and routing configurations.
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {paymentRoutes.map(route => (
              <Card key={route.id} className="bg-gray-800/30 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-white font-semibold">{route.name}</h4>
                    <Badge className={route.status === 'active' ? 'bg-green-600' : 'bg-red-600'}>
                      {route.status}
                    </Badge>
                  </div>
                  <p className="text-gray-400 text-sm mb-2">{route.endpoint}</p>
                  <p className="text-green-400 font-bold">
                    ${route.totalProcessed.toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};