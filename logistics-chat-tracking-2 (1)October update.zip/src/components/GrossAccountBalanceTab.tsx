import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { DollarSign, TrendingUp, Building2, CreditCard } from 'lucide-react';
import AnalyticsReportSection from './AnalyticsReportSection';
export const GrossAccountBalanceTab: React.FC = () => {
  const [totalBalance, setTotalBalance] = useState(0);
  const [dailyGrowth, setDailyGrowth] = useState(0);

  useEffect(() => {
    // Simulate real-time balance updates
    const interval = setInterval(() => {
      setTotalBalance(prev => prev + Math.random() * 10000);
      setDailyGrowth(prev => prev + Math.random() * 1000);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const accounts = [
    { name: 'Alaziel Banking', balance: 2847392.45, type: 'Primary', growth: 15.3 },
    { name: 'Wells Fargo', balance: 1293847.23, type: 'Business', growth: 8.7 },
    { name: 'Trust Account', balance: 5847293.12, type: 'Trust', growth: 22.1 },
    { name: 'Escrow Holdings', balance: 3294857.89, type: 'Escrow', growth: 12.5 },
    { name: 'Investment Portfolio', balance: 8475639.34, type: 'Investment', growth: 28.9 }
  ];

  const grossTotal = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-emerald-900 border-green-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <DollarSign className="h-6 w-6" />
            Gross Account Balance - Unified Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-green-400 mb-2">
              ${grossTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <Badge className="bg-green-600 text-white px-4 py-2">
              TOTAL GROSS BALANCE
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {accounts.map((account, index) => (
              <Card key={index} className="bg-black/40 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-sm text-gray-300">{account.name}</div>
                    <Badge variant="outline" className="text-xs">
                      {account.type}
                    </Badge>
                  </div>
                  <div className="text-xl font-bold text-white mb-2">
                    ${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-green-400" />
                    <span className="text-green-400 text-sm">+{account.growth}%</span>
                  </div>
                  <Progress value={account.growth} className="mt-2 h-2" />
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-blue-900/30 border-blue-500">
              <CardContent className="p-4 text-center">
                <Building2 className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-blue-400">5 Accounts</div>
                <div className="text-sm text-gray-300">Active Banking</div>
              </CardContent>
            </Card>

            <Card className="bg-purple-900/30 border-purple-500">
              <CardContent className="p-4 text-center">
                <CreditCard className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-purple-400">$2.5M+</div>
                <div className="text-sm text-gray-300">Daily Transactions</div>
              </CardContent>
            </Card>

            <Card className="bg-green-900/30 border-green-500">
              <CardContent className="p-4 text-center">
                <TrendingUp className="h-8 w-8 text-green-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-green-400">+18.7%</div>
                <div className="text-sm text-gray-300">Monthly Growth</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
      
      <AnalyticsReportSection />
    </div>
  );
};