import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, DollarSign, ArrowRight, Building, CreditCard, Lock, TrendingUp, Download, Activity, Eye, EyeOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

const TrustBankingOverviewTab = () => {
  const { toast } = useToast();
  const [totalBalance, setTotalBalance] = useState(25000000);
  const [totalRevenue, setTotalRevenue] = useState(8750000);
  const [revenueData, setRevenueData] = useState([]);
  const [liveRevenue, setLiveRevenue] = useState(8750000);
  const [showSensitiveInfo, setShowSensitiveInfo] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    fetchRevenueData();
    const interval = setInterval(() => {
      setLiveRevenue(prev => prev + Math.floor(Math.random() * 5000) + 1000);
      setLastUpdated(new Date());
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const fetchRevenueData = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('revenue-processor', {
        body: { action: 'get_trust_revenue' }
      });
      if (data) {
        setRevenueData(data.revenue_streams || []);
        setTotalRevenue(data.total_revenue || 8750000);
      }
    } catch (error) {
      console.error('Revenue fetch error:', error);
    }
  };

  const trustAccounts = [
    {
      id: 'trust-main',
      name: 'Alaziel Trust Banking - Main Account',
      accountNumber: '5573-9012-4567-8903',
      routingNumber: '031176110',
      balance: 15000000,
      type: 'Primary Trust',
      status: 'Active',
      connectedAccounts: ['PNC Business ***4521', 'Wells Fargo ***7892']
    },
    {
      id: 'trust-investment',
      name: 'Alaziel Trust - Investment Portfolio',
      accountNumber: '5573-9012-4567-8904',
      routingNumber: '031176110',
      balance: 5000000,
      type: 'Investment Trust',
      status: 'Active',
      connectedAccounts: ['Investment Account ***2345']
    },
    {
      id: 'trust-acquisition',
      name: 'Alaziel Trust - Acquisition Fund',
      accountNumber: '5573-9012-4567-8905',
      routingNumber: '031176110',
      balance: 5000000,
      type: 'Acquisition Trust',
      status: 'Active',
      connectedAccounts: ['Escrow Account ***6781']
    }
  ];

  const revenueStreams = [
    { source: 'AI Banking Operations', amount: 2500000, percentage: 28.6 },
    { source: 'Loadboard Platform', amount: 1800000, percentage: 20.6 },
    { source: 'Credit Repair Services', amount: 1500000, percentage: 17.1 },
    { source: 'Payment Processing', amount: 1200000, percentage: 13.7 },
    { source: 'TMS Operations', amount: 950000, percentage: 10.9 },
    { source: 'Email Processing', amount: 800000, percentage: 9.1 }
  ];

  const routeTenMillion = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('enhanced-payment-processor', {
        body: {
          action: 'route_to_trust',
          amount: 10000000,
          purpose: 'property_vehicles_acquisitions'
        }
      });
      
      toast({
        title: 'Transfer Initiated',
        description: '$10,000,000 routed to Trust for property, vehicles, and acquisitions'
      });
      setTotalBalance(prev => prev + 10000000);
    } catch (error) {
      console.error('Transfer error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-300 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Trust Banking System Overview & Revenue Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-green-800/30 p-6 rounded-lg">
              <h3 className="text-green-300 font-semibold mb-2">Total Trust Balance</h3>
              <p className="text-4xl font-bold text-green-400">${totalBalance.toLocaleString()}</p>
              <p className="text-sm text-gray-400 mt-2">Available for acquisitions</p>
            </div>
            <div className="bg-blue-800/30 p-6 rounded-lg">
              <h3 className="text-blue-300 font-semibold mb-2">Total Revenue</h3>
              <p className="text-4xl font-bold text-blue-400">${totalRevenue.toLocaleString()}</p>
              <p className="text-sm text-gray-400 mt-2">All revenue streams</p>
            </div>
            <div className="space-y-3">
              <Button 
                onClick={routeTenMillion}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                <DollarSign className="h-4 w-4 mr-2" />
                Route $10M to Trust
              </Button>
              <p className="text-xs text-gray-400 text-center">
                For houses, cars, land & investments
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="accounts" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="accounts">Trust Accounts</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Streams</TabsTrigger>
          <TabsTrigger value="live-revenue">Live Revenue Total</TabsTrigger>
          <TabsTrigger value="connections">Connections</TabsTrigger>
          <TabsTrigger value="transfers">External Processing</TabsTrigger>
        </TabsList>


        <TabsContent value="accounts" className="space-y-4">
          {trustAccounts.map((account) => (
            <Card key={account.id} className="bg-gray-800 border-blue-500/30">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-blue-300 font-semibold">{account.name}</h3>
                    <p className="text-gray-400 text-sm">{account.type}</p>
                  </div>
                  <Badge className="bg-green-600">{account.status}</Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-gray-400 text-sm">Account Number</p>
                    <p className="text-white font-mono">{account.accountNumber}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Routing Number</p>
                    <p className="text-white font-mono">{account.routingNumber}</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-gray-400 text-sm">Balance</p>
                    <p className="text-2xl font-bold text-green-400">${account.balance.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-400 text-sm">Connected Accounts</p>
                    <p className="text-blue-300 text-sm">{account.connectedAccounts.length} active</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card className="bg-gray-800 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-300 flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Revenue Stream Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {revenueStreams.map((stream, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-green-900/20 rounded-lg">
                    <div>
                      <h4 className="text-green-300 font-semibold">{stream.source}</h4>
                      <p className="text-gray-400 text-sm">{stream.percentage}% of total revenue</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-400">${stream.amount.toLocaleString()}</p>
                      <Button size="sm" variant="outline" className="mt-2">
                        <Download className="h-3 w-3 mr-1" />
                        Export
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>


        <TabsContent value="live-revenue" className="space-y-4">
          <Card className="bg-gradient-to-r from-green-900 to-blue-900 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-300 flex items-center gap-2">
                <Activity className="h-5 w-5 animate-pulse" />
                Live Revenue Total - Platform Streams
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-green-800/30 p-6 rounded-lg">
                  <h3 className="text-green-300 font-semibold mb-2 flex items-center gap-2">
                    <Activity className="h-4 w-4 animate-pulse" />
                    Live Revenue Stream
                  </h3>
                  <p className="text-5xl font-bold text-green-400">${liveRevenue.toLocaleString()}</p>
                  <p className="text-sm text-gray-400 mt-2">Updates every 3 seconds</p>
                </div>
                
                <div className="bg-red-900/30 p-6 rounded-lg border border-red-500/50">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-red-300 font-semibold">PNC Growth Accounts API</h3>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowSensitiveInfo(!showSensitiveInfo)}
                      className="border-red-500 text-red-300"
                    >
                      {showSensitiveInfo ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                    </Button>
                  </div>
                  <Badge className="bg-green-600 mb-3">Active - Revenue Routing</Badge>
                  <p className="text-yellow-300 font-semibold mb-2">Investment Growth - AI ALAZIE XPRESS Revenue</p>
                  
                  {showSensitiveInfo ? (
                    <div className="space-y-2">
                      <div>
                        <p className="text-gray-400 text-sm">Account:</p>
                        <p className="text-white font-mono">5563935283</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Routing:</p>
                        <p className="text-white font-mono">054000030</p>
                      </div>
                       <div>
                         <p className="text-gray-400 text-sm">Balance:</p>
                         <p className="text-green-400 font-bold">Auto-Updated via API</p>
                         <p className="text-xs text-gray-500 mt-1">Last Updated: {lastUpdated.toLocaleTimeString()}</p>
                       </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div>
                        <p className="text-gray-400 text-sm">Account:</p>
                        <p className="text-white font-mono">***********</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Routing:</p>
                        <p className="text-white font-mono">***********</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Balance:</p>
                        <p className="text-green-400 font-bold">Protected</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-800/20 p-4 rounded-lg">
                  <p className="text-blue-300 text-sm">Platform Fees</p>
                  <p className="text-xl font-bold text-blue-400">$2,450,000</p>
                </div>
                <div className="bg-purple-800/20 p-4 rounded-lg">
                  <p className="text-purple-300 text-sm">AI Services</p>
                  <p className="text-xl font-bold text-purple-400">$1,850,000</p>
                </div>
                <div className="bg-green-800/20 p-4 rounded-lg">
                  <p className="text-green-300 text-sm">Subscriptions</p>
                  <p className="text-xl font-bold text-green-400">$1,200,000</p>
                </div>
                <div className="bg-orange-800/20 p-4 rounded-lg">
                  <p className="text-orange-300 text-sm">Transaction Fees</p>
                  <p className="text-xl font-bold text-orange-400">$950,000</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="connections" className="space-y-4">
          {[
            {
              account: 'PNC Business Account ***4521',
              routing: '043000096',
              connection: 'Primary Revenue Source',
              status: 'Connected',
              lastTransfer: '$125,000 - 2025-08-09'
            },
            {
              account: 'Wells Fargo Business ***7892',
              routing: '121000248',
              connection: 'Secondary Operations',
              status: 'Connected',
              lastTransfer: '$75,000 - 2025-08-09'
            },
            {
              account: 'Internal Processing ***3456',
              routing: '021000021',
              connection: 'Payment Processing Hub',
              status: 'Connected',
              lastTransfer: '$50,000 - 2025-08-09'
            }
          ].map((conn, index) => (
            <Card key={index} className="bg-gray-800 border-green-500/30">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <Building className="h-5 w-5 text-blue-400" />
                    <div>
                      <h3 className="text-blue-300 font-semibold">{conn.account}</h3>
                      <p className="text-gray-400 text-sm">Routing: {conn.routing}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-green-600 mb-2">{conn.status}</Badge>
                    <p className="text-gray-400 text-sm">{conn.connection}</p>
                    <p className="text-green-400 text-sm">{conn.lastTransfer}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="transfers" className="space-y-4">
          <Card className="bg-gray-800 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-300">External Payment Processing</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-purple-900/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5 text-purple-400" />
                    <div>
                      <p className="text-purple-300 font-semibold">Property Purchases</p>
                      <p className="text-gray-400 text-sm">Real estate acquisition processing</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400 font-bold">$10,955,000</p>
                    <p className="text-gray-400 text-sm">Available</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-blue-900/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Lock className="h-5 w-5 text-blue-400" />
                    <div>
                      <p className="text-blue-300 font-semibold">Vehicle Acquisitions</p>
                      <p className="text-gray-400 text-sm">Automotive purchase processing</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400 font-bold">$5,485,000</p>
                    <p className="text-gray-400 text-sm">Available</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TrustBankingOverviewTab;