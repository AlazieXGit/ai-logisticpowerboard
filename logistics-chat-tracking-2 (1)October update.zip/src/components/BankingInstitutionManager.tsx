import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, Network, Shield, Activity, Settings, CheckCircle } from 'lucide-react';

interface BankingInstitution {
  id: string;
  name: string;
  routingNumber: string;
  achEnabled: boolean;
  wireEnabled: boolean;
  status: 'active' | 'inactive' | 'maintenance';
  connectionStatus: 'connected' | 'disconnected' | 'pending';
  transactionVolume: number;
  lastActivity: string;
  complianceScore: number;
}

const BankingInstitutionManager: React.FC = () => {
  const [institutions, setInstitutions] = useState<BankingInstitution[]>([
    {
      id: '1',
      name: 'Wells Fargo Bank',
      routingNumber: '121000248',
      achEnabled: true,
      wireEnabled: true,
      status: 'active',
      connectionStatus: 'connected',
      transactionVolume: 15420,
      lastActivity: '2 minutes ago',
      complianceScore: 98
    },
    {
      id: '2',
      name: 'JPMorgan Chase Bank',
      routingNumber: '021000021',
      achEnabled: true,
      wireEnabled: false,
      status: 'active',
      connectionStatus: 'connected',
      transactionVolume: 8750,
      lastActivity: '5 minutes ago',
      complianceScore: 95
    },
    {
      id: '3',
      name: 'Bank of America',
      routingNumber: '026009593',
      achEnabled: false,
      wireEnabled: true,
      status: 'maintenance',
      connectionStatus: 'pending',
      transactionVolume: 0,
      lastActivity: '2 hours ago',
      complianceScore: 92
    }
  ]);

  const toggleACH = (id: string) => {
    setInstitutions(institutions.map(inst => 
      inst.id === id ? { ...inst, achEnabled: !inst.achEnabled } : inst
    ));
  };

  const toggleWire = (id: string) => {
    setInstitutions(institutions.map(inst => 
      inst.id === id ? { ...inst, wireEnabled: !inst.wireEnabled } : inst
    ));
  };

  const toggleStatus = (id: string) => {
    setInstitutions(institutions.map(inst => 
      inst.id === id ? { 
        ...inst, 
        status: inst.status === 'active' ? 'inactive' : 'active',
        connectionStatus: inst.status === 'active' ? 'disconnected' : 'connected'
      } : inst
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-600';
      case 'inactive': return 'bg-red-600';
      case 'maintenance': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  const getConnectionColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-600';
      case 'disconnected': return 'bg-red-600';
      case 'pending': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-purple-900/20 border-purple-500/50">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Banking Institution Manager
          </CardTitle>
          <Badge className="bg-purple-600 w-fit">ACH Network • Wire Transfer • Institution Control</Badge>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="institutions" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="institutions">Institution List</TabsTrigger>
              <TabsTrigger value="network">Network Status</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="institutions" className="space-y-4">
              {institutions.map((institution) => (
                <Card key={institution.id} className="bg-gray-800/30 border-gray-600">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-white text-lg flex items-center gap-2">
                        <Building2 className="h-5 w-5" />
                        {institution.name}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(institution.status)}>
                          {institution.status.toUpperCase()}
                        </Badge>
                        <Badge className={getConnectionColor(institution.connectionStatus)}>
                          {institution.connectionStatus.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <p className="text-gray-400 text-sm">Routing Number</p>
                        <p className="text-white font-mono">{institution.routingNumber}</p>
                        <p className="text-gray-400 text-sm">Last Activity</p>
                        <p className="text-white">{institution.lastActivity}</p>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-gray-400 text-sm">Transaction Volume</p>
                        <p className="text-white font-bold">{institution.transactionVolume.toLocaleString()}</p>
                        <p className="text-gray-400 text-sm">Compliance Score</p>
                        <div className="flex items-center gap-2">
                          <p className="text-white font-bold">{institution.complianceScore}%</p>
                          {institution.complianceScore >= 95 && <CheckCircle className="h-4 w-4 text-green-500" />}
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <Label htmlFor={`ach-${institution.id}`} className="text-sm text-gray-300">
                            ACH Enabled
                          </Label>
                          <Switch
                            id={`ach-${institution.id}`}
                            checked={institution.achEnabled}
                            onCheckedChange={() => toggleACH(institution.id)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <Label htmlFor={`wire-${institution.id}`} className="text-sm text-gray-300">
                            Wire Enabled
                          </Label>
                          <Switch
                            id={`wire-${institution.id}`}
                            checked={institution.wireEnabled}
                            onCheckedChange={() => toggleWire(institution.id)}
                          />
                        </div>
                        
                        <Button
                          size="sm"
                          variant={institution.status === 'active' ? 'destructive' : 'default'}
                          onClick={() => toggleStatus(institution.id)}
                          className="w-full"
                        >
                          {institution.status === 'active' ? 'Deactivate' : 'Activate'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
            
            <TabsContent value="network" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-green-900/20 border-green-500/50">
                  <CardHeader>
                    <CardTitle className="text-green-400 flex items-center gap-2">
                      <Network className="h-5 w-5" />
                      ACH Network Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Connected Institutions:</span>
                        <span className="text-green-400 font-bold">2</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Total Volume Today:</span>
                        <span className="text-green-400 font-bold">24,170</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Network Uptime:</span>
                        <span className="text-green-400 font-bold">99.9%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-blue-900/20 border-blue-500/50">
                  <CardHeader>
                    <CardTitle className="text-blue-400 flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Security Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Fraud Detection:</span>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Encryption Level:</span>
                        <Badge className="bg-blue-600">AES-256</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Compliance:</span>
                        <Badge className="bg-green-600">NACHA</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="analytics" className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      <Activity className="h-5 w-5" />
                      Daily Transactions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-green-400">24,170</p>
                    <p className="text-sm text-gray-400">+12% from yesterday</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Average Processing Time
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-blue-400">1.2s</p>
                    <p className="text-sm text-gray-400">-0.3s improvement</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-800/30 border-gray-600">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Success Rate
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-purple-400">99.8%</p>
                    <p className="text-sm text-gray-400">Excellent performance</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default BankingInstitutionManager;