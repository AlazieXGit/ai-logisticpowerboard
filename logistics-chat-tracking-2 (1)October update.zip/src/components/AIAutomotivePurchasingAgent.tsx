import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Car, DollarSign, Zap, CheckCircle, ShoppingCart, FileText, ExternalLink, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import TrackingModal from './TrackingModal';
import ReceiptModal from './ReceiptModal';
import ContractDetailsModal from './ContractDetailsModal';

export default function AIAutomotivePurchasingAgent() {
  const { toast } = useToast();
  const [processingPurchase, setProcessingPurchase] = useState<number | null>(null);
  const [trackingModalOpen, setTrackingModalOpen] = useState(false);
  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [contractModalOpen, setContractModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  const [vehicles] = useState([
    { id: 1, name: "Rolls-Royce Phantom", price: "$450,000", dealership: "Rolls-Royce Motor Cars", type: "Luxury Sedan", engine: "6.75L V12", year: 2024, available: true },
    { id: 2, name: "Bentley Continental GT", price: "$250,000", dealership: "Bentley Motors", type: "Luxury Coupe", engine: "6.0L W12", year: 2024, available: true },
    { id: 3, name: "Mercedes-Maybach S680", price: "$200,000", dealership: "Mercedes-Benz", type: "Ultra Luxury Sedan", engine: "6.0L V12", year: 2024, available: true }
  ]);

  const [purchasedOrders] = useState([
    { id: 1, vehicle: "Tesla Model S Plaid", price: "$130,000", dealership: "Tesla", orderDate: "2025-08-09", status: "Delivered", trackingNumber: "TES123456", estimatedDelivery: "2025-08-09", description: "Premium electric luxury sedan with autopilot", shippingDetails: "Express delivery via Tesla Transport Network", currentLocation: "Delivered to 2408 Yanceyville St. Greensboro N.C.", route: "Tesla Factory → Greensboro Delivery Center → Customer Address", date: "2025-08-09", transactionId: "TXN-TES-001", deliveryService: "Tesla Transport Network" },
    { id: 2, vehicle: "BMW i7 xDrive60", price: "$120,000", dealership: "BMW", orderDate: "2025-08-09", status: "Delivered", trackingNumber: "BMW789012", estimatedDelivery: "2025-08-09", description: "Electric luxury sedan with advanced AI features", shippingDetails: "Standard BMW delivery service", currentLocation: "Delivered to 2408 Yanceyville St. Greensboro N.C.", route: "BMW Plant → BMW Dealership → Customer Address", date: "2025-08-09", transactionId: "TXN-BMW-002", deliveryService: "BMW Delivery Service" }
  ]);

  const [dealerships] = useState([
    { name: "Rolls-Royce Motor Cars", website: "rolls-roycemotorcars.com", specialty: "Ultra Luxury", status: "Registered & Active" },
    { name: "Bentley Motors", website: "bentleymotors.com", specialty: "Luxury", status: "Registered & Active" },
    { name: "Mercedes-Benz", website: "mbusa.com", specialty: "Luxury/Performance", status: "Registered & Active" },
    { name: "Tesla", website: "tesla.com", specialty: "Electric Vehicles", status: "Registered & Active" }
  ]);

  const handleAIPurchase = async (vehicle: any) => {
    setProcessingPurchase(vehicle.id);
    try {
      const contractData = {
        type: 'vehicle_purchase',
        item: vehicle.name,
        price: vehicle.price,
        recipient: 'Alucius Alford',
        company: 'Alazie LLC',
        dealership: vehicle.dealership,
        delivery_address: '2408 Yanceyville St. Greensboro N.C. 27405',
        email: 'alaziellc.innovation@gmail.com'
      };

      const { data, error } = await supabase.functions.invoke('contract-generator', {
        body: contractData
      });

      if (error) throw error;

      toast({
        title: "AI Purchase Initiated",
        description: `${vehicle.name} purchase contract generated and sent to email`
      });
    } catch (error) {
      toast({
        title: "Purchase Failed",
        description: "Failed to process AI purchase",
        variant: "destructive"
      });
    } finally {
      setProcessingPurchase(null);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="h-6 w-6 text-blue-500" />
            AI Automotive Purchasing Agent
            <Badge variant="outline" className="ml-2">AI Assistant Active</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="vehicles" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="vehicles">Available Vehicles</TabsTrigger>
          <TabsTrigger value="purchased">Purchase Orders</TabsTrigger>
          <TabsTrigger value="dealerships">Dealerships</TabsTrigger>
          <TabsTrigger value="contracts">Contracts</TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="vehicles">
          <div className="grid gap-4">
            {vehicles.map((vehicle) => (
              <Card key={vehicle.id} className="border-l-4 border-l-green-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <Badge variant="outline" className="text-green-600">{vehicle.type}</Badge>
                      <h4 className="font-semibold text-lg">{vehicle.name}</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />
                          {vehicle.price}
                        </div>
                        <div>Dealership: {vehicle.dealership}</div>
                        <div>Engine: {vehicle.engine}</div>
                        <div>Year: {vehicle.year}</div>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleAIPurchase(vehicle)}
                      disabled={processingPurchase === vehicle.id}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Zap className="h-4 w-4 mr-2" />
                      {processingPurchase === vehicle.id ? 'Processing...' : 'AI Purchase'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="purchased">
          <div className="space-y-4">
            <Card className="bg-orange-50 border-orange-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-700">
                  <ShoppingCart className="h-5 w-5" />
                  Purchase Orders & Shipping Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {purchasedOrders.map((order) => (
                  <Card key={order.id} className="mb-4">
                    <CardContent className="p-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-semibold">{order.vehicle}</h4>
                          <p className="text-sm text-gray-600">{order.description}</p>
                          <div className="mt-2 space-y-1 text-sm">
                            <div>Price: {order.price}</div>
                            <div>Order Date: {order.orderDate}</div>
                            <div>Status: <Badge variant="outline">{order.status}</Badge></div>
                          </div>
                        </div>
                        <div>
                          <h5 className="font-medium">Shipping Details</h5>
                          <p className="text-sm text-gray-600">{order.shippingDetails}</p>
                          <div className="mt-2 space-y-1 text-sm">
                            <div>Tracking: {order.trackingNumber}</div>
                            <div>Est. Delivery: {order.estimatedDelivery}</div>
                          </div>
                          <div className="flex gap-2 mt-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setSelectedOrder(order);
                                setTrackingModalOpen(true);
                              }}
                            >
                              <ExternalLink className="h-4 w-4 mr-1" />
                              Track Order
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setSelectedOrder(order);
                                setReceiptModalOpen(true);
                              }}
                            >
                              <Download className="h-4 w-4 mr-1" />
                              Receipt
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="dealerships">
          <div className="grid gap-4">
            {dealerships.map((dealership, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-semibold">{dealership.name}</h4>
                      <p className="text-sm text-gray-600">Website: {dealership.website}</p>
                      <p className="text-sm">Specialty: {dealership.specialty}</p>
                    </div>
                    <div className="flex gap-2">
                      <Badge className="bg-green-600">{dealership.status}</Badge>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => window.open(`https://${dealership.website}`, '_blank')}
                      >
                        <ExternalLink className="h-4 w-4 mr-1" />
                        Visit Site
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contracts">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>AI Generated Contracts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {purchasedOrders.map((order) => (
                    <Card key={order.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold">{order.vehicle}</h4>
                            <div className="text-sm text-gray-600 space-y-1">
                              <div>Contract ID: {order.transactionId}</div>
                              <div>Price: {order.price}</div>
                              <div>Account Debited: PNC Business Account</div>
                              <div>Delivery Service: {order.deliveryService}</div>
                            </div>
                          </div>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              setSelectedOrder(order);
                              setContractModalOpen(true);
                            }}
                          >
                            <FileText className="h-4 w-4 mr-1" />
                            View Contract
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>


        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Super Admin Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Purchase Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div>Total Orders: 2</div>
                    <div>Total Value: $250,000</div>
                    <div>Active Deliveries: 1</div>
                    <div>Completed: 1</div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Contract Details</h4>
                  <div className="space-y-2 text-sm">
                    <div>Owner: Alucius Alford</div>
                    <div>Company: Alazie LLC</div>
                    <div>Email: alaziellc.innovation@gmail.com</div>
                    <div>Address: 2408 Yanceyville St. Greensboro N.C.</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Auto-Purchase Enabled</span>
                  <Badge className="bg-green-600">Active</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Email Notifications</span>
                  <Badge className="bg-green-600">alaziellc.innovation@gmail.com</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Contract Owner</span>
                  <Badge variant="outline">Alucius Alford</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {selectedOrder && (
        <>
          <TrackingModal
            isOpen={trackingModalOpen}
            onClose={() => setTrackingModalOpen(false)}
            order={selectedOrder}
          />
          <ReceiptModal
            isOpen={receiptModalOpen}
            onClose={() => setReceiptModalOpen(false)}
            order={selectedOrder}
          />
          <ContractDetailsModal
            isOpen={contractModalOpen}
            onClose={() => setContractModalOpen(false)}
            contract={selectedOrder}
          />
        </>
      )}
    </div>
  );
}