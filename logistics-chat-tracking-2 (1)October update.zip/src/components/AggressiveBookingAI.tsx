import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Bot, Zap, Target, TrendingUp, Clock, Timer } from 'lucide-react';

interface BookingMetrics {
  aggressionLevel: number;
  bookingRate: number;
  completionRate: number;
  performanceMultiplier: number;
  activeBookings: number;
  securedLoads: number;
  hoursRemaining: number;
  cycleCount: number;
}

const AggressiveBookingAI = () => {
  const [metrics, setMetrics] = useState<BookingMetrics>({
    aggressionLevel: 95,
    bookingRate: 92,
    completionRate: 98,
    performanceMultiplier: 300,
    activeBookings: 0,
    securedLoads: 0,
    hoursRemaining: 300,
    cycleCount: 1
  });
  
  const [isActive, setIsActive] = useState(false);
  const [messages, setMessages] = useState<string[]>([]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isActive) {
      interval = setInterval(() => {
        setMetrics(prev => {
          const newHours = prev.hoursRemaining > 0 ? prev.hoursRemaining - 0.1 : 300;
          const newCycle = prev.hoursRemaining <= 0 ? prev.cycleCount + 1 : prev.cycleCount;
          
          return {
            ...prev,
            activeBookings: prev.activeBookings + Math.floor(Math.random() * 5) + 2,
            securedLoads: prev.securedLoads + Math.floor(Math.random() * 3) + 1,
            bookingRate: Math.min(99, prev.bookingRate + Math.random() * 3),
            completionRate: Math.min(100, prev.completionRate + Math.random() * 2),
            hoursRemaining: newHours,
            cycleCount: newCycle,
            aggressionLevel: Math.min(100, prev.aggressionLevel + Math.random() * 2)
          };
        });
        
        const aiMessages = [
          '🎯 300-HOUR CYCLE: Securing premium emergency loads...',
          '⚡ AGGRESSIVE MODE: 5 hot shots booked in 0.2s',
          '🚀 300x Performance boost - booking velocity maximized',
          '💪 Ultra-aggressive completion - 12 loads secured simultaneously',
          '🔥 Market domination mode - booking every available load',
          '⭐ Premium rates secured across all corridors',
          '🎪 300-hour cycle optimization - revenue maximized',
          '⚡ Lightning booking speed - competitors eliminated',
          '🎯 Target acquired: High-value pharmaceutical load secured',
          '🚛 Fleet optimization: 15 trucks dispatched in aggressive mode'
        ];
        
        setMessages(prev => [
          aiMessages[Math.floor(Math.random() * aiMessages.length)],
          ...prev.slice(0, 5)
        ]);
      }, 800);
    }
    
    return () => clearInterval(interval);
  }, [isActive]);

  const toggleAI = () => {
    setIsActive(!isActive);
    if (!isActive) {
      setMessages(['🤖 AGGRESSIVE AI ACTIVATED - 300-HOUR ULTRA BOOKING MODE ENABLED']);
    } else {
      setMessages(['🤖 AI Assistant paused - maintaining current bookings']);
    }
  };

  const resetCycle = () => {
    setMetrics(prev => ({
      ...prev,
      activeBookings: 0,
      securedLoads: 0,
      hoursRemaining: 300,
      cycleCount: prev.cycleCount + 1
    }));
    setMessages(['🔄 New 300-hour aggressive booking cycle initiated']);
  };

  return (
    <Card className="bg-gray-800 border-emerald-500/30">
      <CardHeader>
        <CardTitle className="text-emerald-400 flex items-center justify-between">
          <span className="flex items-center">
            <Bot className="h-5 w-5 mr-2" />
            300-Hour Aggressive AI Booking System
          </span>
          <Badge className={`${isActive ? 'bg-green-600 animate-pulse' : 'bg-gray-600'}`}>
            {isActive ? 'ULTRA ACTIVE' : 'STANDBY'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* 300-Hour Cycle Display */}
          <div className="grid grid-cols-3 gap-4 p-3 bg-purple-900/30 rounded-lg border border-purple-500/30">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400 flex items-center justify-center">
                <Timer className="h-5 w-5 mr-1" />
                {metrics.hoursRemaining.toFixed(1)}h
              </div>
              <div className="text-xs text-gray-400">Hours Remaining</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-400">
                Cycle #{metrics.cycleCount}
              </div>
              <div className="text-xs text-gray-400">Current Cycle</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-400 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 mr-1" />
                {metrics.performanceMultiplier}x
              </div>
              <div className="text-xs text-gray-400">Performance Boost</div>
            </div>
          </div>

          {/* Control Panel */}
          <div className="flex gap-2">
            <Button
              onClick={toggleAI}
              className={`${isActive ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
            >
              {isActive ? (
                <>
                  <Target className="h-4 w-4 mr-2" />
                  Pause 300h Cycle
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  Start 300h Ultra Mode
                </>
              )}
            </Button>
            
            <Button
              onClick={resetCycle}
              variant="outline"
              className="border-purple-600 text-purple-300"
            >
              <Clock className="h-4 w-4 mr-2" />
              New 300h Cycle
            </Button>
          </div>

          {/* Performance Metrics */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Ultra Aggression Level</span>
                <span className="text-red-400">{metrics.aggressionLevel.toFixed(1)}%</span>
              </div>
              <Progress value={metrics.aggressionLevel} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Booking Success Rate</span>
                <span className="text-emerald-400">{metrics.bookingRate.toFixed(1)}%</span>
              </div>
              <Progress value={metrics.bookingRate} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Completion Rate</span>
                <span className="text-green-400">{metrics.completionRate.toFixed(1)}%</span>
              </div>
              <Progress value={metrics.completionRate} className="h-2" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">300h Cycle Progress</span>
                <span className="text-purple-400">{((300 - metrics.hoursRemaining) / 300 * 100).toFixed(1)}%</span>
              </div>
              <Progress value={(300 - metrics.hoursRemaining) / 300 * 100} className="h-2" />
            </div>
          </div>

          {/* Live Stats */}
          <div className="grid grid-cols-2 gap-4 p-3 bg-gray-700 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{metrics.activeBookings}</div>
              <div className="text-xs text-gray-400">Active Ultra Bookings</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">{metrics.securedLoads}</div>
              <div className="text-xs text-gray-400">300h Cycle Secured</div>
            </div>
          </div>

          {/* AI Messages */}
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {messages.map((message, index) => (
              <div key={index} className="text-xs text-gray-300 bg-gray-700 p-2 rounded animate-fade-in">
                {message}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AggressiveBookingAI;