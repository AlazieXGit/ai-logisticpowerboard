import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Building2, DollarSign, Send, ArrowRight, Shield, 
  Clock, CheckCircle, AlertTriangle 
} from 'lucide-react';
import LiveClock from './LiveClock';

const FundDistributionAccess: React.FC = () => {
  const [selectedAccount, setSelectedAccount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [loading, setLoading] = useState(false);

  const distributionAccounts = [
    {
      id: 'wells-fargo-business',
      name: 'Wells Fargo Business',
      account: '****7892',
      routing: '121000248',
      balance: '$45,230.75',
      status: 'Active'
    },
    {
      id: 'alazie-trust',
      name: 'Alazie Trust Account',
      account: '****5678',
      routing: 'TRUST-001',
      balance: '$128,450.25',
      status: 'Active'
    },
    {
      id: 'revenue-pool',
      name: 'Revenue Distribution Pool',
      account: '****9012',
      routing: 'REV-POOL',
      balance: '$67,890.50',
      status: 'Active'
    }
  ];

  const recentDistributions = [
    {
      id: 'DIST-001',
      date: '2025-01-15',
      time: '14:30:22',
      amount: '$2,450.00',
      recipient: 'Vendor Payment - Load #12345',
      status: 'Completed'
    },
    {
      id: 'DIST-002',
      date: '2025-01-15',
      time: '13:45:11',
      amount: '$1,875.50',
      recipient: 'Carrier Payout - Route ABC',
      status: 'Completed'
    },
    {
      id: 'DIST-003',
      date: '2025-01-15',
      time: '12:15:33',
      amount: '$950.25',
      recipient: 'Administrative Transfer',
      status: 'Pending'
    }
  ];

  const handleDistribution = async () => {
    if (!selectedAccount || !transferAmount || !recipient) return;
    
    setLoading(true);
    // Simulate fund distribution process
    setTimeout(() => {
      setLoading(false);
      setTransferAmount('');
      setRecipient('');
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <LiveClock />
      </div>
      
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            AI ALAZIE XPRESS - Fund Distribution Access
          </CardTitle>
          <Badge className="bg-green-600 w-fit">SUPER ADMIN AUTHORIZED</Badge>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert className="border-green-500 bg-green-900/20">
            <Shield className="h-4 w-4" />
            <AlertDescription className="text-green-300">
              Fund Distribution Portal Active - Full Control Granted
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {distributionAccounts.map((account) => (
              <Card 
                key={account.id} 
                className={`cursor-pointer transition-all ${
                  selectedAccount === account.id 
                    ? 'bg-blue-900/40 border-blue-400' 
                    : 'bg-gray-800/30 border-gray-600'
                }`}
                onClick={() => setSelectedAccount(account.id)}
              >
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h3 className="text-white font-medium">{account.name}</h3>
                    <p className="text-gray-300 text-sm">Account: {account.account}</p>
                    <p className="text-gray-300 text-sm">Routing: {account.routing}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-green-400 font-bold">{account.balance}</span>
                      <Badge className="bg-green-600">{account.status}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {selectedAccount && (
            <Card className="bg-gray-800/30 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Send className="h-5 w-5" />
                  Fund Distribution Controls
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount" className="text-white">Distribution Amount</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Enter amount"
                      value={transferAmount}
                      onChange={(e) => setTransferAmount(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="recipient" className="text-white">Recipient/Purpose</Label>
                    <Input
                      id="recipient"
                      placeholder="Enter recipient details"
                      value={recipient}
                      onChange={(e) => setRecipient(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>
                <Button
                  onClick={handleDistribution}
                  disabled={loading || !transferAmount || !recipient}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  {loading ? 'Processing Distribution...' : 'Execute Fund Distribution'}
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          )}

          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Fund Distributions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentDistributions.map((dist) => (
                  <div key={dist.id} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {dist.status === 'Completed' ? (
                        <CheckCircle className="h-5 w-5 text-green-400" />
                      ) : (
                        <AlertTriangle className="h-5 w-5 text-yellow-400" />
                      )}
                      <div>
                        <p className="text-white font-medium">{dist.recipient}</p>
                        <p className="text-gray-400 text-sm">{dist.date} at {dist.time}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-green-400 font-bold">{dist.amount}</p>
                      <Badge className={dist.status === 'Completed' ? 'bg-green-600' : 'bg-yellow-600'}>
                        {dist.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
};

export default FundDistributionAccess;