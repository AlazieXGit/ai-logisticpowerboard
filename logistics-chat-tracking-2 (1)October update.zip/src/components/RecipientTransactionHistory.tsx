import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Search, Download, Filter, DollarSign, Calendar, MapPin } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Transaction {
  id: string;
  amount: number;
  type: string;
  status: string;
  date: string;
  description: string;
  route?: string;
  reference?: string;
}

interface Recipient {
  id: string;
  name: string;
  type: 'employee' | 'contractor' | 'vendor';
  email: string;
  accountNumber: string;
  routingNumber: string;
  status: string;
}

const SAMPLE_RECIPIENTS: Recipient[] = [
  {
    id: '1',
    name: 'John Smith',
    type: 'employee',
    email: 'john@company.com',
    accountNumber: '****1234',
    routingNumber: '021000021',
    status: 'active'
  },
  {
    id: '2',
    name: 'Jane Contractor',
    type: 'contractor',
    email: 'jane@contractor.com',
    accountNumber: '****5678',
    routingNumber: '021000022',
    status: 'active'
  },
  {
    id: '3',
    name: 'ABC Vendor Corp',
    type: 'vendor',
    email: 'billing@abcvendor.com',
    accountNumber: '****9012',
    routingNumber: '021000023',
    status: 'active'
  }
];

const RecipientTransactionHistory: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRecipient, setSelectedRecipient] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');

  useEffect(() => {
    loadTransactions();
  }, [selectedRecipient, selectedType]);

  const loadTransactions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'get_recipient_transactions',
          recipientId: selectedRecipient !== 'all' ? selectedRecipient : undefined,
          recipientType: selectedType !== 'all' ? selectedType : undefined
        }
      });

      if (error) throw error;
      setTransactions(data?.transactions || generateSampleTransactions());
    } catch (error) {
      console.error('Error loading transactions:', error);
      setTransactions(generateSampleTransactions());
    } finally {
      setLoading(false);
    }
  };

  const generateSampleTransactions = (): Transaction[] => {
    const sampleTransactions: Transaction[] = [];
    const types = ['direct_deposit', 'contractor_payment', 'vendor_payment', 'expense_reimbursement'];
    const statuses = ['completed', 'pending', 'processing'];
    const routes = ['ACH', 'Wire', 'Check', 'Card'];

    SAMPLE_RECIPIENTS.forEach((recipient, recipientIndex) => {
      for (let i = 0; i < 5; i++) {
        sampleTransactions.push({
          id: `txn_${recipientIndex}_${i}`,
          amount: Math.floor(Math.random() * 5000) + 100,
          type: types[Math.floor(Math.random() * types.length)],
          status: statuses[Math.floor(Math.random() * statuses.length)],
          date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
          description: `Payment to ${recipient.name}`,
          route: routes[Math.floor(Math.random() * routes.length)],
          reference: `REF${Math.random().toString(36).substr(2, 9).toUpperCase()}`
        });
      }
    });

    return sampleTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.reference?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'pending': return 'bg-yellow-500';
      case 'processing': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'employee': return 'bg-blue-500';
      case 'contractor': return 'bg-purple-500';
      case 'vendor': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Transaction History & Routes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-700">
              <TabsTrigger value="all" onClick={() => setSelectedType('all')}>All Recipients</TabsTrigger>
              <TabsTrigger value="employee" onClick={() => setSelectedType('employee')}>Employees</TabsTrigger>
              <TabsTrigger value="contractor" onClick={() => setSelectedType('contractor')}>Contractors</TabsTrigger>
              <TabsTrigger value="vendor" onClick={() => setSelectedType('vendor')}>Vendors</TabsTrigger>
            </TabsList>

            <div className="mt-4 space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search transactions..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <Button variant="outline" className="border-emerald-500 text-emerald-400">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
                <Button variant="outline" className="border-emerald-500 text-emerald-400">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {SAMPLE_RECIPIENTS.map((recipient) => (
                  <Card key={recipient.id} className="bg-gray-700 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-white">{recipient.name}</h3>
                        <Badge className={getTypeColor(recipient.type)}>
                          {recipient.type}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-300 space-y-1">
                        <div>{recipient.email}</div>
                        <div>{recipient.accountNumber} • {recipient.routingNumber}</div>
                        <div className="flex items-center gap-2">
                          <Badge variant={recipient.status === 'active' ? 'default' : 'secondary'}>
                            {recipient.status}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <TabsContent value="all" className="mt-0">
                <div className="rounded-md border border-gray-600">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-600">
                        <TableHead className="text-emerald-400">Date</TableHead>
                        <TableHead className="text-emerald-400">Description</TableHead>
                        <TableHead className="text-emerald-400">Amount</TableHead>
                        <TableHead className="text-emerald-400">Route</TableHead>
                        <TableHead className="text-emerald-400">Status</TableHead>
                        <TableHead className="text-emerald-400">Reference</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTransactions.map((transaction) => (
                        <TableRow key={transaction.id} className="border-gray-600">
                          <TableCell className="text-white">
                            {new Date(transaction.date).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-white">{transaction.description}</TableCell>
                          <TableCell className="text-emerald-400 font-semibold">
                            ${transaction.amount.toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="border-blue-500 text-blue-400">
                              <MapPin className="h-3 w-3 mr-1" />
                              {transaction.route}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(transaction.status)}>
                              {transaction.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-gray-300">{transaction.reference}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default RecipientTransactionHistory;