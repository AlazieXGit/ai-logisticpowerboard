import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ShoppingCart, Eye, Star, DollarSign } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  category: string;
  price: string;
  description: string;
  inStock: boolean;
  rating: number;
  image?: string;
}

interface VendorCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  vendor: any;
  onPlaceOrder: (product: Product) => void;
}

const VendorCatalogModal: React.FC<VendorCatalogModalProps> = ({
  isOpen,
  onClose,
  vendor,
  onPlaceOrder
}) => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const products: Product[] = [
    {
      id: 'H001',
      name: 'Assembly Line Humanoid Robot',
      category: 'Humanoid Robots',
      price: '$125,000',
      description: 'Advanced humanoid robot for automotive assembly with precision welding and parts installation',
      inStock: true,
      rating: 4.9
    },
    {
      id: 'H002',
      name: 'Quality Control Inspector Bot',
      category: 'Humanoid Robots', 
      price: '$98,000',
      description: 'AI-powered humanoid for visual inspection and quality assurance testing',
      inStock: true,
      rating: 4.8
    },
    {
      id: 'H003',
      name: 'Paint Shop Humanoid Assistant',
      category: 'Humanoid Robots',
      price: '$110,000',
      description: 'Specialized humanoid robot for automotive painting and surface finishing',
      inStock: false,
      rating: 4.7
    },
    {
      id: 'H004',
      name: 'Engine Assembly Specialist',
      category: 'Humanoid Robots',
      price: '$135,000',
      description: 'Heavy-duty humanoid robot for engine block assembly and transmission work',
      inStock: true,
      rating: 4.9
    },
    {
      id: 'H005',
      name: 'Interior Installation Bot',
      category: 'Humanoid Robots',
      price: '$89,000',
      description: 'Precision humanoid for dashboard, seat, and interior component installation',
      inStock: true,
      rating: 4.6
    },
    {
      id: 'H006',
      name: 'Maintenance & Repair Humanoid',
      category: 'Humanoid Robots',
      price: '$115,000',
      description: 'Multi-tool equipped humanoid for vehicle maintenance and repair operations',
      inStock: true,
      rating: 4.8
    },
    {
      id: 'P001',
      name: 'AI Autopilot System V3',
      category: 'AI Systems',
      price: '$45,000',
      description: 'Advanced neural network autopilot with real-time learning',
      inStock: true,
      rating: 4.9
    },
    {
      id: 'P002', 
      name: 'Neural Network Processor',
      category: 'Processors',
      price: '$12,500',
      description: 'High-performance AI processing unit',
      inStock: true,
      rating: 4.8
    },
    {
      id: 'P003',
      name: 'Robotic Sensor Array',
      category: 'Sensors',
      price: '$8,750',
      description: 'Multi-spectrum sensor array for robotics',
      inStock: false,
      rating: 4.7
    },
    {
      id: 'P004',
      name: 'AI Camera System',
      category: 'Cameras',
      price: '$3,200',
      description: 'Smart camera with AI object recognition',
      inStock: true,
      rating: 4.6
    }
  ];

  const categories = ['all', 'Humanoid Robots', 'AI Systems', 'Processors', 'Sensors', 'Cameras'];
  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-gray-900 text-white border-blue-500">
        <DialogHeader>
          <DialogTitle className="text-2xl text-blue-400">
            {vendor?.name} - Product Catalog
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex gap-2 flex-wrap">
            {categories.map((cat) => (
              <Button
                key={cat}
                size="sm"
                variant={selectedCategory === cat ? "default" : "outline"}
                onClick={() => setSelectedCategory(cat)}
                className="capitalize"
              >
                {cat}
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="bg-gray-800/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-white">{product.name}</h3>
                    <Badge className={product.inStock ? 'bg-green-600' : 'bg-red-600'}>
                      {product.inStock ? 'In Stock' : 'Out of Stock'}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-300">{product.rating}</span>
                    <Badge variant="outline" className="text-xs">
                      {product.category}
                    </Badge>
                  </div>
                  
                  <p className="text-gray-400 text-sm mb-3">{product.description}</p>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-green-400 font-bold flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {product.price}
                    </span>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="text-xs"
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        Details
                      </Button>
                      <Button 
                        size="sm" 
                        disabled={!product.inStock}
                        onClick={() => onPlaceOrder(product)}
                        className="bg-green-600 hover:bg-green-700 text-xs"
                      >
                        <ShoppingCart className="h-3 w-3 mr-1" />
                        Order
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VendorCatalogModal;