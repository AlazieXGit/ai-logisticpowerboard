import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Building2, TrendingUp, Users, Target, BarChart3 } from 'lucide-react';
import EnhancedExecutiveOverview from './EnhancedExecutiveOverview';
import EnhancedDepartmentMetrics from './EnhancedDepartmentMetrics';
import EnhancedResourceAllocation from './EnhancedResourceAllocation';
import EnhancedStrategicInitiatives from './EnhancedStrategicInitiatives';
const EnterpriseDashboard = () => {
  const [activeTab, setActiveTab] = useState('executive');
  const dashboardStats = [
    { title: 'Total Revenue', value: '$2.4M', change: '+12.5%', icon: TrendingUp },
    { title: 'Active Projects', value: '12', change: '+3', icon: Target },
    { title: 'Team Members', value: '156', change: '+8', icon: Users },
    { title: 'Departments', value: '6', change: '0', icon: Building2 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            AI ALAZIE XPRESS ENTERPRISE
          </h1>
          <h2 className="text-2xl font-semibold text-blue-600 mb-4">
            Enterprise Analytics Dashboard
          </h2>
          <p className="text-gray-600">
            Comprehensive data analytics and insights for strategic decision making
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {dashboardStats.map((stat, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    <p className="text-sm text-green-600">{stat.change}</p>
                  </div>
                  <stat.icon className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Dashboard Tabs */}
        <Card className="bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-6 w-6" />
              Enterprise Data Analytics Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 mb-6">
                <TabsTrigger value="executive" className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Executive Overview
                </TabsTrigger>
                <TabsTrigger value="departments" className="flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  Department Metrics
                </TabsTrigger>
                <TabsTrigger value="resources" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Resource Allocation
                </TabsTrigger>
                <TabsTrigger value="initiatives" className="flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Strategic Initiatives
                </TabsTrigger>
              </TabsList>

              <TabsContent value="executive" className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg mb-4">
                  <h3 className="font-semibold text-blue-900 mb-2">C-Level Insights</h3>
                  <p className="text-blue-700 text-sm">
                    Executive dashboard providing high-level KPIs, quarterly performance metrics, 
                    and strategic objective tracking for senior leadership decision making.
                  </p>
                </div>
                <EnhancedExecutiveOverview />
              </TabsContent>

              <TabsContent value="departments" className="space-y-4">
                <div className="bg-green-50 p-4 rounded-lg mb-4">
                  <h3 className="font-semibold text-green-900 mb-2">Cross-Functional KPIs</h3>
                  <p className="text-green-700 text-sm">
                    Department-level performance metrics, cross-functional KPIs, and operational 
                    efficiency indicators across all business units.
                  </p>
                </div>
                <EnhancedDepartmentMetrics />
              </TabsContent>

              <TabsContent value="resources" className="space-y-4">
                <div className="bg-purple-50 p-4 rounded-lg mb-4">
                  <h3 className="font-semibold text-purple-900 mb-2">Optimal Resource Distribution</h3>
                  <p className="text-purple-700 text-sm">
                    Budget allocation, human resource distribution, technology utilization, 
                    and optimization opportunities for maximum efficiency.
                  </p>
                </div>
                <EnhancedResourceAllocation />
              </TabsContent>

              <TabsContent value="initiatives" className="space-y-4">
                <div className="bg-orange-50 p-4 rounded-lg mb-4">
                  <h3 className="font-semibold text-orange-900 mb-2">Project Portfolio Management</h3>
                  <p className="text-orange-700 text-sm">
                    Strategic project tracking, portfolio performance, risk assessment, 
                    and initiative ROI analysis for strategic planning.
                  </p>
                </div>
                <EnhancedStrategicInitiatives />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EnterpriseDashboard;