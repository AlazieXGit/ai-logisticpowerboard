import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { suspendUserSchema, SuspendUserInput } from '@/lib/adminValidation';
import { adminOperationsService } from '@/services/adminOperationsService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

interface AdminUserSuspensionFormProps {
  adminId: string;
  adminEmail: string;
  onSuccess?: () => void;
}

export function AdminUserSuspensionForm({ adminId, adminEmail, onSuccess }: AdminUserSuspensionFormProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  
  const { register, handleSubmit, formState: { errors }, reset } = useForm<SuspendUserInput>({
    resolver: zodResolver(suspendUserSchema),
    defaultValues: { admin_id: adminId, admin_email: adminEmail }
  });

  const onSubmit = async (data: SuspendUserInput) => {
    setLoading(true);
    try {
      await adminOperationsService.suspendUser(data);
      toast({ title: 'Success', description: 'User suspended successfully' });
      reset();
      onSuccess?.();
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to suspend user', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="user_id">User ID</Label>
        <Input id="user_id" {...register('user_id')} placeholder="UUID" />
        {errors.user_id && <p className="text-red-500 text-sm">{errors.user_id.message}</p>}
      </div>
      
      <div>
        <Label htmlFor="user_email">User Email</Label>
        <Input id="user_email" type="email" {...register('user_email')} placeholder="user@example.com" />
        {errors.user_email && <p className="text-red-500 text-sm">{errors.user_email.message}</p>}
      </div>
      
      <div>
        <Label htmlFor="reason">Reason</Label>
        <Textarea id="reason" {...register('reason')} placeholder="Reason for suspension..." />
        {errors.reason && <p className="text-red-500 text-sm">{errors.reason.message}</p>}
      </div>
      
      <div>
        <Label htmlFor="expires_hours">Expires (hours, optional)</Label>
        <Input id="expires_hours" type="number" {...register('expires_hours', { valueAsNumber: true })} />
      </div>
      
      <Button type="submit" disabled={loading}>{loading ? 'Suspending...' : 'Suspend User'}</Button>
    </form>
  );
}
