import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, Database, Settings, Users, Shield, ExternalLink, CheckCircle } from 'lucide-react';

const BackOfficePlatformAccess: React.FC = () => {
  const [connectedSystems, setConnectedSystems] = useState({
    backOffice: false,
    platform: false,
    database: false,
    userManagement: false
  });

  const connectToSystem = (system: keyof typeof connectedSystems) => {
    setConnectedSystems(prev => ({ ...prev, [system]: true }));
  };

  const systems = [
    {
      id: 'backOffice',
      name: 'Back Office System',
      icon: Building2,
      url: 'https://backoffice.alaziel.com',
      description: 'Administrative back office operations',
      credentials: 'alaziellc.innovation@gmail.com / gotchu!!'
    },
    {
      id: 'platform',
      name: 'Main Platform',
      icon: Database,
      url: 'https://platform.alaziel.com',
      description: 'Core platform management system',
      credentials: 'alaziellc.innovation@gmail.com / gotchu!!'
    },
    {
      id: 'database',
      name: 'Database Admin',
      icon: Settings,
      url: 'https://db.alaziel.com',
      description: 'Direct database administration',
      credentials: 'Super Admin Access'
    },
    {
      id: 'userManagement',
      name: 'User Management',
      icon: Users,
      url: 'https://users.alaziel.com',
      description: 'User account management system',
      credentials: 'Full Administrative Access'
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Super Admin Platform Access
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {systems.map((system) => {
              const Icon = system.icon;
              const isConnected = connectedSystems[system.id as keyof typeof connectedSystems];
              
              return (
                <Card key={system.id} className="bg-gray-800/50 border-gray-600">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon className="h-5 w-5 text-blue-400" />
                        <h3 className="text-white font-semibold">{system.name}</h3>
                      </div>
                      {isConnected && (
                        <CheckCircle className="h-5 w-5 text-green-400" />
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-gray-300 text-sm">{system.description}</p>
                    <div className="text-xs text-gray-400">
                      <strong>Credentials:</strong> {system.credentials}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => connectToSystem(system.id as keyof typeof connectedSystems)}
                        disabled={isConnected}
                        className={isConnected ? 'bg-green-600' : 'bg-blue-600 hover:bg-blue-700'}
                      >
                        {isConnected ? 'Connected' : 'Connect'}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(system.url, '_blank')}
                        className="border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white"
                      >
                        <ExternalLink className="h-4 w-4 mr-1" />
                        Open
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="access-logs" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="access-logs">Access Logs</TabsTrigger>
          <TabsTrigger value="system-status">System Status</TabsTrigger>
          <TabsTrigger value="quick-actions">Quick Actions</TabsTrigger>
        </TabsList>
        
        <TabsContent value="access-logs" className="mt-4">
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Recent Access Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-gray-300">
                  <span>Back Office Login</span>
                  <Badge className="bg-green-600">Success</Badge>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Platform Database Access</span>
                  <Badge className="bg-green-600">Active</Badge>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>User Management Portal</span>
                  <Badge className="bg-blue-600">Connected</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="system-status" className="mt-4">
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">System Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">100%</div>
                  <div className="text-sm text-gray-300">Back Office Uptime</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">99.9%</div>
                  <div className="text-sm text-gray-300">Platform Availability</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="quick-actions" className="mt-4">
          <Card className="bg-gray-800/50 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Sync All Systems
                </Button>
                <Button className="bg-green-600 hover:bg-green-700">
                  Generate Access Report
                </Button>
                <Button className="bg-yellow-600 hover:bg-yellow-700">
                  Backup Configurations
                </Button>
                <Button className="bg-red-600 hover:bg-red-700">
                  Emergency Lockdown
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BackOfficePlatformAccess;