import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Code, Zap, Globe, Server, Cpu, Database, 
  Play, Pause, Square, Rocket, Settings, Key
} from 'lucide-react';
import APIManagementSystem from './APIManagementSystem';
import LiveClock from './LiveClock';

const DeveloperPlatformAccess: React.FC = () => {
  const [platformStatus, setPlatformStatus] = useState('active');
  const [aiInfrastructure, setAiInfrastructure] = useState('running');
  return (
    <div className="relative min-h-screen bg-gray-900">
      <LiveClock />
      
      <div className="space-y-6 p-6">
        <Alert className="border-lime-500 bg-lime-900/20">
          <Rocket className="h-4 w-4 text-lime-400" />
          <AlertDescription className="text-lime-300">
            🚀 Developer Platform - API Limited Access | Token-Based Authentication | Rate Limited
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="platform" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="platform">Development Platform</TabsTrigger>
            <TabsTrigger value="api">API Management</TabsTrigger>
          </TabsList>

          <TabsContent value="platform" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gray-800/30 border-lime-500">
                <CardHeader>
                  <CardTitle className="text-lime-400 flex items-center gap-2">
                    <Code className="h-5 w-5" />
                    Internal Development Platform
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Platform Status:</span>
                    <Badge className="bg-lime-600 text-white">API LIMITED</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Access Level:</span>
                    <Badge className="bg-orange-600 text-white">READ ONLY</Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="bg-lime-600 hover:bg-lime-700"
                      onClick={() => setPlatformStatus('active')}
                    >
                      <Play className="h-4 w-4 mr-1" />
                      Start
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => setPlatformStatus('paused')}
                    >
                      <Pause className="h-4 w-4 mr-1" />
                      Pause
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/30 border-lime-500">
                <CardHeader>
                  <CardTitle className="text-lime-400 flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    External Development Platform
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">External Access:</span>
                    <Badge className="bg-blue-600 text-white">TOKEN REQUIRED</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Rate Limits:</span>
                    <Badge className="bg-purple-600 text-white">ACTIVE</Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Key className="h-4 w-4 mr-1" />
                      Generate Token
                    </Button>
                    <Button 
                      size="sm" 
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Settings className="h-4 w-4 mr-1" />
                      Configure
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-800/30 border-lime-500">
              <CardHeader>
                <CardTitle className="text-lime-400">API Access Tiers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-orange-900/20 rounded-lg border border-orange-500/30">
                    <Key className="h-8 w-8 text-orange-400 mx-auto mb-2" />
                    <h3 className="text-orange-300 font-semibold">Read Only</h3>
                    <p className="text-gray-400 text-sm">Limited API access</p>
                  </div>
                  <div className="text-center p-4 bg-blue-900/20 rounded-lg border border-blue-500/30">
                    <Server className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                    <h3 className="text-blue-300 font-semibold">Rate Limited</h3>
                    <p className="text-gray-400 text-sm">1000 requests/hour</p>
                  </div>
                  <div className="text-center p-4 bg-purple-900/20 rounded-lg border border-purple-500/30">
                    <Database className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                    <h3 className="text-purple-300 font-semibold">Secure Access</h3>
                    <p className="text-gray-400 text-sm">Token authentication</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api" className="space-y-6">
            <APIManagementSystem />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default DeveloperPlatformAccess;