import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DollarSign, Calculator, TrendingUp, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface FeeStructure {
  id: string;
  serviceType: string;
  baseFee: number;
  percentageFee: number;
  minimumFee: number;
  maximumFee: number;
  isActive: boolean;
}

interface TransactionFee {
  transactionId: string;
  transactionCode: string;
  serviceType: string;
  transactionAmount: number;
  calculatedFee: number;
  feeBreakdown: {
    baseFee: number;
    percentageFee: number;
    processingFee: number;
    complianceFee: number;
  };
  status: 'pending' | 'approved' | 'accrued';
}

const FeeManagementSystem: React.FC = () => {
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>([]);
  const [transactionFees, setTransactionFees] = useState<TransactionFee[]>([]);
  const [selectedService, setSelectedService] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [calculatedFee, setCalculatedFee] = useState<number | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadFeeStructures();
    loadTransactionFees();
  }, []);

  const loadFeeStructures = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_fee_structures' }
      });
      if (!error && data?.feeStructures) {
        setFeeStructures(data.feeStructures);
      }
    } catch (error) {
      console.log('Failed to load fee structures');
    }
  };

  const loadTransactionFees = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_transaction_fees' }
      });
      if (!error && data?.fees) {
        setTransactionFees(data.fees);
      }
    } catch (error) {
      console.log('Failed to load transaction fees');
    }
  };

  const calculateFee = async () => {
    if (!selectedService || !transactionAmount) {
      toast({
        title: 'Missing Information',
        description: 'Please select service type and enter transaction amount',
        variant: 'destructive'
      });
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'calculate_transaction_fee',
          serviceType: selectedService,
          transactionAmount: parseFloat(transactionAmount)
        }
      });

      if (error) throw error;

      setCalculatedFee(data.totalFee);
      toast({
        title: 'Fee Calculated',
        description: `Total fee: $${data.totalFee.toFixed(2)}`,
        variant: 'default'
      });
    } catch (error) {
      toast({
        title: 'Calculation Failed',
        description: 'Could not calculate transaction fee',
        variant: 'destructive'
      });
    }
  };

  const processTransactionFee = async (transactionCode: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'process_transaction_fee',
          transactionCode,
          serviceType: selectedService,
          transactionAmount: parseFloat(transactionAmount)
        }
      });

      if (error) throw error;

      toast({
        title: 'Fee Processed',
        description: `Fee accrued for transaction ${transactionCode}`,
        variant: 'default'
      });

      loadTransactionFees();
    } catch (error) {
      toast({
        title: 'Processing Failed',
        description: 'Could not process transaction fee',
        variant: 'destructive'
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-600';
      case 'approved': return 'bg-blue-600';
      case 'accrued': return 'bg-green-600';
      default: return 'bg-gray-600';
    }
  };

  const totalAccruedFees = transactionFees
    .filter(fee => fee.status === 'accrued')
    .reduce((sum, fee) => sum + fee.calculatedFee, 0);

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Fee Management System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-emerald-300">Service Type</Label>
              <Select value={selectedService} onValueChange={setSelectedService}>
                <SelectTrigger className="bg-gray-700 border-emerald-500/30 text-white">
                  <SelectValue placeholder="Select service" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="escrow">Escrow Services</SelectItem>
                  <SelectItem value="trust">Trust Management</SelectItem>
                  <SelectItem value="transfer">Account Transfer</SelectItem>
                  <SelectItem value="processing">Payment Processing</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-emerald-300">Transaction Amount</Label>
              <Input
                type="number"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
                className="bg-gray-700 border-emerald-500/30 text-white"
                placeholder="0.00"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={calculateFee}
                className="bg-emerald-600 hover:bg-emerald-700 w-full"
              >
                <Calculator className="h-4 w-4 mr-2" />
                Calculate Fee
              </Button>
            </div>
          </div>

          {calculatedFee !== null && (
            <div className="p-4 bg-emerald-900/20 border border-emerald-500/30 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-emerald-400" />
                <span className="text-emerald-300 font-semibold">Calculated Fee</span>
              </div>
              <div className="text-2xl font-bold text-emerald-400">
                ${calculatedFee.toFixed(2)}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center justify-between">
            <span>Transaction Fees</span>
            <Badge className="bg-emerald-600">
              Total Accrued: ${totalAccruedFees.toFixed(2)}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {transactionFees.map((fee) => (
              <div key={fee.transactionId} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-emerald-400">{fee.transactionCode}</span>
                  <Badge className={getStatusColor(fee.status)}>
                    {fee.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-gray-300">Amount: ${fee.transactionAmount.toFixed(2)}</span>
                  <span className="text-emerald-400 font-semibold">
                    Fee: ${fee.calculatedFee.toFixed(2)}
                  </span>
                  {fee.status === 'pending' && (
                    <Button
                      size="sm"
                      onClick={() => processTransactionFee(fee.transactionCode)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Process
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FeeManagementSystem;