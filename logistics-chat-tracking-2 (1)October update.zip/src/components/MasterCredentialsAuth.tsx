import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Lock, Eye, EyeOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface MasterCredentialsAuthProps {
  onAuthenticated: () => void;
}

const MasterCredentialsAuth: React.FC<MasterCredentialsAuthProps> = ({ onAuthenticated }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pin, setPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Updated Super Admin credentials
  const MASTER_EMAIL = 'alaziellc.innovation@gmail.com';
  const MASTER_PASSWORD = 'gotchu!!';
  const MASTER_PIN = '19762020';

  const handleLogin = async () => {
    if (!email || !password || !pin) {
      toast({ title: 'Error', description: 'Please enter email, password, and PIN', variant: 'destructive' });
      return;
    }

    setIsLoading(true);
    
    // Simulate authentication delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (email === MASTER_EMAIL && password === MASTER_PASSWORD && pin === MASTER_PIN) {
      toast({ title: 'Success', description: 'Master Credentials Access Granted', className: 'bg-emerald-600' });
      onAuthenticated();
    } else {
      toast({ title: 'Access Denied', description: 'Invalid master credentials or PIN', variant: 'destructive' });
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-gray-900 to-black flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-800 border-red-500/50">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-red-600/20 rounded-full">
              <Shield className="h-8 w-8 text-red-400" />
            </div>
          </div>
          <CardTitle className="text-2xl text-red-400">MASTER CREDENTIALS</CardTitle>
          <p className="text-gray-300 text-sm">Super Admin Alucius Alford Only</p>
          <p className="text-xs text-red-300 mt-1">alaziellc.innovation@gmail.com</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-red-300">Master Email</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="alaziellc.innovation@gmail.com"
              className="bg-gray-700 border-red-500/30 text-white"
            />
          </div>
          
          <div className="space-y-2">
            <Label className="text-red-300">Master Password</Label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter master password"
                className="bg-gray-700 border-red-500/30 text-white pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-white"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-red-300">Security PIN #19762020</Label>
            <div className="relative">
              <Input
                type={showPin ? 'text' : 'password'}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="Enter PIN #19762020"
                className="bg-gray-700 border-red-500/30 text-white pr-10"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-white"
                onClick={() => setShowPin(!showPin)}
              >
                {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <Button 
            onClick={handleLogin}
            disabled={isLoading || !email || !password || !pin}
            className="w-full bg-red-600 hover:bg-red-700 text-white"
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Authenticating...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Access Master Credentials
              </div>
            )}
          </Button>

          <div className="text-center text-xs text-gray-400 mt-4">
            <p>🔒 RESTRICTED ACCESS</p>
            <p>Super Admin alaziellc.innovation@gmail.com Only</p>
            <p>PIN Authentication Required</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MasterCredentialsAuth;