import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { 
  FileText, Download, Calendar, 
  TrendingUp, DollarSign, Activity 
} from 'lucide-react';

const ComprehensiveDataPrintouts: React.FC = () => {
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const generateReport = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('synergy-payment-routing', {
        body: { action: 'get-combined-total' }
      });
      
      // Enhanced report data
      const enhancedData = {
        ...data,
        dailySummary: {
          date: new Date().toLocaleDateString(),
          totalRevenue: 125000.50,
          totalExpenses: 15000.25,
          netProfit: 110000.25,
          transactionCount: 1250,
          averageTransaction: 100.00
        },
        platformMetrics: {
          tms: { revenue: 75000, transactions: 450, avgValue: 166.67 },
          banking: { revenue: 85000, transactions: 320, avgValue: 265.63 },
          loadBoard: { revenue: 45000, transactions: 280, avgValue: 160.71 },
          aiServices: { revenue: 35000, transactions: 150, avgValue: 233.33 },
          creditRepair: { revenue: 10000, transactions: 50, avgValue: 200.00 }
        }
      };
      
      setReportData(enhancedData);
    } catch (error) {
      console.error('Error generating report:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    generateReport();
  }, []);

  const exportReport = (format: string) => {
    console.log(`Exporting report in ${format} format`);
    // Implementation for export functionality
  };

  if (!reportData) return <div>Loading comprehensive data...</div>;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/20 to-green-900/20 border-blue-500">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl text-blue-400 flex items-center gap-2">
                <FileText className="h-6 w-6" />
                Complete Data Printouts
              </CardTitle>
              <p className="text-gray-300">Comprehensive daily analytics & reporting</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => exportReport('pdf')} className="bg-red-600">
                <Download className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
              <Button onClick={() => exportReport('excel')} className="bg-green-600">
                <Download className="h-4 w-4 mr-2" />
                Export Excel
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="daily-summary" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="daily-summary">Daily Summary</TabsTrigger>
          <TabsTrigger value="platform-analytics">Platform Analytics</TabsTrigger>
          <TabsTrigger value="account-standings">Account Standings</TabsTrigger>
          <TabsTrigger value="fees-charges">Fees & Charges</TabsTrigger>
          <TabsTrigger value="comprehensive-overview">Complete Overview</TabsTrigger>
        </TabsList>

        <TabsContent value="daily-summary" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-green-900/20 border-green-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-400 text-sm">Total Revenue</p>
                    <p className="text-2xl font-bold text-white">
                      ${reportData.dailySummary.totalRevenue.toLocaleString()}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-red-900/20 border-red-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-red-400 text-sm">Total Expenses</p>
                    <p className="text-2xl font-bold text-white">
                      ${reportData.dailySummary.totalExpenses.toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-red-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-900/20 border-blue-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-400 text-sm">Net Profit</p>
                    <p className="text-2xl font-bold text-white">
                      ${reportData.dailySummary.netProfit.toLocaleString()}
                    </p>
                  </div>
                  <Activity className="h-8 w-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Daily Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Transaction Count:</span>
                    <span className="text-white font-semibold">
                      {reportData.dailySummary.transactionCount.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Average Transaction:</span>
                    <span className="text-white font-semibold">
                      ${reportData.dailySummary.averageTransaction.toFixed(2)}
                    </span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Report Date:</span>
                    <span className="text-white font-semibold">
                      {reportData.dailySummary.date}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Status:</span>
                    <Badge className="bg-green-600">ACTIVE</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="platform-analytics" className="space-y-4">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Platform Performance Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(reportData.platformMetrics).map(([platform, metrics]: [string, any]) => (
                  <div key={platform} className="p-4 bg-gray-700/30 rounded border border-gray-600">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-white font-semibold capitalize">
                        {platform.replace(/([A-Z])/g, ' $1').trim()}
                      </h4>
                      <Badge className="bg-blue-600">
                        {metrics.transactions} transactions
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-gray-400 text-sm">Revenue</p>
                        <p className="text-green-400 font-bold">
                          ${metrics.revenue.toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Transactions</p>
                        <p className="text-blue-400 font-bold">
                          {metrics.transactions}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Avg Value</p>
                        <p className="text-purple-400 font-bold">
                          ${metrics.avgValue.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account-standings" className="space-y-4">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Complete Account Standings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(reportData.bankingAccounts).map(([type, account]: [string, any]) => (
                  <div key={type} className="p-4 bg-gray-700/30 rounded border border-gray-600">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="text-white font-semibold capitalize">{type} Account</h4>
                        <p className="text-gray-400 text-sm">Routing: {account.routing}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 text-2xl font-bold">
                          ${account.balance.toLocaleString()}
                        </p>
                        <Badge className="bg-green-600 mt-1">ACTIVE</Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comprehensive-overview" className="space-y-4">
          <Card className="bg-gray-800/30 border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Complete System Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 bg-blue-900/20 border border-blue-500 rounded">
                  <h4 className="text-blue-400 font-semibold mb-2">System Status</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-300">All Platforms: <Badge className="ml-2 bg-green-600">OPERATIONAL</Badge></p>
                      <p className="text-gray-300">Payment Routing: <Badge className="ml-2 bg-green-600">ACTIVE</Badge></p>
                    </div>
                    <div>
                      <p className="text-gray-300">AI Services: <Badge className="ml-2 bg-green-600">RUNNING</Badge></p>
                      <p className="text-gray-300">Data Sync: <Badge className="ml-2 bg-green-600">SYNCED</Badge></p>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={generateReport} 
                  disabled={loading}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {loading ? 'Generating...' : 'Refresh Complete Report'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ComprehensiveDataPrintouts;