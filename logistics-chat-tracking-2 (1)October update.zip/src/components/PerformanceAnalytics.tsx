import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Activity, Zap, TrendingUp, Database, RefreshCw } from 'lucide-react';

interface PerformanceMetrics {
  responseTime: number;
  throughput: number;
  errorRate: number;
  uptime: number;
  activeUsers: number;
  revenuePerMinute: number;
}

const PerformanceAnalytics: React.FC = () => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    responseTime: 0,
    throughput: 0,
    errorRate: 0,
    uptime: 0,
    activeUsers: 0,
    revenuePerMinute: 0
  });
  const [isOptimizing, setIsOptimizing] = useState(false);

  useEffect(() => {
    const interval = setInterval(updateMetrics, 5000);
    updateMetrics();
    return () => clearInterval(interval);
  }, []);

  const updateMetrics = () => {
    setMetrics({
      responseTime: Math.random() * 100 + 50,
      throughput: Math.random() * 1000 + 500,
      errorRate: Math.random() * 2,
      uptime: 99.8 + Math.random() * 0.2,
      activeUsers: Math.floor(Math.random() * 100) + 50,
      revenuePerMinute: Math.random() * 500 + 200
    });
  };

  const optimizePerformance = async () => {
    setIsOptimizing(true);
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsOptimizing(false);
    updateMetrics();
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Activity className="h-5 w-5" />
            PERFORMANCE ANALYTICS & OPTIMIZATION
            <Badge className="bg-green-600 animate-pulse">LIVE</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">
                {metrics.responseTime.toFixed(0)}ms
              </div>
              <div className="text-sm text-gray-300">Response Time</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">
                {metrics.throughput.toFixed(0)}
              </div>
              <div className="text-sm text-gray-300">Requests/min</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">
                {metrics.uptime.toFixed(2)}%
              </div>
              <div className="text-sm text-gray-300">Uptime</div>
            </div>
          </div>
          
          <div className="mt-6 flex justify-center">
            <Button
              onClick={optimizePerformance}
              disabled={isOptimizing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isOptimizing ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Zap className="h-4 w-4 mr-2" />
              )}
              {isOptimizing ? 'Optimizing...' : 'Optimize Performance'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-emerald-900/20 border-emerald-500/50">
          <CardHeader>
            <CardTitle className="text-emerald-400 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Revenue Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-300">Revenue/Minute</span>
                <span className="text-emerald-400 font-bold">
                  ${metrics.revenuePerMinute.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Active Users</span>
                <span className="text-blue-400 font-bold">
                  {metrics.activeUsers}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Error Rate</span>
                <span className={`font-bold ${metrics.errorRate < 1 ? 'text-green-400' : 'text-red-400'}`}>
                  {metrics.errorRate.toFixed(2)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-orange-900/20 border-orange-500/50">
          <CardHeader>
            <CardTitle className="text-orange-400 flex items-center gap-2">
              <Database className="h-4 w-4" />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Database</span>
                <Badge className="bg-green-600">Optimal</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">API Gateway</span>
                <Badge className="bg-green-600">Healthy</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Payment Systems</span>
                <Badge className="bg-green-600">Active</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PerformanceAnalytics;