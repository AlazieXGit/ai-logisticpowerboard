import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Globe, Star, Truck, DollarSign, Phone, Mail } from 'lucide-react';
import VendorCatalogModal from './VendorCatalogModal';
import PlaceOrderModal from './PlaceOrderModal';

const InternationalVendorManager = () => {
  const [selectedVendor, setSelectedVendor] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showCatalog, setShowCatalog] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);

  const [vendors] = useState([
    {
      id: 'VEN-001',
      name: 'Tesla International Robotics',
      country: 'Germany',
      rating: 4.9,
      products: ['AI Autopilot Systems', 'Neural Network Processors', 'Robotic Sensors', 'AI Cameras'],
      contact: '+49-30-12345678',
      email: 'orders@tesla-robotics.de',
      shippingCost: '$2,500',
      deliveryTime: '7-10 days'
    },
    {
      id: 'VEN-002',
      name: 'BMW Robotics Division',
      country: 'Germany',
      rating: 4.8,
      products: ['AI Navigation Systems', 'Autonomous Driving Units', 'Smart Sensors', 'AI Accessories'],
      contact: '+49-89-87654321',
      email: 'robotics@bmw-international.com',
      shippingCost: '$2,200',
      deliveryTime: '8-12 days'
    },
    {
      id: 'VEN-003',
      name: 'Toyota AI Robotics Japan',
      country: 'Japan',
      rating: 4.7,
      products: ['Hybrid AI Systems', 'Robotic Assembly Units', 'Smart Manufacturing', 'AI Cameras'],
      contact: '+81-3-12345678',
      email: 'ai-orders@toyota-robotics.jp',
      shippingCost: '$3,100',
      deliveryTime: '10-14 days'
    },
    {
      id: 'VEN-004',
      name: 'Mercedes AI Technologies',
      country: 'Germany',
      rating: 4.9,
      products: ['Luxury AI Systems', 'Premium Robotics', 'Advanced Sensors', 'AI Accessories'],
      contact: '+49-711-98765432',
      email: 'tech@mercedes-ai.com',
      shippingCost: '$2,800',
      deliveryTime: '6-9 days'
    }
  ]);

  const handleViewCatalog = (vendor: any) => {
    setSelectedVendor(vendor);
    setShowCatalog(true);
  };

  const handlePlaceOrder = (product: any) => {
    setSelectedProduct(product);
    setShowOrderModal(true);
    setShowCatalog(false);
  };

  const handleDirectOrder = (vendor: any) => {
    setSelectedVendor(vendor);
    setSelectedProduct({ name: 'Direct Order', price: '$0' });
    setShowOrderModal(true);
  };

  const handleConfirmOrder = async (orderData: any) => {
    // Send confirmation emails and process order
    console.log('Order confirmed:', orderData);
    alert(`Order confirmed for ${orderData.buyer}! Confirmation emails sent to all parties.`);
    setShowOrderModal(false);
    setSelectedProduct(null);
    setSelectedVendor(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">International Vendor Network</h2>
        <Button className="bg-blue-600 hover:bg-blue-700">
          Add New Vendor
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {vendors.map((vendor) => (
          <Card key={vendor.id} className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-blue-400" />
                  {vendor.name}
                </div>
                <Badge variant="outline" className="text-blue-300">
                  {vendor.country}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <Star className="h-4 w-4 text-yellow-400 fill-current" />
                <span className="text-white">{vendor.rating}/5.0</span>
              </div>

              <div>
                <h4 className="text-white font-medium mb-2">Products:</h4>
                <div className="flex flex-wrap gap-1">
                  {vendor.products.map((product, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {product}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-400">Contact</p>
                  <p className="text-blue-300 flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    {vendor.contact}
                  </p>
                </div>
                <div>
                  <p className="text-gray-400">Email</p>
                  <p className="text-blue-300 flex items-center gap-1">
                    <Mail className="h-3 w-3" />
                    {vendor.email}
                  </p>
                </div>
                <div>
                  <p className="text-gray-400">Shipping Cost</p>
                  <p className="text-green-400 flex items-center gap-1">
                    <DollarSign className="h-3 w-3" />
                    {vendor.shippingCost}
                  </p>
                </div>
                <div>
                  <p className="text-gray-400">Delivery Time</p>
                  <p className="text-white flex items-center gap-1">
                    <Truck className="h-3 w-3" />
                    {vendor.deliveryTime}
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  className="bg-green-600 hover:bg-green-700 flex-1"
                  onClick={() => handleDirectOrder(vendor)}
                >
                  Place Order
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => handleViewCatalog(vendor)}
                >
                  View Catalog
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <VendorCatalogModal
        isOpen={showCatalog}
        onClose={() => setShowCatalog(false)}
        vendor={selectedVendor}
        onPlaceOrder={handlePlaceOrder}
      />

      <PlaceOrderModal
        isOpen={showOrderModal}
        onClose={() => setShowOrderModal(false)}
        product={selectedProduct}
        vendor={selectedVendor}
        onConfirmOrder={handleConfirmOrder}
      />
    </div>
  );
};

export default InternationalVendorManager;