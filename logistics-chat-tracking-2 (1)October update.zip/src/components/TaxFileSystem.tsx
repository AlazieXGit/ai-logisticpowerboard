import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Download, Upload, Building2, User, Calendar, DollarSign, Lock } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TaxDocument {
  id: string;
  accountId: string;
  accountName: string;
  documentType: string;
  taxYear: string;
  amount: number;
  status: string;
  createdAt: string;
}

const TaxFileSystem: React.FC = () => {
  const [taxDocuments, setTaxDocuments] = useState<TaxDocument[]>([
    {
      id: '1',
      accountId: '5573-9012-4567-8901',
      accountName: 'Alaziel Banking - Main',
      documentType: 'Annual Statement',
      taxYear: '2024',
      amount: 2450000,
      status: 'Generated',
      createdAt: '2024-12-31'
    },
    {
      id: '2',
      accountId: '5573-9012-4567-8902',
      accountName: 'Alaziel Banking - Escrow',
      documentType: 'Annual Statement',
      taxYear: '2024',
      amount: 850000,
      status: 'Generated',
      createdAt: '2024-12-31'
    }
  ]);

  const [companies] = useState([
    {
      id: '1',
      name: 'Alazie LLC',
      ein: '88-1234567',
      address: '123 Business Ave, Dallas, TX 75201',
      accountNumber: '3236618840224',
      routingNumber: '041215663',
      type: 'Square Account'
    },
    {
      id: '2', 
      name: 'Alaziel Banking Corp',
      ein: '77-9876543',
      address: '456 Finance St, Dallas, TX 75202',
      accountNumber: '5573-9012-4567-8901',
      routingNumber: '031176110',
      type: 'Primary Banking'
    }
  ]);

  const generate1099 = async (companyId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'generate_1099',
          companyId,
          taxYear: '2024'
        }
      });
      
      if (error) throw error;
      console.log('1099 generated:', data);
    } catch (error) {
      console.error('Error generating 1099:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-emerald-400">Tax File Management System</h2>
          <p className="text-gray-400">Hard copy tax documents and 1099 filing management</p>
        </div>
        <Badge className="bg-red-600 text-white">
          <Lock className="h-3 w-3 mr-1" />
          HARD COPY SECURED
        </Badge>
      </div>

      <Tabs defaultValue="accounts" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="accounts" className="text-emerald-300">Account Files</TabsTrigger>
          <TabsTrigger value="1099" className="text-emerald-300">1099 Management</TabsTrigger>
          <TabsTrigger value="companies" className="text-emerald-300">Company Info</TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="space-y-4">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Banking Account Tax Files
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {taxDocuments.map((doc) => (
                  <div key={doc.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{doc.accountName}</h3>
                      <p className="text-sm text-gray-400">Account: {doc.accountId}</p>
                      <p className="text-sm text-gray-400">Tax Year: {doc.taxYear} | Amount: ${doc.amount.toLocaleString()}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={doc.status === 'Generated' ? 'bg-green-600' : 'bg-yellow-600'}>
                        {doc.status}
                      </Badge>
                      <Button size="sm" variant="outline" className="border-emerald-500 text-emerald-400">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="1099" className="space-y-4">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                1099 Filing Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="bg-gray-700">
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-emerald-400 mb-2">2024 Tax Year Status</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-300">1099-MISC Generated:</span>
                          <Badge className="bg-green-600">Complete</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-300">1099-NEC Generated:</span>
                          <Badge className="bg-green-600">Complete</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-300">Filing Deadline:</span>
                          <span className="text-yellow-400">Jan 31, 2025</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-700">
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-emerald-400 mb-2">Quick Actions</h3>
                      <div className="space-y-2">
                        <Button className="w-full bg-emerald-600 hover:bg-emerald-700" size="sm">
                          <FileText className="h-4 w-4 mr-2" />
                          Generate All 1099s
                        </Button>
                        <Button className="w-full" variant="outline" size="sm">
                          <Upload className="h-4 w-4 mr-2" />
                          Bulk Upload Recipients
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="companies" className="space-y-4">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Company Filing Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {companies.map((company) => (
                  <div key={company.id} className="p-4 bg-gray-700 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-white text-lg">{company.name}</h3>
                        <div className="mt-2 space-y-1 text-sm text-gray-300">
                          <p><strong>EIN:</strong> {company.ein}</p>
                          <p><strong>Address:</strong> {company.address}</p>
                          <p><strong>Account:</strong> {company.accountNumber}</p>
                          <p><strong>Routing:</strong> {company.routingNumber}</p>
                          <Badge className="mt-2 bg-blue-600">{company.type}</Badge>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button 
                          size="sm" 
                          className="bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => generate1099(company.id)}
                        >
                          <FileText className="h-4 w-4 mr-1" />
                          Generate 1099
                        </Button>
                        <Button size="sm" variant="outline" className="border-emerald-500 text-emerald-400">
                          <Download className="h-4 w-4 mr-1" />
                          Export Info
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TaxFileSystem;