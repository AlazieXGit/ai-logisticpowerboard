import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { Loader2 } from 'lucide-react';

interface InsightsPanelProps {
  context: any;
}

const InsightsPanel: React.FC<InsightsPanelProps> = ({ context }) => {
  const [insights, setInsights] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateInsights = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error } = await supabase.functions.invoke('generate-insights', {
        body: { 
          loads: context.loads || [],
          location: context.location || null,
          timestamp: new Date().toISOString()
        },
      });

      if (error) {
        throw error;
      }

      setInsights(data?.insights || 'No insights generated');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate insights');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-orange-50 to-red-100 border-2 border-orange-200 shadow-xl">
      <div className="p-4 border-b bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <h2 className="text-lg font-bold flex items-center gap-2">
          🧠 AI Insights Generator
        </h2>
      </div>
      <div className="p-4 space-y-4">
        <Button 
          onClick={generateInsights}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Insights...
            </>
          ) : (
            'Generate AI Insights'
          )}
        </Button>
        
        {error && (
          <Badge variant="destructive" className="w-full justify-center">
            {error}
          </Badge>
        )}
        
        {insights && (
          <div className="bg-white rounded-lg p-4 border-2 border-orange-200">
            <h3 className="font-semibold text-gray-800 mb-2">📈 Generated Insights:</h3>
            <p className="text-sm text-gray-700 whitespace-pre-wrap">{insights}</p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default InsightsPanel;