import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Truck, MapPin, DollarSign, Clock, TrendingUp, Package, Zap } from 'lucide-react';
import AIMarketAnalysis from './AIMarketAnalysis';
import AggressiveBookingAI from './AggressiveBookingAI';

interface Load {
  id: string;
  type: 'emergency' | 'hot-shot' | 'courier' | 'non-emergency' | 'box-truck';
  origin: string;
  destination: string;
  weight: number;
  rate: number;
  distance: number;
  status: 'available' | 'booked' | 'in-transit' | 'delivered';
  fees: {
    platform: number;
    special: boolean;
  };
  bookedAt?: Date;
}

const LoadboardIntegration = () => {
  const [loads, setLoads] = useState<Load[]>([]);
  const [activeTab, setActiveTab] = useState('all');
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [liveBookings, setLiveBookings] = useState(0);

  const eligibleTypes = ['emergency', 'hot-shot', 'courier', 'non-emergency'];
  const loadTypes = [
    { key: 'emergency', label: 'Emergency', icon: '🚨', color: 'bg-red-600' },
    { key: 'hot-shot', label: 'Hot Shot', icon: '🔥', color: 'bg-orange-600' },
    { key: 'courier', label: 'Courier', icon: '⚡', color: 'bg-yellow-600' },
    { key: 'non-emergency', label: 'Non-Emergency', icon: '📋', color: 'bg-green-600' },
    { key: 'box-truck', label: 'Box Truck', icon: '📦', color: 'bg-blue-600' }
  ];

  useEffect(() => {
    const generateLoad = (type: Load['type']): Load => {
      const baseRate = Math.floor(Math.random() * 2000) + 500;
      const isEligible = eligibleTypes.includes(type);
      const feeRate = isEligible ? 0.02 : 0.25; // 2% special vs 25% regular
      
      return {
        id: `${type.toUpperCase()}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type,
        origin: `City ${Math.floor(Math.random() * 100)}`,
        destination: `City ${Math.floor(Math.random() * 100)}`,
        weight: Math.floor(Math.random() * 40000) + 1000,
        rate: baseRate,
        distance: Math.floor(Math.random() * 500) + 50,
        status: 'available',
        fees: {
          platform: baseRate * feeRate,
          special: isEligible
        }
      };
    };

    // Initial load generation
    const initialLoads = [];
    loadTypes.forEach(type => {
      for (let i = 0; i < 4; i++) {
        initialLoads.push(generateLoad(type.key as Load['type']));
      }
    });
    setLoads(initialLoads);

    // Aggressive load generation for 200x performance
    const interval = setInterval(() => {
      const randomType = loadTypes[Math.floor(Math.random() * loadTypes.length)];
      const newLoad = generateLoad(randomType.key as Load['type']);
      
      setLoads(prev => [newLoad, ...prev.slice(0, 24)]); // Keep last 25 loads
    }, 2000); // Faster generation

    return () => clearInterval(interval);
  }, []);

  const autoBookLoad = (loadId: string) => {
    setLoads(prev => prev.map(load => {
      if (load.id === loadId && load.status === 'available') {
        setTotalRevenue(prevRevenue => prevRevenue + load.fees.platform);
        setLiveBookings(prevBookings => prevBookings + 1);
        
        return {
          ...load,
          status: 'booked' as const,
          bookedAt: new Date()
        };
      }
      return load;
    }));
  };

  const filteredLoads = activeTab === 'all' 
    ? loads 
    : loads.filter(load => load.type === activeTab);

  const getLoadTypeInfo = (type: Load['type']) => {
    return loadTypes.find(lt => lt.key === type) || loadTypes[0];
  };

  const totalFeeRevenue = loads
    .filter(load => load.status === 'booked')
    .reduce((sum, load) => sum + load.fees.platform, 0);

  const specialRateLoads = loads.filter(load => load.fees.special);

  return (
    <div className="space-y-6">
      {/* AI Components */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AIMarketAnalysis />
        <AggressiveBookingAI />
      </div>

      {/* Revenue Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Truck className="h-4 w-4 mr-2" />
              Live Bookings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{liveBookings}</div>
            <p className="text-xs text-gray-400">Auto-booked loads</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <DollarSign className="h-4 w-4 mr-2" />
              Fee Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">${totalFeeRevenue.toFixed(2)}</div>
            <p className="text-xs text-gray-400">Platform fees</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Zap className="h-4 w-4 mr-2" />
              Special Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">{specialRateLoads.length}</div>
            <p className="text-xs text-gray-400">2% fee loads</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <TrendingUp className="h-4 w-4 mr-2" />
              Available
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{loads.filter(l => l.status === 'available').length}</div>
            <p className="text-xs text-gray-400">Ready for booking</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-emerald-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-emerald-400 text-sm flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Live Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-white">{new Date().toLocaleTimeString()}</div>
            <p className="text-xs text-gray-400">Real-time</p>
          </CardContent>
        </Card>
      </div>

      {/* Load Categories */}
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center justify-between">
            <span>Enhanced Loadboard - AI Optimized</span>
            <Badge className="bg-red-600 animate-pulse">
              <Zap className="h-3 w-3 mr-1" />
              2% SPECIAL ACTIVE
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-6 bg-gray-700">
              <TabsTrigger value="all" className="text-white">All</TabsTrigger>
              {loadTypes.map(type => (
                <TabsTrigger key={type.key} value={type.key} className="text-white">
                  {type.icon} {type.label}
                </TabsTrigger>
              ))}
            </TabsList>
            
            <TabsContent value={activeTab} className="mt-4">
              <div className="space-y-3">
                {filteredLoads.slice(0, 10).map((load) => {
                  const typeInfo = getLoadTypeInfo(load.type);
                  
                  return (
                    <div key={load.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="text-2xl">{typeInfo.icon}</div>
                        <div>
                          <div className="text-white font-medium">{load.id}</div>
                          <div className="text-gray-400 text-sm flex items-center gap-2">
                            <MapPin className="h-3 w-3" />
                            {load.origin} → {load.destination} ({load.distance}mi)
                          </div>
                          <div className="text-gray-400 text-sm flex items-center gap-2">
                            <Package className="h-3 w-3" />
                            {load.weight.toLocaleString()} lbs
                          </div>
                        </div>
                        <Badge className={typeInfo.color}>
                          {typeInfo.label}
                        </Badge>
                        <Badge className={`${
                          load.status === 'available' ? 'bg-green-600' :
                          load.status === 'booked' ? 'bg-blue-600' :
                          load.status === 'in-transit' ? 'bg-yellow-600' :
                          'bg-purple-600'
                        }`}>
                          {load.status}
                        </Badge>
                        {load.fees.special && (
                          <Badge className="bg-red-600 animate-pulse">
                            <Zap className="h-3 w-3 mr-1" />
                            2% SPECIAL
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-white font-bold">${load.rate}</div>
                          <div className={`text-sm ${load.fees.special ? 'text-red-400' : 'text-emerald-400'}`}>
                            +${load.fees.platform.toFixed(2)} ({load.fees.special ? '2%' : '25%'} fee)
                          </div>
                          {load.bookedAt && (
                            <div className="text-gray-400 text-xs">
                              Booked: {load.bookedAt.toLocaleTimeString()}
                            </div>
                          )}
                        </div>
                        
                        {load.status === 'available' && (
                          <Button 
                            size="sm" 
                            onClick={() => autoBookLoad(load.id)}
                            className={`${load.fees.special ? 'bg-red-600 hover:bg-red-700' : 'bg-emerald-600 hover:bg-emerald-700'}`}
                          >
                            {load.fees.special ? (
                              <>
                                <Zap className="h-3 w-3 mr-1" />
                                Book 2%
                              </>
                            ) : (
                              'AI Book'
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoadboardIntegration;