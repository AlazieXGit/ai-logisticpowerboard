import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Download, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import RevenueTrackingTab from './RevenueTrackingTab';
import AssetManagementTab from './AssetManagementTab';
import BusinessOperationsTab from './BusinessOperationsTab';

const PlatformInstructionsDocuments = () => {
  const downloadInstructions = (type) => {
    const instructions = {
      banking: `BANKING INTEGRATION INSTRUCTIONS

1. Account Setup:
   - Username: alaziellc.innovation@gmail.com
   - Password: gotchupin1976
   - Email: alaziellc.innovation@gmail.com

2. Payment Processing Setup:
   - ACH: Configure routing numbers
   - Wire: International SWIFT codes
   - Direct Deposit: Employee payroll setup
   - Instant Transfer: Real-time processing

3. Master Credentials:
   - API Keys: Contact system admin
   - Webhook URLs: Configure endpoints
   - Security Tokens: Generate new tokens

4. Integration Steps:
   - Connect to payment processors
   - Set up automated routing
   - Configure fee structures
   - Test all payment routes`,

      legal: `LEGAL DOCUMENTS INTEGRATION

1. Required Documents:
   - Business License
   - Tax ID Documentation
   - Operating Agreements
   - Compliance Certificates

2. Tax File Integration:
   - W-9 Forms
   - 1099 Processing
   - State Tax Documents
   - Federal Tax Filings

3. Legal Compliance:
   - AML Procedures
   - KYC Documentation
   - Privacy Policies
   - Terms of Service

4. Document Management:
   - Digital signatures
   - Secure storage
   - Access controls
   - Audit trails`,

      technical: `TECHNICAL INTEGRATION GUIDE

1. API Configuration:
   - Base URL: https://api.platform.com
   - Authentication: Bearer tokens
   - Rate Limits: 1000/hour
   - Webhooks: Real-time notifications

2. Payment Routes:
   - Domestic: ACH, Wire, Check
   - International: SWIFT, Correspondent
   - Instant: Real-time processing
   - Batch: Scheduled transfers

3. Security:
   - SSL/TLS encryption
   - Two-factor authentication
   - IP whitelisting
   - Audit logging

4. Testing:
   - Sandbox environment
   - Test credentials
   - Mock transactions
   - Integration validation`
    };

    const element = document.createElement('a');
    element.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(instructions[type]);
    element.download = `${type}_instructions.txt`;
    element.click();
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-300 flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Platform Instructions & Documents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 mb-4">
            Comprehensive platform documentation with editable content and downloadable resources.
          </p>
          <div className="flex gap-4">
            <Button 
              onClick={() => downloadInstructions('banking')}
              className="bg-green-600 hover:bg-green-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Banking Instructions
            </Button>
            <Button 
              onClick={() => downloadInstructions('legal')}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Legal Documents
            </Button>
            <Button 
              onClick={() => downloadInstructions('technical')}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Technical Guide
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="revenue" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="revenue">Revenue Tracking</TabsTrigger>
          <TabsTrigger value="assets">Asset Management</TabsTrigger>
          <TabsTrigger value="operations">Business Operations</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue">
          <RevenueTrackingTab />
        </TabsContent>

        <TabsContent value="assets">
          <AssetManagementTab />
        </TabsContent>

        <TabsContent value="operations">
          <BusinessOperationsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PlatformInstructionsDocuments;