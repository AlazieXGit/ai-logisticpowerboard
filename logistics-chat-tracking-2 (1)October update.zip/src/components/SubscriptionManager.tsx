import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, CreditCard, TrendingUp, Settings } from 'lucide-react';

interface Subscriber {
  id: string;
  name: string;
  email: string;
  plan: string;
  status: 'active' | 'inactive' | 'pending';
  revenue: number;
  joinDate: string;
}

const mockSubscribers: Subscriber[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@example.com',
    plan: 'Professional',
    status: 'active',
    revenue: 99,
    joinDate: '2024-01-15'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    plan: 'Enterprise',
    status: 'active',
    revenue: 299,
    joinDate: '2024-01-20'
  }
];

export const SubscriptionManager: React.FC = () => {
  const [subscribers] = useState<Subscriber[]>(mockSubscribers);

  const totalRevenue = subscribers.reduce((sum, sub) => sum + sub.revenue, 0);
  const activeSubscribers = subscribers.filter(sub => sub.status === 'active').length;

  return (
    <div className="p-6 space-y-6">
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Subscribers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{subscribers.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Subscribers</CardTitle>
            <Users className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeSubscribers}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="subscribers" className="space-y-4">
        <TabsList>
          <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
          <TabsTrigger value="plans">Plans</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
        </TabsList>

        <TabsContent value="subscribers">
          <Card>
            <CardHeader>
              <CardTitle>Subscriber Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {subscribers.map((subscriber) => (
                  <div key={subscriber.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">{subscriber.name}</h3>
                      <p className="text-sm text-gray-600">{subscriber.email}</p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant={subscriber.status === 'active' ? 'default' : 'secondary'}>
                        {subscriber.plan}
                      </Badge>
                      <span className="font-medium">${subscriber.revenue}/mo</span>
                      <Button size="sm" variant="outline">
                        Manage
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="plans">
          <Card>
            <CardHeader>
              <CardTitle>Subscription Plans & Payment Links</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg bg-blue-50">
                  <h3 className="font-medium mb-2">Basic Tier - $29/month</h3>
                  <p className="text-sm text-gray-600 mb-3">AI Boost 50x, Load Board Access</p>
                  <Button 
                    className="w-full"
                    onClick={() => window.open('https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00', '_blank')}
                  >
                    Subscribe Basic
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg bg-green-50">
                  <h3 className="font-medium mb-2">Professional - $99/month</h3>
                  <p className="text-sm text-gray-600 mb-3">AI Boost 100x, Advanced Features</p>
                  <Button 
                    className="w-full"
                    onClick={() => window.open('https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00', '_blank')}
                  >
                    Subscribe Pro
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg bg-purple-50">
                  <h3 className="font-medium mb-2">Enterprise - $299/month</h3>
                  <p className="text-sm text-gray-600 mb-3">AI Boost 250x, Full Suite</p>
                  <Button 
                    className="w-full"
                    onClick={() => window.open('https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00', '_blank')}
                  >
                    Subscribe Premium
                  </Button>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-gray-100 rounded-lg">
                <h4 className="font-medium mb-2">Main Payment Link (All Tiers)</h4>
                <div className="flex items-center space-x-2">
                  <code className="flex-1 p-2 bg-white rounded text-sm">
                    https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00
                  </code>
                  <Button 
                    size="sm"
                    onClick={() => window.open('https://buy.stripe.com/eVqaEX7O89TPaV0eqtcQU00', '_blank')}
                  >
                    Open
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Detailed revenue tracking and forecasting.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};