import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Copy, DollarSign, CreditCard, Building, AlertTriangle, CheckCircle, Clock, Send, FileText, Shield, ArrowRight } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LiveClock } from './LiveClock';

interface TransactionRecord {
  id: string;
  fromAccount: string;
  fromRouting: string;
  toAccount: string;
  toRouting: string;
  amount: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
  reference: string;
  type: 'internal' | 'external';
}

interface ProcessingAccount {
  name: string;
  routing: string;
  account: string;
  type: 'primary' | 'secondary' | 'backup';
  balance: string;
}

const ManualPaymentCenter: React.FC = () => {
  const [amount, setAmount] = useState('');
  const [recipientRouting, setRecipientRouting] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [memo, setMemo] = useState('');
  const [selectedProcessor, setSelectedProcessor] = useState('primary');
  
  
  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    console.log(`${type} copied to clipboard`);
  };

  const processingAccounts: ProcessingAccount[] = [
    {
      name: 'Primary Stripe Processing',
      routing: '041215663',
      account: '2079529306039',
      type: 'primary',
      balance: '$847,293.42'
    },
    {
      name: 'Secondary ACH Processing',
      routing: '041215663', 
      account: '3236618840224',
      type: 'secondary',
      balance: '$234,567.89'
    },
    {
      name: 'Backup Wells Fargo',
      routing: '121000248',
      account: '4567890123456',
      type: 'backup',
      balance: '$89,432.10'
    }
  ];

  const recentTransactions: TransactionRecord[] = [
    {
      id: 'TXN001',
      fromAccount: '2079529306039',
      fromRouting: '041215663',
      toAccount: '9876543210987',
      toRouting: '031101279',
      amount: '$15,000.00',
      date: '2025-01-15 14:32:00',
      status: 'completed',
      reference: 'STRIPE-MANUAL-001',
      type: 'external'
    },
    {
      id: 'TXN002',
      fromAccount: '3236618840224',
      fromRouting: '041215663',
      toAccount: '1234567890123',
      toRouting: '121000248',
      amount: '$7,500.00',
      date: '2025-01-15 13:15:00',
      status: 'pending',
      reference: 'STRIPE-MANUAL-002',
      type: 'external'
    }
  ];

  const processManualTransfer = () => {
    if (!amount || !recipientRouting || !recipientAccount) {
      console.log('Error: Please fill in all required fields');
      return;
    }

    console.log(`Transfer Initiated: Manual transfer of ${amount} initiated successfully`);
  };

  return (
    <div className="space-y-6">
      <LiveClock />
      <Card className="bg-emerald-900/20 border-emerald-500/50">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            STRIPE MANUAL PAYMENT CENTER
            <Badge className="bg-emerald-600 text-white">AUTHORIZED</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="transfer" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="transfer">Manual Transfer</TabsTrigger>
          <TabsTrigger value="accounts">Processing Accounts</TabsTrigger>
          <TabsTrigger value="transactions">Transaction History</TabsTrigger>
          <TabsTrigger value="documents">Legal Documents</TabsTrigger>
        </TabsList>

        <TabsContent value="transfer" className="space-y-4">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400">Manual Fund Transfer</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-gray-300">Processing Account</Label>
                  <select 
                    value={selectedProcessor}
                    onChange={(e) => setSelectedProcessor(e.target.value)}
                    className="w-full p-2 bg-gray-700 border border-emerald-500/30 rounded text-white"
                  >
                    {processingAccounts.map((acc, idx) => (
                      <option key={idx} value={acc.type}>{acc.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label className="text-gray-300">Transfer Amount</Label>
                  <Input
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="$0.00"
                    className="bg-gray-700 border-emerald-500/30 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-gray-300">Recipient Routing Number</Label>
                  <Input
                    value={recipientRouting}
                    onChange={(e) => setRecipientRouting(e.target.value)}
                    placeholder="9-digit routing number"
                    className="bg-gray-700 border-emerald-500/30 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-gray-300">Recipient Account Number</Label>
                  <Input
                    value={recipientAccount}
                    onChange={(e) => setRecipientAccount(e.target.value)}
                    placeholder="Account number"
                    className="bg-gray-700 border-emerald-500/30 text-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Transfer Memo</Label>
                <Textarea
                  value={memo}
                  onChange={(e) => setMemo(e.target.value)}
                  placeholder="Transfer description..."
                  className="bg-gray-700 border-emerald-500/30 text-white"
                />
              </div>

              <Button
                onClick={processManualTransfer}
                className="bg-emerald-600 hover:bg-emerald-700 text-white w-full"
              >
                <Shield className="h-4 w-4 mr-2" />
                Process Manual Transfer
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          {processingAccounts.map((account, idx) => (
            <Card key={idx} className="bg-gray-800 border-emerald-500/30">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-emerald-400">{account.name}</CardTitle>
                  <Badge className={
                    account.type === 'primary' ? 'bg-green-600' :
                    account.type === 'secondary' ? 'bg-blue-600' : 'bg-yellow-600'
                  }>
                    {account.type.toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-gray-300">Routing Number</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        value={account.routing}
                        readOnly
                        className="bg-gray-700 border-emerald-500/30 text-white font-mono"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(account.routing, 'Routing')}
                        className="text-emerald-400"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Account Number</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        value={account.account}
                        readOnly
                        className="bg-gray-700 border-emerald-500/30 text-white font-mono"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(account.account, 'Account')}
                        className="text-emerald-400"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Available Balance</Label>
                    <p className="text-emerald-400 font-semibold text-lg">{account.balance}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="transactions" className="space-y-4">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400">Recent Manual Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTransactions.map((txn) => (
                  <div key={txn.id} className="border border-gray-600 rounded p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-emerald-400 font-mono">{txn.reference}</span>
                      <Badge className={
                        txn.status === 'completed' ? 'bg-green-600' :
                        txn.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                      }>
                        {txn.status.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <Label className="text-gray-300">From Account</Label>
                        <p className="text-white font-mono">{txn.fromRouting} / {txn.fromAccount}</p>
                      </div>
                      <div>
                        <Label className="text-gray-300">To Account</Label>
                        <p className="text-white font-mono">{txn.toRouting} / {txn.toAccount}</p>
                      </div>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-emerald-400 font-semibold">{txn.amount}</span>
                      <span className="text-gray-400">{txn.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          <Card className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Legal Transfer Documentation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-900/20 border border-yellow-500/50 rounded p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-400" />
                  <span className="text-yellow-400 font-semibold">LEGAL NOTICE</span>
                </div>
                <p className="text-gray-300 text-sm">
                  All manual fund transfers require proper authorization and documentation. 
                  By processing transfers through this system, you acknowledge compliance 
                  with all applicable banking regulations and internal policies.
                </p>
              </div>
              
              <div className="space-y-2">
                <Label className="text-gray-300">Transfer Authorization Form</Label>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Transfer Authorization
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label className="text-gray-300">Compliance Documentation</Label>
                <Button className="bg-purple-600 hover:bg-purple-700 text-white w-full">
                  <Shield className="h-4 w-4 mr-2" />
                  Download Compliance Package
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ManualPaymentCenter;