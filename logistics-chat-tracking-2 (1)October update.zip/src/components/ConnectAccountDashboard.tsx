import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CheckCircle, XCircle, Clock, DollarSign, Upload, RefreshCw } from 'lucide-react'
import { StripeConnectService } from '@/services/StripeConnectService'
import { supabase } from '@/lib/supabase'
import ComplianceUploader from './ComplianceUploader'
import PayoutScheduleManager from './PayoutScheduleManager'

export default function ConnectAccountDashboard() {
  const [account, setAccount] = useState<any>(null)
  const [payouts, setPayouts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    loadAccountData()
    const interval = setInterval(loadAccountData, 30000)
    return () => clearInterval(interval)
  }, [])

  const loadAccountData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const accountData = await StripeConnectService.getConnectAccount(user.id)
      setAccount(accountData)

      if (accountData) {
        const payoutsData = await StripeConnectService.getPayouts(accountData.id)
        setPayouts(payoutsData || [])
      }
    } catch (err) {
      console.error('Error loading account data:', err)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const handleRefresh = () => {
    setRefreshing(true)
    loadAccountData()
  }

  const getStatusBadge = (status: string) => {
    const variants: any = {
      completed: 'default',
      verified: 'default',
      pending: 'secondary',
      in_progress: 'secondary',
      rejected: 'destructive',
      unverified: 'outline',
    }
    return <Badge variant={variants[status] || 'outline'}>{status.replace('_', ' ')}</Badge>
  }

  const getTotalPending = () => {
    return payouts
      .filter(p => p.status === 'pending' || p.status === 'in_transit')
      .reduce((sum, p) => sum + parseFloat(p.amount), 0)
  }

  if (loading) {
    return <div className="flex justify-center p-12"><RefreshCw className="animate-spin" /></div>
  }

  if (!account) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Connected Account</CardTitle>
          <CardDescription>Complete onboarding to start receiving payouts</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={() => window.location.href = '/connect-onboarding'}>Start Onboarding</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Connect Account Dashboard</h2>
        <Button onClick={handleRefresh} disabled={refreshing} variant="outline" size="sm">
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Account Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {account.charges_enabled ? <CheckCircle className="text-green-500" /> : <XCircle className="text-red-500" />}
              {getStatusBadge(account.onboarding_status)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Verification Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {account.payouts_enabled ? <CheckCircle className="text-green-500" /> : <Clock className="text-yellow-500" />}
              {getStatusBadge(account.verification_status)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Pending Payouts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <DollarSign className="text-blue-500" />
              <span className="text-2xl font-bold">${getTotalPending().toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="payouts" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="payouts">Payouts</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
        </TabsList>

        <TabsContent value="payouts">
          <Card>
            <CardHeader>
              <CardTitle>Payout History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {payouts.map((payout) => (
                  <div key={payout.id} className="flex justify-between items-center p-3 border rounded">
                    <div>
                      <p className="font-medium">${parseFloat(payout.amount).toFixed(2)}</p>
                      <p className="text-sm text-muted-foreground">{new Date(payout.created_at).toLocaleDateString()}</p>
                    </div>
                    {getStatusBadge(payout.status)}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule">
          <PayoutScheduleManager connectAccountId={account.id} />
        </TabsContent>

        <TabsContent value="compliance">
          <ComplianceUploader connectAccountId={account.id} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
