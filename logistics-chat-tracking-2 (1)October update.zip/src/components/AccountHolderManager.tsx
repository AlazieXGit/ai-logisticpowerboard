import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, CreditCard, Building, Mail, Phone, MapPin } from 'lucide-react';
import ManualTransferForum from './ManualTransferForum';

export const AccountHolderManager: React.FC = () => {
  const [selectedHolder, setSelectedHolder] = useState('alacias');

  const accountHolders = {
    alacias: {
      name: 'Alacias J. Bethea',
      address: '9876 Financial District, Tower 3, New York, NY 10004',
      phone: '(555) 123-4567',
      email: 'alacias.bethea@alaziegroup.com',
      debitCards: [
        { id: 'dc007', number: '4000-1234-5678-9012', fullNumber: '4000123456789012', bank: 'JPMorgan Chase', balance: 3247592.45, cvv: '321', exp: '09/28', priority: 'HIGH' },
        { id: 'dc008', number: '5432-1098-7654-3210', fullNumber: '5432109876543210', bank: 'US Bank', balance: 2163847.23, cvv: '654', exp: '11/27', priority: 'HIGH' },
        { id: 'dc009', number: '6789-0123-4567-8901', fullNumber: '6789012345678901', bank: 'TD Bank', balance: 1894756.89, cvv: '987', exp: '02/29', priority: 'HIGH' }
      ],
      creditCards: [
        { id: 'cc007', number: '3400-000000-00009', fullNumber: '340000000000009', bank: 'American Express Platinum', limit: 7500000, available: 7376543.21, cvv: '7890', exp: '12/27', priority: 'HIGH' },
        { id: 'cc008', number: '4444-4444-4444-4448', fullNumber: '4444444444444448', bank: 'Visa Black', limit: 5000000, available: 4898765.43, cvv: '012', exp: '08/28', priority: 'HIGH' },
        { id: 'cc009', number: '5454-5454-5454-5454', fullNumber: '5454545454545454', bank: 'Mastercard World Elite', limit: 8000000, available: 7647362.15, cvv: '345', exp: '05/29', priority: 'HIGH' }
      ],
      checkingAccounts: [
        { id: 'ca007', routing: '021000021', account: '1111222233334444', bank: 'JPMorgan Chase', balance: 15947563.28, priority: 'HIGH' },
        { id: 'ca008', routing: '091000019', account: '5555666677778888', bank: 'US Bank', balance: 8543298.76, priority: 'HIGH' },
        { id: 'ca009', routing: '031201360', account: '9999000011112222', bank: 'TD Bank', balance: 11847596.34, priority: 'HIGH' }
      ]
    },
    brysen: {
      name: 'Brysen Carter Alford',
      address: '2468 Innovation Way, Suite 1500, San Francisco, CA 94105',
      phone: '(555) 987-6543',
      email: 'brysen.alford@alaziegroup.com',
      debitCards: [
        { id: 'dc010', number: '4242-4242-4242-4242', fullNumber: '4242424242424242', bank: 'Wells Fargo Premier', balance: 2847592.45, cvv: '111', exp: '06/28', priority: 'HIGH' },
        { id: 'dc011', number: '5555-3333-4444-1111', fullNumber: '5555333344441111', bank: 'Capital One', balance: 1963847.23, cvv: '222', exp: '10/27', priority: 'HIGH' },
        { id: 'dc012', number: '6011-1111-1111-1117', fullNumber: '6011111111111117', bank: 'Discover Premier', balance: 2594756.89, cvv: '333', exp: '01/30', priority: 'HIGH' }
      ],
      creditCards: [
        { id: 'cc010', number: '3782-822463-10005', fullNumber: '378282246310005', bank: 'American Express Centurion', limit: 15000000, available: 14876543.21, cvv: '1111', exp: '07/27', priority: 'HIGH' },
        { id: 'cc011', number: '4000-0000-0000-0077', fullNumber: '4000000000000077', bank: 'Visa Infinite', limit: 10000000, available: 9898765.43, cvv: '444', exp: '03/28', priority: 'HIGH' },
        { id: 'cc012', number: '2223-0000-4841-0010', fullNumber: '2223000048410010', bank: 'Mastercard World', limit: 12000000, available: 11647362.15, cvv: '555', exp: '04/29', priority: 'HIGH' }
      ],
      checkingAccounts: [
        { id: 'ca010', routing: '121000248', account: '7777888899990000', bank: 'Wells Fargo Premier', balance: 18947563.28, priority: 'HIGH' },
        { id: 'ca011', routing: '051405515', account: '3333444455556666', bank: 'Capital One', balance: 12543298.76, priority: 'HIGH' },
        { id: 'ca012', routing: '011000015', account: '1234567890123456', bank: 'Discover Bank Premier', balance: 16847596.34, priority: 'HIGH' }
      ]
    }
  };

  const currentHolder = accountHolders[selectedHolder as keyof typeof accountHolders];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-indigo-900 to-purple-900 border-indigo-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <User className="h-6 w-6" />
            Additional Account Holders Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2 mb-4">
            <Button 
              onClick={() => setSelectedHolder('alacias')}
              className={`${selectedHolder === 'alacias' ? 'bg-indigo-600' : 'bg-gray-700'} text-white`}
            >
              Alacias J. Bethea
            </Button>
            <Button 
              onClick={() => setSelectedHolder('brysen')}
              className={`${selectedHolder === 'brysen' ? 'bg-indigo-600' : 'bg-gray-700'} text-white`}
            >
              Brysen Carter Alford
            </Button>
          </div>

          <Card className="bg-black/20 border-gray-600">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-white font-bold mb-2 flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Account Holder Details
                  </h3>
                  <p className="text-gray-300">Name: {currentHolder.name}</p>
                  <p className="text-gray-300 flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {currentHolder.address}
                  </p>
                </div>
                <div>
                  <h3 className="text-white font-bold mb-2">Contact Information</h3>
                  <p className="text-gray-300 flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    {currentHolder.phone}
                  </p>
                  <p className="text-gray-300 flex items-center gap-1">
                    <Mail className="h-3 w-3" />
                    {currentHolder.email}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <ManualTransferForum />

          <Tabs defaultValue="debit" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800">
              <TabsTrigger value="debit" className="text-white">Debit Cards</TabsTrigger>
              <TabsTrigger value="credit" className="text-white">Credit Cards</TabsTrigger>
              <TabsTrigger value="checking" className="text-white">Checking Accounts</TabsTrigger>
            </TabsList>

            <TabsContent value="debit" className="space-y-4">
              <div className="grid gap-4">
                {currentHolder.debitCards.map((card) => (
                  <Card key={card.id} className="bg-black/40 border-green-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-2">
                          <CreditCard className="h-5 w-5 text-green-400" />
                          <span className="text-white font-semibold">{card.bank}</span>
                          <Badge className="bg-red-600 text-white">{card.priority}</Badge>
                        </div>
                      </div>
                      <div className="bg-gray-800 p-3 rounded mb-3">
                        <p className="text-green-400 font-mono text-sm">Card: {card.fullNumber}</p>
                        <p className="text-gray-300 text-sm">CVV: {card.cvv} | Exp: {card.exp}</p>
                      </div>
                      <div className="text-green-400 text-xl font-bold mb-3">
                        Balance: ${card.balance.toLocaleString()}
                      </div>
                      <Button className="w-full bg-orange-600 hover:bg-orange-700">
                        <Mail className="h-4 w-4 mr-2" />
                        Express Mail Physical Card to {currentHolder.name}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="credit" className="space-y-4">
              <div className="grid gap-4">
                {currentHolder.creditCards.map((card) => (
                  <Card key={card.id} className="bg-black/40 border-purple-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-2">
                          <CreditCard className="h-5 w-5 text-purple-400" />
                          <span className="text-white font-semibold">{card.bank}</span>
                          <Badge className="bg-red-600 text-white">{card.priority}</Badge>
                        </div>
                      </div>
                      <div className="bg-gray-800 p-3 rounded mb-3">
                        <p className="text-purple-400 font-mono text-sm">Card: {card.fullNumber}</p>
                        <p className="text-gray-300 text-sm">CVV: {card.cvv} | Exp: {card.exp}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-3">
                        <div>
                          <span className="text-gray-400 text-sm">Available</span>
                          <div className="text-purple-400 text-lg font-bold">
                            ${card.available.toLocaleString()}
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-400 text-sm">Limit</span>
                          <div className="text-white text-lg font-bold">
                            ${card.limit.toLocaleString()}
                          </div>
                        </div>
                      </div>
                      <Button className="w-full bg-orange-600 hover:bg-orange-700">
                        <Mail className="h-4 w-4 mr-2" />
                        Express Mail Physical Card to {currentHolder.name}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="checking" className="space-y-4">
              <div className="grid gap-4">
                {currentHolder.checkingAccounts.map((account) => (
                  <Card key={account.id} className="bg-black/40 border-blue-500">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-2">
                          <Building className="h-5 w-5 text-blue-400" />
                          <span className="text-white font-semibold">{account.bank}</span>
                          <Badge className="bg-red-600 text-white">{account.priority}</Badge>
                        </div>
                      </div>
                      <div className="bg-gray-800 p-3 rounded mb-3">
                        <p className="text-blue-400 font-mono text-sm">Routing: {account.routing}</p>
                        <p className="text-blue-400 font-mono text-sm">Account: {account.account}</p>
                      </div>
                      <div className="text-blue-400 text-xl font-bold">
                        Balance: ${account.balance.toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountHolderManager;