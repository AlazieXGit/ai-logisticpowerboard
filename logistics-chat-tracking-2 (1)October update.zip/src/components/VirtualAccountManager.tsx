import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, Shield, Zap, Plus, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface VirtualAccount {
  id: string;
  name: string;
  virtualNumber: string;
  routingNumber: string;
  balance: number;
  status: 'active' | 'pending' | 'suspended';
  processingEnabled: boolean;
  linkedMainAccount: string;
  createdAt: string;
}

const VirtualAccountManager: React.FC = () => {
  const [virtualAccounts, setVirtualAccounts] = useState<VirtualAccount[]>([]);
  const [newAccountName, setNewAccountName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadVirtualAccounts();
  }, []);

  const loadVirtualAccounts = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'getVirtualAccounts' }
      });

      if (error) throw error;

      if (data?.success) {
        setVirtualAccounts(data.data);
      } else {
        // Mock data for demo
        setVirtualAccounts([
          {
            id: 'va-001',
            name: 'Primary Virtual Processing',
            virtualNumber: '5573-9012-4567-9001',
            routingNumber: '031176110',
            balance: 125000.00,
            status: 'active',
            processingEnabled: true,
            linkedMainAccount: 'alaziel-main-2024',
            createdAt: new Date().toISOString()
          },
          {
            id: 'va-002',
            name: 'Secondary Virtual Processing',
            virtualNumber: '5573-9012-4567-9002',
            routingNumber: '031176110',
            balance: 75000.00,
            status: 'active',
            processingEnabled: true,
            linkedMainAccount: 'alaziel-escrow-2024',
            createdAt: new Date().toISOString()
          }
        ]);
      }
    } catch (error) {
      console.error('Error loading virtual accounts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createVirtualAccount = async () => {
    if (!newAccountName.trim()) {
      toast({ title: 'Error', description: 'Please enter account name', variant: 'destructive' });
      return;
    }

    setIsCreating(true);
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'createVirtualAccount',
          name: newAccountName,
          linkedAccount: 'alaziel-main-2024'
        }
      });

      if (error) throw error;

      if (data?.success) {
        await loadVirtualAccounts();
        setNewAccountName('');
        toast({ title: 'Success', description: 'Virtual account created successfully' });
      }
    } catch (error) {
      console.error('Error creating virtual account:', error);
      toast({ title: 'Error', description: 'Failed to create virtual account', variant: 'destructive' });
    } finally {
      setIsCreating(false);
    }
  };

  const toggleProcessing = async (accountId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: {
          action: 'toggleVirtualProcessing',
          accountId
        }
      });

      if (error) throw error;

      if (data?.success) {
        await loadVirtualAccounts();
        toast({ title: 'Success', description: 'Processing status updated' });
      }
    } catch (error) {
      console.error('Error toggling processing:', error);
      toast({ title: 'Error', description: 'Failed to update processing status', variant: 'destructive' });
    }
  };

  const copyAccountInfo = (account: VirtualAccount) => {
    const info = `Account: ${account.virtualNumber}\nRouting: ${account.routingNumber}\nName: ${account.name}`;
    navigator.clipboard.writeText(info);
    toast({ title: 'Copied', description: 'Virtual account info copied to clipboard' });
  };

  if (isLoading) {
    return (
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardContent className="p-6">
          <div className="text-center text-emerald-400">Loading virtual accounts...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-emerald-500/30">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Virtual Account Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <Label className="text-emerald-300">New Virtual Account Name</Label>
              <Input
                value={newAccountName}
                onChange={(e) => setNewAccountName(e.target.value)}
                placeholder="Enter account name"
                className="bg-gray-700 border-emerald-500/30 text-white"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={createVirtualAccount}
                disabled={isCreating}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                {isCreating ? 'Creating...' : 'Create Virtual Account'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {virtualAccounts.map((account) => (
          <Card key={account.id} className="bg-gray-800 border-emerald-500/30">
            <CardHeader>
              <CardTitle className="text-emerald-400 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  {account.name}
                </div>
                <div className="flex gap-2">
                  <Badge className={account.status === 'active' ? 'bg-green-600' : 'bg-red-600'}>
                    {account.status}
                  </Badge>
                  <Badge className={account.processingEnabled ? 'bg-blue-600' : 'bg-gray-600'}>
                    {account.processingEnabled ? 'Processing ON' : 'Processing OFF'}
                  </Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Virtual Account:</span>
                  <span className="text-emerald-400 font-mono">{account.virtualNumber}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Routing:</span>
                  <span className="text-emerald-400 font-mono">{account.routingNumber}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Balance:</span>
                  <span className="text-emerald-400 font-bold">
                    ${account.balance.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Linked Account:</span>
                  <span className="text-blue-400 text-sm">{account.linkedMainAccount}</span>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button
                  onClick={() => copyAccountInfo(account)}
                  variant="outline"
                  size="sm"
                  className="flex-1 border-emerald-500/30 text-emerald-400 hover:bg-emerald-900/20"
                >
                  <Copy className="h-3 w-3 mr-1" />
                  Copy Info
                </Button>
                <Button
                  onClick={() => toggleProcessing(account.id)}
                  size="sm"
                  className={`flex-1 ${
                    account.processingEnabled 
                      ? 'bg-red-600 hover:bg-red-700' 
                      : 'bg-green-600 hover:bg-green-700'
                  }`}
                >
                  <Zap className="h-3 w-3 mr-1" />
                  {account.processingEnabled ? 'Disable' : 'Enable'} Processing
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default VirtualAccountManager;