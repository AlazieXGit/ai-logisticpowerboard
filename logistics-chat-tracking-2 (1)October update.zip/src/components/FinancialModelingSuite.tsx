import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, Calculator, BarChart3, PieChart, Target } from 'lucide-react';

const FinancialModelingSuite: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState('revenue');

  const revenueData = {
    currentRevenue: 2450000,
    projectedGrowth: 35,
    quarterlyTargets: [650000, 720000, 850000, 980000],
    platformFees: 245000,
    adminFees: 24500
  };

  const investmentModels = [
    { name: 'AI Robotics Investment', amount: 500000, roi: 45, timeline: '18 months' },
    { name: 'Banking Platform Expansion', amount: 750000, roi: 38, timeline: '24 months' },
    { name: 'Logistics Automation', amount: 300000, roi: 52, timeline: '12 months' }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/30 border-emerald-500">
        <CardHeader>
          <CardTitle className="text-emerald-400 flex items-center gap-2">
            <Calculator className="h-6 w-6" />
            Financial Modeling Suite - Advanced Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedModel} onValueChange={setSelectedModel}>
            <TabsList className="grid grid-cols-4 bg-gray-700">
              <TabsTrigger value="revenue">Revenue Models</TabsTrigger>
              <TabsTrigger value="investment">Investment Analysis</TabsTrigger>
              <TabsTrigger value="risk">Risk Assessment</TabsTrigger>
              <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
            </TabsList>

            <TabsContent value="revenue" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-emerald-900/20 border-emerald-600">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-emerald-300 text-sm">Current Revenue</p>
                        <p className="text-2xl font-bold text-white">
                          ${revenueData.currentRevenue.toLocaleString()}
                        </p>
                      </div>
                      <DollarSign className="h-8 w-8 text-emerald-400" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-blue-900/20 border-blue-600">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-300 text-sm">Platform Fees (10%)</p>
                        <p className="text-2xl font-bold text-white">
                          ${revenueData.platformFees.toLocaleString()}
                        </p>
                      </div>
                      <PieChart className="h-8 w-8 text-blue-400" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-purple-900/20 border-purple-600">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-300 text-sm">Admin Integration Fees</p>
                        <p className="text-2xl font-bold text-white">
                          ${revenueData.adminFees.toLocaleString()}
                        </p>
                      </div>
                      <Target className="h-8 w-8 text-purple-400" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gray-900/50">
                <CardHeader>
                  <CardTitle className="text-white">Quarterly Revenue Projections</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-4 gap-4">
                    {revenueData.quarterlyTargets.map((target, index) => (
                      <div key={index} className="text-center">
                        <Badge className="bg-emerald-600 mb-2">Q{index + 1} 2025</Badge>
                        <p className="text-xl font-bold text-white">${target.toLocaleString()}</p>
                        <p className="text-sm text-gray-400">+{Math.round(Math.random() * 15 + 10)}% growth</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="investment" className="space-y-4">
              <div className="space-y-4">
                {investmentModels.map((investment, index) => (
                  <Card key={index} className="bg-gray-900/50 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-white font-semibold">{investment.name}</h3>
                          <p className="text-gray-400">Investment: ${investment.amount.toLocaleString()}</p>
                        </div>
                        <div className="text-right">
                          <Badge className="bg-green-600 mb-1">{investment.roi}% ROI</Badge>
                          <p className="text-sm text-gray-400">{investment.timeline}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="risk" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-red-900/20 border-red-600">
                  <CardHeader>
                    <CardTitle className="text-red-400">Risk Factors</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-gray-300">
                      <li>• Market volatility: Medium risk</li>
                      <li>• Regulatory changes: Low risk</li>
                      <li>• Technology disruption: High opportunity</li>
                      <li>• Competition: Medium risk</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="bg-green-900/20 border-green-600">
                  <CardHeader>
                    <CardTitle className="text-green-400">Mitigation Strategies</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-gray-300">
                      <li>• Diversified revenue streams</li>
                      <li>• Automated compliance monitoring</li>
                      <li>• Continuous innovation pipeline</li>
                      <li>• Strategic partnerships</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="forecasting" className="space-y-4">
              <Card className="bg-gray-900/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    5-Year Financial Forecast
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-5 gap-4">
                    {[2025, 2026, 2027, 2028, 2029].map((year, index) => (
                      <div key={year} className="text-center">
                        <Badge className="bg-blue-600 mb-2">{year}</Badge>
                        <p className="text-lg font-bold text-white">
                          ${(2450000 * Math.pow(1.35, index)).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </p>
                        <p className="text-sm text-gray-400">
                          {index === 0 ? 'Current' : `+${(Math.pow(1.35, index) * 100 - 100).toFixed(0)}%`}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancialModelingSuite;