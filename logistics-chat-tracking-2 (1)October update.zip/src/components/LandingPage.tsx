import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Truck, Brain, BarChart3, MessageSquare, Shield, Zap, ArrowRight, Lock, CreditCard, Building2, Sparkles, X, ChevronDown, ChevronUp } from 'lucide-react';

import AuthModal from './AuthModal';
import SuperAdminAuth from './SuperAdminAuth';
import SynergyAILogin from './SynergyAILogin';

const LandingPage: React.FC = () => {
  const [authModal, setAuthModal] = useState<'login' | 'signup' | null>(null);
  const [showSuperAdmin, setShowSuperAdmin] = useState(false);
  const [showSynergyAI, setShowSynergyAI] = useState(false);
  const [miniAdminExpanded, setMiniAdminExpanded] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');

  const handleMiniAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminEmail && adminPassword) {
      setShowSuperAdmin(true);
    }
  };

  const features = [
    {
      icon: <Building2 className="h-8 w-8" />,
      title: "Alazie Express Banking",
      description: "Enterprise banking automation with AI-powered transaction processing at alazie.express"
    },
    {
      icon: <Brain className="h-8 w-8" />,
      title: "Alaziel AI Intelligence",
      description: "Advanced AI analytics for banking, logistics, and business optimization on alazie.express"
    },
    {
      icon: <CreditCard className="h-8 w-8" />,
      title: "Express Payment Processing",
      description: "Secure payment automation with fraud detection and smart routing via alazie.express"
    },
    {
      icon: <Truck className="h-8 w-8" />,
      title: "Express Logistics",
      description: "Real-time load tracking and route optimization powered by alazie.express platform"
    },
    {
      icon: <MessageSquare className="h-8 w-8" />,
      title: "Alazie Express Support",
      description: "24/7 intelligent support for banking, logistics, and business operations"
    },
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "Express Analytics",
      description: "Comprehensive reporting and real-time data visualization on alazie.express"
    },
    {
      icon: <Sparkles className="h-8 w-8" />,
      title: "SYNERGY AI Platform",
      description: "Next-generation AI platform with advanced automation, analytics, and intelligent business solutions"
    }
  ];

  if (showSuperAdmin) {
    return <SuperAdminAuth onAuthenticated={(auth) => { if(auth) console.log('Dashboard access granted'); setShowSuperAdmin(false); }} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-teal-900">
      {/* Minimized Super Admin Login - Top Left Corner */}
      <div className="fixed top-4 left-4 z-50">
        <Card className={`bg-slate-900/95 border-red-500/50 backdrop-blur-sm transition-all duration-300 ${miniAdminExpanded ? 'w-72' : 'w-auto'}`}>
          <CardHeader className="p-3 cursor-pointer" onClick={() => setMiniAdminExpanded(!miniAdminExpanded)}>
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4 text-red-400" />
                <span className="text-sm font-semibold text-red-400">Admin</span>
              </div>
              {miniAdminExpanded ? (
                <ChevronUp className="h-4 w-4 text-red-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-red-400" />
              )}
            </div>
          </CardHeader>
          
          {miniAdminExpanded && (
            <CardContent className="p-3 pt-0">
              <form onSubmit={handleMiniAdminLogin} className="space-y-2">
                <Input
                  type="email"
                  placeholder="Admin Email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="h-8 text-sm bg-slate-800 border-red-500/30 text-white"
                  required
                />
                <Input
                  type="password"
                  placeholder="Password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="h-8 text-sm bg-slate-800 border-red-500/30 text-white"
                  required
                />
                <Button 
                  type="submit" 
                  size="sm" 
                  className="w-full bg-red-600 hover:bg-red-700 text-white h-8 text-xs"
                >
                  <Lock className="mr-1 h-3 w-3" /> Login
                </Button>
              </form>
            </CardContent>
          )}
        </Card>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="text-center">
          <div className="mx-auto h-32 w-32 bg-gradient-to-br from-emerald-400 to-teal-400 rounded-full flex items-center justify-center mb-6">
            <Brain className="h-16 w-16 text-white" />
          </div>
          
          <h1 className="text-7xl font-bold text-white mb-6">
            <span className="bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent">
              Alazie Express
            </span>
          </h1>
          
          <p className="text-2xl text-gray-300 mb-4 max-w-4xl mx-auto">
            Revolutionary AI-powered business platform at alazie.express - integrating banking, logistics, and intelligent automation for comprehensive enterprise solutions.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Badge className="bg-emerald-600/20 text-emerald-300 px-4 py-2">
              <Building2 className="h-4 w-4 mr-2" />
              alazie.express Banking
            </Badge>
            <Badge className="bg-teal-600/20 text-teal-300 px-4 py-2">
              <Truck className="h-4 w-4 mr-2" />
              Express Logistics
            </Badge>
            <Badge className="bg-cyan-600/20 text-cyan-300 px-4 py-2">
              <Brain className="h-4 w-4 mr-2" />
              AI-Powered
            </Badge>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-emerald-600 to-teal-600" onClick={() => setAuthModal('signup')}>
              Get Started Free <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" onClick={() => setAuthModal('login')}>
              Sign In
            </Button>
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600" onClick={() => setShowSynergyAI(true)}>
              <Sparkles className="mr-2 h-5 w-5" /> SYNERGY AI
            </Button>
            <Button variant="ghost" size="lg" onClick={() => console.log('Demo requested')}>
              View Demo
            </Button>
          </div>
        </div>
      </div>

      <div className="py-20 bg-black/30">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-white mb-16 text-center">
            <span className="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              alazie.express Solutions
            </span>
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-slate-800/50 border-emerald-500/20">
                <CardHeader className="text-center">
                  <div className="text-emerald-400 mb-4 flex justify-center">{feature.icon}</div>
                  <CardTitle className="text-white">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-300 text-center">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {authModal && <AuthModal mode={authModal} onClose={() => setAuthModal(null)} onSwitch={setAuthModal} />}
      {showSynergyAI && <SynergyAILogin onLogin={(userType) => { console.log('Synergy AI login:', userType); setShowSynergyAI(false); }} onClose={() => setShowSynergyAI(false)} />}
    </div>
  );
};

export default LandingPage;
