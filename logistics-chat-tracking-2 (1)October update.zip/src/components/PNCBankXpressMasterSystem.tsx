import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, CreditCard, Link, Clock, Zap, CheckCircle } from 'lucide-react';

export const PNCBankXpressMasterSystem: React.FC = () => {
  const [stripeConnected, setStripeConnected] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [internalPaymentActive, setInternalPaymentActive] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const connectStripe = () => {
    setStripeConnected(true);
    setInternalPaymentActive(true);
  };

  const formatDateTime = (date: Date) => {
    return date.toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-900 to-indigo-900 border-blue-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            PNC Bank - Xpress AI MASTER System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-blue-500 bg-blue-900/20">
            <Clock className="h-4 w-4" />
            <AlertDescription className="text-blue-300">
              Master Account System - {formatDateTime(currentTime)}
            </AlertDescription>
          </Alert>

          <Card className="bg-black/40 border-blue-400">
            <CardContent className="p-6">
              <div className="text-center space-y-3">
                <h2 className="text-white text-2xl font-bold">PNC Bank Master Account</h2>
                <div className="text-blue-400 text-lg">
                  Account: 026009593-****XXXX
                </div>
                <div className="text-blue-300">
                  Routing: 054000030
                </div>
                <Badge className={stripeConnected ? "bg-green-600" : "bg-yellow-600"}>
                  {stripeConnected ? "STRIPE CONNECTED" : "AWAITING CONNECTION"}
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="connection" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="connection" className="text-white">Stripe Connection</TabsTrigger>
              <TabsTrigger value="virtual" className="text-white">Virtual Accounts</TabsTrigger>
              <TabsTrigger value="internal" className="text-white">Internal Payment</TabsTrigger>
              <TabsTrigger value="details" className="text-white">Account Details</TabsTrigger>
            </TabsList>

            <TabsContent value="connection" className="space-y-4">
              <Card className="bg-black/40 border-green-500">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Link className="h-5 w-5" />
                    Stripe Integration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-green-500 bg-green-900/20">
                    <Zap className="h-4 w-4" />
                    <AlertDescription className="text-green-300">
                      Connect PNC Bank with Stripe for external virtual account fund transfers
                    </AlertDescription>
                  </Alert>
                  
                  <div className="space-y-3">
                    <Button 
                      onClick={connectStripe}
                      className="w-full bg-green-600 hover:bg-green-700"
                      disabled={stripeConnected}
                    >
                      {stripeConnected ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Stripe Connected
                        </>
                      ) : (
                        <>
                          <Link className="h-4 w-4 mr-2" />
                          Connect to Stripe
                        </>
                      )}
                    </Button>
                    
                    {stripeConnected && (
                      <div className="bg-green-900/20 p-3 rounded border border-green-500">
                        <p className="text-green-300 text-sm">
                          ✓ Stripe integration active
                        </p>
                        <p className="text-green-300 text-sm">
                          ✓ External virtual accounts enabled
                        </p>
                        <p className="text-green-300 text-sm">
                          ✓ Fund transfers operational
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="virtual" className="space-y-4">
              <Card className="bg-black/40 border-purple-500">
                <CardHeader>
                  <CardTitle className="text-white">External Virtual Accounts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-white font-semibold">Main Virtual Account</p>
                        <p className="text-purple-400 font-mono">ACC: 35563935267</p>
                      </div>
                      <Badge className={stripeConnected ? "bg-green-600" : "bg-gray-600"}>
                        {stripeConnected ? "CONNECTED" : "PENDING"}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-white font-semibold">Reserve Account</p>
                        <p className="text-blue-400 font-mono">ACC: 5563935275</p>
                      </div>
                      <Badge className={stripeConnected ? "bg-green-600" : "bg-gray-600"}>
                        {stripeConnected ? "CONNECTED" : "PENDING"}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-white font-semibold">Combined Account</p>
                        <p className="text-green-400 font-mono">ACC: 5563935283</p>
                      </div>
                      <Badge className={stripeConnected ? "bg-green-600" : "bg-gray-600"}>
                        {stripeConnected ? "CONNECTED" : "PENDING"}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="internal" className="space-y-4">
              <Card className="bg-black/40 border-orange-500">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Internal Payment System
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-orange-500 bg-orange-900/20">
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription className="text-orange-300">
                      Internal payment system {internalPaymentActive ? 'ACTIVE' : 'INACTIVE'} - Connected with external virtual accounts
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="bg-orange-600 hover:bg-orange-700" disabled={!stripeConnected}>
                      Process Internal Transfer
                    </Button>
                    <Button className="bg-blue-600 hover:bg-blue-700" disabled={!stripeConnected}>
                      External Account Transfer
                    </Button>
                    <Button className="bg-purple-600 hover:bg-purple-700" disabled={!stripeConnected}>
                      Virtual Account Sync
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700" disabled={!stripeConnected}>
                      Payment Processing
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="details" className="space-y-4">
              <Card className="bg-black/40 border-yellow-500">
                <CardHeader>
                  <CardTitle className="text-white">Master Account Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Bank Name</span>
                      <span className="text-yellow-400">PNC Bank</span>
                    </div>
                  </div>
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Account Type</span>
                      <span className="text-yellow-400">Business Master</span>
                    </div>
                  </div>
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Routing Number</span>
                      <span className="text-yellow-400">054000030</span>
                    </div>
                  </div>
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Last Updated</span>
                      <span className="text-yellow-400">{formatDateTime(currentTime)}</span>
                    </div>
                  </div>
                  <div className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between">
                      <span className="text-white">Status</span>
                      <span className="text-green-400">ACTIVE & OPERATIONAL</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PNCBankXpressMasterSystem;