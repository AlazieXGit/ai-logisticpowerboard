import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, DollarSign, ArrowRight, CheckCircle, AlertTriangle } from 'lucide-react';

interface RevenueStream {
  name: string;
  amount: number;
  lastTransfer: string;
  status: 'pending' | 'processing' | 'completed';
}

export default function AutomatedRevenueTransfer() {
  const [revenueStreams, setRevenueStreams] = useState<RevenueStream[]>([
    { name: 'Total Revenue', amount: 2847392.50, lastTransfer: '2025-01-07 00:00:00', status: 'completed' },
    { name: 'Subscription Revenue', amount: 156780.25, lastTransfer: '2025-01-07 00:00:00', status: 'completed' },
    { name: 'Platform Fees', amount: 89432.75, lastTransfer: '2025-01-07 00:00:00', status: 'completed' },
    { name: 'AI Development Funds', amount: 234567.80, lastTransfer: '2025-01-07 00:00:00', status: 'completed' },
    { name: 'TMS Revenue', amount: 445623.90, lastTransfer: '2025-01-07 00:00:00', status: 'completed' },
    { name: 'Auto Booking Revenue', amount: 678945.30, lastTransfer: '2025-01-07 00:00:00', status: 'completed' }
  ]);

  const [nextTransfer, setNextTransfer] = useState('2025-01-08 00:00:00');
  const [transferProgress, setTransferProgress] = useState(0);
  const [isTransferring, setIsTransferring] = useState(false);

  const totalRevenue = revenueStreams.reduce((sum, stream) => sum + stream.amount, 0);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const transferTime = new Date(nextTransfer);
      const timeUntilTransfer = transferTime.getTime() - now.getTime();
      
      if (timeUntilTransfer <= 0) {
        initiateTransfer();
      } else {
        const progress = ((24 * 60 * 60 * 1000 - timeUntilTransfer) / (24 * 60 * 60 * 1000)) * 100;
        setTransferProgress(Math.max(0, Math.min(100, progress)));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [nextTransfer]);

  const initiateTransfer = async () => {
    setIsTransferring(true);
    
    // Simulate transfer process
    for (let i = 0; i < revenueStreams.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setRevenueStreams(prev => prev.map((stream, index) => 
        index === i ? { ...stream, status: 'processing' as const } : stream
      ));
      
      await new Promise(resolve => setTimeout(resolve, 3000));
      setRevenueStreams(prev => prev.map((stream, index) => 
        index === i ? { 
          ...stream, 
          status: 'completed' as const,
          lastTransfer: new Date().toISOString().slice(0, 19).replace('T', ' '),
          amount: 0
        } : stream
      ));
    }

    // Set next transfer time (24 hours from now)
    const nextTime = new Date();
    nextTime.setHours(nextTime.getHours() + 24);
    setNextTransfer(nextTime.toISOString().slice(0, 19).replace('T', ' '));
    setIsTransferring(false);
    setTransferProgress(0);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'processing': return 'bg-blue-500';
      case 'completed': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Automated 24-Hour Revenue Transfer System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                ${totalRevenue.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Total Pending Revenue</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold">
                {nextTransfer}
              </div>
              <div className="text-sm text-gray-600">Next Transfer Time</div>
            </div>
            <div className="text-center">
              <Badge className="bg-blue-600">
                Alazie LLC Primary Account
              </Badge>
              <div className="text-sm text-gray-600 mt-1">Transfer Destination</div>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Transfer Progress</span>
              <span className="text-sm text-gray-600">{transferProgress.toFixed(1)}%</span>
            </div>
            <Progress value={transferProgress} className="h-2" />
          </div>

          <div className="space-y-3">
            {revenueStreams.map((stream, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <div>
                    <div className="font-medium">{stream.name}</div>
                    <div className="text-sm text-gray-600">
                      Last Transfer: {stream.lastTransfer}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="font-bold text-green-600">
                      ${stream.amount.toLocaleString()}
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-gray-400" />
                  <Badge className={getStatusColor(stream.status)}>
                    {stream.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>

          {isTransferring && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2 text-blue-700">
                <AlertTriangle className="h-4 w-4" />
                <span className="font-medium">Transfer in Progress</span>
              </div>
              <div className="text-sm text-blue-600 mt-1">
                Processing automated revenue transfer to Alazie LLC primary account...
              </div>
            </div>
          )}

          <div className="mt-6 flex gap-3">
            <Button 
              onClick={initiateTransfer} 
              disabled={isTransferring}
              className="bg-green-600 hover:bg-green-700"
            >
              {isTransferring ? 'Transferring...' : 'Manual Transfer Now'}
            </Button>
            <Button variant="outline">
              View Transfer History
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}