import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Clock, AlertTriangle } from 'lucide-react';

interface SessionTimeoutManagerProps {
  isSystemActive: boolean;
  onSessionExpired: () => void;
}

const SessionTimeoutManager: React.FC<SessionTimeoutManagerProps> = ({ 
  isSystemActive, 
  onSessionExpired 
}) => {
  const [timeRemaining, setTimeRemaining] = useState(3600); // 1 hour in seconds
  const [isActive, setIsActive] = useState(false);
  const [showWarning, setShowWarning] = useState(false);

  useEffect(() => {
    if (isSystemActive && !isActive) {
      setIsActive(true);
      setTimeRemaining(3600);
      setShowWarning(false);
    } else if (!isSystemActive) {
      setIsActive(false);
      setTimeRemaining(3600);
      setShowWarning(false);
    }
  }, [isSystemActive, isActive]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isActive && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          const newTime = prev - 1;
          
          // Show warning at 2 minutes remaining
          if (newTime === 120) {
            setShowWarning(true);
          }
          
          // Session expired
          if (newTime <= 0) {
            setIsActive(false);
            onSessionExpired();
            return 0;
          }
          
          return newTime;
        });
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, timeRemaining, onSessionExpired]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = (timeRemaining / 3600) * 100;

  if (!isSystemActive) {
    return (
      <Card className="bg-black/80 border-gray-500">
        <CardHeader>
          <CardTitle className="text-gray-400 flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Session Manager - System Inactive
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert className="border-gray-500 bg-gray-900/20">
            <AlertDescription className="text-gray-400">
              System is currently inactive. No preview sessions available.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-black/80 border-lime-500">
      <CardHeader>
        <CardTitle className="text-lime-400 flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Live Preview Session Timer
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {showWarning && (
          <Alert className="border-yellow-500 bg-yellow-900/20">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-yellow-300">
              ⚠️ Session expires in 2 minutes! System will close preview access.
            </AlertDescription>
          </Alert>
        )}
        
        <div className="text-center">
          <div className="text-3xl font-mono font-bold text-lime-400 mb-2">
            {formatTime(timeRemaining)}
          </div>
          <div className="text-sm text-gray-400 mb-4">
            Time remaining for preview access
          </div>
          
          <Progress 
            value={progressPercentage} 
            className="w-full h-3 bg-gray-800"
          />
        </div>
        
        <div className="text-center text-xs text-gray-500">
          Preview sessions automatically close after 1 hour
        </div>
      </CardContent>
    </Card>
  );
};

export default SessionTimeoutManager;