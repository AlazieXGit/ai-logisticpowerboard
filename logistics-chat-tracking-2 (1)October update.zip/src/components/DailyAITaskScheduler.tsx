import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, Bot, Calendar, Clock, CheckCircle, Play } from 'lucide-react';

interface AITask {
  id: string;
  name: string;
  status: 'active' | 'completed' | 'pending' | 'restarting';
  progress: number;
  hoursRemaining: number;
  lastRestart: string;
}

export default function DailyAITaskScheduler() {
  const [aiTasks, setAiTasks] = useState<AITask[]>([
    { id: '1', name: 'Load Matching AI', status: 'active', progress: 75, hoursRemaining: 6, lastRestart: '2025-01-07 00:00:00' },
    { id: '2', name: 'Revenue Optimization AI', status: 'active', progress: 82, hoursRemaining: 4.5, lastRestart: '2025-01-07 00:00:00' },
    { id: '3', name: 'Booking Automation AI', status: 'active', progress: 68, hoursRemaining: 7.8, lastRestart: '2025-01-07 00:00:00' },
    { id: '4', name: 'Performance Analytics AI', status: 'active', progress: 91, hoursRemaining: 2.2, lastRestart: '2025-01-07 00:00:00' },
    { id: '5', name: 'TMS Operations AI', status: 'active', progress: 55, hoursRemaining: 10.5, lastRestart: '2025-01-07 00:00:00' },
    { id: '6', name: 'Banking Automation AI', status: 'active', progress: 77, hoursRemaining: 5.5, lastRestart: '2025-01-07 00:00:00' }
  ]);

  const [nextRestart, setNextRestart] = useState('2025-01-08 00:00:00');
  const [isRestarting, setIsRestarting] = useState(false);
  const [systemUptime, setSystemUptime] = useState(23.5);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const restartTime = new Date(nextRestart);
      const timeUntilRestart = restartTime.getTime() - now.getTime();
      
      if (timeUntilRestart <= 0) {
        initiateRestart();
      }

      // Update task progress
      setAiTasks(prev => prev.map(task => ({
        ...task,
        progress: Math.min(100, task.progress + Math.random() * 2),
        hoursRemaining: Math.max(0, task.hoursRemaining - 0.01)
      })));

      setSystemUptime(prev => Math.min(24, prev + 0.01));
    }, 5000);

    return () => clearInterval(interval);
  }, [nextRestart]);

  const initiateRestart = async () => {
    setIsRestarting(true);
    
    // Restart each AI task
    for (let i = 0; i < aiTasks.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setAiTasks(prev => prev.map((task, index) => 
        index === i ? { ...task, status: 'restarting' as const } : task
      ));
      
      await new Promise(resolve => setTimeout(resolve, 2000));
      setAiTasks(prev => prev.map((task, index) => 
        index === i ? { 
          ...task, 
          status: 'active' as const,
          progress: 0,
          hoursRemaining: 24,
          lastRestart: new Date().toISOString().slice(0, 19).replace('T', ' ')
        } : task
      ));
    }

    // Set next restart time (24 hours from now)
    const nextTime = new Date();
    nextTime.setHours(nextTime.getHours() + 24);
    setNextRestart(nextTime.toISOString().slice(0, 19).replace('T', ' '));
    setIsRestarting(false);
    setSystemUptime(0);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'restarting': return 'bg-blue-500';
      case 'pending': return 'bg-yellow-500';
      case 'completed': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Daily AI Task Scheduler & Restart System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {aiTasks.filter(t => t.status === 'active').length}
              </div>
              <div className="text-sm text-gray-600">Active AI Tasks</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold">
                {nextRestart}
              </div>
              <div className="text-sm text-gray-600">Next Restart</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-green-600">
                {systemUptime.toFixed(1)}h
              </div>
              <div className="text-sm text-gray-600">System Uptime</div>
            </div>
            <div className="text-center">
              <Badge className="bg-purple-600">
                300 Hour Cycle
              </Badge>
              <div className="text-sm text-gray-600 mt-1">Aggressive Mode</div>
            </div>
          </div>

          <div className="space-y-4">
            {aiTasks.map((task) => (
              <div key={task.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Bot className="h-5 w-5 text-blue-600" />
                    <div>
                      <div className="font-medium">{task.name}</div>
                      <div className="text-sm text-gray-600">
                        Last Restart: {task.lastRestart} | {task.hoursRemaining.toFixed(1)}h remaining
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className={getStatusColor(task.status)}>
                      {task.status}
                    </Badge>
                    <Button size="sm" variant="outline">
                      <Play className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{task.progress.toFixed(1)}%</span>
                  </div>
                  <Progress value={task.progress} className="h-2" />
                </div>
              </div>
            ))}
          </div>

          {isRestarting && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2 text-blue-700">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span className="font-medium">Daily Restart in Progress</span>
              </div>
              <div className="text-sm text-blue-600 mt-1">
                Restarting all AI tasks for aggressive 300-hour booking cycle...
              </div>
            </div>
          )}

          <div className="mt-6 flex gap-3">
            <Button 
              onClick={initiateRestart} 
              disabled={isRestarting}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isRestarting ? 'Restarting...' : 'Manual Restart Now'}
            </Button>
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Schedule Settings
            </Button>
            <Button variant="outline">
              <Clock className="h-4 w-4 mr-2" />
              Task History
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}