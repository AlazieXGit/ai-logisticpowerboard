import React, { useEffect, useState } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Ban, Shield } from 'lucide-react';

interface IPAccessValidatorProps {
  children: React.ReactNode;
}

const IPAccessValidator: React.FC<IPAccessValidatorProps> = ({ children }) => {
  const [isBlocked, setIsBlocked] = useState(false);
  const [userIP, setUserIP] = useState<string>('');

  useEffect(() => {
    const checkIPAccess = async () => {
      try {
        // Get user's IP with error handling
        const response = await fetch('https://api.ipify.org?format=json');
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const currentIP = data.ip;
        setUserIP(currentIP);

        // Check blocked IPs list
        const blockedIPs = [
          '192.168.1.100', // Target IP to block
          // Add more IPs as needed
        ];

        // Also check localStorage for dynamically blocked IPs
        try {
          const storedBlocked = localStorage.getItem('blockedIPs');
          if (storedBlocked) {
            const parsed = JSON.parse(storedBlocked);
            const dynamicBlocked = parsed.map((item: any) => item.ip);
            blockedIPs.push(...dynamicBlocked);
          }
        } catch (storageError) {
          console.warn('Error reading blocked IPs from localStorage:', storageError);
        }

        if (blockedIPs.includes(currentIP)) {
          setIsBlocked(true);
          // Log the blocked access attempt
          console.warn(`Blocked access attempt from IP: ${currentIP}`);
        }
      } catch (error) {
        console.error('Error checking IP access:', error);
        // Don't block on network errors - allow access
        setUserIP('Unknown');
        setIsBlocked(false);
      }
    };

    checkIPAccess();
  }, []);

  if (isBlocked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-900 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full space-y-6 text-center">
          <div className="bg-red-900/20 border border-red-500 rounded-lg p-8">
            <Ban className="h-24 w-24 mx-auto mb-6 text-red-400" />
            <h1 className="text-3xl font-bold text-red-400 mb-4">
              ACCESS DENIED
            </h1>
            <Alert className="border-red-500 bg-red-900/40 mb-6">
              <Shield className="h-4 w-4" />
              <AlertDescription className="text-red-300">
                Your IP address ({userIP}) has been blocked from accessing this system.
              </AlertDescription>
            </Alert>
            <div className="text-gray-300 space-y-2">
              <p>🚫 This account has been immediately locked out</p>
              <p>⚠️ All access attempts are logged and monitored</p>
              <p>🔒 Contact system administrator for assistance</p>
            </div>
            <div className="mt-8 text-xs text-gray-500">
              Incident logged: {new Date().toLocaleString()}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default IPAccessValidator;