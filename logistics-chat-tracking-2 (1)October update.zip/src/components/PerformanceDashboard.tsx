import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BarChart3, TrendingUp, Zap, Target, Clock, DollarSign, Activity } from 'lucide-react';

interface PerformanceMetrics {
  autoBookingPerformance: number;
  negotiationSpeed: number;
  revenueBoost: number;
  completionRate: number;
  aiOptimization: number;
  systemEfficiency: number;
  totalTransactions: number;
  avgResponseTime: number;
}

const PerformanceDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    autoBookingPerformance: 800, // 200x4
    negotiationSpeed: 20000, // 100x200
    revenueBoost: 450,
    completionRate: 98.7,
    aiOptimization: 96.3,
    systemEfficiency: 94.8,
    totalTransactions: 15847,
    avgResponseTime: 0.023
  });

  const [realTimeData, setRealTimeData] = useState<number[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate real-time performance updates
      setMetrics(prev => ({
        autoBookingPerformance: prev.autoBookingPerformance + Math.random() * 100 - 50,
        negotiationSpeed: prev.negotiationSpeed + Math.random() * 2000 - 1000,
        revenueBoost: prev.revenueBoost + Math.random() * 20 - 10,
        completionRate: Math.min(99.9, prev.completionRate + Math.random() * 0.3 - 0.15),
        aiOptimization: Math.min(99.5, prev.aiOptimization + Math.random() * 0.5 - 0.25),
        systemEfficiency: Math.min(99.0, prev.systemEfficiency + Math.random() * 0.4 - 0.2),
        totalTransactions: prev.totalTransactions + Math.floor(Math.random() * 10),
        avgResponseTime: Math.max(0.01, prev.avgResponseTime + Math.random() * 0.01 - 0.005)
      }));

      // Update real-time chart data
      setRealTimeData(prev => {
        const newData = [...prev, Math.random() * 100 + 50];
        return newData.slice(-20); // Keep last 20 data points
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const performanceCards = [
    {
      title: 'Auto Booking Performance',
      value: `${metrics.autoBookingPerformance.toFixed(0)}x`,
      target: '800x (200x4)',
      icon: <Zap className="h-5 w-5" />,
      color: 'text-blue-400',
      bgColor: 'bg-blue-900/20',
      progress: Math.min(100, (metrics.autoBookingPerformance / 800) * 100)
    },
    {
      title: 'Negotiation Speed',
      value: `${metrics.negotiationSpeed.toFixed(0)}x`,
      target: '20,000x (100x200)',
      icon: <Target className="h-5 w-5" />,
      color: 'text-green-400',
      bgColor: 'bg-green-900/20',
      progress: Math.min(100, (metrics.negotiationSpeed / 20000) * 100)
    },
    {
      title: 'Revenue Boost',
      value: `${metrics.revenueBoost.toFixed(1)}%`,
      target: '450% Target',
      icon: <TrendingUp className="h-5 w-5" />,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-900/20',
      progress: Math.min(100, (metrics.revenueBoost / 450) * 100)
    },
    {
      title: 'Completion Rate',
      value: `${metrics.completionRate.toFixed(1)}%`,
      target: '99% Target',
      icon: <Activity className="h-5 w-5" />,
      color: 'text-purple-400',
      bgColor: 'bg-purple-900/20',
      progress: metrics.completionRate
    },
    {
      title: 'AI Optimization',
      value: `${metrics.aiOptimization.toFixed(1)}%`,
      target: '95% Target',
      icon: <BarChart3 className="h-5 w-5" />,
      color: 'text-pink-400',
      bgColor: 'bg-pink-900/20',
      progress: metrics.aiOptimization
    },
    {
      title: 'System Efficiency',
      value: `${metrics.systemEfficiency.toFixed(1)}%`,
      target: '95% Target',
      icon: <Clock className="h-5 w-5" />,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-900/20',
      progress: metrics.systemEfficiency
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Performance Analytics Dashboard
          </CardTitle>
          <div className="flex gap-2">
            <Badge className="bg-green-600">OPTIMIZED 200x4</Badge>
            <Badge className="bg-blue-600">NEGOTIATION 100x200</Badge>
            <Badge className="bg-purple-600">REVENUE BOOST ACTIVE</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {performanceCards.map((card, index) => (
              <Card key={index} className={`${card.bgColor} border-gray-600`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`${card.color}`}>
                      {card.icon}
                    </div>
                    <Badge className="bg-gray-700 text-gray-300 text-xs">
                      LIVE
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">{card.title}</div>
                    <div className={`text-2xl font-bold ${card.color}`}>
                      {card.value}
                    </div>
                    <div className="text-xs text-gray-400">{card.target}</div>
                    
                    <div className="space-y-1">
                      <Progress 
                        value={card.progress} 
                        className="h-2"
                      />
                      <div className="text-xs text-gray-400 text-right">
                        {card.progress.toFixed(1)}% of target
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-900/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white text-lg">System Statistics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between">
              <span className="text-gray-300">Total Transactions:</span>
              <span className="text-green-400 font-bold">{metrics.totalTransactions.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Avg Response Time:</span>
              <span className="text-blue-400 font-bold">{metrics.avgResponseTime.toFixed(3)}s</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Revenue Multiplier:</span>
              <span className="text-yellow-400 font-bold">{(metrics.revenueBoost / 100).toFixed(2)}x</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Optimization Level:</span>
              <span className="text-purple-400 font-bold">MAXIMUM</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white text-lg">Real-Time Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-32 flex items-end justify-between gap-1">
              {realTimeData.map((value, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-t from-blue-600 to-blue-400 rounded-t"
                  style={{
                    height: `${value}%`,
                    width: `${100 / realTimeData.length}%`
                  }}
                />
              ))}
            </div>
            <div className="text-center text-sm text-gray-400 mt-2">
              Live Performance Metrics
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PerformanceDashboard;