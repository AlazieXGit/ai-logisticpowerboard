import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Plus, Edit3, Trash2, Search, Building2, UserCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface VendorContractor {
  id: string;
  name: string;
  type: 'vendor' | 'contractor';
  email: string;
  phone: string;
  company: string;
  services: string;
  rate: number;
  status: 'active' | 'inactive' | 'pending';
  created_at: string;
}

const VendorContractorManager: React.FC = () => {
  const [vendors, setVendors] = useState<VendorContractor[]>([]);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    type: 'vendor' as 'vendor' | 'contractor',
    email: '',
    phone: '',
    company: '',
    services: '',
    rate: 0,
    status: 'active' as 'active' | 'inactive' | 'pending'
  });

  useEffect(() => {
    loadVendors();
  }, []);

  const loadVendors = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { action: 'get_vendors_contractors' }
      });
      if (data?.vendors) {
        setVendors(data.vendors);
      }
    } catch (error) {
      console.error('Error loading vendors:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const action = editingId ? 'update_vendor_contractor' : 'add_vendor_contractor';
      const { data, error } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action, 
          vendor: { ...formData, id: editingId },
          admin_id: 'super_admin'
        }
      });
      
      if (data?.success) {
        loadVendors();
        resetForm();
      }
    } catch (error) {
      console.error('Error saving vendor:', error);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { data } = await supabase.functions.invoke('banking-operations', {
        body: { 
          action: 'delete_vendor_contractor', 
          vendor_id: id,
          admin_id: 'super_admin'
        }
      });
      
      if (data?.success) {
        loadVendors();
      }
    } catch (error) {
      console.error('Error deleting vendor:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'vendor',
      email: '',
      phone: '',
      company: '',
      services: '',
      rate: 0,
      status: 'active'
    });
    setIsAddingNew(false);
    setEditingId(null);
  };

  const startEdit = (vendor: VendorContractor) => {
    setFormData({
      name: vendor.name,
      type: vendor.type,
      email: vendor.email,
      phone: vendor.phone,
      company: vendor.company,
      services: vendor.services,
      rate: vendor.rate,
      status: vendor.status
    });
    setEditingId(vendor.id);
    setIsAddingNew(true);
  };

  const filteredVendors = vendors.filter(v => 
    v.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Card className="bg-blue-900/20 border-blue-500/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Users className="h-5 w-5" />
            Vendor & Contractor Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
                <Input
                  placeholder="Search vendors/contractors..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-800 border-gray-600"
                />
              </div>
            </div>
            <Button 
              onClick={() => setIsAddingNew(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add New
            </Button>
          </div>

          {isAddingNew && (
            <Card className="mb-6 bg-gray-800/50 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">
                  {editingId ? 'Edit' : 'Add New'} {formData.type === 'vendor' ? 'Vendor' : 'Contractor'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Name</Label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="bg-gray-700 border-gray-600"
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Type</Label>
                    <Select value={formData.type} onValueChange={(value: 'vendor' | 'contractor') => setFormData({...formData, type: value})}>
                      <SelectTrigger className="bg-gray-700 border-gray-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="vendor">Vendor</SelectItem>
                        <SelectItem value="contractor">Contractor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-gray-300">Email</Label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="bg-gray-700 border-gray-600"
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Phone</Label>
                    <Input
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="bg-gray-700 border-gray-600"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Company</Label>
                    <Input
                      value={formData.company}
                      onChange={(e) => setFormData({...formData, company: e.target.value})}
                      className="bg-gray-700 border-gray-600"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Rate ($/hr)</Label>
                    <Input
                      type="number"
                      value={formData.rate}
                      onChange={(e) => setFormData({...formData, rate: parseFloat(e.target.value)})}
                      className="bg-gray-700 border-gray-600"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label className="text-gray-300">Services</Label>
                    <Textarea
                      value={formData.services}
                      onChange={(e) => setFormData({...formData, services: e.target.value})}
                      className="bg-gray-700 border-gray-600"
                      placeholder="Describe services provided..."
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Status</Label>
                    <Select value={formData.status} onValueChange={(value: 'active' | 'inactive' | 'pending') => setFormData({...formData, status: value})}>
                      <SelectTrigger className="bg-gray-700 border-gray-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2 flex gap-2">
                    <Button type="submit" className="bg-green-600 hover:bg-green-700">
                      {editingId ? 'Update' : 'Add'} {formData.type === 'vendor' ? 'Vendor' : 'Contractor'}
                    </Button>
                    <Button type="button" variant="outline" onClick={resetForm}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-4">
            {filteredVendors.map((vendor) => (
              <Card key={vendor.id} className="bg-gray-800/50 border-gray-600">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {vendor.type === 'vendor' ? 
                          <Building2 className="h-5 w-5 text-blue-400" /> : 
                          <UserCheck className="h-5 w-5 text-green-400" />
                        }
                        <h3 className="font-semibold text-white">{vendor.name}</h3>
                        <Badge className={vendor.type === 'vendor' ? 'bg-blue-600' : 'bg-green-600'}>
                          {vendor.type.toUpperCase()}
                        </Badge>
                        <Badge className={
                          vendor.status === 'active' ? 'bg-green-600' :
                          vendor.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                        }>
                          {vendor.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-300">
                        <div>
                          <p><strong>Company:</strong> {vendor.company}</p>
                          <p><strong>Email:</strong> {vendor.email}</p>
                        </div>
                        <div>
                          <p><strong>Phone:</strong> {vendor.phone}</p>
                          <p><strong>Rate:</strong> ${vendor.rate}/hr</p>
                        </div>
                      </div>
                      <p className="text-gray-400 text-sm mt-2">
                        <strong>Services:</strong> {vendor.services}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => startEdit(vendor)}
                        className="border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white"
                      >
                        <Edit3 className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(vendor.id)}
                        className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VendorContractorManager;