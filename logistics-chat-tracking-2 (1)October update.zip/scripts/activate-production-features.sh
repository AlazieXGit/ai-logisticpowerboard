#!/bin/bash
# Production Feature Activation Script
# AI-Xpress Platform - Move Development Features to Production

set -e

echo "🚀 AI-Xpress Platform - Production Feature Activation"
echo "=================================================="

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Check if .env.production exists
if [ ! -f .env.production ]; then
    echo -e "${RED}❌ .env.production not found${NC}"
    echo "Please create .env.production from .env.production template"
    exit 1
fi

echo -e "${YELLOW}📋 Pre-Activation Checklist${NC}"
echo "1. ✓ .env.production exists"

# Backup current .env
if [ -f .env ]; then
    echo "2. 📦 Backing up current .env to .env.backup"
    cp .env .env.backup
fi

# Copy production config
echo "3. 📝 Activating production configuration"
cp .env.production .env

echo ""
echo -e "${GREEN}✅ Feature Activation Status:${NC}"
echo ""

# Check each feature
check_feature() {
    local feature=$1
    local name=$2
    if grep -q "${feature}=true" .env; then
        echo -e "  ✅ ${name}: ${GREEN}ENABLED${NC}"
    else
        echo -e "  ⏸️  ${name}: ${YELLOW}DISABLED${NC}"
    fi
}

check_feature "FEATURE_PNC_BANK" "PNC Bank Integration"
check_feature "FEATURE_WELLS_FARGO" "Wells Fargo Integration"
check_feature "FEATURE_AI_DEV_PLATFORM" "AI Development Platform"
check_feature "FEATURE_SUPER_ADMIN_DEV" "Super Admin Dev Access"
check_feature "FEATURE_MINI_ADMIN_LOGIN" "Minimized Admin Login"
check_feature "FEATURE_COMMUNITY_COMMS" "Community Communications"

echo ""
echo -e "${YELLOW}⚠️  Security Reminders:${NC}"
echo "1. Generate new SECRET_KEY: openssl rand -hex 64"
echo "2. Update PNC_API_KEY with production credentials"
echo "3. Set STRIPE_SECRET_KEY to live key (sk_live_...)"
echo "4. Configure production database credentials"
echo "5. Update CORS_ORIGINS with your domain"

echo ""
echo -e "${GREEN}🔄 Next Steps:${NC}"
echo "1. Update security credentials in .env"
echo "2. Run: docker-compose down && docker-compose up -d"
echo "3. Run: python backend/seed_data.py (if needed)"
echo "4. Test features at: http://localhost:8000/docs"
echo "5. Monitor logs: docker-compose logs -f"

echo ""
echo -e "${GREEN}✅ Production configuration activated!${NC}"
